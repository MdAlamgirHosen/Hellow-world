import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdminComponent } from './admin/admin.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { ManageBlogsComponent } from './manage-blogs/manage-blogs.component';
import { ManageCategoryComponent } from './manage-category/manage-category.component';
import { ManagePagesComponent } from './manage-pages/manage-pages.component';

import { AuthorGuard } from '../author/author.guard';

const routes: Routes = [
  {
    path: 'admin',
        component: AdminComponent,
        canActivate: [AuthorGuard],
        children: [
          {
          path: '',
          children: [
            { path: 'blogs', component: ManageBlogsComponent },
            { path: 'categories', component: ManageCategoryComponent },
            { path: 'pages', component: ManagePagesComponent },
            { path: '', component: AdminDashboardComponent }
          ],
        }
      ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
