import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-blogs',
  templateUrl: './manage-blogs.component.html',
  styleUrls: ['./manage-blogs.component.css']
})
export class ManageBlogsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
