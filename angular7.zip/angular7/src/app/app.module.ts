import { BrowserModule, Title } from '@angular/platform-browser';// Title create for http client module
import { HttpClientModule} from '@angular/common/http'; // for http client module
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { BlogpostModule } from './blogpost/blogpost.module'; //root module theke child module k chiniye dilam
import { CmspageModule } from './cmspage/cmspage.module'; //root module theke chiniye dilam
import { AdminModule } from './admin/admin.module';// for admin module
import { AuthorModule } from './author/author.module';// for author module
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { BannerComponent } from './banner/banner.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    BannerComponent,
    PagenotfoundComponent
  ],
  imports: [
    BrowserModule,
    BlogpostModule,
    CmspageModule,
    HttpClientModule,
    AuthorModule,
    AdminModule,
    AppRoutingModule
  ],
  providers: [Title],// top create Title and show prodivers title input
  bootstrap: [AppComponent]
})
export class AppModule { }
