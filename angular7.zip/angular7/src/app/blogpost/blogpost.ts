export class Blogpost {
    id: number;
    title: string;
    short_desc: string;
    authhor: string;
    image:string;
    Created_at: Date;
}
