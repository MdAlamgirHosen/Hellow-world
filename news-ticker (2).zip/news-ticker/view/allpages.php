<style href="<?php echo PLUGIN_URL.'/news-ticker/asset/css/style.css'; ?>" type="text/css"></style>	
<script src="<?php echo PLUGIN_URL.'/news-ticker/asset/js/jquery.ticker.js'; ?>"></script>

<h2 class="allpage_heading">News ticker er All page text css</h2>

<?php
 echo "I'm here of all page";
?>

<img src="<?php echo PLUGIN_URL.'/news-ticker/asset/img/icon.png'; ?>" alt="not fount images">