<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>add new page</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
	
	
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.16.0/jquery.validate.min.js"></script>


 <script type="text/javascript"> 
   $(function(){
     $("#frmPost").validate({
	    submitHandler:function(){
		  console.log($("#vform").serialize());
		}
	 });
   });
</script>
</head>


<body>
	
<form action="#" method="" id="frmPost">
  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" class="form-control" id="textName" required  name="textName" placeholder="Enter Your Name">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="textEmail" required name="textEmail" placeholder="Enter your email">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" id="textname" required name="textpass" placeholder="Password">
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>


</body>
</html>