<?php
/**
 * @package New ticker
 * @version 1.0
 */
/*
Plugin Name: news ticker
Plugin URI: https://github.com/MdAlamgirHosen/Hellow-world/blob/master/news-ticker.zip
Description: This is updown ticker
Author: Md Alamgir
Author URI: https://github.com/MdAlamgirHosen
Text Domain: news-ticker
Domain Path: /languages/
Version: 1.0
*/

define("PLUGIN_DIR_PATH",plugin_dir_path(__FILE__));
define("PLUGIN_URL",plugins_url());



function ticker_add(){ 

  wp_enqueue_script('jquery');
  wp_enqueue_script( 'ticker_js', plugins_url( '/asset/js/jquery.ticker.js', __FILE__ ), array('jquery'), 1.2, false);
  wp_enqueue_script( 'script', plugins_url( '/asset/js/script.js', __FILE__ ), array('jquery'), 1.2, false);
  wp_enqueue_style( 'ticker_css', plugins_url( '/asset/css/style.css', __FILE__ ));
  
  
  wp_localize_script("script","ajaxurl",admin_url("admin_ajax.php"));
  
}
add_action('init', 'ticker_add');


	
function ticker_html_markup($atts){
	extract( shortcode_atts(array(
	 'id'=> 'tickerid',
	 'category'=> '',
	 'count'=> '5',
	 'category_slug'=> 'category_ID',
	 'speed'=> '3000',
	 'color'=> '#000',
	 'pading'=> '5px',
	 'fsize'=> '24px',
	),
	$atts, 'projects'
	) );
	$q = new WP_Query(
	array('post_per_page' => $count, 'post_type' => 'post', $category_slug => $category));
	
	$list = '<script type="text/javascript"> jQuery(document).ready(function(){

			jQuery("#ticker_news'.$id.'").ticker({
				itemSpeed: '.$speed.',
				});
			});
			</script>
			
<div id="ticker_news'.$id.'" class="ticker">
  <strong style="background-color:'.$color.'; padding:'.$pading.'">Leatest News:</strong>
  <ul>';
  
    while($q->have_posts()) : $q->the_post();
	 $idd = get_the_ID();
	 $list .= '<li><a style="font-size:'.$fsize.'" href="<?php the_permalink(); ?>">'.get_the_title().'</a></li>';
	 
     endwhile;
	 $list.= '</ul>
</div>';
   wp_reset_query();
	return $list;
}
add_shortcode('tickerupdown', 'ticker_html_markup');



/*
// setting er betor menu dite chaile

add_action( 'admin_menu', 'my_plugin_menu' );

function my_plugin_menu() {
	add_options_page( 
		'My Options',
		'news-ticker',
		'manage_options',
		'my-plugin.php',
		'my_plugin_page'
	);
}


function my_plugin_page(){
	echo"Md Alamgir Here";
	?> <h1> He say I love you</h1>  <?php
}

*/

// for dashbord menu 

add_action( 'admin_menu', 'my_plugin_menus' );

function my_plugin_menus() {
	add_menu_page( 
		"My Options",//page title
		"News-Ticker",//menu title
		"manage_options", //admin level
		"my-plugin",//page slug~parent slug
		"my_plugin_pages",//call backfunction
		"dashicons-share-alt",//icon
		 //plugins_url( '/asset/img/icon.png', __FILE__ ),
        30
	);
	add_submenu_page( 
		"my-plugin",//parent slug
		"All pages",//page title
		"All pages",//menu title
		"manage_options",//user level
		"my-plugin", //menu slug
		"my_plugin_pages"//call backfunction
	);
	
	add_submenu_page( 
		"my-plugin",//parent slug
		"Add New",//page title
		"Add New",//menu title
		"manage_options",//user level
		"All pages", //menu slug
		"my_plugin_pages2"//call backfunction
	);
}


function my_plugin_pages(){
	include_once PLUGIN_DIR_PATH."/view/allpages.php";
}

function my_plugin_pages2(){
	include_once PLUGIN_DIR_PATH."/view/addnew.php";
}


//table generating code
function custom_plugin_tables(){
 global $wpdb;
 require_once(ABSPATH . 'wp-admin/includes/upgrade.php'); 
 
 if(count($wpdb->get_var('SHOW TABLES LIKE "wp_table_name"')) ==0 ){
	$sql_query_to_create_table = "CREATE TABLE `wp_table_name` (
		 `id` int(11) NOT NULL AUTO_INCREMENT,
		 `name` varchar(255) DEFAULT NULL,
		 `phone` varchar(255) DEFAULT NULL,
		 `email` varchar(255) DEFAULT NULL,
		 `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		 PRIMARY KEY (`id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8";
	
  dbDelta($sql_query_to_create_table);	
 }
}
register_activation_hook( __FILE__, 'custom_plugin_tables' );


//deactivation mysql table code
function deactive_table(){
	global $wpdb;
	$wpdb->query("DROP table IF Exists wp_table_name");
	
	$the_post_id = get_option("custom_plugin_page_id");
	if(!empty($the_post_id)){
		wp_delete_post($the_post_id,true);
	}
	
}
register_deactivation_hook( __FILE__, "deactive_table" );

// uninstall mysql code or delete page form the list
function uninstall_table(){
	global $wpdb;
	$wpdb->query("DROP table IF Exists wp_table_name");
	$the_post_id = get_option("custom_plugin_page_id");
	if(!empty($the_post_id)){
		wp_delete_post($the_post_id,true);
	}
}
register_uninstall_hook( __FILE__, "uninstall_table" );


// for page create code
function create_page(){
	$page = array();
	$page['post_title'] = "custom_plugin page title";
	$page['post_content'] = "custom_plugin page content";
	$page['post_status'] = "publish";
	$page['post_slug'] = "custom_plugin";
	$page['post_type'] = "page";
	
	$wp_option = wp_insert_post($page); //post id and return value
	add_option("custom_plugin_page_id",$wp_option);
	}
register_activation_hook( __FILE__, 'create_page' );




//custom js header a deyar code:



















?>