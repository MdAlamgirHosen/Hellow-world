<?php

/**
 * Fired during plugin activation
 *
 * @link       https://alamgir.com
 * @since      1.0.0
 *
 * @package    Movie_Rating
 * @subpackage Movie_Rating/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Movie_Rating
 * @subpackage Movie_Rating/includes
 * @author     Alamgir <alamgirwordpress1@gmail.com>
 */
class Movie_Rating_Activator {

	private $tables;
	public function __construct($tables_object){
	   $this->tables = $tables_object;
	}

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public function activate() {

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		global $wpdb;
		if(count($wpdb->get_var("show tables like'".$this->tables->movieratingtable()."'")) == 0){
		// need to write table generating code..
			$slqQuery = 'CREATE TABLE `'.$this->tables->movieratingtable().'` (
		 `id` int(11) NOT NULL AUTO_INCREMENT,
		 `name` varchar(255) DEFAULT NULL,
		 `email` varchar(255) DEFAULT NULL,
		 `phone_no` varchar(15) DEFAULT NULL,
		 PRIMARY KEY (`id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4';
		
		dbDelta($slqQuery);
		}                
			
	}
	

}
