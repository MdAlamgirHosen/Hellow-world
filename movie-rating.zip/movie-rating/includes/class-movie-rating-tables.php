<?php

/**
 * This file create for all dynamic tables
 *
 * @link       https://alamgir.com
 * @since      1.0.0
 *
 * @package    Movie_Rating
 * @subpackage Movie_Rating/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Movie_Rating
 * @subpackage Movie_Rating/includes
 * @author     Alamgir <alamgirwordpress1@gmail.com>
 */
class Movie_Rating_Tables {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	
	public function movieratingtable(){
		global $wpdb;
		return $wpdb->prefix."movie_rating_table"; // wp_movie_rating_table	
	}

}
