<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://alamgir.com
 * @since      1.0.0
 *
 * @package    Movie_Rating
 * @subpackage Movie_Rating/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Movie_Rating
 * @subpackage Movie_Rating/includes
 * @author     Alamgir <alamgirwordpress1@gmail.com>
 */
class Movie_Rating_Deactivator {
	private $tables;
	public function __construct($tables_object){
	   $this->tables = $tables_object;
	}
	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public function deactivate() {
		// drop table code
		global $wpdb;
		$wpdb->query("Drop table IF EXISTS ".$this->tables->movieratingtable());
	}


}
