<?php 
/*
Template Name: About Us
*/

?>
<?php get_header(); ?>

<?php while ( have_posts() ): the_post(); ?>
		

					<?php the_content(); ?>

			<?php if ( ot_get_option('page-comments') == 'on' ) { comments_template('/comments.php',true); } ?>
			
		<?php endwhile; ?>

<div class="gfmw_full_contianer pagepadding_content_area2">
	<div class="gfwm_center blogpost">
		<div class="wt_inner">
		
		  <section class="wta_content_area"> 
		    
 <div class="wta_down_content_area_start"> 
     <h2 class="about_top_title">About</h2>
       <div class="wta_top_img"> 
		  <img src="<?php echo get_template_directory_uri();?>/images/lake-2-cropped.png" alt=""/>
		</div> 
		<p class="wta_top_content">
<strong>Thompson-Dewitt Financial Group (TD CAP) </strong><br/><br/>

TD CAP is a leading International Commercial Real Estate Investment Firm, and Financial Advisory firm. Our businesses include real estate financing, private equity, rescue financing, financial advisory and restructuring, and alternative financing.    TD CAP Advisory Services includes restructuring and reorganization of Debtor In Possession or troubled companies, restructuring of real estate debt, corporate acquisitions, joint ventures, major project consulting services. <br/><br/>

Our team members are of the highest caliber with multi-discipline backgrounds and expertise in real estate, private equity, leverage finance, restructuring of debt and equity within the corporate and real estate environments, insurance, manufacturing, banking, investment banking, construction, medicine and other disciplines. <br/><br/>

Our activities are global with active environments in North America, Mexico, Central and South America, various Caribbean nations, Europe, Australia and Asia. <br/><br/>

Our investors and clients benefit from our financing capabilities, restructuring of debt and equity, and advisory capabilities collectively creating a strong financial environment that adds value to our financings and assignments.


</p><br/><br/>
		
		
		<p class="wta_top_content">
<strong>Why TD CAP</strong><br/>
<img src="<?php echo get_template_directory_uri();?>/images/abouts.jpg" alt=""/>TD CAP was created through the merging of three highly successful international companies and our Parent TD Financial Group with disciplines in Real Estate Finance, Private Equity, Organizational and Debt and Equity Restructuring, Corporate and Real Estate Advisory Services. Our team is committed to serve our clients and has committed our own funds and have aligned ourselves with our investment partners to accomplish each task we are engaged with. We seek long-term relationships and operate with integrity and make our money the old-fashioned way with hard work, responsibility to our clients and dedication to our work. <br/><br/>

Since 2006, our Real Estate Equity and Debt business has grown globally with successful business relationships in twenty-five countries and have provided effective advisory solutions to all clientele. <br/><br/>

We represent a substantial pool of capital for investment in a wide spectrum of projects and seek to position ourselves, globally, for both the benefit of our clients and investors<br/><br/>

Internationally, we specialize in the financing of real estate projects, portfolio analysis and strategic advisory, due diligence confidentially and with professionalism. Our expert knowledge and our ability to handle complex transactions coupled with our capability to fund loans, and create real estate syndications using our investor funds and our international network of investors maximizes our clients ability to achieve success.




</p>
	 </div>
	 

		  </section>
		  




		<div class="wta_sidebar_area">
		   <h2 class="about_top_title_side">Our Services</h2>
		 <section class="wta_content_area"> 
		     <div class="wta_five_area10"> 
			   <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			   <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			  <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			  <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			   <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			   <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			   <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
		  </section>
		</div>



        </div>
     </div>
</div>

<?php get_footer(); ?>











