<?php 
/*
Template Name: Recently Closed
*/

?>
<?php get_header(); ?>


<?php get_template_part('ltc/pagetitle'); ?>

<div class="gfmw_full_contianer singlepost">
	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">

	<section class="postlist pagepostnse rencet_closes">
		
		
<div class="gw_inner padding_sets">
	

		<?php while ( have_posts() ): the_post(); ?>
		

					<?php the_content(); ?>

			<?php if ( ot_get_option('page-comments') == 'on' ) { comments_template('/comments.php',true); } ?>
			
		<?php endwhile; ?>
<div class="galleryglobal">	
<?php 

 if ( function_exists( 'ot_get_option' ) ) {
	   $images = explode( ',', get_post_meta( get_the_ID(), 'ltr_gallery', true ) );
	  if ( !empty( $images ) ) {
		foreach( $images as $id ) {
		  if ( !empty( $id ) ) {
			$full_img_src = wp_get_attachment_image_src( $id, 'thumb-full' );
            $thumb_img_src = wp_get_attachment_image_src( $id,'thumb-large' );
			echo '
			<div class="galleryIlistRb"><a href="'.$full_img_src[0].'" rel="lightbox"><img data-thumb="'. $thumb_img_src[0].'" src="'.$thumb_img_src[0].'"/></a></div>
			';
		  }
		}
	  }
	}
	

?>
</div>		
	</div>	
	
	</section>


	</div>
</div>
</div>

<?php get_footer(); ?>