<!DOCTYPE html> 
<html class="no-js" <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title><?php if(is_front_page()) { echo bloginfo("name");  }elseif ( is_home() ) { echo bloginfo("name");} else { echo lt_page_title();  } ?>
	</title>
    <?php get_template_part('ltc/metatag'); ?>
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
	
	
	<?php wp_head(); ?>
	
<?php if ( ot_get_option( 'gogle_verify' )): ?>
<?php echo ot_get_option('gogle_verify'); ?>
<?php endif; ?>
<script>
function openCity(cityName) {
    var i;
    var x = document.getElementsByClassName("city");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    document.getElementById(cityName).style.display = "block";  
}
</script>

</head>

<body <?php body_class(); ?>>

<!--------------------Head Section------------------------>
<header class="wta_main_header_area">

<div class="gfmw_main wta_somethign_header_top">
 <div class="gfmw_header"> 
     <div class="wta_header_top"> 
	 
		   <div class="wta_left_site_area"> 
			<ul class="wta_right_nav">
			  	<li class="active"><a href="http://localhost/woocommercewebsite/wordpress/nicon/">NICON</a></li>
			  	<li><a href="http://localhost/woocommercewebsite/wordpress/pentax/">PENTAX</a></li>
			 	<li><a href="http://localhost/woocommercewebsite/wordpress/look-book/">AF-ON</a></li>
			  </ul>
		   </div>
	    
	      <div class="wta_right_site_area"> 
			 <ul class="social_menu_area">
				<li><a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li>
				<li><a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a></li>
				<li><a href="https://www.google-plus.com/"><i class="fa fa-google-plus"></i></a></li>
				<li><a href="https://www.linked.com/"><i class="fa fa-linkedin"></i></a></li>
				<li><a href="https://www.google.com/"><i class="fa fa-pinterest"></i></a></li>
				<li><a href="https://www.google.com/"><i class="fa fa-instagram"></i></a></li>
			 </ul>
	      </div>
	   </div>
	 </div>
</div>	


<div class="gfmw_main wta_somethign_header_middle">
 <div class="gfmw_header"> 
     <div class="wta_header_top"> 
	    
	 	<div class="gfmw_logo_area wta_right_logo"">
			<?php if ( ot_get_option('custom-logo')): ?>
				<a href=" <?php echo site_url(); ?> "><img src="<?php echo ot_get_option('custom-logo'); ?>" class="gfmw_logo"></a>
				
				<?php else: ?>
				<a href="<?php echo site_url(); ?>"><img src="<?php bloginfo('template_url'); ?>/images/logo.png" class="gfmw_logo"></a>
				
				<?php endif; ?>
				
		   </div>
	 </div>
</div>	
 
  <div class="gfmw_menuarea">
	<div class="gfmw_center menu_area_gw">
       <div class="gfmw_menu">
			<div class="mob_menus_gfmw">
			<p> Go to</p>
			<div class="menu_icons_mob"></div>
			</div>
			<?php wp_nav_menu(array('theme_location'=>'header','menu_class'=>'gfmw_nav','container'=>'','gfmw_menu' => '','fallback_cb'=> false)); ?>
			<div class="wta_search"> 
		     	<a href="#"><i class="fa fa-search" aria-hidden="true"></i></a>
			</div>
	   </div>
	</div>
 </div>
 
</header> 



