<?php

/*  Initialize the options before anything else. 
/* ------------------------------------ */
add_action( 'admin_init', 'custom_theme_options', 1 );


/*  Build the custom settings & update OptionTree.
/* ------------------------------------ */
function custom_theme_options() {
	
	// Get a copy of the saved settings array.
	$saved_settings = get_option( 'option_tree_settings', array() );

	// Custom settings array that will eventually be passed to the OptionTree Settings API Class.
	$custom_settings = array(

/*  Help pages
/* ------------------------------------ */	
	'contextual_help' => array(
      'content'       => array( 
        array(
          'id'        => 'general_help',
          'title'     => 'Documentation',
          'content'   => '
			<h1>Gift For Men Women</h1>
			
		'
        )
      )
    ),
	
/*  Admin panel sections
/* ------------------------------------ */	
	'sections'        => array(
		array(
			'id'		=> 'general',
			'title'		=> 'General'
		),
		
		array(
			'id'		=> 'header',
			'title'		=> 'Header'
		),
		array(
			'id'		=> 'footer',
			'title'		=> 'Footer'
		),
		array(
			'id'		=> 'slider',
			'title'		=> 'Slider'
		),
		array(
			'id'		=> 'blockcontent',
			'title'		=> 'Block Content'
		),
		array(
			'id'		=> 'homepage',
			'title'		=> 'Home Page'
		),
		array(
			'id'		=> 'page1',
			'title'		=> 'Page 1'
		),
		array(
			'id'		=> 'page2',
			'title'		=> 'Page 2'
		),
		array(
			'id'		=> 'page3',
			'title'		=> 'Page 3'
		),
		array(
			'id'		=> 'page4',
			'title'		=> 'Page 4'
		),
		array(
			'id'		=> 'page5',
			'title'		=> 'Page 5'
		),
		array(
			'id'		=> 'page6',
			'title'		=> 'Request Quote'
		),
		array(
			'id'		=> 'mainpage',
			'title'		=> 'All Pages'
		),
		array(
			'id'		=> 'sitecontent',
			'title'		=> 'Site Content'
		),
		array(
			'id'		=> 'blog',
			'title'		=> 'Blog'
		),
		array(
			'id'		=> 'layout',
			'title'		=> 'Layout'
		),
		array(
			'id'		=> 'sidebars',
			'title'		=> 'Sidebars'
		),
		array(
			'id'		=> 'social-links',
			'title'		=> 'Social Links'
		),
		array(
			'id'		=> 'styling',
			'title'		=> 'Styling'
		),
		
	),
	
/*  Theme options
/* ------------------------------------ */
	'settings'        => array(
		
		// General: Responsive Layout
		/*array(
			'id'		=> 'responsive',
			'label'		=> 'Responsive Layout',
			'desc'		=> 'Mobile and tablet optimizations [ <strong>responsive.css</strong> ]',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'general'
		),*/
		// General: Google Site Verification
		array(
			'id'		=> 'gogle_verify',
			'label'		=> 'Google Site Verification Code',
			'desc'		=> 'Enter your site verification code ',
			'type'		=> 'textarea',
			'section'	=> 'general'
		),
		array(
			'id'		=> 'first_look',
			'label'		=> 'First Look Code Area',
			'desc'		=> 'Enter your First Look code ',
			'type'		=> 'textarea',
			'section'	=> 'blockcontent'
		),
		array(
			'id'		=> 'clients_h',
			'label'		=> 'Our Clients Code Area',
			'desc'		=> 'Enter your Our Clients US code ',
			'type'		=> 'textarea',
			'section'	=> 'blockcontent'
		),
		array(
			'id'		=> 'short_service',
			'label'		=> 'Short Services Code Area',
			'desc'		=> 'Enter your Short Services code ',
			'type'		=> 'textarea',
			'section'	=> 'blockcontent'
		),
		array(
			'id'		=> 'short_about',
			'label'		=> 'About US Code Area',
			'desc'		=> 'Enter your About US code ',
			'type'		=> 'textarea',
			'section'	=> 'blockcontent'
		),
		array(
			'id'		=> 'recent_work',
			'label'		=> 'Recent Work Code Area',
			'desc'		=> 'Enter your Recent Work code ',
			'type'		=> 'textarea',
			'section'	=> 'blockcontent'
		),array(
			'id'		=> 'seo_content_home',
			'label'		=> 'SEO Content Part Code Area',
			'desc'		=> 'Enter your SEO Content Part code ',
			'type'		=> 'textarea',
			'section'	=> 'blockcontent'
		),array(
			'id'		=> 'responsive_design',
			'label'		=> 'Responsive Part Code Area',
			'desc'		=> 'Enter your Responsive Part code ',
			'type'		=> 'textarea',
			'section'	=> 'blockcontent'
		),array(
			'id'		=> 'design_process',
			'label'		=> 'Design Process Code Area',
			'desc'		=> 'Enter your Design Process code ',
			'type'		=> 'textarea',
			'section'	=> 'blockcontent'
		),
		array(
			'id'		=> 'time_to_start',
			'label'		=> 'Time To Start Code Area',
			'desc'		=> 'Enter your Time To Start code ',
			'type'		=> 'textarea',
			'section'	=> 'blockcontent'
		),
		array(
			'id'		=> 'why_choose_us',
			'label'		=> 'Why Choose US Code Area',
			'desc'		=> 'Enter your Why Choose US code ',
			'type'		=> 'textarea',
			'section'	=> 'blockcontent'
		),
		
		array(
			'id'		=> 'ready_call_action',
			'label'		=> 'Ready Call Action Code Area',
			'desc'		=> 'Enter your Ready Call Action code ',
			'type'		=> 'textarea',
			'section'	=> 'blockcontent'
		),
		array(
			'id'		=> 'client_testimonial',
			'label'		=> 'Testimonial Code Area',
			'desc'		=> 'Enter your Testimonial code ',
			'type'		=> 'textarea',
			'section'	=> 'blockcontent'
		),
		// General: Sidebar Top Boxes
		/*array(
			'id'		=> 'sidebar-top',
			'label'		=> 'Sidebar Top Boxes',
			'desc'		=> 'Boxes at the top of the sidebars',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'general'
		),*/
		// General: Mobile Sidebar
		/*array(
			'id'		=> 'mobile-sidebar-hide',
			'label'		=> 'Mobile Sidebar Content',
			'desc'		=> 'Hide sidebar content on low-resolution mobile devices (320px)',
			'type'		=> 'radio',
			'std'		=> '1',
			'section'	=> 'general',
			'choices'	=> array(
				array( 
					'value' => '1',
					'label' => 'Show sidebars'
				),
				array( 
					'value' => 's1',
					'label' => 'Hide primary sidebar'
				),
				array( 
					'value' => 's2',
					'label' => 'Hide secondary sidebar'
				),
				array( 
					'value' => 's1-s2',
					'label' => 'Hide both sidebars'
				)
			)
		),*/
		// General: Favicon
		array(
			'id'		=> 'favicon',
			'label'		=> 'Favicon',
			'desc'		=> 'Upload a 16x16px Png/Gif image that will be your favicon',
			'type'		=> 'upload',
			'section'	=> 'general'
		),
		// General: RSS Feed
		array(
			'id'		=> 'rss-feed',
			'label'		=> 'FeedBurner URL',
			'desc'		=> 'Enter your full FeedBurner URL (or any other preferred feed URL) if you wish to use FeedBurner over the standard WordPress feed e.g. http://feeds.feedburner.com/yoururlhere ',
			'type'		=> 'text',
			'section'	=> 'general'
		),
		// General: Comments
		array(
			'id'		=> 'page-comments',
			'label'		=> 'Page Comments',
			'desc'		=> 'Comments on pages',
			'std'		=> 'off',
			'type'		=> 'on-off',
			'section'	=> 'general'
		),
		// General: Recommended Plugins
		array(
			'id'		=> 'recommended-plugins',
			'label'		=> 'Recommended Plugins',
			'desc'		=> 'Enable or disable the recommended plugins notice',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'general'
		),
		// General: Recommended Plugins
		array(
			'id'		=> 'scroll_totop',
			'label'		=> 'Scroll To Top Button',
			'desc'		=> 'Enable or disable Scroll To Top Button',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'general'
		),
		// Blog: Heading
		array(
			'id'		=> 'blog-heading',
			'label'		=> 'Heading',
			'desc'		=> 'Your blog heading',
			'type'		=> 'text',
			'section'	=> 'blog'
		),
		// Blog: Subheading
		array(
			'id'		=> 'blog-subheading',
			'label'		=> 'Subheading',
			'desc'		=> 'Your blog subheading',
			'type'		=> 'text',
			'section'	=> 'blog'
		),
		// Blog: Excerpt Length
		array(
			'id'			=> 'excerpt-length',
			'label'			=> 'Excerpt Length',
			'desc'			=> 'Max number of words',
			'std'			=> '34',
			'type'			=> 'numeric-slider',
			'section'		=> 'blog',
			'min_max_step'	=> '0,100,1'
		),
		// Blog: Featured Posts
		array(
			'id'		=> 'featured-posts-include',
			'label'		=> 'Featured Posts',
			'desc'		=> 'To show featured posts in the slider AND the content below<br /><i>Usually not recommended</i>',
			'type'		=> 'checkbox',
			'section'	=> 'blog',
			'choices'	=> array(
				array( 
					'value' => '1',
					'label' => 'Include featured posts in content area'
				)
			)
		),
		// Blog: Featured Category
		array(
			'id'		=> 'featured-category',
			'label'		=> 'Featured Category',
			'desc'		=> 'By not selecting a category, it will show your latest post(s) from all categories',
			'type'		=> 'category-select',
			'section'	=> 'blog'
		),
		// Blog: Featured Category Count
		array(
			'id'			=> 'featured-posts-count',
			'label'			=> 'Featured Post Count',
			'desc'			=> 'Max number of featured posts to display. <br /><i>Set to 1 and it will show it without any slider script</i><br /><i>Set it to 0 to disable</i>',
			'std'			=> '1',
			'type'			=> 'numeric-slider',
			'section'		=> 'blog',
			'min_max_step'	=> '0,10,1'
		),
		// Blog: Thumbnail Placeholder
		array(
			'id'		=> 'placeholder',
			'label'		=> 'Thumbnail Placeholder',
			'desc'		=> 'Show featured image placeholders if no featured image is set',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'blog'
		),
		// Blog: Comment Count
		array(
			'id'		=> 'comment-count',
			'label'		=> 'Thumbnail Comment Count',
			'desc'		=> 'Comment count on thumbnails',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'blog'
		),
		// Blog: Single - Authorbox
		array(
			'id'		=> 'author-bio',
			'label'		=> 'Single &mdash; Author Bio',
			'desc'		=> 'Shows post author description, if it exists',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'blog'
		),
		// Blog: Single - Related Posts
		array(
			'id'		=> 'related-posts',
			'label'		=> 'Single &mdash; Related Posts',
			'desc'		=> 'Shows randomized related articles below the post',
			'std'		=> 'categories',
			'type'		=> 'radio',
			'section'	=> 'blog',
			'choices'	=> array(
				array( 
					'value' => '1',
					'label' => 'Disable'
				),
				array( 
					'value' => 'categories',
					'label' => 'Related by categories'
				),
				array( 
					'value' => 'tags',
					'label' => 'Related by tags'
				)
			)
		),
		// Blog: Single - Post Navigation Location
		array(
			'id'		=> 'post-nav',
			'label'		=> 'Single &mdash; Post Navigation',
			'desc'		=> 'Shows links to the next and previous article',
			'std'		=> 's1',
			'type'		=> 'radio',
			'section'	=> 'blog',
			'choices'	=> array(
				array( 
					'value' => '1',
					'label' => 'Disable'
				),
				array( 
					'value' => 's1',
					'label' => 'Sidebar Primary'
				),
				array( 
					'value' => 's2',
					'label' => 'Sidebar Secondary'
				),
				array( 
					'value' => 'content',
					'label' => 'Below content'
				)
			)
		),
		// Header: Custom Logo
		array(
			'id'		=> 'custom-logo',
			'label'		=> 'Custom Logo',
			'desc'		=> 'Upload your custom logo image. Set logo max-height in styling options.',
			'type'		=> 'upload',
			'section'	=> 'header'
		),
		// Header: Top Phone Number
		array(
			'id'		=> 'header_rightarea',
			'label'		=> 'Header Phone Number and Call Action',
			'desc'		=> 'Replace Header Phone Number and Call Action',
			'type'		=> 'textarea',
			'section'	=> 'header'
		),/*
		// Header: Site Description
		array(
			'id'		=> 'site-description',
			'label'		=> 'Site Description',
			'desc'		=> 'The description that appears next to your logo',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'header'
		),
		// Header: Top Call Action and Short menu
		array(
			'id'		=> 'heaadercall',
			'label'		=> 'Top Call Action and Short menu',
			'desc'		=> 'Header - Phone number, blog, testimonial button',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'header'
		),*/
		// Header: Top Phone Number
		array(
			'id'		=> 'headerphone',
			'label'		=> 'Header Phone Number',
			'desc'		=> 'Replace Header Top Phone Number',
			'type'		=> 'text',
			'section'	=> 'header'
		),
		// Header: Top Email
		array(
			'id'		=> 'headerTopEmail',
			'label'		=> 'Header Email',
			'desc'		=> 'Replace Header Email',
			'type'		=> 'text',
			'section'	=> 'header'
		),
		// Footer: Widget Columns
		/*array(
			'id'		=> 'footer-widgets',
			'label'		=> 'Footer Widget Columns',
			'desc'		=> 'Select columns to enable footer widgets<br /><i>Recommended number: 5</i>',
			'std'		=> '0',
			'type'		=> 'radio-image',
			'section'	=> 'footer',
			'class'		=> '',
			'choices'	=> array(
				array(
					'value'		=> '0',
					'label'		=> 'Disable',
					'src'		=> get_template_directory_uri() . '/functions/images/layout-off.png'
				),
				array(
					'value'		=> '1',
					'label'		=> '1 Column',
					'src'		=> get_template_directory_uri() . '/functions/images/footer-widgets-1.png'
				),
				array(
					'value'		=> '2',
					'label'		=> '2 Columns',
					'src'		=> get_template_directory_uri() . '/functions/images/footer-widgets-2.png'
				),
				array(
					'value'		=> '3',
					'label'		=> '3 Columns',
					'src'		=> get_template_directory_uri() . '/functions/images/footer-widgets-3.png'
				),
				array(
					'value'		=> '4',
					'label'		=> '4 Columns',
					'src'		=> get_template_directory_uri() . '/functions/images/footer-widgets-3.png'
				),
				array(
					'value'		=> '5',
					'label'		=> '5 Columns',
					'src'		=> get_template_directory_uri() . '/functions/images/footer-widgets-4.png'
				)
			)
		),
		// Footer: Custom Logo
		array(
			'id'		=> 'footer-logo',
			'label'		=> 'Footer Logo',
			'desc'		=> 'Upload your custom logo image',
			'type'		=> 'upload',
			'section'	=> 'footer'
		),*/
		// Footer: Title 
		array(
			'id'		=> 'fotitles',
			'label'		=> 'Footer Title ',
			'desc'		=> 'Replace Footer Title',
			'type'		=> 'text',
			'section'	=> 'footer'
		),
		// Footer: Footer Phone
		array(
			'id'		=> 'footerphone',
			'label'		=> 'Footer Phone Number',
			'desc'		=> 'Replace footer phone number',
			'type'		=> 'text',
			'section'	=> 'footer'
		),
		// Footer: Footer Email
		array(
			'id'		=> 'footerEmail',
			'label'		=> 'Footer Email ',
			'desc'		=> 'Replace footer Email ',
			'type'		=> 'text',
			'section'	=> 'footer'
		),
		// Footer: Footer Address
		array(
			'id'		=> 'fotoerAddress',
			'label'		=> 'Footer Address',
			'desc'		=> 'Replace footer Address ',
			'type'		=> 'text',
			'section'	=> 'footer'
		),
		/*
		// Footer: copyrighttext
		array(
			'id'		=> 'copyrighttext',
			'label'		=> 'Copyright Text',
			'desc'		=> 'Replace the footer copyright top text',
			'type'		=> 'text',
			'section'	=> 'footer'
		),
		// Footer: Copyright
		array(
			'id'		=> 'copyright',
			'label'		=> 'Footer Copyright',
			'desc'		=> 'Replace the footer copyright text',
			'type'		=> 'text',
			'section'	=> 'footer'
		),*/
		
		// Footer: Facebook Link
		array(
			'id'		=> 'fblink',
			'label'		=> 'Facebook Link',
			'desc'		=> 'Replace Facebook Link',
			'type'		=> 'text',
			'section'	=> 'footer'
		),
		// Footer: Twitter Link
		array(
			'id'		=> 'twlink',
			'label'		=> 'Twitter Link',
			'desc'		=> 'Replace Twitter Link',
			'type'		=> 'text',
			'section'	=> 'footer'
		),
		// Footer: Google+ Link
		array(
			'id'		=> 'pinterestnyc',
			'label'		=> 'Pinterest Link',
			'desc'		=> 'Replace Pinterest Link',
			'type'		=> 'text',
			'section'	=> 'footer'
		),
		// Footer: linkedin Link
		array(
			'id'		=> 'yelpnyc',
			'label'		=> 'Yelp Link',
			'desc'		=> 'Replace Yelp Link',
			'type'		=> 'text',
			'section'	=> 'footer'
		),
		// Footer: copyrighttext
		array(
			'id'		=> 'copyrighttext',
			'label'		=> 'Copyright Text',
			'desc'		=> 'Replace the footer copyright top text',
			'type'		=> 'text',
			'section'	=> 'footer'
		),
		// Footer: Copyright
		array(
			'id'		=> 'copyright',
			'label'		=> 'Footer Domain',
			'desc'		=> 'Copy Right Domain',
			'type'		=> 'text',
			'section'	=> 'footer'
		),
		/*
		array(
			'id'		=> 'now_hiringfooter',
			'label'		=> 'Now Hiring Footer',
			'desc'		=> 'Edit Now Hiring Footer',
			'type'		=> 'textarea',
			'section'	=> 'footer'
		),*/
		// Slider: Custom Image
		array(
			'id'		=> 'slider-image-1',
			'label'		=> 'Slider Image 1',
			'desc'		=> 'Upload first slider image preferred size 2000x631px',
			'type'		=> 'upload',
			'section'	=> 'slider'
		),
		// Slider: Custom Image
		array(
			'id'		=> 'slider-image-2',
			'label'		=> 'Slider Image 2',
			'desc'		=> 'Upload second slider image preferred size 2000x631px',
			'type'		=> 'upload',
			'section'	=> 'slider'
		),
		// Slider: Custom Image
		array(
			'id'		=> 'slider-image-3',
			'label'		=> 'Slider Image 3',
			'desc'		=> 'Upload third slider image preferred size 2000x631px',
			'type'		=> 'upload',
			'section'	=> 'slider'
		),
		// Slider: Custom Image
		array(
			'id'		=> 'slider-image-4',
			'label'		=> 'Slider Image 4',
			'desc'		=> 'Upload fourth slider image preferred size 2000x631px',
			'type'		=> 'upload',
			'section'	=> 'slider'
		),
		// Slider: Custom Image
		array(
			'id'		=> 'slider-image-5',
			'label'		=> 'Slider Image 5',
			'desc'		=> 'Upload five slider image preferred size 2000x631px',
			'type'		=> 'upload',
			'section'	=> 'slider'
		),
		
		// Home Page: Slider on/off
		array(
			'id'		=> 'slider_home',
			'label'		=> 'Slider ON/OFF',
			'desc'		=> 'Slider On or Off for home page ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'homepage'
		),
		// Home Page: See our Work  on/off
		array(
			'id'		=> 'seeourwork_home',
			'label'		=> 'Home Page See Our Work Section',
			'desc'		=> 'Home see our work section ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'homepage'
		),
		// Home Page: Home Page 
		array(
			'id'		=> 'service_home_p',
			'label'		=> 'Home Page  Services Section',
			'desc'		=> 'Home Page  Services ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'homepage'
		),
		// Home Page: Home Page 
		array(
			'id'		=> 'client_short_h',
			'label'		=> 'Home Page Our Clients',
			'desc'		=> 'Home Page  Our Clients ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'homepage'
		),
		// Home Page: Home Page 
		array(
			'id'		=> 'about_home_p',
			'label'		=> 'Home Page About US',
			'desc'		=> 'Home Page  About US ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'homepage'
		),
		// Home Page: Home Page Responsive Content
		array(
			'id'		=> 'seo_con_home',
			'label'		=> 'Home Page SEO Content',
			'desc'		=> 'Home Page SEO Content / Details  ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'homepage'
		),
		array(
			'id'		=> 'responsive_home',
			'label'		=> 'Home Page Responsive Content',
			'desc'		=> 'Home Page Responsive Content / Details about responsive ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'homepage'
		),
		// Home Page: Home Page Start Today Section
		array(
			'id'		=> 'start_home',
			'label'		=> 'Home Page Start Today Section',
			'desc'		=> 'Home Page Start Today Section, its time to start today ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'homepage'
		),
		// Home Page: Home Page Recent Work Section
		array(
			'id'		=> 'recent_home',
			'label'		=> 'Home Page Recent Work Section',
			'desc'		=> 'Home Page Recent Work Section ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'homepage'
		),
		// Home Page: Home Page Why Us Section
		array(
			'id'		=> 'whyus_home',
			'label'		=> 'Home Page Why Us Section',
			'desc'		=> 'Home Page Why Us Section ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'homepage'
		),
		// Home Page: Design Process Section
		array(
			'id'		=> 'designpro_home',
			'label'		=> 'Design Process Section',
			'desc'		=> 'Design Process Section ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'homepage'
		),
		// Home Page: Testimonial Section
		array(
			'id'		=> 'testimonial_home',
			'label'		=> 'Testimonial Section',
			'desc'		=> 'Testimonial Section ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'homepage'
		),
		// Home Page: Home Page Ready Get Started Section
		array(
			'id'		=> 'ready_home',
			'label'		=> 'Home Page Ready Get Started Section',
			'desc'		=> 'Home Page Ready Get Started Section ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'homepage'
		),
		
		// Page 1: 
		array(
			'id'		=> 'page1_customcontent',
			'label'		=> 'Custom Content',
			'desc'		=> '',
			'type'		=> 'textarea',
			'section'	=> 'page1'
		),
		// Page 1: 
		array(
			'id'		=> 'client_short_h1',
			'label'		=> 'Our Clients Content',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page1'
		),
		// Page 1: 
		array(
			'id'		=> 'service_home_p1',
			'label'		=> 'Service Short Content',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page1'
		),
		// Page 1: 
		array(
			'id'		=> 'about_home_p1',
			'label'		=> 'About Short Content',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page1'
		),
		// Page 1: 
		array(
			'id'		=> 'page1_firstlook',
			'label'		=> 'First Look Content',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page1'
		),
		// Page 1:  
		array(
			'id'		=> 'page1_recentwork',
			'label'		=> 'Recent Work ',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page1'
		),
		// Page 1: 
		array(
			'id'		=> 'page1_responsive',
			'label'		=> 'Responsive Design',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page1'
		),
		// Page 1: 
		array(
			'id'		=> 'page1_designprocess',
			'label'		=> 'Design Process',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page1'
		),
		// Page 1: 
		array(
			'id'		=> 'page1_timetostart',
			'label'		=> 'Time To Start With Us',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page1'
		),
		// Page 1: 
		array(
			'id'		=> 'page1_whyus',
			'label'		=> 'Why US',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page1'
		),
		// Page 1:  
		array(
			'id'		=> 'page1_testimonial',
			'label'		=> 'Testimonial',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page1'
		),
		// Page 1:  
		array(
			'id'		=> 'page1_footercallaction',
			'label'		=> 'Footer Call Action',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page1'
		),
		// Page 2 Start
		// Page 2: 
		array(
			'id'		=> 'page2_customcontent',
			'label'		=> 'Custom Content',
			'desc'		=> '',
			'type'		=> 'textarea',
			'section'	=> 'page2'
		),
		// Page 2: 
		array(
			'id'		=> 'page2_firstlook',
			'label'		=> 'First Look Content',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page2'
		),
		// Page 2:  
		array(
			'id'		=> 'page2_recentwork',
			'label'		=> 'Recent Work ',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page2'
		),
		// Page 2: 
		array(
			'id'		=> 'page2_responsive',
			'label'		=> 'Responsive Design',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page2'
		),
		// Page 2: 
		array(
			'id'		=> 'page2_designprocess',
			'label'		=> 'Design Process',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page2'
		),
		// Page 2: 
		array(
			'id'		=> 'page2_timetostart',
			'label'		=> 'Time To Start With Us',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page2'
		),
		// Page 2: 
		array(
			'id'		=> 'page2_whyus',
			'label'		=> 'Why US',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page2'
		),
		// Page 2:  
		array(
			'id'		=> 'page2_testimonial',
			'label'		=> 'Testimonial',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page2'
		),
		// Page 2:  
		array(
			'id'		=> 'page2_footercallaction',
			'label'		=> 'Footer Call Action',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page2'
		),
		// Page 2 End
		
		// Page 3 Start
		// Page 3: 
		array(
			'id'		=> 'page3_customcontent',
			'label'		=> 'Custom Content',
			'desc'		=> '',
			'type'		=> 'textarea',
			'section'	=> 'page3'
		),
		// Page 3: 
		array(
			'id'		=> 'page3_firstlook',
			'label'		=> 'First Look Content',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page3'
		),
		// Page 3:  
		array(
			'id'		=> 'page3_recentwork',
			'label'		=> 'Recent Work ',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page3'
		),
		// Page 3: 
		array(
			'id'		=> 'page3_responsive',
			'label'		=> 'Responsive Design',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page3'
		),
		// Page 3: 
		array(
			'id'		=> 'page3_designprocess',
			'label'		=> 'Design Process',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page3'
		),
		// Page 3: 
		array(
			'id'		=> 'page3_timetostart',
			'label'		=> 'Time To Start With Us',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page3'
		),
		// Page 3: 
		array(
			'id'		=> 'page3_whyus',
			'label'		=> 'Why US',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page3'
		),
		// Page 3:  
		array(
			'id'		=> 'page3_testimonial',
			'label'		=> 'Testimonial',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page3'
		),
		// Page 3:  
		array(
			'id'		=> 'page3_footercallaction',
			'label'		=> 'Footer Call Action',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page3'
		),
		// Page 3 End
		// Page 4 Start
		// Page 4: 
		array(
			'id'		=> 'page4_customcontent',
			'label'		=> 'Custom Content',
			'desc'		=> '',
			'type'		=> 'textarea',
			'section'	=> 'page4'
		),
		// Page 4: 
		array(
			'id'		=> 'page4_firstlook',
			'label'		=> 'First Look Content',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page4'
		),
		// Page 4:  
		array(
			'id'		=> 'page4_recentwork',
			'label'		=> 'Recent Work ',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page4'
		),
		// Page 4: 
		array(
			'id'		=> 'page4_responsive',
			'label'		=> 'Responsive Design',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page4'
		),
		// Page 4: 
		array(
			'id'		=> 'page4_designprocess',
			'label'		=> 'Design Process',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page4'
		),
		// Page 4: 
		array(
			'id'		=> 'page4_timetostart',
			'label'		=> 'Time To Start With Us',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page4'
		),
		// Page 4: 
		array(
			'id'		=> 'page4_whyus',
			'label'		=> 'Why US',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page4'
		),
		// Page 4:  
		array(
			'id'		=> 'page4_testimonial',
			'label'		=> 'Testimonial',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page4'
		),
		// Page 4:  
		array(
			'id'		=> 'page4_footercallaction',
			'label'		=> 'Footer Call Action',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page4'
		),
		// Page 4 End
		
		// Page 5 Start
		// Page 5: 
		array(
			'id'		=> 'page5_customcontent',
			'label'		=> 'Custom Content',
			'desc'		=> '',
			'type'		=> 'textarea',
			'section'	=> 'page5'
		),
		// Page 5: 
		array(
			'id'		=> 'page5_firstlook',
			'label'		=> 'First Look Content',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page5'
		),
		// Page 5:  
		array(
			'id'		=> 'page5_recentwork',
			'label'		=> 'Recent Work ',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page5'
		),
		// Page 5: 
		array(
			'id'		=> 'page5_responsive',
			'label'		=> 'Responsive Design',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page5'
		),
		// Page 5: 
		array(
			'id'		=> 'page5_designprocess',
			'label'		=> 'Design Process',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page5'
		),
		// Page 5: 
		array(
			'id'		=> 'page5_timetostart',
			'label'		=> 'Time To Start With Us',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page5'
		),
		// Page 5: 
		array(
			'id'		=> 'page5_whyus',
			'label'		=> 'Why US',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page5'
		),
		// Page 5:  
		array(
			'id'		=> 'page5_testimonial',
			'label'		=> 'Testimonial',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page5'
		),
		// Page 5:  
		array(
			'id'		=> 'page5_footercallaction',
			'label'		=> 'Footer Call Action',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'page5'
		),
		// Page 5 End
		
		// Request a Quote Page:  
		array(
			'id'		=> 'request_customcontent',
			'label'		=> 'Custom Content',
			'desc'		=> '',
			'type'		=> 'textarea',
			'section'	=> 'page6'
		),
		// Request a Quote End
		
		// main page Start
		// main page: 
		array(
			'id'		=> 'mainpage_customcontent',
			'label'		=> 'Custom Content',
			'desc'		=> '',
			'type'		=> 'textarea',
			'section'	=> 'mainpage'
		),
		// main page: 
		array(
			'id'		=> 'mainpage_firstlook',
			'label'		=> 'First Look Content',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'mainpage'
		),
		// main page:  
		array(
			'id'		=> 'mainpage_recentwork',
			'label'		=> 'Recent Work ',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'mainpage'
		),
		// main page: 
		array(
			'id'		=> 'mainpage_responsive',
			'label'		=> 'Responsive Design',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'mainpage'
		),
		// main page: 
		array(
			'id'		=> 'mainpage_designprocess',
			'label'		=> 'Design Process',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'mainpage'
		),
		// main page: 
		array(
			'id'		=> 'mainpage_timetostart',
			'label'		=> 'Time To Start With Us',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'mainpage'
		),
		// main page: 
		array(
			'id'		=> 'mainpage_whyus',
			'label'		=> 'Why US',
			'desc'		=> ' ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'mainpage'
		),
		// main page:  
		array(
			'id'		=> 'mainpage_testimonial',
			'label'		=> 'Testimonial',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'mainpage'
		),
		// main page:  
		array(
			'id'		=> 'mainpage_footercallaction',
			'label'		=> 'Footer Call Action',
			'desc'		=> '',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'mainpage'
		),
		// main page End
		
		// Who We Are : Who We Are Banner Section
		array(
			'id'		=> 'banner_about',
			'label'		=> 'Banner Section',
			'desc'		=> 'Banner Section  ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'about'
		),
		// Who We Are : Recent Work Section
		array(
			'id'		=> 'recent_about',
			'label'		=> 'Recent Work Section',
			'desc'		=> 'Recent Work Section  ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'about'
		),
		// Who We Are : Design Process Section
		array(
			'id'		=> 'designpro_about',
			'label'		=> 'Design Process Section',
			'desc'		=> 'Design Process Section  ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'about'
		),
		// Who We Are: Who We Are Responsive Content
		array(
			'id'		=> 'responsive_about',
			'label'		=> 'Responsive Content',
			'desc'		=> 'Responsive Content / Details about responsive ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'about'
		),
		// Who We Are: Who We Are Start Today Section
		array(
			'id'		=> 'start_about',
			'label'		=> ' Start Today Section',
			'desc'		=> ' Start Today Section, its time to start today ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'about'
		),
		// Our Work: Who We Are Why Us Section
		array(
			'id'		=> 'whyus_about',
			'label'		=> 'Why Us Section',
			'desc'		=> ' Why Us Section ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'about'
		),
		// Our Work: Testimonial Section
		array(
			'id'		=> 'testimonial_about',
			'label'		=> 'Testimonial Section',
			'desc'		=> ' Testimonial Section ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'about'
		),
		// Who We Are: Who We Are Ready Get Started Section
		array(
			'id'		=> 'ready_about',
			'label'		=> ' Ready Get Started Section',
			'desc'		=> ' Ready Get Started Section ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'about'
		),
		// Services: Services Banner Section
		array(
			'id'		=> 'banner_services',
			'label'		=> 'Banner Section',
			'desc'		=> 'Banner Section  ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'services'
		),
		// Services: Recent Work Section
		array(
			'id'		=> 'recent_services',
			'label'		=> 'Recent Work Section',
			'desc'		=> 'Recent Work Section  ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'services'
		),
		// Services: Services Responsive Content
		array(
			'id'		=> 'responsive_services',
			'label'		=> 'Responsive Content',
			'desc'		=> 'Responsive Content / Details about responsive ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'services'
		),
		// Services: Design Process Section
		array(
			'id'		=> 'designpro_services',
			'label'		=> 'Design Process Section',
			'desc'		=> 'Design Process Section  ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'services'
		),
		// Services: Services Start Today Section
		array(
			'id'		=> 'start_services',
			'label'		=> ' Start Today Section',
			'desc'		=> ' Start Today Section, its time to start today ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'services'
		),
		// Services: Services Why Us Section
		array(
			'id'		=> 'whyus_services',
			'label'		=> 'Why Us Section',
			'desc'		=> ' Why Us Section ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'services'
		),
		// Services: Services Testimonial Section
		array(
			'id'		=> 'testimonial_services',
			'label'		=> 'Testimonial Section',
			'desc'		=> ' Testimonial Section ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'services'
		),
		//Services: Services Ready Get Started Section
		array(
			'id'		=> 'ready_services',
			'label'		=> ' Ready Get Started Section',
			'desc'		=> ' Ready Get Started Section ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'services'
		),
		
		// website: website Banner Section
		array(
			'id'		=> 'banner_website',
			'label'		=> 'Banner Section',
			'desc'		=> 'Banner Section  ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'website'
		),
		// website: website Responsive Content
		array(
			'id'		=> 'responsive_website',
			'label'		=> 'Responsive Content',
			'desc'		=> 'Responsive Content / Details about responsive ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'website'
		),
		// website: website Start Today Section
		array(
			'id'		=> 'start_website',
			'label'		=> ' Start Today Section',
			'desc'		=> ' Start Today Section, its time to start today ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'website'
		),
		// website: website Recent Work Section
		array(
			'id'		=> 'recent_website',
			'label'		=> ' Recent Work Section',
			'desc'		=> ' Recent Work Section ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'website'
		),
		// website: website Design Process Section
		array(
			'id'		=> 'designpro_website',
			'label'		=> ' Design Process Section',
			'desc'		=> ' Design Process Section ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'website'
		),
		// website: website Why Us Section
		array(
			'id'		=> 'whyus_website',
			'label'		=> 'Why Us Section',
			'desc'		=> ' Why Us Section ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'website'
		),
		//website: website Ready Get Started Section
		array(
			'id'		=> 'ready_website',
			'label'		=> ' Ready Get Started Section',
			'desc'		=> ' Ready Get Started Section ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'website'
		),
		// website: website Sort Testimonial Section
		array(
			'id'		=> 'testimonial_website',
			'label'		=> ' Sort Testimonial Section',
			'desc'		=> ' Sort Testimonial Section ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'website'
		),
		
		// Home Page: See Our Work Heading Top
		array(
			'id'		=> 'headtext',
			'label'		=> 'See Our Work Heading Top',
			'desc'		=> 'Change the heading top text and save ',
			'type'		=> 'text',
			'section'	=> 'homepage'
		),
		
		
		// Home Page: See Our Work Heading Content
		array(
			'id'		=> 'heading',
			'label'		=> 'See Our Work Heading Content',
			'desc'		=> 'Change the heading  text and save ',
			'type'		=> 'text',
			'section'	=> 'homepage'
		),
		// Home Page: See Our Work Short Description
		array(
			'id'		=> 'shortdes',
			'label'		=> 'See Our Work Short Description',
			'desc'		=> 'Change Short Description ',
			'type'		=> 'text',
			'section'	=> 'homepage'
		),
		// Home Page: See Our Work Button Text
		array(
			'id'		=> 'seebutton',
			'label'		=> 'See Our Work Button Text',
			'desc'		=> 'Change See Our Work Button Text ',
			'type'		=> 'text',
			'section'	=> 'homepage'
		),
	    // Home Page: See Our Work Partner Image 1
		array(
			'id'		=> 'partner-1',
			'label'		=> 'See Our Work Partner Image One',
			'desc'		=> 'Upload See Our Work Partner Image One ',
			'type'		=> 'upload',
			'section'	=> 'homepage'
		),
		 // Home Page: See Our Work Partner Image 2
		array(
			'id'		=> 'partner-2',
			'label'		=> 'See Our Work Partner Image Two',
			'desc'		=> 'Upload See Our Work Partner Image Two ',
			'type'		=> 'upload',
			'section'	=> 'homepage'
		),
		
		 // Home Page: See Our Work Right Side Demo Image
		array(
			'id'		=> 'workdemo',
			'label'		=> 'See Our Work Right Side Demo Image',
			'desc'		=> 'Upload See Our Work Right Side Demo Image preferred size 700x500px ',
			'type'		=> 'upload',
			'section'	=> 'homepage'
		),
		
		// Home Page: See Our Work Right Side Demo Image
		array(
			'id'		=> 'clientlogo',
			'label'		=> 'Our Clients',
			'desc'		=> 'Hide or Show Clients ',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'homepage'
		),
		
		// Home Page: Services Tittle 
		array(
			'id'		=> 'servicetitle',
			'label'		=> 'Services Tittle ',
			'desc'		=> 'Change Services Tittle  ',
			'type'		=> 'text',
			'section'	=> 'homepage'
		),
		// Home Page: Services Short Description 
		array(
			'id'		=> 'sersortdesc',
			'label'		=> 'Services Short Description ',
			'desc'		=> 'Change Services Short Description ',
			'type'		=> 'text',
			'section'	=> 'homepage'
		),
		 // Home Page: Services 1 Image
		array(
			'id'		=> 'serimg-1',
			'label'		=> 'Services 1 Image',
			'desc'		=> 'Upload Services 1 Image preferred size 200x200px ',
			'type'		=> 'upload',
			'section'	=> 'homepage'
		),
		// Home Page: Services 1 Image Link To
		array(
			'id'		=> 'serlink-1',
			'label'		=> 'Services 1 Image Link To',
			'desc'		=> 'Change Services 1 Image Link To ',
			'type'		=> 'text',
			'section'	=> 'homepage'
		),
		// Home Page: Services 1 Title
		array(
			'id'		=> 'ser-title-1',
			'label'		=> 'Services 1 Title ',
			'desc'		=> 'Change Services 1 Title ',
			'type'		=> 'text',
			'section'	=> 'homepage'
		),
		
		// Home Page: Services 1 Description
		array(
			'id'		=> 'ser-des-1',
			'label'		=> 'Services 1 Description ',
			'desc'		=> 'Change Services 1 Description ',
			'type'		=> 'text',
			'section'	=> 'homepage'
		),
		 // Home Page: Services 2 Image
		array(
			'id'		=> 'serimg-2',
			'label'		=> 'Services 2 Image',
			'desc'		=> 'Upload Services 2 Image preferred size 200x200px ',
			'type'		=> 'upload',
			'section'	=> 'homepage'
		),
		// Home Page: Services 2 Image Link To
		array(
			'id'		=> 'serlink-2',
			'label'		=> 'Services 2 Image Link To',
			'desc'		=> 'Change Services 2 Image Link To ',
			'type'		=> 'text',
			'section'	=> 'homepage'
		),
		// Home Page: Services 2 Title
		array(
			'id'		=> 'ser-title-2',
			'label'		=> 'Services 2 Title ',
			'desc'		=> 'Change Services 2 Title ',
			'type'		=> 'text',
			'section'	=> 'homepage'
		),
		
		// Home Page: Services 2 Description
		array(
			'id'		=> 'ser-des-2',
			'label'		=> 'Services 2 Description ',
			'desc'		=> 'Change Services 2 Description ',
			'type'		=> 'text',
			'section'	=> 'homepage'
		),
		 // Home Page: Services 3 Image
		array(
			'id'		=> 'serimg-3',
			'label'		=> 'Services 3 Image',
			'desc'		=> 'Upload Services 3 Image preferred size 200x200px ',
			'type'		=> 'upload',
			'section'	=> 'homepage'
		),
		// Home Page: Services 3 Image Link To
		array(
			'id'		=> 'serlink-3',
			'label'		=> 'Services 3 Image Link To',
			'desc'		=> 'Change Services 3 Image Link To ',
			'type'		=> 'text',
			'section'	=> 'homepage'
		),
		// Home Page: Services 3 Title
		array(
			'id'		=> 'ser-title-3',
			'label'		=> 'Services 3 Title ',
			'desc'		=> 'Change Services 3 Title ',
			'type'		=> 'text',
			'section'	=> 'homepage'
		),
					
		
		// Home Page: Services 3 Description
		array(
			'id'		=> 'ser-des-3',
			'label'		=> 'Services 3 Description ',
			'desc'		=> 'Change Services 3 Description ',
			'type'		=> 'text',
			'section'	=> 'homepage'
		),
		// Home Page: Responsive Title
		array(
			'id'		=> 'restitle',
			'label'		=> 'Responsive Title',
			'desc'		=> 'Change Responsive Title ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		 // Home Page: Responsive Image
		array(
			'id'		=> 'resimage',
			'label'		=> 'Responsive Image',
			'desc'		=> 'Upload Responsive Image preferred size 960x500 ',
			'type'		=> 'upload',
			'section'	=> 'sitecontent'
		),
		// Home Page: Responsive Description
		array(
			'id'		=> 'resdesc',
			'label'		=> 'Responsive Description',
			'desc'		=> 'Change Responsive Description ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Mid Body 3box Section Title
		array(
			'id'		=> 'midbtitle',
			'label'		=> 'Mid Body 3box Title',
			'desc'		=> 'Change Mid Body 3box Title ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Mid Body 3box Section Description
		array(
			'id'		=> 'midbdescription',
			'label'		=> 'Mid Body 3box Section Description',
			'desc'		=> 'Change Mid Body 3box Section Description ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Mid Body Box-1 Title
		array(
			'id'		=> 'mbox-1-title',
			'label'		=> 'Mid Body Box-1 Title',
			'desc'		=> 'Change Mid Body Box-1 Title ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Mid Body Box-1 Description
		array(
			'id'		=> 'mbox-1-des',
			'label'		=> 'Mid Body Box-1 Description',
			'desc'		=> 'Change Mid Body Box-1 Description ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Mid Body Box-2 Title
		array(
			'id'		=> 'mbox-2-title',
			'label'		=> 'Mid Body Box-2 Title',
			'desc'		=> 'Change Mid Body Box-2 Title ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Mid Body Box-1 Description
		array(
			'id'		=> 'mbox-2-des',
			'label'		=> 'Mid Body Box-2 Description',
			'desc'		=> 'Change Mid Body Box-1 Description ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Mid Body Box-3 Title
		array(
			'id'		=> 'mbox-3-title',
			'label'		=> 'Mid Body Box-3 Title',
			'desc'		=> 'Change Mid Body Box-3 Title ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Mid Body Box-1 Description
		array(
			'id'		=> 'mbox-2-des',
			'label'		=> 'Mid Body Box-2 Description',
			'desc'		=> 'Change Mid Body Box-1 Description ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Why Choose Title
		array(
			'id'		=> 'whyus',
			'label'		=> 'Why Choose Title',
			'desc'		=> 'Change Why Choose Title ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Why Choose 6 box  Title 1
		array(
			'id'		=> 'whyboxtitle-1',
			'label'		=> 'Why Choose box 1 Title ',
			'desc'		=> 'Change Why Choose box 1 Title ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Why Choose 6 box  Description 1
		array(
			'id'		=> 'whyboxdes-1',
			'label'		=> 'Why Choose box 1 Description ',
			'desc'		=> 'Change Why Choose box 1 Description ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Why Choose 6 box  Title 2
		array(
			'id'		=> 'whyboxtitle-2',
			'label'		=> 'Why Choose box 2 Title ',
			'desc'		=> 'Change Why Choose box 2 Title ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Why Choose 6 box  Description 2
		array(
			'id'		=> 'whyboxdes-2',
			'label'		=> 'Why Choose box 2 Description ',
			'desc'		=> 'Change Why Choose box 2 Description ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Why Choose 6 box  Title 3
		array(
			'id'		=> 'whyboxtitle-3',
			'label'		=> 'Why Choose box 3 Title ',
			'desc'		=> 'Change Why Choose box 3 Title ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Why Choose 6 box  Description 3
		array(
			'id'		=> 'whyboxdes-3',
			'label'		=> 'Why Choose box 3 Description ',
			'desc'		=> 'Change Why Choose box 3 Description ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Why Choose 6 box  Title 4
		array(
			'id'		=> 'whyboxtitle-4',
			'label'		=> 'Why Choose box 4 Title ',
			'desc'		=> 'Change Why Choose box 4 Title ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Why Choose 6 box  Description 4
		array(
			'id'		=> 'whyboxdes-4',
			'label'		=> 'Why Choose box 4 Description ',
			'desc'		=> 'Change Why Choose box 4 Description ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Why Choose 6 box  Title 5
		array(
			'id'		=> 'whyboxtitle-5',
			'label'		=> 'Why Choose box 5 Title ',
			'desc'		=> 'Change Why Choose box 5 Title ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Why Choose 6 box  Description 5
		array(
			'id'		=> 'whyboxdes-5',
			'label'		=> 'Why Choose box 5 Description ',
			'desc'		=> 'Change Why Choose box 5 Description ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Why Choose 6 box  Title 6
		array(
			'id'		=> 'whyboxtitle-6',
			'label'		=> 'Why Choose box 6 Title ',
			'desc'		=> 'Change Why Choose box 6 Title ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Why Choose 6 box  Description 6
		array(
			'id'		=> 'whyboxdes-6',
			'label'		=> 'Why Choose box 6 Description ',
			'desc'		=> 'Change Why Choose box 6 Description ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Footer Top Call Action Title
		array(
			'id'		=> 'readytitle',
			'label'		=> 'Footer Top Call Action Title',
			'desc'		=> 'Change Footer Top Call Action Title ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		// Home Page: Footer Top Call Action Description 
		array(
			'id'		=> 'readydes',
			'label'		=> 'Footer Top Call Action Description',
			'desc'		=> 'Change Footer Top Call Action Description ',
			'type'		=> 'text',
			'section'	=> 'sitecontent'
		),
		
        // Services Page: Services Banner Title
		array(
			'id'		=> 'serbntitle',
			'label'		=> ' Services Banner Title',
			'desc'		=> 'Change Services Banner Title ',
			'type'		=> 'text',
			'section'	=> 'services'
		),
		// Services Page: Services Banner Sort Description
		array(
			'id'		=> 'serbndesc',
			'label'		=> 'Services Banner Sort Description',
			'desc'		=> 'Change Services Banner Sort Description ',
			'type'		=> 'text',
			'section'	=> 'services'
		),
		// Services Page: Services 1 Title
		array(
			'id'		=> 'ser_title-1',
			'label'		=> 'Services 1 Title ',
			'desc'		=> 'Change Services 1 Title ',
			'type'		=> 'text',
			'section'	=> 'services'
		),
		// Services Page: Services 2 Title
		array(
			'id'		=> 'ser_title-2',
			'label'		=> 'Services 2 Title ',
			'desc'		=> 'Change Services 2 Title ',
			'type'		=> 'text',
			'section'	=> 'services'
		),
		// Services Page: Services 3 Title
		array(
			'id'		=> 'ser_title-3',
			'label'		=> 'Services 3 Title ',
			'desc'		=> 'Change Services 3 Title ',
			'type'		=> 'text',
			'section'	=> 'services'
		),
		 // Services Page: Services 1 Image
		array(
			'id'		=> 'ser_img-1',
			'label'		=> 'Services 1 Image',
			'desc'		=> 'Upload Services 1 Image preferred size 400x230px ',
			'type'		=> 'upload',
			'section'	=> 'services'
		),
		// Services Page: Services 1 Content
		array(
			'id'		=> 'ser_des-1',
			'label'		=> 'Services 1 Content ',
			'desc'		=> 'Services 1 Content ',
			'type'		=> 'textarea',
			'section'	=> 'services'
		),
		 // Services Page: Services 2 Image
		array(
			'id'		=> 'ser_img-2',
			'label'		=> 'Services 2 Image',
			'desc'		=> 'Upload Services 2 Image preferred size 400x230px ',
			'type'		=> 'upload',
			'section'	=> 'services'
		),
		// Services Page: Services 2 Content
		array(
			'id'		=> 'ser_des-2',
			'label'		=> 'Services 2 Content ',
			'desc'		=> 'Services 2 Content ',
			'type'		=> 'textarea',
			'section'	=> 'services'
		),
		// Services Page: Services 3 Image
		array(
			'id'		=> 'ser_img-3',
			'label'		=> 'Services 3 Image',
			'desc'		=> 'Upload Services 3 Image preferred size 400x230px ',
			'type'		=> 'upload',
			'section'	=> 'services'
		),
		// Services Page: Services 3 Content
		array(
			'id'		=> 'ser_des-3',
			'label'		=> 'Services 3 Content ',
			'desc'		=> 'Services 3 Content ',
			'type'		=> 'textarea',
			'section'	=> 'services'
		),

		
		 
		// Services Page: Services 4 Image
		array(
			'id'		=> 'ser_img-4',
			'label'		=> 'Services 4 Image',
			'desc'		=> 'Upload Services 4 Image preferred size 400x230px ',
			'type'		=> 'upload',
			'section'	=> 'services'
		),
		// Services Page: Services 4 Content
		array(
			'id'		=> 'ser_des-4',
			'label'		=> 'Services 4 Content ',
			'desc'		=> 'Services 4 Content ',
			'type'		=> 'textarea',
			'section'	=> 'services'
		),

		// Services Page: Services 5 Image
		array(
			'id'		=> 'ser_img-5',
			'label'		=> 'Services 5 Image',
			'desc'		=> 'Upload Services 5 Image preferred size 400x230px ',
			'type'		=> 'upload',
			'section'	=> 'services'
		),
		// Services Page: Services 5 Content
		array(
			'id'		=> 'ser_des-5',
			'label'		=> 'Services 5 Content ',
			'desc'		=> 'Services 5 Content ',
			'type'		=> 'textarea',
			'section'	=> 'services'
		),
		// Services Page: Services 6 Image
		array(
			'id'		=> 'ser_img-6',
			'label'		=> 'Services 6 Image',
			'desc'		=> 'Upload Services 6 Image preferred size 400x230px ',
			'type'		=> 'upload',
			'section'	=> 'services'
		),
		// Services Page: Services 6 Content
		array(
			'id'		=> 'ser_des-6',
			'label'		=> 'Services 6 Content ',
			'desc'		=> 'Services 6 Content ',
			'type'		=> 'textarea',
			'section'	=> 'services'
		),
// Services Page: Services 7 Image
		array(
			'id'		=> 'ser_img-7',
			'label'		=> 'Services 7 Image',
			'desc'		=> 'Upload Services 7 Image preferred size 400x230px ',
			'type'		=> 'upload',
			'section'	=> 'services'
		),
		// Services Page: Services 7 Content
		array(
			'id'		=> 'ser_des-7',
			'label'		=> 'Services 7 Content ',
			'desc'		=> 'Services 7 Content ',
			'type'		=> 'textarea',
			'section'	=> 'services'
		),
// Services Page: Services 8 Image
		array(
			'id'		=> 'ser_img-8',
			'label'		=> 'Services 8 Image',
			'desc'		=> 'Upload Services 8 Image preferred size 400x230px ',
			'type'		=> 'upload',
			'section'	=> 'services'
		),
		// Services Page: Services 8 Content
		array(
			'id'		=> 'ser_des-8',
			'label'		=> 'Services 8 Content ',
			'desc'		=> 'Services 8 Content ',
			'type'		=> 'textarea',
			'section'	=> 'services'
		),
       // Services Page: Services 9 Image
		array(
			'id'		=> 'ser_img-9',
			'label'		=> 'Services 9 Image',
			'desc'		=> 'Upload Services 9 Image preferred size 400x230px ',
			'type'		=> 'upload',
			'section'	=> 'services'
		),
		// Services Page: Services 9 Content
		array(
			'id'		=> 'ser_des-9',
			'label'		=> 'Services 9 Content ',
			'desc'		=> 'Services 9 Content ',
			'type'		=> 'textarea',
			'section'	=> 'services'
		),

		
        // Who We Are Page: Who We Are Banner Title
		array(
			'id'		=> 'abobntitle',
			'label'		=> ' Who We Are Banner Title',
			'desc'		=> 'Change Who We Are Banner Title ',
			'type'		=> 'text',
			'section'	=> 'about'
		),
		// Who We Are Page: Who We Are Sort Description
		array(
			'id'		=> 'abobndesc',
			'label'		=> 'Who We Are Banner Sort Description',
			'desc'		=> 'Change Who We Are Banner Sort Description ',
			'type'		=> 'text',
			'section'	=> 'about'
		),
		// About Page: About Heading Title
		array(
			'id'		=> 'abouttitle-1',
			'label'		=> ' About Heading Title',
			'desc'		=> 'Change About Heading Title ',
			'type'		=> 'text',
			'section'	=> 'about'
		),
		// About Page: About 1 Image
		array(
			'id'		=> 'abo_img-1',
			'label'		=> 'About 1 Image',
			'desc'		=> 'Upload About 1 Image preferred size 400x230px ',
			'type'		=> 'upload',
			'section'	=> 'about'
		),
		// About Page: About 1 Content
		array(
			'id'		=> 'abo_des-1',
			'label'		=> 'About 1 Content ',
			'desc'		=> 'About 1 Content ',
			'type'		=> 'textarea',
			'section'	=> 'about'
		),
      // About Page: About 2 Image
		array(
			'id'		=> 'abo_img-2',
			'label'		=> 'About 2 Image',
			'desc'		=> 'Upload About 2 Image preferred size 400x230px ',
			'type'		=> 'upload',
			'section'	=> 'about'
		),
		// About Page: About 2 Content
		array(
			'id'		=> 'abo_des-2',
			'label'		=> 'About 2 Content ',
			'desc'		=> 'About 2 Content ',
			'type'		=> 'textarea',
			'section'	=> 'about'
		),
      // About Page: About 3 Image
		array(
			'id'		=> 'abo_img-3',
			'label'		=> 'About 3 Image',
			'desc'		=> 'Upload About 3 Image preferred size 400x230px ',
			'type'		=> 'upload',
			'section'	=> 'about'
		),
		// About Page: About 3 Content
		array(
			'id'		=> 'abo_des-3',
			'label'		=> 'About 3 Content ',
			'desc'		=> 'About 3 Content ',
			'type'		=> 'textarea',
			'section'	=> 'about'
		),

		

        // Contact Page: Contact Banner Title
		array(
			'id'		=> 'conbntitle',
			'label'		=> ' Contact Banner Title',
			'desc'		=> 'Change Contact Banner Title ',
			'type'		=> 'text',
			'section'	=> 'contact'
		),
		// Contact Page: Contact Banner Sort Description
		array(
			'id'		=> 'conbndesc',
			'label'		=> 'Contact Banner Sort Description',
			'desc'		=> 'Change Contact Banner Sort Description ',
			'type'		=> 'text',
			'section'	=> 'contact'
		),
		// Contact Page: Contact Title
		array(
			'id'		=> 'titlecon',
			'label'		=> 'Contact Title',
			'desc'		=> 'Change Contact Title ',
			'type'		=> 'text',
			'section'	=> 'contact'
		),
		// Contact Page: Contact Sort Description
		array(
			'id'		=> 'shortdescontact',
			'label'		=> 'Contact Sort Description',
			'desc'		=> 'Change Contact Sort Description',
			'type'		=> 'text',
			'section'	=> 'contact'
		),

		// Contact Page: Contact Form
		array(
			'id'		=> 'contactform',
			'label'		=> 'Contact Form',
			'desc'		=> 'Change Contact Form URL',
			'type'		=> 'text',
			'section'	=> 'contact'
		),
		// Contact Page: Contact Address
		array(
			'id'		=> 'contactadd',
			'label'		=> 'Contact Address',
			'desc'		=> 'Change Contact Address ',
			'type'		=> 'text',
			'section'	=> 'contact'
		),
		// Contact Page: Contact Phone
		array(
			'id'		=> 'conphone',
			'label'		=> 'Contact Phone',
			'desc'		=> 'Change Contact Phone ',
			'type'		=> 'text',
			'section'	=> 'contact'
		),
		// Contact Page: Contact Fax
		array(
			'id'		=> 'contactfax',
			'label'		=> 'Contact Fax',
			'desc'		=> 'Change Contact Fax ',
			'type'		=> 'text',
			'section'	=> 'contact'
		),
		// Contact Page: Contact Page Map
		array(
			'id'		=> 'contactmap',
			'label'		=> 'Contact Page Map',
			'desc'		=> 'Change Contact Page Map ',
			'type'		=> 'textarea',
			'section'	=> 'contact'
		),
		
		// Website Page: Website Banner Title
		array(
			'id'		=> 'webbntitle',
			'label'		=> ' Website Banner Title',
			'desc'		=> 'Change Website Banner Title ',
			'type'		=> 'text',
			'section'	=> 'website'
		),
		// Website Page: Website Banner Sort Description
		array(
			'id'		=> 'webecomdesc',
			'label'		=> 'Website Banner Sort Description',
			'desc'		=> 'Change Website Banner Sort Description ',
			'type'		=> 'text',
			'section'	=> 'website'
		),
		// Website Page: Website Left Content
		array(
			'id'		=> 'webleftconent',
			'label'		=> 'Website Left Content',
			'desc'		=> 'Change Website Left Content ',
			'type'		=> 'textarea',
			'section'	=> 'website'
		),
		// Website Page: Website Right Image
		array(
			'id'		=> 'web_right_img',
			'label'		=> 'Website Right Imaget',
			'desc'		=> 'Upload Website Right Image preferred size 700x500px',
			'type'		=> 'upload',
			'section'	=> 'website'
		),
		// Recent Work Page: Site 1
		array(
			'id'		=> 'r_worksite-1',
			'label'		=> 'Site 1 Image',
			'desc'		=> 'Upload Site 1 Image preferred size 400x300px ',
			'type'		=> 'upload',
			'section'	=> 'recentwork'
		),
		// Recent Work Page: Site 1 Title
		array(
			'id'		=> 'r_sitestitle-1',
			'label'		=> 'Site 1 Title',
			'desc'		=> 'Change Site 1 Title ',
			'type'		=> 'text',
			'section'	=> 'recentwork'
		),
       // Recent Work Page: Site 1 Sort Description
		array(
			'id'		=> 'r_sitedesc-1',
			'label'		=> 'Site 1 Sort Description',
			'desc'		=> 'Change Site 1 Sort Description',
			'type'		=> 'text',
			'section'	=> 'recentwork'
		),

		 // Recent Work Page: Site 2
		array(
			'id'		=> 'r_worksite-2',
			'label'		=> 'Site 2 Image',
			'desc'		=> 'Upload Site 2 Image preferred size 400x300px ',
			'type'		=> 'upload',
			'section'	=> 'recentwork'
		),
		// Recent Work Page: Site 2 Title
		array(
			'id'		=> 'r_sitestitle-2',
			'label'		=> 'Site 2 Title',
			'desc'		=> 'Change Site 2 Title ',
			'type'		=> 'text',
			'section'	=> 'recentwork'
		),
       // Recent Work Page: Site 2 Sort Description
		array(
			'id'		=> 'r_sitedesc-2',
			'label'		=> 'Site 2 Sort Description',
			'desc'		=> 'Change Site 2 Sort Description',
			'type'		=> 'text',
			'section'	=> 'recentwork'
		),

		 // Recent Work Page: Site 3
		array(
			'id'		=> 'r_worksite-3',
			'label'		=> 'Site 3 Image',
			'desc'		=> 'Upload Site 3 Image preferred size 400x300px ',
			'type'		=> 'upload',
			'section'	=> 'recentwork'
		),
		// Recent Work Page: Site 3 Title
		array(
			'id'		=> 'r_sitestitle-3',
			'label'		=> 'Site 3 Title',
			'desc'		=> 'Change Site 3 Title ',
			'type'		=> 'text',
			'section'	=> 'recentwork'
		),
       // Recent Work Page: Site 3 Sort Description
		array(
			'id'		=> 'r_sitedesc-3',
			'label'		=> 'Site 3 Sort Description',
			'desc'		=> 'Change Site 3 Sort Description',
			'type'		=> 'text',
			'section'	=> 'recentwork'
		),

		 // Recent Work Page: Site 4
		array(
			'id'		=> 'r_worksite-4',
			'label'		=> 'Site 4 Image',
			'desc'		=> 'Upload Site 4 Image preferred size 400x300px ',
			'type'		=> 'upload',
			'section'	=> 'recentwork'
		),
		// Recent Work Page: Site 4 Title
		array(
			'id'		=> 'r_sitestitle-4',
			'label'		=> 'Site 4 Title',
			'desc'		=> 'Change Site 4 Title ',
			'type'		=> 'text',
			'section'	=> 'recentwork'
		),
       // Recent Work Page: Site 4 Sort Description
		array(
			'id'		=> 'r_sitedesc-4',
			'label'		=> 'Site 4 Sort Description',
			'desc'		=> 'Change Site 4 Sort Description',
			'type'		=> 'text',
			'section'	=> 'recentwork'
		),

		 // Recent Work Page: Site 5
		array(
			'id'		=> 'r_worksite-5',
			'label'		=> 'Site 5 Image',
			'desc'		=> 'Upload Site 5 Image preferred size 400x300px ',
			'type'		=> 'upload',
			'section'	=> 'recentwork'
		),
		// Recent WorkPage: Site 5 Title
		array(
			'id'		=> 'r_sitestitle-5',
			'label'		=> 'Site 5 Title',
			'desc'		=> 'Change Site 5 Title ',
			'type'		=> 'text',
			'section'	=> 'recentwork'
		),
       // Recent Work Page: Site 5 Sort Description
		array(
			'id'		=> 'r_sitedesc-5',
			'label'		=> 'Site 5 Sort Description',
			'desc'		=> 'Change Site 5 Sort Description',
			'type'		=> 'text',
			'section'	=> 'recentwork'
		),

		 // Recent Work Page: Site 6
		array(
			'id'		=> 'r_worksite-6',
			'label'		=> 'Site 6 Image',
			'desc'		=> 'Upload Site 6 Image preferred size 400x300px ',
			'type'		=> 'upload',
			'section'	=> 'recentwork'
		),
		// Recent Work Page: Site 6 Title
		array(
			'id'		=> 'r_sitestitle-6',
			'label'		=> 'Site 6 Title',
			'desc'		=> 'Change Site 6 Title ',
			'type'		=> 'text',
			'section'	=> 'recentwork'
		),
       // Recent Work : Site 6 Sort Description
		array(
			'id'		=> 'r_sitedesc-6',
			'label'		=> 'Site 6 Sort Description',
			'desc'		=> 'Change Site 6 Sort Description',
			'type'		=> 'text',
			'section'	=> 'recentwork'
		),
		 // Design Process : Design Process Title
		array(
			'id'		=> 'designtitle',
			'label'		=> 'Design Process Title',
			'desc'		=> 'Design Process Heading Top Title',
			'type'		=> 'text',
			'section'	=> 'designprocess'
		),
		 // Design Process : Design Process Heading Description 
		array(
			'id'		=> 'design_des',
			'label'		=> 'Description Top',
			'desc'		=> 'Description about design process',
			'type'		=> 'text',
			'section'	=> 'designprocess'
		),

		 // Design Process : Process one Image
		array(
			'id'		=> 'design_img_1',
			'label'		=> ' Process One Image',
			'desc'		=> 'Upload  Process one Image preferred size 159x159px ',
			'type'		=> 'upload',
			'section'	=> 'designprocess'
		),
		 // Design Process : Process one title
		array(
			'id'		=> 'pro_title_1',
			'label'		=> 'Process one title',
			'desc'		=> 'Process one title',
			'type'		=> 'text',
			'section'	=> 'designprocess'
		),
		 // Design Process : Process one description
		array(
			'id'		=> 'pro_des_1',
			'label'		=> 'Process one description',
			'desc'		=> 'Process one description',
			'type'		=> 'text',
			'section'	=> 'designprocess'
		),
		 // Design Process : Process Two Image
		array(
			'id'		=> 'design_img_2',
			'label'		=> ' Process Two Image',
			'desc'		=> 'Upload  Process Two Image preferred size 159x159px ',
			'type'		=> 'upload',
			'section'	=> 'designprocess'
		),
		 // Design Process : Process Two title
		array(
			'id'		=> 'pro_title_2',
			'label'		=> 'Process Two title',
			'desc'		=> 'Process Two title',
			'type'		=> 'text',
			'section'	=> 'designprocess'
		),
		 // Design Process : Process Two description
		array(
			'id'		=> 'pro_des_2',
			'label'		=> 'Process Two description',
			'desc'		=> 'Process Two description',
			'type'		=> 'text',
			'section'	=> 'designprocess'
		),
		// Design Process : Process Three Image
		array(
			'id'		=> 'design_img_3',
			'label'		=> ' Process Three Image',
			'desc'		=> 'Upload  Process Three Image preferred size 159x159px ',
			'type'		=> 'upload',
			'section'	=> 'designprocess'
		),
		 // Design Process : Process Three title
		array(
			'id'		=> 'pro_title_3',
			'label'		=> 'Process Three title',
			'desc'		=> 'Process Three title',
			'type'		=> 'text',
			'section'	=> 'designprocess'
		),
		 // Design Process : Process Three description
		array(
			'id'		=> 'pro_des_3',
			'label'		=> 'Process Three description',
			'desc'		=> 'Process Three description',
			'type'		=> 'text',
			'section'	=> 'designprocess'
		),
		// Design Process : Process Four Image
		array(
			'id'		=> 'design_img_4',
			'label'		=> ' Process Four Image',
			'desc'		=> 'Upload  Process Four Image preferred size 159x159px ',
			'type'		=> 'upload',
			'section'	=> 'designprocess'
		),
		 // Design Process : Process Four title
		array(
			'id'		=> 'pro_title_4',
			'label'		=> 'Process Four title',
			'desc'		=> 'Process Four title',
			'type'		=> 'text',
			'section'	=> 'designprocess'
		),
		 // Design Process : Process Four description
		array(
			'id'		=> 'pro_des_4',
			'label'		=> 'Process Four description',
			'desc'		=> 'Process Four description',
			'type'		=> 'text',
			'section'	=> 'designprocess'
		),
		// Design Process : Process Five Image
		array(
			'id'		=> 'design_img_5',
			'label'		=> ' Process Five Image',
			'desc'		=> 'Upload  Process Five Image preferred size 159x159px ',
			'type'		=> 'upload',
			'section'	=> 'designprocess'
		),
		 // Design Process : Process Five title
		array(
			'id'		=> 'pro_title_5',
			'label'		=> 'Process Five title',
			'desc'		=> 'Process Five title',
			'type'		=> 'text',
			'section'	=> 'designprocess'
		),
		 // Design Process : Process Five description
		array(
			'id'		=> 'pro_des_5',
			'label'		=> 'Process Five description',
			'desc'		=> 'Process Five description',
			'type'		=> 'text',
			'section'	=> 'designprocess'
		),
		
       // Client Talk : Client Talk  Heading Title
		array(
			'id'		=> 'client_head_title',
			'label'		=> 'Heading Title',
			'desc'		=> 'Heading Title',
			'type'		=> 'text',
			'section'	=> 'clienttalk'
		),
		 // Client Talk : Client Talk  Heading description
		array(
			'id'		=> 'client_top_des',
			'label'		=> 'Heading description',
			'desc'		=> 'Heading description',
			'type'		=> 'text',
			'section'	=> 'clienttalk'
		),
		// Client Talk : Client One Image
		array(
			'id'		=> 'client_img_1',
			'label'		=> ' Client One Image',
			'desc'		=> 'Upload  Client One Image preferred size 159x159px ',
			'type'		=> 'upload',
			'section'	=> 'clienttalk'
		),
		 // Client Talk : Client One title
		array(
			'id'		=> 'client_title_1',
			'label'		=> 'Client One title',
			'desc'		=> 'Client One title',
			'type'		=> 'text',
			'section'	=> 'clienttalk'
		),
		 // Client Talk : Client One description
		array(
			'id'		=> 'client_des_1',
			'label'		=> 'Client One description',
			'desc'		=> 'Client One description',
			'type'		=> 'text',
			'section'	=> 'clienttalk'
		),
		// Client Talk : Client Two Image
		array(
			'id'		=> 'client_img_2',
			'label'		=> 'Client Two Image',
			'desc'		=> 'Upload  Client Two Image preferred size 159x159px ',
			'type'		=> 'upload',
			'section'	=> 'clienttalk'
		),
		 // Client Talk : Client Two title
		array(
			'id'		=> 'client_title_2',
			'label'		=> 'Client Two title',
			'desc'		=> 'Client Two title',
			'type'		=> 'text',
			'section'	=> 'clienttalk'
		),
		 // Client Talk : Client Two description
		array(
			'id'		=> 'client_des_3',
			'label'		=> 'Client Two description',
			'desc'		=> 'Client Two description',
			'type'		=> 'text',
			'section'	=> 'clienttalk'
		),




		// Layout : Global
		array(
			'id'		=> 'layout-global',
			'label'		=> 'Global Layout',
			'desc'		=> 'Other layouts will override this option if they are set',
			'std'		=> 'col-3cm',
			'type'		=> 'radio-image',
			'section'	=> 'layout',
			'choices'	=> array(
				array(
					'value'		=> 'col-1c',
					'label'		=> '1 Column',
					'src'		=> get_template_directory_uri() . '/functions/images/col-1c.png'
				),
				array(
					'value'		=> 'col-2cl',
					'label'		=> '2 Column Left',
					'src'		=> get_template_directory_uri() . '/functions/images/col-2cl.png'
				),
				array(
					'value'		=> 'col-2cr',
					'label'		=> '2 Column Right',
					'src'		=> get_template_directory_uri() . '/functions/images/col-2cr.png'
				),
				array(
					'value'		=> 'col-3cm',
					'label'		=> '3 Column Middle',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cm.png'
				),
				array(
					'value'		=> 'col-3cl',
					'label'		=> '3 Column Left',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cl.png'
				),
				array(
					'value'		=> 'col-3cr',
					'label'		=> '3 Column Right',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cr.png'
				)
			)
		),
		
		// Layout : Home
		array(
			'id'		=> 'layout-home',
			'label'		=> 'Home',
			'desc'		=> '[ <strong>is_home</strong> ] Posts homepage layout',
			'std'		=> 'inherit',
			'type'		=> 'radio-image',
			'section'	=> 'layout',
			'choices'	=> array(
				array(
					'value'		=> 'inherit',
					'label'		=> 'Inherit Global Layout',
					'src'		=> get_template_directory_uri() . '/functions/images/layout-off.png'
				),
				array(
					'value'		=> 'col-1c',
					'label'		=> '1 Column',
					'src'		=> get_template_directory_uri() . '/functions/images/col-1c.png'
				),
				array(
					'value'		=> 'col-2cl',
					'label'		=> '2 Column Left',
					'src'		=> get_template_directory_uri() . '/functions/images/col-2cl.png'
				),
				array(
					'value'		=> 'col-2cr',
					'label'		=> '2 Column Right',
					'src'		=> get_template_directory_uri() . '/functions/images/col-2cr.png'
				),
				array(
					'value'		=> 'col-3cm',
					'label'		=> '3 Column Middle',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cm.png'
				),
				array(
					'value'		=> 'col-3cl',
					'label'		=> '3 Column Left',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cl.png'
				),
				array(
					'value'		=> 'col-3cr',
					'label'		=> '3 Column Right',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cr.png'
				)
			)
		),
		// Layout : Single
		array(
			'id'		=> 'layout-single',
			'label'		=> 'Single',
			'desc'		=> '[ <strong>is_single</strong> ] Single post layout - If a post has a set layout, it will override this.',
			'std'		=> 'inherit',
			'type'		=> 'radio-image',
			'section'	=> 'layout',
			'choices'	=> array(
				array(
					'value'		=> 'inherit',
					'label'		=> 'Inherit Global Layout',
					'src'		=> get_template_directory_uri() . '/functions/images/layout-off.png'
				),
				array(
					'value'		=> 'col-1c',
					'label'		=> '1 Column',
					'src'		=> get_template_directory_uri() . '/functions/images/col-1c.png'
				),
				array(
					'value'		=> 'col-2cl',
					'label'		=> '2 Column Left',
					'src'		=> get_template_directory_uri() . '/functions/images/col-2cl.png'
				),
				array(
					'value'		=> 'col-2cr',
					'label'		=> '2 Column Right',
					'src'		=> get_template_directory_uri() . '/functions/images/col-2cr.png'
				),
				array(
					'value'		=> 'col-3cm',
					'label'		=> '3 Column Middle',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cm.png'
				),
				array(
					'value'		=> 'col-3cl',
					'label'		=> '3 Column Left',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cl.png'
				),
				array(
					'value'		=> 'col-3cr',
					'label'		=> '3 Column Right',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cr.png'
				)
			)
		),
		// Layout : Archive
		array(
			'id'		=> 'layout-archive',
			'label'		=> 'Archive',
			'desc'		=> '[ <strong>is_archive</strong> ] Category, date, tag and author archive layout',
			'std'		=> 'inherit',
			'type'		=> 'radio-image',
			'section'	=> 'layout',
			'choices'	=> array(
				array(
					'value'		=> 'inherit',
					'label'		=> 'Inherit Global Layout',
					'src'		=> get_template_directory_uri() . '/functions/images/layout-off.png'
				),
				array(
					'value'		=> 'col-1c',
					'label'		=> '1 Column',
					'src'		=> get_template_directory_uri() . '/functions/images/col-1c.png'
				),
				array(
					'value'		=> 'col-2cl',
					'label'		=> '2 Column Left',
					'src'		=> get_template_directory_uri() . '/functions/images/col-2cl.png'
				),
				array(
					'value'		=> 'col-2cr',
					'label'		=> '2 Column Right',
					'src'		=> get_template_directory_uri() . '/functions/images/col-2cr.png'
				),
				array(
					'value'		=> 'col-3cm',
					'label'		=> '3 Column Middle',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cm.png'
				),
				array(
					'value'		=> 'col-3cl',
					'label'		=> '3 Column Left',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cl.png'
				),
				array(
					'value'		=> 'col-3cr',
					'label'		=> '3 Column Right',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cr.png'
				)
			)
		),
		// Layout : Archive - Category
		array(
			'id'		=> 'layout-archive-category',
			'label'		=> 'Archive &mdash; Category',
			'desc'		=> '[ <strong>is_category</strong> ] Category archive layout',
			'std'		=> 'inherit',
			'type'		=> 'radio-image',
			'section'	=> 'layout',
			'choices'	=> array(
				array(
					'value'		=> 'inherit',
					'label'		=> 'Inherit Global Layout',
					'src'		=> get_template_directory_uri() . '/functions/images/layout-off.png'
				),
				array(
					'value'		=> 'col-1c',
					'label'		=> '1 Column',
					'src'		=> get_template_directory_uri() . '/functions/images/col-1c.png'
				),
				array(
					'value'		=> 'col-2cl',
					'label'		=> '2 Column Left',
					'src'		=> get_template_directory_uri() . '/functions/images/col-2cl.png'
				),
				array(
					'value'		=> 'col-2cr',
					'label'		=> '2 Column Right',
					'src'		=> get_template_directory_uri() . '/functions/images/col-2cr.png'
				),
				array(
					'value'		=> 'col-3cm',
					'label'		=> '3 Column Middle',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cm.png'
				),
				array(
					'value'		=> 'col-3cl',
					'label'		=> '3 Column Left',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cl.png'
				),
				array(
					'value'		=> 'col-3cr',
					'label'		=> '3 Column Right',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cr.png'
				)
			)
		),
		// Layout : Search
		array(
			'id'		=> 'layout-search',
			'label'		=> 'Search',
			'desc'		=> '[ <strong>is_search</strong> ] Search page layout',
			'std'		=> 'inherit',
			'type'		=> 'radio-image',
			'section'	=> 'layout',
			'choices'	=> array(
				array(
					'value'		=> 'inherit',
					'label'		=> 'Inherit Global Layout',
					'src'		=> get_template_directory_uri() . '/functions/images/layout-off.png'
				),
				array(
					'value'		=> 'col-1c',
					'label'		=> '1 Column',
					'src'		=> get_template_directory_uri() . '/functions/images/col-1c.png'
				),
				array(
					'value'		=> 'col-2cl',
					'label'		=> '2 Column Left',
					'src'		=> get_template_directory_uri() . '/functions/images/col-2cl.png'
				),
				array(
					'value'		=> 'col-2cr',
					'label'		=> '2 Column Right',
					'src'		=> get_template_directory_uri() . '/functions/images/col-2cr.png'
				),
				array(
					'value'		=> 'col-3cm',
					'label'		=> '3 Column Middle',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cm.png'
				),
				array(
					'value'		=> 'col-3cl',
					'label'		=> '3 Column Left',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cl.png'
				),
				array(
					'value'		=> 'col-3cr',
					'label'		=> '3 Column Right',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cr.png'
				)
			)
		),
		// Layout : Error 404
		array(
			'id'		=> 'layout-404',
			'label'		=> 'Error 404',
			'desc'		=> '[ <strong>is_404</strong> ] Error 404 page layout',
			'std'		=> 'inherit',
			'type'		=> 'radio-image',
			'section'	=> 'layout',
			'choices'	=> array(
				array(
					'value'		=> 'inherit',
					'label'		=> 'Inherit Global Layout',
					'src'		=> get_template_directory_uri() . '/functions/images/layout-off.png'
				),
				array(
					'value'		=> 'col-1c',
					'label'		=> '1 Column',
					'src'		=> get_template_directory_uri() . '/functions/images/col-1c.png'
				),
				array(
					'value'		=> 'col-2cl',
					'label'		=> '2 Column Left',
					'src'		=> get_template_directory_uri() . '/functions/images/col-2cl.png'
				),
				array(
					'value'		=> 'col-2cr',
					'label'		=> '2 Column Right',
					'src'		=> get_template_directory_uri() . '/functions/images/col-2cr.png'
				),
				array(
					'value'		=> 'col-3cm',
					'label'		=> '3 Column Middle',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cm.png'
				),
				array(
					'value'		=> 'col-3cl',
					'label'		=> '3 Column Left',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cl.png'
				),
				array(
					'value'		=> 'col-3cr',
					'label'		=> '3 Column Right',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cr.png'
				)
			)
		),
		// Layout : Default Page
		array(
			'id'		=> 'layout-page',
			'label'		=> 'Default Page',
			'desc'		=> '[ <strong>is_page</strong> ] Default page layout - If a page has a set layout, it will override this.',
			'std'		=> 'inherit',
			'type'		=> 'radio-image',
			'section'	=> 'layout',
			'choices'	=> array(
				array(
					'value'		=> 'inherit',
					'label'		=> 'Inherit Global Layout',
					'src'		=> get_template_directory_uri() . '/functions/images/layout-off.png'
				),
				array(
					'value'		=> 'col-1c',
					'label'		=> '1 Column',
					'src'		=> get_template_directory_uri() . '/functions/images/col-1c.png'
				),
				array(
					'value'		=> 'col-2cl',
					'label'		=> '2 Column Left',
					'src'		=> get_template_directory_uri() . '/functions/images/col-2cl.png'
				),
				array(
					'value'		=> 'col-2cr',
					'label'		=> '2 Column Right',
					'src'		=> get_template_directory_uri() . '/functions/images/col-2cr.png'
				),
				array(
					'value'		=> 'col-3cm',
					'label'		=> '3 Column Middle',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cm.png'
				),
				array(
					'value'		=> 'col-3cl',
					'label'		=> '3 Column Left',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cl.png'
				),
				array(
					'value'		=> 'col-3cr',
					'label'		=> '3 Column Right',
					'src'		=> get_template_directory_uri() . '/functions/images/col-3cr.png'
				)
			)
		),
		// Sidebars: Create Areas
		array(
			'id'		=> 'sidebar-areas',
			'label'		=> 'Create Sidebars',
			'desc'		=> 'You must save changes for the new areas to appear below. <br /><i>Warning: Make sure each area has a unique ID.</i>',
			'type'		=> 'list-item',
			'section'	=> 'sidebars',
			'choices'	=> array(),
			'settings'	=> array(
				array(
					'id'		=> 'id',
					'label'		=> 'Sidebar ID',
					'desc'		=> 'This ID must be unique, for example "sidebar-about"',
					'std'		=> 'sidebar-',
					'type'		=> 'text',
					'choices'	=> array()
				)
			)
		),
		// Sidebar 1 & 2
		array(
			'id'		=> 's1-home',
			'label'		=> 'Home',
			'desc'		=> '[ <strong>is_home</strong> ] Primary',
			'type'		=> 'sidebar-select',
			'section'	=> 'sidebars'
		),
		array(
			'id'		=> 's2-home',
			'label'		=> 'Home',
			'desc'		=> '[ <strong>is_home</strong> ] Secondary',
			'type'		=> 'sidebar-select',
			'section'	=> 'sidebars'
		),
		array(
			'id'		=> 's1-single',
			'label'		=> 'Single',
			'desc'		=> '[ <strong>is_single</strong> ] Primary - If a single post has a unique sidebar, it will override this.',
			'type'		=> 'sidebar-select',
			'section'	=> 'sidebars'
		),
		array(
			'id'		=> 's2-single',
			'label'		=> 'Single',
			'desc'		=> '[ <strong>is_single</strong> ] Secondary - If a single post has a unique sidebar, it will override this.',
			'type'		=> 'sidebar-select',
			'section'	=> 'sidebars'
		),
		array(
			'id'		=> 's1-archive',
			'label'		=> 'Archive',
			'desc'		=> '[ <strong>is_archive</strong> ] Primary',
			'type'		=> 'sidebar-select',
			'section'	=> 'sidebars'
		),
		array(
			'id'		=> 's2-archive',
			'label'		=> 'Archive',
			'desc'		=> '[ <strong>is_archive</strong> ] Secondary',
			'type'		=> 'sidebar-select',
			'section'	=> 'sidebars'
		),
		array(
			'id'		=> 's1-archive-category',
			'label'		=> 'Archive &mdash; Category',
			'desc'		=> '[ <strong>is_category</strong> ] Primary',
			'type'		=> 'sidebar-select',
			'section'	=> 'sidebars'
		),
		array(
			'id'		=> 's2-archive-category',
			'label'		=> 'Archive &mdash; Category',
			'desc'		=> '[ <strong>is_category</strong> ] Secondary',
			'type'		=> 'sidebar-select',
			'section'	=> 'sidebars'
		),
		array(
			'id'		=> 's1-search',
			'label'		=> 'Search',
			'desc'		=> '[ <strong>is_search</strong> ] Primary',
			'type'		=> 'sidebar-select',
			'section'	=> 'sidebars'
		),
		array(
			'id'		=> 's2-search',
			'label'		=> 'Search',
			'desc'		=> '[ <strong>is_search</strong> ] Secondary',
			'type'		=> 'sidebar-select',
			'section'	=> 'sidebars'
		),
		array(
			'id'		=> 's1-404',
			'label'		=> 'Error 404',
			'desc'		=> '[ <strong>is_404</strong> ] Primary',
			'type'		=> 'sidebar-select',
			'section'	=> 'sidebars'
		),
		array(
			'id'		=> 's2-404',
			'label'		=> 'Error 404',
			'desc'		=> '[ <strong>is_404</strong> ] Secondary',
			'type'		=> 'sidebar-select',
			'section'	=> 'sidebars'
		),
		array(
			'id'		=> 's1-page',
			'label'		=> 'Default Page',
			'desc'		=> '[ <strong>is_page</strong> ] Primary - If a page has a unique sidebar, it will override this.',
			'type'		=> 'sidebar-select',
			'section'	=> 'sidebars'
		),
		array(
			'id'		=> 's2-page',
			'label'		=> 'Default Page',
			'desc'		=> '[ <strong>is_page</strong> ] Secondary - If a page has a unique sidebar, it will override this.',
			'type'		=> 'sidebar-select',
			'section'	=> 'sidebars'
		),
		// Social Links : List
		array(
			'id'		=> 'social-links',
			'label'		=> 'Social Links',
			'desc'		=> 'Create and organize your social links',
			'type'		=> 'list-item',
			'section'	=> 'social-links',
			'choices'	=> array(),
			'settings'	=> array(
				array(
					'id'		=> 'social-icon',
					'label'		=> 'Icon Name',
					'desc'		=> 'Font Awesome icon names [<a href="http://fortawesome.github.io/Font-Awesome/icons/" target="_blank"><strong>View all</strong>]</a>  ',
					'std'		=> 'fa-',
					'type'		=> 'text',
					'choices'	=> array()
				),
				array(
					'id'		=> 'social-link',
					'label'		=> 'Link',
					'desc'		=> 'Enter the full url for your icon button',
					'std'		=> 'http://',
					'type'		=> 'text',
					'choices'	=> array()
				),
				array(
					'id'		=> 'social-color',
					'label'		=> 'Icon Color',
					'desc'		=> 'Set a unique color for your icon (optional)',
					'std'		=> '',
					'type'		=> 'colorpicker',
					'section'	=> 'styling'
				),
				array(
					'id'		=> 'social-target',
					'label'		=> 'Link Options',
					'desc'		=> '',
					'std'		=> '',
					'type'		=> 'checkbox',
					'choices'	=> array(
						array( 
							'value' => '_blank',
							'label' => 'Open in new window'
						)
					)
				)
			)
		),
		// Styling: Enable
		array(
			'id'		=> 'dynamic-styles',
			'label'		=> 'Dynamic Styles',
			'desc'		=> 'Turn on to use the styling options below',
			'std'		=> 'on',
			'type'		=> 'on-off',
			'section'	=> 'styling'
		),
		// Styling: Boxed Layout
		array(
			'id'		=> 'boxed',
			'label'		=> 'Boxed Layout',
			'desc'		=> 'Use a boxed layout',
			'std'		=> 'off',
			'type'		=> 'on-off',
			'section'	=> 'styling'
		),
		// Styling: Font
		array(
			'id'		=> 'font',
			'label'		=> 'Font',
			'desc'		=> 'Select font for the theme',
			'type'		=> 'select',
			'std'		=> '30',
			'section'	=> 'styling',
			'choices'	=> array(
				array( 
					'value' => 'titillium-web',
					'label' => 'Titillium Web, Latin (Self-hosted)'
				),
				array( 
					'value' => 'titillium-web-ext',
					'label' => 'Titillium Web, Latin-Ext (Google Fonts)'
				),
				array( 
					'value' => 'droid-serif',
					'label' => 'Droid Serif, Latin (Google Fonts)'
				),
				array( 
					'value' => 'source-sans-pro',
					'label' => 'Source Sans Pro, Latin-Ext (Google Fonts)'
				),
				array( 
					'value' => 'lato',
					'label' => 'Lato, Latin (Google Fonts)'
				),
				array( 
					'value' => 'ubuntu',
					'label' => 'Ubuntu, Latin-Ext (Google Fonts)'
				),
				array( 
					'value' => 'ubuntu-cyr',
					'label' => 'Ubuntu, Latin / Cyrillic-Ext (Google Fonts)'
				),
				array( 
					'value' => 'roboto-condensed',
					'label' => 'Roboto Condensed, Latin-Ext (Google Fonts)'
				),
				array( 
					'value' => 'roboto-condensed-cyr',
					'label' => 'Roboto Condensed, Latin / Cyrillic-Ext (Google Fonts)'
				),
				array( 
					'value' => 'open-sans',
					'label' => 'Open Sans, Latin-Ext (Google Fonts)'
				),
				array( 
					'value' => 'open-sans-cyr',
					'label' => 'Open Sans, Latin / Cyrillic-Ext (Google Fonts)'
				),
				array( 
					'value' => 'pt-serif',
					'label' => 'PT Serif, Latin-Ext (Google Fonts)'
				),
				array( 
					'value' => 'pt-serif-cyr',
					'label' => 'PT Serif, Latin / Cyrillic-Ext (Google Fonts)'
				),
				array( 
					'value' => 'arial',
					'label' => 'Arial'
				),
				array( 
					'value' => 'georgia',
					'label' => 'Georgia'
				)
			)
		),
		// Styling: Container Width
		array(
			'id'			=> 'container-width',
			'label'			=> 'Website Max-width',
			'desc'			=> 'Max-width of the container. If you use 2 sidebars, your container should be at least 1200px.<br /><i>Note: For 720px content (default) use <strong>1380px</strong> for 2 sidebars and <strong>1120px</strong> for 1 sidebar. If you use a combination of both, try something inbetween.</i>',
			'std'			=> '1380',
			'type'			=> 'numeric-slider',
			'section'		=> 'styling',
			'min_max_step'	=> '1024,1600,1'
		),
		// Styling: Sidebar Padding
		array(
			'id'		=> 'sidebar-padding',
			'label'		=> 'Sidebar Width',
			'desc'		=> 'Change sidebar content padding and width',
			'type'		=> 'radio',
			'std'		=> '30',
			'section'	=> 'styling',
			'choices'	=> array(
				array( 
					'value' => '30',
					'label' => '280px primary, 200px secondary (30px padding)'
				),
				array( 
					'value' => '20',
					'label' => '300px primary, 220px secondary (20px padding)'
				)
			)
		),
		// Styling: Primary Color
		array(
			'id'		=> 'color-1',
			'label'		=> 'Primary Color',
			'std'		=> '#3b8dbd',
			'type'		=> 'colorpicker',
			'section'	=> 'styling',
			'class'		=> ''
		),
		// Styling: Secondary Color
		array(
			'id'		=> 'color-2',
			'label'		=> 'Secondary Color',
			'std'		=> '#82b965',
			'type'		=> 'colorpicker',
			'section'	=> 'styling',
			'class'		=> ''
		),
		// Styling: Topbar Background
		array(
			'id'		=> 'color-topbar',
			'label'		=> 'Topbar Background',
			'std'		=> '#26272b',
			'type'		=> 'colorpicker',
			'section'	=> 'styling',
			'class'		=> ''
		),
		// Styling: Header Background
		array(
			'id'		=> 'color-header',
			'label'		=> 'Header Background',
			'std'		=> '#33363b',
			'type'		=> 'colorpicker',
			'section'	=> 'styling',
			'class'		=> ''
		),
		// Styling: Header Menu Background
		array(
			'id'		=> 'color-header-menu',
			'label'		=> 'Header Menu Background',
			'std'		=> '',
			'type'		=> 'colorpicker',
			'section'	=> 'styling',
			'class'		=> ''
		),
		// Styling: Footer Background
		array(
			'id'		=> 'color-footer',
			'label'		=> 'Footer Background',
			'std'		=> '#33363b',
			'type'		=> 'colorpicker',
			'section'	=> 'styling',
			'class'		=> ''
		),
		// Styling: Header Logo Max-height
		array(
			'id'			=> 'logo-max-height',
			'label'			=> 'Header Logo Image Max-height',
			'desc'			=> 'Your logo image should have the double height of this to be high resolution',
			'std'			=> '60',
			'type'			=> 'numeric-slider',
			'section'		=> 'styling',
			'min_max_step'	=> '40,200,1'
		),
		// Styling: Image Border Radius
		array(
			'id'			=> 'image-border-radius',
			'label'			=> 'Image Border Radius',
			'desc'			=> 'Give your thumbnails and layout images rounded corners',
			'std'			=> '0',
			'type'			=> 'numeric-slider',
			'section'		=> 'styling',
			'min_max_step'	=> '0,15,1'
		),
		// Styling: Body Background
		array(
			'id'		=> 'body-background',
			'label'		=> 'Body Background',
			'std'		=> '#eaeaea',
			'type'		=> 'colorpicker',
			'section'	=> 'styling'
		)
	)
);

/*  Settings are not the same? Update the DB
/* ------------------------------------ */
	if ( $saved_settings !== $custom_settings ) {
		update_option( 'option_tree_settings', $custom_settings ); 
	} 
}
