<?php 
/*
Template Name: Contact Page
*/

?>
<?php get_header(); ?>

<div class="gfmw_full_contianer cakemom">


<div class="gfwm_center blogpost">
<div class="gw_inner wpadding gfmwfix">


<div class="wta_left_img_area">
<img src="<?php echo get_template_directory_uri(); ?>/images/contact.jpg" alt="" />
</div>


<div class="wta_right_img_area">
<section class="postlist pagepostnse rencet_closes">

<h2 class="wta_title_page">CALL US TO place your order today!</h2>

</section>


<div class="gw_inner padding_sets">
<div class="galleryglobal">
<div class="formCenters">

<?php echo do_shortcode( '[contact-form-7 id="38" title="contact2"]' ); ?>



</div>
<div class="wta_sidebar_area">
<div class="wta_contact_area">
<h2 class="wta_contanct_title" style="color: #E0AC56!important;">Contact Us</h2>
<p class="wta_content_cont1"><b>Thompson-DeWitt Financial Group</b></p>
<p class="wta_content_cont">42 Broadway Suite 12-239 </p>
<p class="wta_content_cont">New York, NY 10004</p>
<p class="wta_content_cont"><strong>Telephone: </strong> <a href="tel: 212 652 2646">212 652 2646</a></p>
<p class="wta_content_cont"><strong>Fax:</strong> <a href="tel: 212 652 2643">212 652 2643</a></p>
 
<div class="wta_google_map"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d201.6300010495075!2d-115.11637563549704!3d36.04275300416125!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c8cfc843bc4ca3%3A0xdb499c1d19932580!2sThe+Body+Waxing+Studio+For+Ladies+%26+Gents!5e0!3m2!1sen!2sbd!4v1503169531772" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></div>

</div>
</div>
</div>

</div>

</div>


</div>
</div>



</div>
<?php get_footer(); ?>