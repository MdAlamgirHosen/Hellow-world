<?php // footer widgets ?>


<!-------------------Footer start------------------------->


<footer id="footer">


<div class="gfmw_full_contianer page_footer_gfmw">
	<div class="gfwm_center blogpost">
		<div class="gw_inner footer_main gfmwfix">
		
        <div class="lt_footer_boxs footerbox_two">
		 <h3 class="heading half_space  st_1493193743">Quick Links<span class="divider-left"></span></h3>
		
		<ul id="menu-footer-menu-2" class="footer_menu_ul_ltc"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-7 current_page_item menu-item-54 active"><a href="http://localhost/Accounting/wordpress/">Store Location</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-30"><a href="http://localhost/Accounting/wordpress/faqs/">My Account</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-29"><a href="http://localhost/Accounting/wordpress/about-us/">
Size Guide</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-52"><a href="http://localhost/Accounting/wordpress/relocation-money/">Terms & Conditions</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-26"><a href="http://localhost/Accounting/wordpress/contact/">Return & Exchange</a></li>
</ul>		 
	

		</div>
		
        <div class="lt_footer_boxs footerbox_two">
		 <h3 class="heading half_space  st_1493193743">STORE MENU<span class="divider-left"></span></h3>
		<ul id="menu-footer-menu-2" class="footer_menu_ul_ltc"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-7 current_page_item menu-item-54 active"><a href="http://localhost/woocommercewebsite/wordpress/home/">    CANON
    
    

    
    
    

</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-30"><a href="http://localhost/woocommercewebsite/wordpress/men/">PHILIPS</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-29"><a href="http://localhost/woocommercewebsite/wordpress/olympus/">
OLYMPUS</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-52"><a href="http://localhost/woocommercewebsite/wordpress/nicon/">NICON</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-26"><a href="http://localhost/woocommercewebsite/wordpress/pentax/">PENTAX</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-26"><a href="http://localhost/Accounting/wordpress/contact/">AF-ON</a></li>
</ul>		 
	






		</div>
	
		<div class="lt_footer_boxs normal_text lt_last_footer">
		 
		 <h3 class="heading half_space  st_1493193743">HELP<span class="divider-left"></span></h3>
		 <p>Track Orders</p>

		<p>FAQs</p>

		<p>Shipping & Delivery</p>
		<p>Privacy Policy</p>
		 
		</div>
		
		
		<div class="lt_footer_boxs normal_text footerbox_one">
		 <h3 class="heading half_space  st_1493193743">NEWSLETTER SIGN UP<span class="divider-left"></span></h3>
		 <p>Subscribe our newsletter to get latest new about our new product and promo campaign.</p>
		 
		    <form action="/action_page.php" method="get">
			  <input type="email" class="wta_input_form" name="lname" placeholder="Enter Your E-mail Address...">
			  <input type="submit" class="wta_input_form" value="Submit">
			</form>
		<div class="wt_inner footersociallogo">
<ul class="social-links-lt">
						<li class="facebook_lt">
							<a href="">facebook </a></li>
						<li class="twitter_lt">
							<a href=""> twitter </a></li>
						<li class="googleplus_lt">
							<a href=""> GOOGLE PLUS </a></li>
						<li class="linkedin_lt ">
							<a href=""> linkedin </a></li>
						<li class="pinterest_lt ">
							<a href=""> pinterest </a></li>
						<li class="yelp_lt ">
							<a href=""> yelp </a></li>
					</ul>
					</div>
		 

		</div>

</div>
</div>
</div>

<div class="gfmw_full_contianer page_copyright">
	<div class="gfwm_center blogpost">
		<div class="gw_inner copyright_gw gfmwfix">
<p class="copy_rn">
Copyright  © 2017 <span>Demo</span> All Rights Reserved By Demo. 
</p>


</div>
</div>
</div>
</footer>
<!-------------------Footer Section End------------------------->		
<?php if ( ot_get_option( 'scroll_totop' ) !='off'): ?>
<a class="back-to-top" href="#">back to top  </a>
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>

