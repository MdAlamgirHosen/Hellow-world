<?php 
/*

Template Name: Blog page

*/


get_header(); 

?>

<?php get_template_part('ltc/pagetitle'); ?>

<div class="today_bMain pagebg">

<div class="container">

<div style="width:100%;  height:auto; position:relative; float:left;">
        <?php
			$args = array( 'numberposts' => 3 );
			$lastposts = get_posts( $args );
			foreach($lastposts as $post) : setup_postdata($post); ?>

			 
			 <div class="featured">
			   <article id="post-16" class="group post-16 post type-post status-publish format-standard has-post-thumbnail hentry category-uncategorized"> 
				 <div class="listpostimg ">
				  <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_post_thumbnail(); ?></a>
				 </div>
				 <div class="listposting_content">
				  <div class="inner_catlist"> 
				   <p class="post-category"><?php the_time('F jS, Y'); ?> 
								 <span><?php comments_popup_link( 'No comments yet', '1 comment', '% comments', 'comments-link', 'Comments are off for this post');?></span> </p>
				  </div>

				  <a class="listing_posttitle" href="<?php the_permalink(); ?>"><?php the_title(); ?></a> 
				  <p><?php echo wp_trim_words( get_the_content(), 40, '<a href="'.get_permalink().'"> ....Read more</a>' ); ?></p>
				 </div>
			   </article> 
			 </div>
           <?php endforeach; ?>
</div>

</div>

</div>
<?php get_footer(); ?>