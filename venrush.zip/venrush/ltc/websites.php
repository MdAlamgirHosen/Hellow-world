<?php 


?>


<div class="today_bMain web_mids">

<div class="container">

<div class="tJleft">
 <?php if ( ot_get_option('webleftconent')): ?>
 <?php echo ot_get_option('webleftconent'); ?>
 <?php else: ?>
<p class="tj_leftph_web">
 Website Design
</p>

<p class="tj_leftpn_m">
A New Era of Custom CMS Websites that convert better than our competitors.<span style="font-weight:bold;"> It allows you to customize without learning html code. Our Proprietary Lead Generation</span> 
 Software generates only the freshest leads online to ensure your buyers have not already moved on.
 <br>
 <br>
 A New Era of Custom CMS Websites that convert better than our competitors.
 </p>
<ul>
<li> We know why most websites fail to achieve business objectives.</li>
<li> Our methodology is proven for each industry.</li>
<li> You’ll be working with a team of experts. </li>
<li> You’ll be working with a team of experts. </li>
</ul>

 <a multilinks-noscroll="true" id="webbicon" href="" class="effect11" data-hover="Request a Quote"><span> Request a Quote </span></a>
<?php endif; ?>

</div>
<div class="tJright">
 <?php if ( ot_get_option('web_right_img')): ?>
<img class="left_imgm" src="<?php echo ot_get_option('web_right_img'); ?>">
<?php else: ?>
<img class="left_imgm" src="<?php echo get_template_directory_uri(); ?>/images/mid_image_mo.png">
<?php endif; ?>
</div>

</div>

</div>








