<?php 


?>


<div class="today_bMain mTmid">

<div class="container">

<div class="tJleft">

<?php if ( ot_get_option('headtext')): ?>
<p class="tj_leftpm">
<?php echo ot_get_option('headtext'); ?>
</p>
<?php else: ?>	
<p class="tj_leftpm">
Website Design, Online Marketing, & Mobile App Development with Development with 
</p>
<?php endif; ?>
<?php if ( ot_get_option('heading')): ?>
<p class="tj_leftph">
<?php echo ot_get_option('heading'); ?>
</p>
<?php else: ?>	
<p class="tj_leftph">
 Stunning Results 
</p>
<?php endif; ?>
<?php if ( ot_get_option('shortdes')): ?>
<p class="tj_leftpn">
<?php echo ot_get_option('shortdes'); ?>
</p>
 <?php else: ?>	
<p class="tj_leftpn">
A New Era of Custom CMS Websites that convert better than our competitors.<span style="font-weight:bold;"> It allows you to customize without learning html code. Our Proprietary Lead Generation</span> 
 Software generates only the freshest leads online to ensure your buyers have not already moved on.</p>
<?php endif; ?>
<?php if ( ot_get_option('seebutton')): ?>
 <a multilinks-noscroll="true" href="" class="effect11" data-hover="<?php echo ot_get_option('seebutton'); ?>"><span> <?php echo ot_get_option('seebutton'); ?> </span></a>
  <?php else: ?>	
 <a multilinks-noscroll="true" href="" class="effect11" data-hover="See Our Work"><span> See Our Work </span></a>
 <?php endif; ?>
 <img class="img-line" src="<?php echo get_template_directory_uri(); ?>/images/home-see-our-work-shadow.png">
 <?php if ( ot_get_option('partner-1')): ?>
  <img class="s_imagem" style="padding:5px 0px 5px 35px;" src="<?php echo ot_get_option('partner-1'); ?> ">
 <?php else: ?>
    <img class="s_imagem" style="padding:5px 0px 5px 35px;" src="<?php echo get_template_directory_uri(); ?>/images/partner-1.png">
<?php endif; ?>
 <?php if ( ot_get_option('partner-2')): ?>
    <img class="s_imagei" style="padding:5px 0px 5px 5px;" src="<?php echo ot_get_option('partner-2'); ?>">
	 <?php else: ?>
    <img class="s_imagei" style="padding:5px 0px 5px 5px;" src="<?php echo get_template_directory_uri(); ?>/images/partner-2.png">
<?php endif; ?>
</div>
<div class="tJright">
 <?php if ( ot_get_option('workdemo')): ?>
<img class="left_imgm" src="<?php echo ot_get_option('workdemo'); ?>">
<?php else: ?>
<img class="left_imgm" src="<?php echo get_template_directory_uri(); ?>/images/about-usimage.png">
<?php endif; ?>
</div>

</div>

</div>
