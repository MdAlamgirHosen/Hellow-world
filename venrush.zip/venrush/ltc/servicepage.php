<?php 


?>



<div class="today_bMain ser-1">

<div class="container">
<div class="ser_box_sec">

<div style="width:100%;  height:auto; position:relative; float:left;">
<?php if ( ot_get_option('ser_title-1')): ?>
<p class="ser_p"> <?php echo ot_get_option('ser_title-1'); ?></p>
 <?php else: ?>
<p class="ser_p"> TechsHelpMe Services</p>
<?php endif; ?>
</div>
<div class="ser-boxs">
<?php if ( ot_get_option('ser_img-1')): ?>
<img class="creative-d" src="<?php echo ot_get_option('ser_img-1'); ?>">
 <?php else: ?>
<img class="creative-d" src="<?php echo get_template_directory_uri(); ?>/images/icons/virusremoval.png">
<?php endif; ?>
<?php if ( ot_get_option('ser_des-1')): ?>
<?php echo ot_get_option('ser_des-1'); ?>
 <?php else: ?>
<p class="ser_box_h"> Virus removal</p>
<p class="ser-sml">
From fashion to finance, non-profit to new startup, education to ecommerce and everything in between. Here are a handful of 
our clients from a variety of industries to show case our work. Enjoy! From fashion to finance, non-profit to new startup,<br> <br>education to ecommerce and everything in between. Here are a handful of our clients from a variety of industries to show case our work. Enjoy!
From fashion to finance, 
</p>



<p class="more_info_aling">
  <a href="" class="moreinfo"> More Info</a>
  </p>
<?php endif; ?>
</div>


<div class="ser-boxs">
<?php if ( ot_get_option('ser_img-2')): ?>
<img class="creative-d" src="<?php echo ot_get_option('ser_img-2'); ?>">
 <?php else: ?>
<img class="creative-d" src="<?php echo get_template_directory_uri(); ?>/images/icons/pc-tune-up.png">
<?php endif; ?>
<?php if ( ot_get_option('ser_des-2')): ?>
<?php echo ot_get_option('ser_des-2'); ?>
 <?php else: ?>
<p class="ser_box_h"> PC Tune up</p>
<p class="ser-sml">
From fashion to finance, non-profit to new startup, education to ecommerce and everything in between. Here are a handful of 
our clients from a variety of industries to show case our work. Enjoy! From fashion to finance, non-profit to new startup,<br> <br>education to ecommerce and everything in between. Here are a handful of our clients from a variety of industries to show case our work. Enjoy!
From fashion to finance, 
</p>



<p class="more_info_aling">
  <a href="" class="moreinfo"> More Info</a>
  </p>
<?php endif; ?>
</div>

<div class="ser-boxs">
<?php if ( ot_get_option('ser_img-3')): ?>
<img class="creative-d" src="<?php echo ot_get_option('ser_img-3'); ?>">
 <?php else: ?>
<img class="creative-d" src="<?php echo get_template_directory_uri(); ?>/images/icons/software-install.png">
<?php endif; ?>
<?php if ( ot_get_option('ser_des-3')): ?>
<?php echo ot_get_option('ser_des-3'); ?>
 <?php else: ?>
<p class="ser_box_h"> Software Installation</p>
<p class="ser-sml">
From fashion to finance, non-profit to new startup, education to ecommerce and everything in between. Here are a handful of 
our clients from a variety of industries to show case our work. Enjoy! From fashion to finance, non-profit to new startup,<br> <br>education to ecommerce and everything in between. Here are a handful of our clients from a variety of industries to show case our work. Enjoy!
From fashion to finance, 
</p>



<p class="more_info_aling">
  <a href="" class="moreinfo"> More Info</a>
  </p>
<?php endif; ?>
</div>
</div>
</div>
</div>

<div class="today_bMain ser-2">

<div class="container">
<div class="ser_box_sec">

<div style="width:100%;  height:auto; position:relative; float:left;">


</div>

<div class="ser-boxs">
<?php if ( ot_get_option('ser_img-4')): ?>
<img class="creative-d" src="<?php echo ot_get_option('ser_img-4'); ?>">
 <?php else: ?>
<img class="creative-d" src="<?php echo get_template_directory_uri(); ?>/images/icons/file-transfer.png">
<?php endif; ?>
<?php if ( ot_get_option('ser_des-4')): ?>
<?php echo ot_get_option('ser_des-4'); ?>
 <?php else: ?>
<p class="ser_box_h"> File Transfer</p>
<p class="ser-sml">
From fashion to finance, non-profit to new startup, education to ecommerce and everything in between. Here are a handful of 
our clients from a variety of industries to show case our work. Enjoy! From fashion to finance, non-profit to new startup,<br> <br>education to ecommerce and everything in between. Here are a handful of our clients from a variety of industries to show case our work. Enjoy!
From fashion to finance, 
</p>



<p class="more_info_aling">
  <a href="" class="moreinfo"> More Info</a>
  </p>
<?php endif; ?>
</div>


<div class="ser-boxs">
<?php if ( ot_get_option('ser_img-5')): ?>
<img class="creative-d" src="<?php echo ot_get_option('ser_img-5'); ?>">
 <?php else: ?>
<img class="creative-d" src="<?php echo get_template_directory_uri(); ?>/images/icons/databasebackup.png">
<?php endif; ?>
<?php if ( ot_get_option('ser_des-5')): ?>
<?php echo ot_get_option('ser_des-5'); ?>
 <?php else: ?>
<p class="ser_box_h"> Data Backup</p>
<p class="ser-sml">
From fashion to finance, non-profit to new startup, education to ecommerce and everything in between. Here are a handful of 
our clients from a variety of industries to show case our work. Enjoy! From fashion to finance, non-profit to new startup,<br> <br>education to ecommerce and everything in between. Here are a handful of our clients from a variety of industries to show case our work. Enjoy!
From fashion to finance, 
</p>



<p class="more_info_aling">
  <a href="" class="moreinfo"> More Info</a>
  </p>
<?php endif; ?>
</div>

<div class="ser-boxs">
<?php if ( ot_get_option('ser_img-6')): ?>
<img class="creative-d" src="<?php echo ot_get_option('ser_img-6'); ?>">
 <?php else: ?>
<img class="creative-d" src="<?php echo get_template_directory_uri(); ?>/images/icons/wirlesssetup.png">
<?php endif; ?>
<?php if ( ot_get_option('ser_des-6')): ?>
<?php echo ot_get_option('ser_des-6'); ?>
 <?php else: ?>
<p class="ser_box_h"> Wireless Networking Setup & Troubleshoot</p>
<p class="ser-sml">
From fashion to finance, non-profit to new startup, education to ecommerce and everything in between. Here are a handful of 
our clients from a variety of industries to show case our work. Enjoy! From fashion to finance, non-profit to new startup,<br> <br>education to ecommerce and everything in between. Here are a handful of our clients from a variety of industries to show case our work. Enjoy!
From fashion to finance, 
</p>



<p class="more_info_aling">
  <a href="" class="moreinfo"> More Info</a>
  </p>
<?php endif; ?>
</div>
</div>
</div>
</div>


<div class="today_bMain ser-3">

<div class="container">
<div style="border-bottom:none;" class="ser_box_sec">

<div style="width:100%;  height:auto; position:relative; float:left;">

</div>

<div class="ser-boxs">
<?php if ( ot_get_option('ser_img-7')): ?>
<img class="creative-d" src="<?php echo ot_get_option('ser_img-7'); ?>">
 <?php else: ?>
<img class="creative-d" src="<?php echo get_template_directory_uri(); ?>/images/icons/email-trabalshoot.png">
<?php endif; ?>
<?php if ( ot_get_option('ser_des-7')): ?>
<?php echo ot_get_option('ser_des-7'); ?>
 <?php else: ?>
<p class="ser_box_h"> Email troubleshoot</p>
<p class="ser-sml">
From fashion to finance, non-profit to new startup, education to ecommerce and everything in between. Here are a handful of 
our clients from a variety of industries to show case our work. Enjoy! From fashion to finance, non-profit to new startup,<br> <br>education to ecommerce and everything in between. Here are a handful of our clients from a variety of industries to show case our work. Enjoy!
From fashion to finance, 
</p>



<p class="more_info_aling">
  <a href="" class="moreinfo"> More Info</a>
  </p>
<?php endif; ?>
</div>

<div class="ser-boxs">
<?php if ( ot_get_option('ser_img-8')): ?>
<img class="creative-d" src="<?php echo ot_get_option('ser_img-8'); ?>">
 <?php else: ?>
<img class="creative-d" src="<?php echo get_template_directory_uri(); ?>/images/icons/print-setup-icon.png">
<?php endif; ?>
<?php if ( ot_get_option('ser_des-8')): ?>
<?php echo ot_get_option('ser_des-8'); ?>
 <?php else: ?>
<p class="ser_box_h"> Printer set up & troubleshoot</p>
<p class="ser-sml">
From fashion to finance, non-profit to new startup, education to ecommerce and everything in between. Here are a handful of 
our clients from a variety of industries to show case our work. Enjoy! From fashion to finance, non-profit to new startup,<br> <br>education to ecommerce and everything in between. Here are a handful of our clients from a variety of industries to show case our work. Enjoy!
From fashion to finance, 
</p>



<p class="more_info_aling">
  <a href="" class="moreinfo"> More Info</a>
  </p>
<?php endif; ?>
</div>

<div class="ser-boxs">
<?php if ( ot_get_option('ser_img-9')): ?>
<img class="creative-d" src="<?php echo ot_get_option('ser_img-9'); ?>">
 <?php else: ?>
<img class="creative-d" src="<?php echo get_template_directory_uri(); ?>/images/icons/any-trubleshoot.png">
<?php endif; ?>
<?php if ( ot_get_option('ser_des-9')): ?>
<?php echo ot_get_option('ser_des-9'); ?>
 <?php else: ?>
<p class="ser_box_h"> troubleshoot </p>
<p class="ser-sml">
From fashion to finance, non-profit to new startup, education to ecommerce and everything in between. Here are a handful of 
our clients from a variety of industries to show case our work. Enjoy! From fashion to finance, non-profit to new startup,<br> <br>education to ecommerce and everything in between. Here are a handful of our clients from a variety of industries to show case our work. Enjoy!
From fashion to finance, 
</p>



<p class="more_info_aling">
  <a href="" class="moreinfo"> More Info</a>
  </p>
<?php endif; ?>
</div>
</div>
</div>
</div>




























