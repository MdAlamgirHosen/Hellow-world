<?php 


?>



<div class="today_bMain mRespon">
<div class="container">
<div style="width:100%;  height:auto; position:relative; float:left;">
<?php if ( ot_get_option('restitle')): ?>
   <p class="mRespon_p">
  <?php echo ot_get_option('restitle'); ?>
   </p>
   <?php else: ?>	
    <p class="mRespon_p">
   Every website that we build is <span style="color:#02adee; font-weight:bold;">responsive.</span>
   </p>
    <?php endif; ?>
	<?php if ( ot_get_option('resimage')): ?>
   <img class="mRespon_img" src="<?php echo ot_get_option('resimage'); ?>">
   <?php else: ?>	
    <img class="mRespon_img" src="<?php echo get_template_directory_uri();?>/images/responsive-sample.jpg">
	 <?php endif; ?>
	 <?php if ( ot_get_option('resdesc')): ?>
   <p class="mRespon_pm">
   <?php echo ot_get_option('resdesc'); ?>
   </p>
     <?php else: ?>	
    <p class="mRespon_pm">
    Mobile<span style="color:#02adee; font-weight:bold;"> web solutions </span>to help you reach your customers.  responsive.
   <br>
     We can design you a basic or complex web solution that is<span style="color:#02adee; font-weight:bold;"> attractive, functional, and adapts </span>to devices of all screen sizes. 
   </p>
    <?php endif; ?>
</div>
</div>
</div>


