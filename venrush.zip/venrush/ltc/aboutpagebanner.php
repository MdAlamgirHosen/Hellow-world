<?php 


?>



<div class="today_bMain headBn_about">

<div class="container">

<div style="width:100%;  height:auto; position:relative; float:left;">
<?php if ( ot_get_option('abobntitle')): ?>
<p class="workonp">
   <?php echo ot_get_option('abobntitle'); ?>
   </p>
    <?php else: ?>
   <p class="workonp">
    We have handcrafted over 4000 dynamic websites and over 1000 unique logo designs
   </p>
   <?php endif; ?> 
   <?php if ( ot_get_option('abobndesc')): ?>
<p class="workonps">
    <?php echo ot_get_option('abobndesc'); ?>
   </p>
   <?php else: ?>
   <p class="workonps">
    From fashion to finance, non-profit to new startup, education to ecommerce and everything
   </p>
    <?php endif; ?> 
</div>

</div>

</div>
