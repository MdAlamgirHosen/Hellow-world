<?php




/*   Faqs
/* ------------------------------------ */
if ( ! function_exists( 'lt_faqs_' ) ) {

	function lt_faqs_() {
		global $post;

		$ltfaqs = get_post_meta($post->ID,'faq_titles',true);
		
		if ( !empty( $ltfaqs ) ) {
				$i = 0;
				foreach( $ltfaqs as $item_faqs ) {
					$i++;
					// Build each separate html-section only if set
					if ( isset($item_faqs['title']) && !empty($item_faqs['title']) ) 
						{ $title = $item_faqs['title']; } else $title = '';
					if ( isset($item_faqs['faq_description']) && !empty($item_faqs['faq_description']) ) 
						{ $proDes =  $item_faqs['faq_description']; } else $link = '';
					
					
					
					// Put them together
					if ( isset($item_faqs['title']) && !empty($item_faqs['title'])   ) {
					echo '<div class="panel panel-default">';
						echo '<a class="fq_collapse" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne'.$i.'" aria-expanded="false" aria-controls="collapseOne'.$i.'"> '.$title.'  </a>';
						echo '  <div id="collapseOne'.$i.'" class="panel-collapse collapse " role="tabpanel" aria-labelledby="headingOne'.$i.'">';
						echo ' <div class="panel-body">';
						echo ' <p class="wy_us_content_ w_faq_text">'. $proDes;
						echo ' </p>';
						echo ' </div>';
						echo ' </div>';
						echo ' </div>';
					}
					
				}
				
			}
		
	}
	
}

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 


add_action( 'add_meta_boxes', 'profile_hourop' );

function profile_hourop($post){
    add_meta_box('profilhourop', ' Hours Of Operation', 'model_pro_meta_hourop', 'model', 'side' , 'high');
}


add_action('save_post', 'model_pro_meta_hourop_save');

function model_pro_meta_hourop_save(){ 
    global $post;
    if(isset($_POST["model_monday"])){
         //UPDATE: 
        $model_monday_pro = $_POST['model_monday'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_monday', $model_monday_pro);
        //print_r($_POST);
    }
	 if(isset($_POST["model_thusday"])){
         //UPDATE: 
        $model_thusday_pro = $_POST['model_thusday'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_thusday', $model_thusday_pro);
        //print_r($_POST);
    }
	if(isset($_POST["model_wednesday"])){
         //UPDATE: 
        $model_wednesday_pro = $_POST['model_wednesday'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_wednesday', $model_wednesday_pro);
        //print_r($_POST);
    }
	if(isset($_POST["model_thrusdays"])){
         //UPDATE: 
        $model_thrusdays_pro = $_POST['model_thrusdays'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_thrusdays', $model_thrusdays_pro);
        //print_r($_POST);
    }
	if(isset($_POST["model_friday"])){
         //UPDATE: 
        $model_friday_pro = $_POST['model_friday'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_friday', $model_friday_pro);
        //print_r($_POST);
    }
	if(isset($_POST["model_satuerday"])){
         //UPDATE: 
        $model_satuerday_pro = $_POST['model_satuerday'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_satuerday', $model_satuerday_pro);
        //print_r($_POST);
    }
	if(isset($_POST["model_sunday"])){
         //UPDATE: 
        $model_sunday_pro = $_POST['model_sunday'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_sunday', $model_sunday_pro);
        //print_r($_POST);
    }
}

function model_pro_meta_hourop($post){

    $model_monday_pro = get_post_meta($post->ID, 'model_monday',  true); 
	$model_thusday_pro = get_post_meta($post->ID, 'model_thusday', true); 
	$model_wednesday_pro = get_post_meta($post->ID, 'model_wednesday', true); 
	$model_thrusdays_pro = get_post_meta($post->ID, 'model_thrusdays', true); 
	$model_friday_pro = get_post_meta($post->ID, 'model_friday',  true); 
	$model_satuerday_pro = get_post_meta($post->ID, 'model_satuerday', true); 
	$model_sunday_pro = get_post_meta($post->ID, 'model_sunday', true); 
	
    ?>   
<div style="width:100%; height:30px; position:reltive; ">	
    <label for="model_monday">Monday:  </label>
<input style="float:right; width:150px;"   type="text" name="model_monday" id="model_monday" placeholder="Monday..." value="<?php echo $model_monday_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">	
<label for="model_thusday">Tuesday:  </label>
<input style="float:right; width:150px;" type="text" name="model_thusday" id="model_thusday" placeholder="Tuesday..." value="<?php echo $model_thusday_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">	
    <label for="model_wednesday">Wednesday:  </label>
<input style="float:right; width:150px;"   type="text" name="model_wednesday" id="model_wednesday"  placeholder="Wednesday..." value="<?php echo $model_wednesday_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">	
 <label for="model_thrusdays">Thursday:  </label>
<input style="float:right; width:150px;" type="text" name="model_thrusdays" id="model_thrusdays"  placeholder="Thursday..." value="<?php echo $model_thrusdays_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">	
    <label for="model_friday">Friday:  </label>
<input style="float:right; width:150px;"   type="text" name="model_friday" id="model_friday"  placeholder="Friday..." value="<?php echo $model_friday_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">
 <label for="model_satuerday">Saturday:  </label>
<input style="float:right; width:150px;" type="text" name="model_satuerday" id="model_satuerday"  placeholder="Saturday..." value="<?php echo $model_satuerday_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">
 <label for="model_sunday">Sunday:  </label>
<input style="float:right; width:150px;" type="text" name="model_sunday" id="model_sunday"  placeholder="Sunday..." value="<?php echo $model_sunday_pro; ?>"/>
</div>
    <?php
}












add_action( 'add_meta_boxes', 'profile_outcall' );

function profile_outcall($post){
    add_meta_box('profiloutcall', 'Model OutCall ', 'model_pro_meta_outcall', 'model', 'side' , 'high');
}


add_action('save_post', 'profile_metabox_outcall_save');

function profile_metabox_outcall_save(){ 
    global $post;
    if(isset($_POST["model_onehour"])){
         //UPDATE: 
        $model_onehour_pro = $_POST['model_onehour'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_onehour', $model_onehour_pro);
        //print_r($_POST);
    }
	 if(isset($_POST["model_nintymiun"])){
         //UPDATE: 
        $model_nintymiun_pro = $_POST['model_nintymiun'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_nintymiun', $model_nintymiun_pro);
        //print_r($_POST);
    }
	if(isset($_POST["model_twohour"])){
         //UPDATE: 
        $model_twohour_pro = $_POST['model_twohour'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_twohour', $model_twohour_pro);
        //print_r($_POST);
    }
	if(isset($_POST["model_threehour"])){
         //UPDATE: 
        $model_threehour_pro = $_POST['model_threehour'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_threehour', $model_threehour_pro);
        //print_r($_POST);
    }
	if(isset($_POST["model_oneday"])){
         //UPDATE: 
        $model_oneday_pro = $_POST['model_oneday'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_oneday', $model_oneday_pro);
        //print_r($_POST);
    }
	if(isset($_POST["model_special"])){
         //UPDATE: 
        $model_special_pro = $_POST['model_special'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_special', $model_special_pro);
        //print_r($_POST);
    }
}

function model_pro_meta_outcall($post){

    $model_onehour_pro = get_post_meta($post->ID, 'model_onehour',  true); 
	$model_nintymiun_pro = get_post_meta($post->ID, 'model_nintymiun', true); 
	$model_twohour_pro = get_post_meta($post->ID, 'model_twohour', true); 
	$model_threehour_pro = get_post_meta($post->ID, 'model_threehour', true); 
	$model_oneday_pro = get_post_meta($post->ID, 'model_oneday',  true); 
	$model_special_pro = get_post_meta($post->ID, 'model_special', true); 
	
    ?>   
<div style="width:100%; height:30px; position:reltive; ">	
    <label for="model_onehour">1 Hour :  </label>
<input style="float:right; width:150px;"   type="text" name="model_onehour" id="model_onehour" placeholder="1 Hour..." value="<?php echo $model_onehour_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">	
<label for="model_nintymiun">90 Minutes :  </label>
<input style="float:right; width:150px;" type="text" name="model_nintymiun" id="model_nintymiun" placeholder="90 Minutes..." value="<?php echo $model_nintymiun_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">	
    <label for="model_twohour">2 Hours:  </label>
<input style="float:right; width:150px;"   type="text" name="model_twohour" id="model_twohour"  placeholder="2 Hours..." value="<?php echo $model_twohour_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">	
 <label for="model_threehour">3 Hours:  </label>
<input style="float:right; width:150px;" type="text" name="model_threehour" id="model_threehour"  placeholder="3 Hours..." value="<?php echo $model_threehour_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">	
    <label for="model_oneday">1 Day:  </label>
<input style="float:right; width:150px;"   type="text" name="model_oneday" id="model_oneday"  placeholder="1 Day..." value="<?php echo $model_oneday_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">
 <label for="model_special">Speical Events :  </label>
<input style="float:right; width:150px;" type="text" name="model_special" id="model_special"  placeholder="Speical Events..." value="<?php echo $model_special_pro; ?>"/>
</div>
    <?php
}














include 'page-7.php';




add_action( 'init', 'create_post_type' );
function create_post_type() {
  register_post_type( 'model',
    array(
      'labels' => array(
        'name' => __( 'Model Profiles' ),
        'singular_name' => __( 'Model Profile' )
      ),
      'public' => true,
      'has_archive' => true,
	  'show_in_nav_menus' => true, 
	  'show_ui'             => TRUE,
	  'show_in_menu'        => TRUE,
	  'priority'   => 'high',
	  'menu_position'       => 5,
	  'taxonomies' => array('featured'),
	  'supports' => array('title', 'editor', 'author', 'thumbnail', 'excerpt', )
    )
  );
}

add_action( 'init', 'create_post_type_sidebar' );
function create_post_type_sidebar() {
  register_post_type( 'wtsidebar',
    array(
      'labels' => array(
        'name' => __( 'Side Bar Content' ),
        'singular_name' => __( 'SideBar' )
      ),
      'public' => true,
      'has_archive' => true,
	  'show_in_nav_menus' => true, 
	  'show_ui'             => TRUE,
	  'show_in_menu'        => TRUE,
	  'priority'   => 'high',
	  'menu_position'       => 5,
	  'taxonomies' => array('featured'),
	  'supports' => array('title', 'editor', 'author', 'thumbnail', 'excerpt', )
    )
  );
}


function change_page_menu_classes($menu)
{
    global $post;
    if (get_post_type($post) == 'model')
    {
        $menu = str_replace( 'current_page_parent', '', $menu ); // remove all current_page_parent classes
        $menu = str_replace( 'menu-item-30', 'menu-item-30 current-menu-item', $menu ); // add the current_page_parent class to the page you want
    }
    return $menu;
}
add_filter( 'nav_menu_css_class', 'change_page_menu_classes', 10,2 );




add_action( 'add_meta_boxes', 'so_custom_meta_box', 1 );

function so_custom_meta_box($post){
    add_meta_box('so_meta_box', 'Display at Home Page', 'custom_element_grid_class_meta_box', 'model', 'side' , 'high');
}

add_action('save_post', 'so_save_metabox');

function so_save_metabox(){ 
    global $post;
    if(isset($_POST["custom_element_grid_class"])){
         //UPDATE: 
        $meta_element_class = $_POST['custom_element_grid_class'];
        //END OF UPDATE

        update_post_meta($post->ID, 'custom_element_grid_class_meta_box', $meta_element_class);
        //print_r($_POST);
    }
}

function custom_element_grid_class_meta_box($post){
    $meta_element_class = get_post_meta($post->ID, 'custom_element_grid_class_meta_box', true); //true ensures you get just one value instead of an array
    ?>   
    <label>Choose Yes to display this profile at home page :  </label>

    <select name="custom_element_grid_class" id="custom_element_grid_class">
      <option value="yes" <?php selected( $meta_element_class, 'yes' ); ?>>yes</option>
      <option value="no" <?php selected( $meta_element_class, 'no' ); ?>>no</option>

    </select>
    <?php
}





add_action( 'add_meta_boxes', 'profile_lsitmetabox' );

function profile_lsitmetabox($post){
    add_meta_box('profilemetabox', 'Model Profile', 'model_pro_meta_box', 'model', 'side' , 'high');
}


add_action('save_post', 'profile_metabox_save');

function profile_metabox_save(){ 
    global $post;
    if(isset($_POST["model_age"])){
         //UPDATE: 
        $age_pro = $_POST['model_age'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_age', $age_pro);
        //print_r($_POST);
    }
	 if(isset($_POST["model_height"])){
         //UPDATE: 
        $model_height_pro = $_POST['model_height'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_height', $model_height_pro);
        //print_r($_POST);
    }
	if(isset($_POST["model_weight"])){
         //UPDATE: 
        $model_weight_pro = $_POST['model_weight'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_weight', $model_weight_pro);
        //print_r($_POST);
    }
	if(isset($_POST["model_eyes"])){
         //UPDATE: 
        $model_eyes_pro = $_POST['model_eyes'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_eyes', $model_eyes_pro);
        //print_r($_POST);
    }
	if(isset($_POST["model_hair"])){
         //UPDATE: 
        $model_hair_pro = $_POST['model_hair'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_hair', $model_hair_pro);
        //print_r($_POST);
    }
	if(isset($_POST["model_bustsize"])){
         //UPDATE: 
        $model_bustsize_pro = $_POST['model_bustsize'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_bustsize', $model_bustsize_pro);
        //print_r($_POST);
    }
	if(isset($_POST["model_ethnicity"])){
         //UPDATE: 
        $model_ethnicity_pro = $_POST['model_ethnicity'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_ethnicity', $model_ethnicity_pro);
        //print_r($_POST);
    }
	if(isset($_POST["model_languages"])){
         //UPDATE: 
        $model_languages_pro = $_POST['model_languages'];
        //END OF UPDATE

        update_post_meta($post->ID, 'model_languages', $model_languages_pro);
        //print_r($_POST);
    }
}

function model_pro_meta_box($post){

    $age_pro = get_post_meta($post->ID, 'model_age',  true); 
	$model_height_pro = get_post_meta($post->ID, 'model_height', true); 
	$model_weight_pro = get_post_meta($post->ID, 'model_weight', true); 
	$model_eyes_pro = get_post_meta($post->ID, 'model_eyes', true); 
	$model_hair_pro = get_post_meta($post->ID, 'model_hair',  true); 
	$model_bustsize_pro = get_post_meta($post->ID, 'model_bustsize', true); 
	$model_ethnicity_pro = get_post_meta($post->ID, 'model_ethnicity', true); 
	$model_languages_pro = get_post_meta($post->ID, 'model_languages', true); 
    ?>   
<div style="width:100%; height:30px; position:reltive; ">	
    <label for="model_age">Age:  </label>
<input style="float:right; width:150px;"   type="text" name="model_age" id="model_age" placeholder="Age..." value="<?php echo $age_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">	
<label for="model_height">Height:  </label>
<input style="float:right; width:150px;" type="text" name="model_height" id="model_height" placeholder="Height..." value="<?php echo $model_height_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">	
    <label for="model_weight">Weight:  </label>
<input style="float:right; width:150px;"   type="text" name="model_weight" id="model_weight"  placeholder="Weight..." value="<?php echo $model_weight_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">	
 <label for="model_eyes">Eyes:  </label>
<input style="float:right; width:150px;" type="text" name="model_eyes" id="model_eyes"  placeholder="Eyes..." value="<?php echo $model_eyes_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">	
    <label for="model_hair">Hair:  </label>
<input style="float:right; width:150px;"   type="text" name="model_hair" id="model_hair"  placeholder="Hair..." value="<?php echo $model_hair_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">
 <label for="model_bustsize">Bust Size :  </label>
<input style="float:right; width:150px;" type="text" name="model_bustsize" id="model_bustsize"  placeholder="Bust Size..." value="<?php echo $model_bustsize_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">	
    <label for="model_ethnicity">Ethnicity :  </label>
<input style="float:right; width:150px;"   type="text" name="model_ethnicity" id="model_ethnicity"  placeholder="Ethnicity..." value="<?php echo $model_ethnicity_pro; ?>"/>
</div>
<div style="width:100%; height:30px; position:reltive; ">
 <label for="model_languages">Languages :  </label>
<input style="float:right; width:150px;" type="text" name="model_languages" id="model_languages"  placeholder="Languages..." value="<?php echo $model_languages_pro; ?>"/>
</div>

    <?php
}



/* ------------------------------------------------------------------------- *
 *  Filter Nav
/* ------------------------------------------------------------------------- */

add_filter('nav_menu_css_class', 'add_active_class', 10, 2 );

function add_active_class($classes, $item) {

  if( in_array( 'current-menu-item', $classes ) ||
    in_array( 'current-menu-ancestor', $classes ) ||
    in_array( 'current-menu-parent', $classes ) ||
    in_array( 'current_page_parent', $classes ) ||
    in_array( 'current_page_ancestor', $classes )
    ) {

    $classes[] = "active";
  }

  return $classes;
}

/*  Enqueue css
/* ------------------------------------ */	
if ( ! function_exists( 'lt_styles' ) ) {
	
	function lt_styles() {
		wp_enqueue_style( 'style', get_stylesheet_uri() );
			if ( ot_get_option('responsive') != 'off' ) { wp_enqueue_style( 'responsive', get_template_directory_uri().'/responsive.css' ); }
		wp_enqueue_style( 'font-awesome', get_template_directory_uri().'/css/font-awesome.min.css' );
		wp_enqueue_style( 'font-awesomes', get_template_directory_uri().'/css/font-awesome.css' );
		wp_enqueue_style( 'boostrap', get_template_directory_uri().'/css/bootstrap.min.css' );
	}
	
}
add_action( 'wp_enqueue_scripts', 'lt_styles' );

/* ------------------------------------------------------------------------- *
 *  Custom functions
/* ------------------------------------------------------------------------- */
	
	// Use a child theme instead of placing custom functions here
	// http://codex.wordpress.org/Child_Themes


/* ------------------------------------------------------------------------- *
 *  OptionTree framework integration: Use in theme mode
/* ------------------------------------------------------------------------- */
	
	add_filter( 'ot_show_pages', '__return_false' );
	add_filter( 'ot_show_new_layout', '__return_false' );
	add_filter( 'ot_theme_mode', '__return_true' );
	load_template( get_template_directory() . '/option-tree/ot-loader.php' );


/* ------------------------------------------------------------------------- *
 *  Load theme files
/* ------------------------------------------------------------------------- */	

if ( ! function_exists( 'lt_load' ) ) {
	
	function lt_load() {
		
		
		// Load theme options and meta boxes
		load_template( get_template_directory() . '/functions/theme-options.php' );
		load_template( get_template_directory() . '/functions/meta-boxes.php' );
		
		// Load custom widgets
		load_template( get_template_directory() . '/functions/widgets/lt-tabs.php' );
		load_template( get_template_directory() . '/functions/widgets/lt-video.php' );
		load_template( get_template_directory() . '/functions/widgets/lt-posts.php' );

		// Load dynamic styles
		load_template( get_template_directory() . '/functions/dynamic-styles.php' );
		
		// Load TGM plugin activation
		load_template( get_template_directory() . '/functions/class-tgm-plugin-activation.php' );
	}
	
}
add_action( 'after_setup_theme', 'lt_load' );	


/* ------------------------------------------------------------------------- *
 *  Base functionality
/* ------------------------------------------------------------------------- */
	
	// Content width
	if ( !isset( $content_width ) ) { $content_width = 1366; }


/*  Theme setup
/* ------------------------------------ */
if ( ! function_exists( 'lt_setup' ) ) {
	
	function lt_setup() {	
		// Enable automatic feed links
		add_theme_support( 'automatic-feed-links' );
		
		// Enable featured image
		add_theme_support( 'post-thumbnails' );
		
		
		// Enable post format support
		add_theme_support( 'post-formats', array( 'aside', 'gallery', 'image', 'status' ) );
		
		// Declare WooCommerce support
		add_theme_support( 'woocommerce' );
		
		// Thumbnail sizes
		add_image_size( 'thumb-small', 160, 160, true );
		add_image_size( 'thumb-medium', 520, 245, true );
		add_image_size( 'thumb-large', 720, 340, true );

		// Custom menu areas
		register_nav_menus( array(
			'topbar' => 'Topbar',
			'header' => 'Header',
			'footer_1' => 'Footer-1',
			'footer_2' => 'Footer-2',
			'footer_3' => 'Footer-3',
			'footer_4' => 'Footer-4',
			'footer_5' => 'Footer-5',
		) );
	}
	
}
add_action( 'after_setup_theme', 'lt_setup' );


/*  Register sidebars
/* ------------------------------------ */	
if ( ! function_exists( 'lt_sidebars' ) ) {

	function lt_sidebars()	{
		register_sidebar(array( 'name' => 'Primary','id' => 'primary','description' => "Normal full width sidebar", 'before_widget' => '<div  class="sidebar_csty">','after_widget' => '</div>'));
		register_sidebar(array( 'name' => 'Secondary','id' => 'secondary','description' => "Normal full width sidebar", 'before_widget' => '<div id="mfooter" class="tfooter">','after_widget' => '</div>','before_title' => '<h3>','after_title' => '</h3>'));
		if ( ot_get_option('footer-widgets') >= '1' ) { register_sidebar(array( 'name' => 'Footer 1','id' => 'footer-1', 'description' => "Widetized footer", 'before_widget' => '<ul id="f_menu_1" class="footer_mn">','after_widget' => '</ul>','before_title' => '<p class="foo_head">','after_title' => '</p>')); }
		if ( ot_get_option('footer-widgets') >= '2' ) { register_sidebar(array( 'name' => 'Footer 2','id' => 'footer-2', 'description' => "Widetized footer", 'before_widget' => '<ul id="f_menu_2" class="footer_mn">','after_widget' => '</ul>','before_title' => '<p class="foo_head">','after_title' => '</p>')); }
		if ( ot_get_option('footer-widgets') >= '3' ) { register_sidebar(array( 'name' => 'Footer 3','id' => 'footer-3', 'description' => "Widetized footer", 'before_widget' => '<ul id="f_menu_3" class="footer_mn">','after_widget' => '</ul>','before_title' => '<p class="foo_head">','after_title' => '</p>')); }
		if ( ot_get_option('footer-widgets') >= '4' ) { register_sidebar(array( 'name' => 'Footer 4','id' => 'footer-4', 'description' => "Widetized footer", 'before_widget' => '<ul id="f_menu_4" class="footer_mn">','after_widget' => '</ul>','before_title' => '<p class="foo_head">','after_title' => '</p>')); }
		if ( ot_get_option('footer-widgets') >= '5' ) { register_sidebar(array( 'name' => 'Footer 5','id' => 'footer-5', 'description' => "Widetized footer", 'before_widget' => '<ul id="f_menu_5" class="footer_mn">','after_widget' => '</ul>','before_title' => '<p class="foo_head">','after_title' => '</p>')); }
	}
	
}
add_action( 'widgets_init', 'lt_sidebars' );


/*  Enqueue javascript
/* ------------------------------------ */	
if ( ! function_exists( 'lt_scripts' ) ) {
	
	function lt_scripts() {
	   	wp_enqueue_script( 'flexslider', get_template_directory_uri() . '/js/jquery.flexslider.min.js', array( 'jquery' ),'', false );
		wp_enqueue_script( 'jquerymin', get_template_directory_uri() . '/js/jquerymin.js', array( 'jquery' ),'1.9.1', false );
		//wp_enqueue_script( 'jssor', get_template_directory_uri() . '/js/jssor.js', array( 'jquery' ),'', false );
		//wp_enqueue_script( 'slider', get_template_directory_uri() . '/js/jssor.slider.js', array( 'jquery' ),'', false );
		wp_enqueue_script( 'botstrp', get_template_directory_uri() . '/js/bootstrap.min.js', array( 'jquery' ),'', false );
		wp_enqueue_script( 'wtclient', get_template_directory_uri() . '/js/wtclient.js', array( 'jquery' ),'', false );
		wp_enqueue_script( 'ltjscript', get_template_directory_uri() . '/js/ltjscript.js', array( 'jquery' ),'', false );
		wp_enqueue_script( 'ltgfmw', get_template_directory_uri() . '/js/ltgfmw.js', array( 'jquery' ),'', false );
		wp_enqueue_script( 'custom', get_template_directory_uri() . '/js/modernizr.custom.js', array( 'jquery' ),'', true );
		wp_enqueue_script( 'jplayer', get_template_directory_uri() . '/js/jquery.jplayer.min.js', array( 'jquery' ),'', true );
		wp_enqueue_script( 'scripts', get_template_directory_uri() . '/js/scripts.js', array( 'jquery' ),'', true );
		if ( is_singular() && get_option( 'thread_comments' ) )	{ wp_enqueue_script( 'comment-reply' ); }
	}  
	
}
add_action( 'wp_enqueue_scripts', 'lt_scripts' ); 





/*  Register custom sidebars
/* ------------------------------------ */
if ( ! function_exists( 'lt_custom_sidebars' ) ) {

	function lt_custom_sidebars() {
		if ( !ot_get_option('sidebar-areas') =='' ) {
			
			$sidebars = ot_get_option('sidebar-areas', array());
			
			if ( !empty( $sidebars ) ) {
				foreach( $sidebars as $sidebar ) {
					if ( isset($sidebar['title']) && !empty($sidebar['title']) && isset($sidebar['id']) && !empty($sidebar['id']) && ($sidebar['id'] !='sidebar-') ) {
						register_sidebar(array('name' => ''.$sidebar['title'].'','id' => ''.strtolower($sidebar['id']).'','before_widget' => '<div id="%1$s" class="widget %2$s">','after_widget' => '</div>','before_title' => '<h3>','after_title' => '</h3>'));
					}
				}
			}
		}
	}
	
}
add_action( 'widgets_init', 'lt_custom_sidebars' );


/* ------------------------------------------------------------------------- *
 *  Template functions
/* ------------------------------------------------------------------------- */	

/*  Layout class
/* ------------------------------------ */
if ( ! function_exists( 'lt_layout_class' ) ) {
	
	function lt_layout_class() {
		// Default layout
		$layout = 'col-3cm';
		$default = 'col-3cm';

		// Check for page/post specific layout
		if ( is_page() || is_single() ) {
			// Reset post data
			wp_reset_postdata();
			global $post;
			// Get meta
			$meta = get_post_meta($post->ID,'_layout',true);
			// Get if set and not set to inherit
			if ( isset($meta) && !empty($meta) && $meta != 'inherit' ) { $layout = $meta; }
			// Else check for page-global / single-global
			elseif ( is_single() && ( ot_get_option('layout-single') !='inherit' ) ) $layout = ot_get_option('layout-single',''.$default.'');
			elseif ( is_page() && ( ot_get_option('layout-page') !='inherit' ) ) $layout = ot_get_option('layout-page',''.$default.'');
			// Else get global option
			else $layout = ot_get_option('layout-global',''.$default.'');
		}
		
		// Set layout based on page
		elseif ( is_home() && ( ot_get_option('layout-home') !='inherit' ) ) $layout = ot_get_option('layout-home',''.$default.'');
		elseif ( is_category() && ( ot_get_option('layout-archive-category') !='inherit' ) ) $layout = ot_get_option('layout-archive-category',''.$default.'');
		elseif ( is_archive() && ( ot_get_option('layout-archive') !='inherit' ) ) $layout = ot_get_option('layout-archive',''.$default.'');
		elseif ( is_search() && ( ot_get_option('layout-search') !='inherit' ) ) $layout = ot_get_option('layout-search',''.$default.'');
		elseif ( is_404() && ( ot_get_option('layout-404') !='inherit' ) ) $layout = ot_get_option('layout-404',''.$default.'');
		
		// Global option
		else $layout = ot_get_option('layout-global',''.$default.'');
		
		// Return layout class
		return $layout;
	}
	
}


/*  Dynamic sidebar primary
/* ------------------------------------ */
if ( ! function_exists( 'lt_sidebar_primary' ) ) {
	
	function lt_sidebar_primary() {
		// Default sidebar
		$sidebar = 'primary';

		// Set sidebar based on page
		if ( is_home() && ot_get_option('s1-home') ) $sidebar = ot_get_option('s1-home');
		if ( is_single() && ot_get_option('s1-single') ) $sidebar = ot_get_option('s1-single');
		if ( is_archive() && ot_get_option('s1-archive') ) $sidebar = ot_get_option('s1-archive');
		if ( is_category() && ot_get_option('s1-archive-category') ) $sidebar = ot_get_option('s1-archive-category');
		if ( is_search() && ot_get_option('s1-search') ) $sidebar = ot_get_option('s1-search');
		if ( is_404() && ot_get_option('s1-404') ) $sidebar = ot_get_option('s1-404');
		if ( is_page() && ot_get_option('s1-page') ) $sidebar = ot_get_option('s1-page');

		// Check for page/post specific sidebar
		if ( is_page() || is_single() ) {
			// Reset post data
			wp_reset_postdata();
			global $post;
			// Get meta
			$meta = get_post_meta($post->ID,'_sidebar_primary',true);
			if ( $meta ) { $sidebar = $meta; }
		}

		// Return sidebar
		return $sidebar;
	}
	
}


/*  Dynamic sidebar secondary
/* ------------------------------------ */
if ( ! function_exists( 'lt_sidebar_secondary' ) ) {

	function lt_sidebar_secondary() {
		// Default sidebar
		$sidebar = 'secondary';

		// Set sidebar based on page
		if ( is_home() && ot_get_option('s2-home') ) $sidebar = ot_get_option('s2-home');
		if ( is_single() && ot_get_option('s2-single') ) $sidebar = ot_get_option('s2-single');
		if ( is_archive() && ot_get_option('s2-archive') ) $sidebar = ot_get_option('s2-archive');
		if ( is_category() && ot_get_option('s2-archive-category') ) $sidebar = ot_get_option('s2-archive-category');
		if ( is_search() && ot_get_option('s2-search') ) $sidebar = ot_get_option('s2-search');
		if ( is_404() && ot_get_option('s2-404') ) $sidebar = ot_get_option('s2-404');
		if ( is_page() && ot_get_option('s2-page') ) $sidebar = ot_get_option('s2-page');

		// Check for page/post specific sidebar
		if ( is_page() || is_single() ) {
			// Reset post data
			wp_reset_postdata();
			global $post;
			// Get meta
			$meta = get_post_meta($post->ID,'_sidebar_secondary',true);
			if ( $meta ) { $sidebar = $meta; }
		}

		// Return sidebar
		return $sidebar;
	}
	
}


/*  Social links
/* ------------------------------------ */
if ( ! function_exists( 'lt_social_links' ) ) {

	function lt_social_links() {
		if ( !ot_get_option('social-links') =='' ) {
			$links = ot_get_option('social-links', array());
			if ( !empty( $links ) ) {
				echo '<ul class="social-links">';	
				foreach( $links as $item ) {
					
					// Build each separate html-section only if set
					if ( isset($item['title']) && !empty($item['title']) ) 
						{ $title = 'title="' .$item['title']. '"'; } else $title = '';
					if ( isset($item['social-link']) && !empty($item['social-link']) ) 
						{ $link = 'href="' .$item['social-link']. '"'; } else $link = '';
					if ( isset($item['social-target']) && !empty($item['social-target']) ) 
						{ $target = 'target="' .$item['social-target']. '"'; } else $target = '';
					if ( isset($item['social-icon']) && !empty($item['social-icon']) ) 
						{ $icon = 'class="fa ' .$item['social-icon']. '"'; } else $icon = '';
					if ( isset($item['social-color']) && !empty($item['social-color']) ) 
						{ $color = 'style="color: ' .$item['social-color']. ';"'; } else $color = '';
					
					// Put them together
					if ( isset($item['title']) && !empty($item['title']) && isset($item['social-icon']) && !empty($item['social-icon']) && ($item['social-icon'] !='fa-') ) {
						echo '<li><a rel="nofollow" class="social-tooltip" '.$title.' '.$link.' '.$target.'><i '.$icon.' '.$color.'></i></a></li>';
					}
				}
				echo '</ul>';
			}
		}
	}
	
}



/* Cons
/* ------------------------------------ */
if ( ! function_exists( 'lt_cons_' ) ) {

	function lt_cons_() {
		global $post;

		$ldpros = get_post_meta($post->ID,'cons_',true);
		
		if ( !empty( $ldpros ) ) {
				echo '<ul class="pros_ul cons">';	
				foreach( $ldpros as $item_cons ) {
					
					// Build each separate html-section only if set
					if ( isset($item_cons['title']) && !empty($item_cons['title']) ) 
						{ $title = $item_cons['title']; } else $title = '';
					if ( isset($item_cons['cons_txt']) && !empty($item_cons['cons_txt']) ) 
						{ $link =  $item_cons['cons_txt']; } else $link = '';
					
					
					// Put them together
					if ( isset($item_cons['title']) && !empty($item_cons['title'])   ) {
						echo '<li> '.$title.'  </li>';
					}
				}
				echo '</ul>';
			}
		
	}
	
}


/*  Site name/logo
/* ------------------------------------ */
if ( ! function_exists( 'lt_site_title' ) ) {

	function lt_site_title() {
	
		// Text or image?
		if ( ot_get_option('custom-logo') ) {
			$logo = '<img class="logo_" src="'.ot_get_option('custom-logo').'" alt="'.get_bloginfo('name').'">';
		} else {
			$logo = get_bloginfo('name');
		}
		
		$link = '<a href="'.home_url('/').'" rel="home">'.$logo.'</a>';
		
		if ( is_front_page() || is_home() ) {
			$sitename = '<h1 class="site-title">'.$link.'</h1>'."\n";
		} else {
			$sitename = '<p class="site-title">'.$link.'</p>'."\n";
		}
		
		return $sitename;
	}
	
}


/*  Page title
/* ------------------------------------ */
if ( ! function_exists( 'lt_page_title' ) ) {

	function lt_page_title() {
		global $post;

		$heading = get_post_meta($post->ID,'_heading',true);
		$title = $heading?$heading:the_title();
		
		return $title;
	}
	
}
/*  Page Description 
/* ------------------------------------ */
if ( ! function_exists( 'lt_page_description' ) ) {

	function lt_page_description() {
		global $post;

		$ldescription = get_post_meta($post->ID,'_description',true);
		$descriptionlt = $ldescription?$ldescription:bloginfo();
		
		return $descriptionlt;
	}
	
}

/*  Amazon Link Description 
/* ------------------------------------ */
if ( ! function_exists( 'lt_amazonlink' ) ) {

	function lt_amazonlink() {
		global $post;

		$amazonlink = get_post_meta($post->ID,'_amazonlink',true);
		
		
		return $amazonlink;
	}
	
}

/*  Amazon Price
/* ------------------------------------ */
if ( ! function_exists( 'lt_amazonprice' ) ) {

	function lt_amazonprice() {
		global $post;

		$amazonPrice = get_post_meta($post->ID,'_amazonprice',true);
		
		
		return $amazonPrice;
	}
	
}

/*  Header Title For Page
/* ------------------------------------ */
if ( ! function_exists( 'lt_giftsfor' ) ) {

	function lt_giftsfor() {
		global $post;

		$giftsfor_ = get_post_meta($post->ID,'_giftsfor',true);
		
		
		return $giftsfor_;
	}
	
}

/*  Header Description For Page
/* ------------------------------------ */
if ( ! function_exists( 'lt_headerdescription' ) ) {

	function lt_headerdescription() {
		global $post;

		$giftsfordes_ = get_post_meta($post->ID,'_headerdescription',true);
		
		
		return $giftsfordes_;
	}
	
}

/*  Category ID For Page
/* ------------------------------------ */
if ( ! function_exists( 'lt_gifts_catid' ) ) {

	function lt_gifts_catid() {
		global $post;

		$giftscatid = get_post_meta($post->ID,'_gifts_catid',true);
		
		
		return $giftscatid;
	}
	
}



/*  Blog title
/* ------------------------------------ */
if ( ! function_exists( 'lt_blog_title' ) ) {

	function lt_blog_title() {
		global $post;
		$heading = ot_get_option('blog-heading');
		$subheading = ot_get_option('blog-subheading');
		if($heading) { 
			$title = $heading;
		} else {
			$title = get_bloginfo('name');
		}
		if($subheading) {
			$title = $title.' <span>'.$subheading.'</span>';
		}

		return $title;
	}
	
}




/*  Related posts
/* ------------------------------------ */
if ( ! function_exists( 'lt_related_posts' ) ) {

	function lt_related_posts() {
		wp_reset_postdata();
		global $post;

		// Define shared post arguments
		$args = array(
			'no_found_rows'				=> true,
			'update_post_meta_cache'	=> false,
			'update_post_term_cache'	=> false,
			'ignore_sticky_posts'		=> 1,
			'orderby'					=> 'rand',
			'post__not_in'				=> array($post->ID),
			'posts_per_page'			=> 3
		);
		// Related by categories
		if ( ot_get_option('related-posts') == 'categories' ) {
			
			$cats = get_post_meta($post->ID, 'related-cat', true);
			
			if ( !$cats ) {
				$cats = wp_get_post_categories($post->ID, array('fields'=>'ids'));
				$args['category__in'] = $cats;
			} else {
				$args['cat'] = $cats;
			}
		}
		// Related by tags
		if ( ot_get_option('related-posts') == 'tags' ) {
		
			$tags = get_post_meta($post->ID, 'related-tag', true);
			
			if ( !$tags ) {
				$tags = wp_get_post_tags($post->ID, array('fields'=>'ids'));
				$args['tag__in'] = $tags;
			} else {
				$args['tag_slug__in'] = explode(',', $tags);
			}
			if ( !$tags ) { $break = true; }
		}
		
		$query = !isset($break)?new WP_Query($args):new WP_Query;
		return $query;
	}
	
}


/*  Get images attached to post
/* ------------------------------------ */
if ( ! function_exists( 'lt_post_images' ) ) {

	function lt_post_images( $args=array() ) {
		global $post;

		$defaults = array(
			'numberposts'		=> -1,
			'order'				=> 'ASC',
			'orderby'			=> 'menu_order',
			'post_mime_type'	=> 'image',
			'post_parent'		=>  $post->ID,
			'post_type'			=> 'attachment',
		);

		$args = wp_parse_args( $args, $defaults );

		return get_posts( $args );
	}
	
}


/*  Get featured post ids
/* ------------------------------------ */
if ( ! function_exists( 'lt_get_featured_post_ids' ) ) {

	function lt_get_featured_post_ids() {
		$args = array(
			'category'		=> ot_get_option('featured-category'),
			'numberposts'	=> ot_get_option('featured-posts-count')
		);
		$posts = get_posts($args);
		if ( !$posts ) return false;
		foreach ( $posts as $post )
			$ids[] = $post->ID;
		return $ids;
	}
	
}


/* ------------------------------------------------------------------------- *
 *  Admin panel functions
/* ------------------------------------------------------------------------- */		

/*  Post formats script
/* ------------------------------------ */
if ( ! function_exists( 'lt_post_formats_script' ) ) {

	function lt_post_formats_script( $hook ) {
		// Only load on posts, pages
		if ( !in_array($hook, array('post.php','post-new.php')) )
			return;
		wp_enqueue_script('post-formats', get_template_directory_uri() . '/functions/js/post-formats.js', array( 'jquery' ));
	}
	
}
add_action( 'admin_enqueue_scripts', 'lt_post_formats_script');


/* ------------------------------------------------------------------------- *
 *  Filters
/* ------------------------------------------------------------------------- */

/*  Body class
/* ------------------------------------ */
if ( ! function_exists( 'lt_body_class' ) ) {

	function lt_body_class( $classes ) {
		$classes[] = lt_layout_class();
		if ( ot_get_option( 'boxed' ) != 'on' ) { $classes[] = 'full-width'; }
		if ( ot_get_option( 'boxed' ) == 'on' ) { $classes[] = 'boxed'; }
		if ( has_nav_menu('topbar') ) {	$classes[] = 'topbar-enabled'; }
		if ( ot_get_option( 'mobile-sidebar-hide' ) == 's1' ) { $classes[] = 'mobile-sidebar-hide-s1'; }
		if ( ot_get_option( 'mobile-sidebar-hide' ) == 's2' ) { $classes[] = 'mobile-sidebar-hide-s2'; }
		if ( ot_get_option( 'mobile-sidebar-hide' ) == 's1-s2' ) { $classes[] = 'mobile-sidebar-hide'; }
		return $classes;
	}
	
}
add_filter( 'body_class', 'lt_body_class' );


/*  Site title
/* ------------------------------------ */
if ( ! function_exists( 'lt_wp_title' ) ) {

	function lt_wp_title( $title ) {
		// Do not filter for RSS feed / if SEO plugin installed
		if ( is_feed() || class_exists('All_in_One_SEO_Pack') || class_exists('HeadSpace_Plugin') || class_exists('Platinum_SEO_Pack') || class_exists('wpSEO') || defined('WPSEO_VERSION') )
			return $title;
		if ( is_front_page() ) { 
			$title = get_bloginfo('name').' - '.get_bloginfo('description');
		}
		if ( is_front_page() && get_bloginfo('description') == '' ) { 
			$title = get_bloginfo('name');
		}
		if ( !is_front_page() ) { 
			$title .= ' - '.get_bloginfo('name');
		}
		return $title;
	}
	
}
add_filter( 'wp_title', 'lt_wp_title' );


/*  Custom rss feed
/* ------------------------------------ */
if ( ! function_exists( 'lt_feed_link' ) ) {

	function lt_feed_link( $output, $feed ) {
		// Do not redirect comments feed
		if ( strpos( $output, 'comments' ) )
			return $output;
		// Return feed url
		return ot_get_option('rss-feed',$output);
	}
	
}
add_filter( 'feed_link', 'lt_feed_link', 10, 2 );


/*  Custom favicon
/* ------------------------------------ */
if ( ! function_exists( 'lt_favicon' ) ) {

	function lt_favicon() {
		if ( ot_get_option('favicon') ) {
			echo '<link rel="shortcut icon" href="'.ot_get_option('favicon').'" />'."\n";
		}
	}
	
}
add_filter( 'wp_head', 'lt_favicon' );


/*  Excerpt ending
/* ------------------------------------ */
if ( ! function_exists( 'lt_excerpt_more' ) ) {

	function lt_excerpt_more( $more ) {
		return '&#46;&#46;&#46;';
	}
	
}
add_filter( 'excerpt_more', 'lt_excerpt_more' );


/*  Excerpt length
/* ------------------------------------ */
if ( ! function_exists( 'lt_excerpt_length' ) ) {

	function lt_excerpt_length( $length ) {
		return ot_get_option('excerpt-length',$length);
	}
	
}
add_filter( 'excerpt_length', 'lt_excerpt_length', 999 );


/*  Add wmode transparent to media embeds
/* ------------------------------------ */
if ( ! function_exists( 'lt_embed_wmode_transparent' ) ) {
	
	function lt_embed_wmode_transparent( $html, $url, $attr ) {
		if ( strpos( $html, "<embed src=" ) !== false )
		   { return str_replace('</param><embed', '</param><param name="wmode" value="opaque"></param><embed wmode="opaque" ', $html); }
		elseif ( strpos ( $html, 'feature=oembed' ) !== false )
		   { return str_replace( 'feature=oembed', 'feature=oembed&wmode=opaque', $html ); }
		else
		   { return $html; }
	}
	
}
add_filter( 'embed_oembed_html', 'lt_embed_wmode_transparent', 10, 3 );


/*  Add responsive container to embeds
/* ------------------------------------ */	
if ( ! function_exists( 'lt_embed_html' ) ) {

	function lt_embed_html( $html, $url ) {
		
		$pattern    = '/^https?:\/\/(www\.)?twitter\.com/';
		$is_twitter = preg_match( $pattern, $url );
		
		if ( 1 === $is_twitter ) {
			return $html;
		}
	
		return '<div class="video-container">' . $html . '</div>';
	}

}
add_filter( 'embed_oembed_html', 'lt_embed_html', 10, 3 );


/*  Add responsive container to jetpack embeds
/* ------------------------------------ */	
if ( ! function_exists( 'lt_embed_html_jp' ) ) {

	function lt_embed_html_jp( $html ) {
		return '<div class="video-container">' . $html . '</div>';
	}

}
add_filter( 'video_embed_html', 'lt_embed_html_jp' );


/*  Upscale cropped thumbnails
/* ------------------------------------ */
if ( ! function_exists( 'lt_thumbnail_upscale' ) ) {

	function lt_thumbnail_upscale( $default, $orig_w, $orig_h, $new_w, $new_h, $crop ){
		if ( !$crop ) return null; // let the wordpress default function handle this

		$aspect_ratio = $orig_w / $orig_h;
		$size_ratio = max($new_w / $orig_w, $new_h / $orig_h);

		$crop_w = round($new_w / $size_ratio);
		$crop_h = round($new_h / $size_ratio);

		$s_x = floor( ($orig_w - $crop_w) / 2 );
		$s_y = floor( ($orig_h - $crop_h) / 2 );

		return array( 0, 0, (int) $s_x, (int) $s_y, (int) $new_w, (int) $new_h, (int) $crop_w, (int) $crop_h );
	}
	
}
add_filter( 'image_resize_dimensions', 'lt_thumbnail_upscale', 10, 6 );


/*  Add shortcode support to text widget
/* ------------------------------------ */
add_filter( 'widget_text', 'do_shortcode' );


/*  Browser detection body_class() output
/* ------------------------------------ */
if ( ! function_exists( 'lt_browser_body_class' ) ) {

	function lt_browser_body_class( $classes ) {
		global $is_lynx, $is_gecko, $is_IE, $is_opera, $is_NS4, $is_safari, $is_chrome, $is_iphone;

		if($is_lynx) $classes[] = 'lynx';
		elseif($is_gecko) $classes[] = 'gecko';
		elseif($is_opera) $classes[] = 'opera';
		elseif($is_NS4) $classes[] = 'ns4';
		elseif($is_safari) $classes[] = 'safari';
		elseif($is_chrome) $classes[] = 'chrome';
		elseif($is_IE) {
			$browser = $_SERVER['HTTP_USER_AGENT'];
			$browser = substr( "$browser", 25, 8);
			if ($browser == "MSIE 7.0"  ) {
				$classes[] = 'ie7';
				$classes[] = 'ie';
			} elseif ($browser == "MSIE 6.0" ) {
				$classes[] = 'ie6';
				$classes[] = 'ie';
			} elseif ($browser == "MSIE 8.0" ) {
				$classes[] = 'ie8';
				$classes[] = 'ie';
			} elseif ($browser == "MSIE 9.0" ) {
				$classes[] = 'ie9';
				$classes[] = 'ie';
			} else {
				$classes[] = 'ie';
			}
		}
		else $classes[] = 'unknown';

		if( $is_iphone ) $classes[] = 'iphone';

		return $classes;
	}
	
}
add_filter( 'body_class', 'lt_browser_body_class' );


/* ------------------------------------------------------------------------- *
 *  Actions
/* ------------------------------------------------------------------------- */	

/*  Include or exclude featured articles in loop
/* ------------------------------------ */
if ( ! function_exists( 'lt_pre_get_posts' ) ) {

	function lt_pre_get_posts( $query ) {
		// Are we on main query ?
		if ( !$query->is_main_query() ) return;
		if ( $query->is_home() ) {

			// Featured posts enabled
			if ( ot_get_option('featured-posts-count') != '0' ) {
				// Get featured post ids
				$featured_post_ids = lt_get_featured_post_ids();
				// Exclude posts
				if ( $featured_post_ids && !ot_get_option('featured-posts-include') )
					$query->set('post__not_in', $featured_post_ids);
			}
		}
	}
	
}
add_action( 'pre_get_posts', 'lt_pre_get_posts' );


/*  Script for no-js / js class
/* ------------------------------------ */
if ( ! function_exists( 'lt_html_js_class' ) ) {

	function lt_html_js_class () {
		echo '<script>document.documentElement.className = document.documentElement.className.replace("no-js","js");</script>'. "\n";
	}
	
}
add_action( 'wp_head', 'lt_html_js_class', 1 );


/*  IE js header
/* ------------------------------------ */
if ( ! function_exists( 'lt_ie_js_header' ) ) {

	function lt_ie_js_header () {
		echo '<!--[if lt IE 9]>'. "\n";
		echo '<script src="' . esc_url( get_template_directory_uri() . '/js/ie/html5.js' ) . '"></script>'. "\n";
		echo '<script src="' . esc_url( get_template_directory_uri() . '/js/ie/selectivizr.js' ) . '"></script>'. "\n";
		echo '<![endif]-->'. "\n";
	}
	
}
add_action( 'wp_head', 'lt_ie_js_header' );


/*  IE js footer
/* ------------------------------------ */
if ( ! function_exists( 'lt_ie_js_footer' ) ) {

	function lt_ie_js_footer () {
		echo '<!--[if lt IE 9]>'. "\n";
		echo '<script src="' . esc_url( get_template_directory_uri() . '/js/ie/respond.js' ) . '"></script>'. "\n";
		echo '<![endif]-->'. "\n";
	}
	
}
add_action( 'wp_footer', 'lt_ie_js_footer', 20 );	


/*  TGM plugin activation
/* ------------------------------------ */
if ( ! function_exists( 'lt_plugins' ) ) {
	
	function lt_plugins() {
		if ( ot_get_option('recommended-plugins') != 'off' ) {
			// Add the following plugins
			$plugins = array(
				array(
					'name' 				=> 'Regenerate Thumbnails',
					'slug' 				=> 'regenerate-thumbnails',
					'required'			=> false,
					'force_activation' 	=> false,
					'force_deactivation'=> false,
				),
				array(
					'name' 				=> 'WP-PageNavi',
					'slug' 				=> 'wp-pagenavi',
					'required'			=> false,
					'force_activation' 	=> false,
					'force_deactivation'=> false,
				),
				array(
					'name' 				=> 'Contact Form 7',
					'slug' 				=> 'contact-form-7',
					'required'			=> false,
					'force_activation' 	=> false,
					'force_deactivation'=> false,
				)
			);	
			tgmpa( $plugins );
		}
	}
	
}
add_action( 'tgmpa_register', 'lt_plugins' );


/*  WooCommerce basic support
/* ------------------------------------ */
function lt_wc_wrapper_start() {
	echo '<section class="content">';
	echo '<div class="pad">';
}
function lt_wc_wrapper_end() {
	echo '</div>';
	echo '</section>';
}
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
add_action('woocommerce_before_main_content', 'lt_wc_wrapper_start', 10);
add_action('woocommerce_after_main_content', 'lt_wc_wrapper_end', 10);


/*  WP-PageNavi support - @devinsays (via GitHub)
/* ------------------------------------ */
function lt_deregister_styles() {
	wp_deregister_style( 'wp-pagenavi' );
}
add_action( 'wp_print_styles', 'lt_deregister_styles', 100 );


function gnc_wp_html_email() {
    return 'text/html';
}

add_filter( 'wp_mail_content_type', 'gnc_wp_html_email' );



add_action( 'phpmailer_init', 'send_smtp_email' );
function send_smtp_email( $phpmailer ) {

	// Define that we are sending with SMTP
	$phpmailer->isSMTP();

	// The hostname of the mail server
	$phpmailer->Host = "gator4238.hostgator.com";

	// Use SMTP authentication (true|false)
	$phpmailer->SMTPAuth = true;

	// SMTP port number - likely to be 25, 465 or 587
	$phpmailer->Port = "465";

	// Username to use for SMTP authentication
	$phpmailer->Username = "webadmin@animaltreasuresjewelry.com";

	// Password to use for SMTP authentication
	$phpmailer->Password = "hoKIse9Ks&8sjLLO";

	// Encryption system to use - ssl or tls
	$phpmailer->SMTPSecure = "ssl";

	$phpmailer->From = "webadmin@animaltreasuresjewelry.com";
	$phpmailer->FromName = "Animal Treasures Jewelry";
}



function gw_custom_meta() {
    add_meta_box( 'sm_meta', __( 'Featured Posts', 'sm-textdomain' ), 'sm_meta_callback', 'post' );
}
function sm_meta_callback( $post ) {
    $featured = get_post_meta( $post->ID );
    ?>
 
	<p>
    <div class="sm-row-content">
        <label for="meta-checkbox">
            <input type="checkbox" name="meta-checkbox" id="meta-checkbox" value="yes" <?php if ( isset ( $featured['meta-checkbox'] ) ) checked( $featured['meta-checkbox'][0], 'yes' ); ?> />
            <?php _e( 'Featured this post', 'sm-textdomain' )?>
        </label>
        
    </div>
</p>
 
    <?php
}
add_action( 'add_meta_boxes', 'gw_custom_meta' );


/**
 * Saves the custom meta input
 */
function sm_meta_save( $post_id ) {
 
    // Checks save status
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'sm_nonce' ] ) && wp_verify_nonce( $_POST[ 'sm_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';
 
    // Exits script depending on save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }
 
 // Checks for input and saves
if( isset( $_POST[ 'meta-checkbox' ] ) ) {
    update_post_meta( $post_id, 'meta-checkbox', 'yes' );
} else {
    update_post_meta( $post_id, 'meta-checkbox', '' );
}
 
}
add_action( 'save_post', 'sm_meta_save' );



/*===================================================================================
 * Add Author Links
 * =================================================================================*/
function add_to_author_profile( $contactmethods ) {
	
	$contactmethods['rss_url'] = 'RSS URL';
	$contactmethods['google_profile'] = 'Google Profile URL';
	$contactmethods['twitter_profile'] = 'Twitter Profile URL';
	$contactmethods['facebook_profile'] = 'Facebook Profile URL';
	$contactmethods['linkedin_profile'] = 'Linkedin Profile URL';
	
	return $contactmethods;
}
add_filter( 'user_contactmethods', 'add_to_author_profile', 10, 1);

/*===================================================================================
 * Add Author Links
 * =================================================================================*/
add_action( 'woocommerce_after_shop_loop_item_title', 'bbloomer_ins_woocommerce_product_excerpt', 35, 2);
 
function bbloomer_ins_woocommerce_product_excerpt() {
     if (!is_page('my-account') ) {
     echo '<span class="excerpt">';
     the_excerpt();
     echo '</span>';
     }
}



remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10);
add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10);

if ( ! function_exists( 'woocommerce_template_loop_product_thumbnail' ) ) {
    function woocommerce_template_loop_product_thumbnail() {
        echo woocommerce_get_product_thumbnail();
    }
}
if ( ! function_exists( 'woocommerce_get_product_thumbnail' ) ) {
    function woocommerce_get_product_thumbnail( $size = 'shop_catalog', $placeholder_width = 0, $placeholder_height = 0  ) {
        global $post, $woocommerce;
        $output = '<div class="product-wrap">';

        if ( has_post_thumbnail() ) {
            $output .= get_the_post_thumbnail( $post->ID, $size );
        }
        $output .= '</div>';
        return $output;
    }
}
