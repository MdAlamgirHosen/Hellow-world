<?php get_header(); ?>
<?php get_template_part('inc/page-title'); ?>
<div class="gfmw_full_contianer fourzeo_pg">

<div class="gfwm_center blogpost">

<div class="gw_inner wpadding gfmwfix">
			<h2>404</h2>
			<h3>PAGE NOT FOUND!</h3>
			<p>Looks like the page you're trying to visit doesn't exist. Please check the URL and try again.</p>
	
		<a class="a_buttons_c_gfmw" href="<?php echo site_url(); ?>">
 Take Me Home
</a>
</div>

</div>

</div>



<?php get_footer(); ?>