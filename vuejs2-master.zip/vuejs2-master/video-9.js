var myapp = new Vue({
  el:"#my-app",
  data:{

  },
  methods:{
    keypressfunction: function(){
      console.log("I am running...");
    }
  }
});
