var myapp = new Vue({
  el:"#my-app",
  data:{
    name:"Online Web tutor",
    title:"This is channel link",
    imageLink:"gallery1.png",
    isActive:true,
    ulink:"https://www.youtube.com/channel/UCB2flCo-gW6RhpVVXySqcMg/playlists",
    txtName:"Sanjay Kumar",
    txtEmail:"sanay@gmail.com",
    htmlContent:"<p>This is my paragraph set from JS file</p>"
  }
});
