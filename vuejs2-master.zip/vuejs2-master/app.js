var myview = new Vue({
   el:"#our-app",
   data:{
     message:"This is our first code",
     fname:"Sanjay",
     channel:"Online web tutor"
   }
});
