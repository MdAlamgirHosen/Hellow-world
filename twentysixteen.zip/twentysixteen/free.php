<?php
/**
 * The template Name: free page
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

	<section id="free_qoute"> 
		   <div class="container">
		   	<div class="row">
		   		<div class="col-lg-12"> 
				   <div class="title text-center"> 
				   <h2>Free Info</h2>
				  </div>
				</div>
		   	</div>
		   </div>
		</section>
		<section id="Free_area"> 
		   <div class="container">
		   	 <div class="row">
				<div class="col-sm-8 col-md-8 col-lg-8"> 
				  <div class="art_text1"> 
				    <div class="col-sm-4 col-md-4 col-lg-4"> 
					  <div class="img_area">
					    <img src="<?php echo get_template_directory_uri(); ?>/img/special.jpg" alt="" />
					  </div>
					</div>
					
					<div class="col-sm-8 col-md-8 col-lg-8"> 
					  <div class="img_area_text">
					     <h2>Personal Blog</h2>
						 <p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy </p>
					  </div>
					</div>
				  </div>
				</div>
				
				<div class="col-sm-4 col-md-4 col-lg-4"> 
				  <div class="img_art"> 
				     <h3>Recent Posts</h3>
					  <p>Demo</p>
				  </div>
				</div>
		   	</div>
		   </div>
		</section>
<?php get_footer(); ?>
