<div class="album-container">
    <img src="<?php echo GALLERY_IMG_IMAGES_URL . "/admin_images/album_options.png" ?>"
         alt="album optins"/>
    <div class="album-overlay">
        <p>This section is disabled for current version of plugin</p>
        <a class="album_purchase_link" href="http://huge-it.com/wordpress-gallery/">Get Full Version</a>
    </div>
</div>
