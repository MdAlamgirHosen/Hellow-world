<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>add new page</title>
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
	
	
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.16.0/jquery.validate.min.js"></script>


 <script type="text/javascript"> 
 /*var post_data = $("#frmPost").serialize()+"&action=custom_plugin_library&param=post_form_data";
  juery.post(ajaxurl,post_data, function(respose){
  var data = $.parseJSON(respose);
  console.log(data);
  console.log("Name: "+data.textName+
  " Email: "+data.textEmail);
  });*/
 
 jQuery(function(){
   
  jQuery("#frmPost").validate({
	 
		submitHandler:function(){
		 var name = jQuery("#textName").val();
		 var email = jQuery("#textEmail").val();
		 var description = encodeURIComponent(tinyMCE.get("desc_id").getContent());
		
	var postdata = "action=custom_plugin_library&param=savedata&email="+email+"&name="+name+"&desc="+description;
		 jQuery.post(ajaxurl, postdata, function(respose){
		   console.log(respose);
		 })
		}
	 });
  
});
 
 
</script>

<?php wp_enqueue_media(); ?>

</head>


<body>
	
<?php 
  
 global $wpdb;
 
 $dbresult = $wpdb->get_row(
    $wpdb->prepare(
	 "SELECT * from wp_table_name order by Id desc limit 1", ''
	)
 );

?>	
		
<?php 
/* global $wpdb;
 
 /*$wpdb->insert("wp_table_name",
 array(
 "name"=>"alamgir",
 "phone"=>"01790079711",
 "email"=>"designeralamgirhosen037@gmail.com"
 )); 
 //$wpdb->query("INSERT into wp_table_name(name,phone,email) VALUES('jhon','01722345678','jhon@gmail.com')");
 
  $wpdb->query(
   $wpdb->prepare(
   "INSERT into wp_table_name(name,phone,email) VALUES('%s','%s','%s')", "admin",'01734568745',"admin@gmail.com"
   )
  ); */

 /* $wpdb->update(
    "wp_table_name",array("email"=>"jhon24@gmail"),array("id"=>3)
  ); 
  
  $wpdb->query(
   $wpdb->prepare(
   "update wp_table_name set email='%s' where id=%d", "admin124@gmail.com",4
   )
  );
  
  $wpdb->delete(
    "wp_table_name",array("id"=>3)
  );
  
  $wpdb->query(
   $wpdb->prepare(
   "delete from wp_table_name where id=%d",4
   )
  );*/
  
?>	
	


	
<form action="#" id="frmPost">
  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" class="form-control" id="textName" required value="<?php echo $dbresult->name; ?>"  name="textName" placeholder="Enter Your Name">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="textEmail" required value="<?php echo $dbresult->email; ?>" name="textEmail" placeholder="Enter your email">
  </div>
  
  <div class="form-group">
    <label for="exampleInputEmail1">Add Desc :</label>
    <?php wp_editor(html_entity_decode($dbresult->describtion),"desc_id",""); ?>
  </div>
  
  <div class="form-group">
    <label for="exampleInputEmail1">Upload Image :</label>
    <input type="button" class="form-control"  id="textimage"  name="textimage" value="Upload Image">
	<img src="" id="getImage" style="height:100px;width: 100px;" alt="img not found" />
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>


</body>
</html>