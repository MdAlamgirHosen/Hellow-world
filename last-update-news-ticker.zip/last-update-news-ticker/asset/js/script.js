
jQuery(function(){
   
   jQuery("#textimage").on("click", function(){
   
    var images = wp.media({
	  title: "Upload Image",
	  multiple: false
	}).open().on("select", function(e){
	 var uploadedImages = images.state().get("selection").first(); // false or single image er jonno .first() function use korte hobe
	 var selectedImages =uploadedImages.toJSON();
	 
	 jQuery("#getImage").attr("src", selectedImages.url);
	 
	 /*
	 //single image er jonno
	 console.log(selectedImages.title+" "+selectedImages.url+" "+selectedImages.filename);
	 
	 // for multiple image er jonno
	  jQuery.each(selectedImages,function(index,image){
	   console.log("Image URL: "+image.url+" adn title: "+image.title);
	  });
	
	 // for useing map
	  selectedImages.map(function(image){
	   var itemDetails = image.toJSON();
	   console.log(itemDetails.url);
	  });
	  
	   */
	});
	
	
   });
  
});

   
