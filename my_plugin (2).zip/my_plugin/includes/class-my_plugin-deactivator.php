<?php

/**
 * Fired during plugin deactivation
 *
 * @link       www.example.com
 * @since      1.0.0
 *
 * @package    My_plugin
 * @subpackage My_plugin/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    My_plugin
 * @subpackage My_plugin/includes
 * @author     Md Alamgir <designeralamgirhosen037@gmail.com>
 */
class My_plugin_Deactivator {

	private $tables;
	public function __construct($tables_object){
	   $this->tables = $tables_object;
	}
	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public function deactivate() {
     
	global $wpdb;
	 $wpdb->query("DROP table IF Exists ".$this->tables->myplugintable());
	}
	
	public function myplugintable(){
	  global $wpdb;
	  return $wpdb->prefix."my_plugin_table";
	}

}
