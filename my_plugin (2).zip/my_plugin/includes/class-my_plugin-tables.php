<?php

/**
 * Fired during plugin table
 *
 * @link       www.example.com
 * @since      1.0.0
 *
 * @package    My_plugin
 * @subpackage My_plugin/includes
 */

/**
 * Fired during plugin table.
 *
 * This class defines all code necessary to run during the plugin's table.
 *
 * @since      1.0.0
 * @package    My_plugin
 * @subpackage My_plugin/includes
 * @author     Md Alamgir <designeralamgirhosen037@gmail.com>
 */
class My_plugin_tables {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	 
	public function myplugintable(){
	  global $wpdb;
	  return $wpdb->prefix."my_plugin_table";
	}

}
