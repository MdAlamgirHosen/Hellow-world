<?php

/**
 * Fired during plugin activation
 *
 * @link       www.example.com
 * @since      1.0.0
 *
 * @package    My_plugin
 * @subpackage My_plugin/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    My_plugin
 * @subpackage My_plugin/includes
 * @author     Md Alamgir <designeralamgirhosen037@gmail.com>
 */
class My_plugin_Activator {

	private $tables;
	public function __construct($tables_object){
	   $this->tables = $tables_object;
	}
	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public function activate() {
	
		 require_once(ABSPATH . 'wp-admin/includes/upgrade.php'); 
		 global $wpdb;
		 if(count($wpdb->get_var("show tables like '".$this->tables->myplugintable()."'")) == 0){
			$sql = 'CREATE TABLE `'.$this->tables->myplugintable().'` (
				 `id` int(11) NOT NULL AUTO_INCREMENT,
				 `name` varchar(255) DEFAULT NULL,
				 `about` text,
				 `email` varchar(255) DEFAULT NULL,
				 `Image` text,
				 `label` text,
				 PRIMARY KEY (`id`)
				) ENGINE=InnoDB DEFAULT CHARSET=utf8';
			
		  dbDelta($sql);	
		 }
	}

	/*
	 //ei khane thaklew hoy better way te construct declar kore korte hobe.
	
	 public function myplugintable(){
	  global $wpdb;
	  return $wpdb->prefix."my_plugin_table";
	}
	
	*/
    
	
}
