<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       www.example.com
 * @since      1.0.0
 *
 * @package    My_plugin
 * @subpackage My_plugin/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    My_plugin
 * @subpackage My_plugin/admin
 * @author     Md Alamgir <designeralamgirhosen037@gmail.com>
 */
class My_plugin_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	
	private $tables;
	
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		
		require_once MYPLUGIN_URL.'/includes/class-my_plugin-tables.php';
		$this->tables = new My_plugin_tables();
	}
  
	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in My_plugin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The My_plugin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( "bootstrap", plugin_dir_url( __FILE__ ) . 'css/bootstrap.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( "dataTables", plugin_dir_url( __FILE__ ) . 'css/jquery.dataTables.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( "notifyBar", plugin_dir_url( __FILE__ ) . 'css/jquery.notifyBar.css', array(), $this->version, 'all' );
		wp_enqueue_style( "my_plugin", plugin_dir_url( __FILE__ ) . 'css/my_plugin-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in My_plugin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The My_plugin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( "bootstrap", plugin_dir_url( __FILE__ ) . 'js/bootstrap.min.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "dataTables", plugin_dir_url( __FILE__ ) . 'js/jquery.dataTables.min.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "jquery", plugin_dir_url( __FILE__ ) . 'js/jquery.min.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "notifyBar", plugin_dir_url( __FILE__ ) . 'js/jquery.notifyBar.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "validate", plugin_dir_url( __FILE__ ) . 'js/jquery.validate.min.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "my_plugin", plugin_dir_url( __FILE__ ) . 'js/my_plugin-admin.js', array( 'jquery' ), $this->version, false );
		
		wp_localize_script("my_plugin","adminajaxurl",admin_url("admin-ajax.php"));
	}
	
	
		// for dashbord menu 

	public function my_plugin_admin_menu() {
	
			add_menu_page( 
				"My Options",//page title
				"my-plugin",//menu title
				"manage_options", //admin level
				"my_plugin_admin",//page slug~parent slug
				array($this,"my_plugin_admin_pages"),//call backfunction
				"dashicons-microphone",//icon
				 //plugins_url( '/asset/img/icon.png', __FILE__ ),
				20
			);
			add_submenu_page( 
				"my_plugin_admin",//parent slug
				"All admin pages",//page title
				"All admin pages",//menu title
				"manage_options",//user level
				"my_plugin_admin", //menu slug
				array($this,"my_plugin_admin_pages")//call backfunction
			);
			
			add_submenu_page( 
				"my_plugin_admin",//parent slug
				"Add New admin",//page title
				"Add New admin",//menu title
				"manage_options",//user level
				"add new admin", //menu slug
				array($this,"my_plugin_admin_pages2")//call backfunction
			);
		}


		public function my_plugin_admin_pages(){
			include_once MYPLUGIN_URL.'/admin/partials/all_admin_page.php';
		}

		public function my_plugin_admin_pages2(){
			include_once MYPLUGIN_URL.'/admin/partials/add_admin_page.php';
		}
		
		
		
		
		// for ajax request code here
		function my_plugin_admin_handle(){
		   $param = isset($_REQUEST['param']) ? $_REQUEST['param']: "";
		   global $wpdb;
		   if(!empty($param) && $param == "save_admin"){
		    $textname = isset($_REQUEST['textname']) ? $_REQUEST['textname'] : "";
		    $textemail = isset($_REQUEST['textemail']) ? $_REQUEST['textemail'] : "";
		    $about = isset($_REQUEST['about']) ? $_REQUEST['about'] : "";
		    $image_url = isset($_REQUEST['image_url']) ? $_REQUEST['image_url'] : "";
		    $label = isset($_REQUEST['label']) ? $_REQUEST['label'] : "";
			$label = json_encode($label);
			
			$wpdb->insert($this->tables->myplugintable(), array(
			 "name" => $textname,
			 "email" => $textemail,
			 "about" => $about,
			 "Image" => $image_url,
			 "label" => $label
			));
			
			if($wpdb->insert_id > 0){
			 echo json_encode(array(
			 "status" =>1,
			 "message" => "successfully Inserted Data"
			 ));
			}
			else{
			 echo json_encode(array(
			 "status" =>0,
			 "message" => "Data Not Inserted"
			 ));
			}
		   }
		   wp_die();
		}

	
	
	

}
