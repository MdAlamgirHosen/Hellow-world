<div class="container">
	<div class="row"> 
	    <div class="panel panel-primary">
		  <div class="panel-heading">Panel Heading</div>
		  <div class="panel-body">
			<table id="example" class="display" style="width:100%">
				<thead>
					<tr>
					    <th>Sl No</th>
						<th>Name</th>
						<th>E-mail</th>
						<th>About Us</th>
						<th>Image</th>
						<th>Lebel</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
				   <?php 
				    global $wpdb;
				    $alldata = $wpdb->get_results(
					   $wpdb->prepare("SELECT * from ".$this->tables->myplugintable()." order by id desc","",ARRAY_A)   
					);
					if(count($alldata) > 0){
					 $i = 1;
					 foreach($alldata as $index => $data){
						?>
						<tr>
						<td><?php echo $i++; ?></td>
						<td><?php echo $data['name'] ?></td>
						<td><?php echo $data['email'] ?></td>
						<td><?php echo $data['about'] ?></td>
						<td><img src="<?php echo $data['Image'] ?>" height="100px" width="100px" alt="" /></td>
						<td><?php 
						   $userlavel = (array)json_decode($data['label']);
						   print_r($userlavel);
						 ?></td>
						<td><a href="javascript:void(0)" class="btn btn-info">Edit | </a>
						    <a href="javascript:void(0)" class="btn btn-danger">Delete</a>
						</td>
					    </tr>
					<?php
					 }
					
					}else{
					  echo "play list not found";
					}
					
				   ?>
				</tbody>
				<tfoot>
					<tr>
						<th>Sl No</th>
						<th>Name</th>
						<th>E-mail</th>
						<th>About Us</th>
						<th>Image</th>
						<th>Lebel</th>
					</tr>
				</tfoot>
			</table>
		  </div>
		</div>
	</div>
</div>