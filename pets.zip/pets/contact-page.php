<?php 
/*
Template Name: Contact Page
*/

?>
<?php get_header(); ?>


<div class="gfmw_full_contianer page_title_gfmws">
	<div class="gfwm_center blogpost">
		<div class="gw_inner  gfmwfix">
				 <p><?php the_title(); ?></p>
		</div>
</div>
</div>




<?php while ( have_posts() ): the_post(); ?>
		

					<?php the_content(); ?>

			<?php if ( ot_get_option('page-comments') == 'on' ) { comments_template('/comments.php',true); } ?>
			
		<?php endwhile; ?>





<?php get_template_part('ltc/request-form'); ?>



<?php get_footer(); ?>