<?php get_header(); ?>



<div class="gfmw_full_contianer page_title_gfmws">
	<div class="gfwm_center blogpost">
		<div class="gw_inner  gfmwfix">
				 <p>Blog</p>
		</div>
</div>
</div>
	
<div class="gfmw_full_contianer singlepost">
	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">

	<section id="ajax-posts" class="postlist">
		
		<?php get_template_part('inc/featured'); ?>
		
		<?php if ( have_posts() ) : ?>
		
			
				<?php $i = 1; echo '<div class="post-row">'; while ( have_posts() ): the_post(); ?>
				<?php get_template_part('content'); ?>
				<?php if($i % 2 == 0) { echo '</div><div class="post-row">'; } $i++; endwhile; echo '</div>'; ?>
		
		
			<?php get_template_part('inc/pagination'); ?>
			
		<?php endif; ?>
		
</section>

	<section class="page_sidebar">
		<?php get_sidebar(); ?> 
		
	</section>
	</div>
</div>
</div>




<?php get_footer(); ?>