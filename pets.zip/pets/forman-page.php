<?php 
/*
Template Name: All Pages
*/

?>
<?php get_header(); ?>
<div class="gfmw_full_contianer headpart_page">
	<div class="gfwm_center blogpost">
		<div class="gw_inner  gfmwfix">
				<div class="img_part_right_gw">
					<img src="http://giftformenwomen.com/wp-content/uploads/2016/11/gifts-for-men-women-gifs-ideas.png" alt="best gifts ideas for men and women - giftformenwomen">
				</div>
				<div class="content_headsty_right">
					<p class="title_of_header"> 
						<span>Gifts For</span> <?php echo lt_giftsfor(); ?> 
					</p>
					<p class="title_of_header headtext_sub"> 
						<?php echo lt_headerdescription(); ?> 
					</p>
				</div>
		</div>
</div>
</div>
<div class="gfmw_full_contianer singlepost">
	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">

	<section id="ajax-posts" class="postlist">

	




<?php 


// the query
$gfmw_query = array(
    'cat'      => array(lt_gifts_catid()),
    'order'    => 'ASC',
    'showposts' => 80
        );
query_posts($gfmw_query);
?>
<?php while (have_posts()) : the_post(); ?>

<div class="page_post_list">
<div class="img_pagepost"> <a class="post_norlink" href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'single-post-thumbnail' ); ?></a></div>
<a class="page_post_title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
<a class="button_bottom_gwbox_post" href="<?php the_permalink(); ?>"> Read More	&rarr;</a>
</div>
<?php endwhile; wp_reset_postdata(); ?>


</section>

	<section class="page_sidebar">
		<?php get_sidebar(); ?> 
		
	</section>
	</div>
</div>
</div>




<div class="gfmw_full_contianer page_simple_content">
	<div class="gfwm_center blogpost">
		<div class="gw_inner pagesimple_content gfmwfix">
				
			
			<?php while ( have_posts() ): the_post(); ?>
		

					<?php the_content(); ?>

			<?php if ( ot_get_option('page-comments') == 'on' ) { comments_template('/comments.php',true); } ?>
			
		<?php endwhile; ?>

		
		
		</div>
</div>
</div>























<?php get_footer(); ?>