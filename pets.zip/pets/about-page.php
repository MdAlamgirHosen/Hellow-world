<?php 
/*
Template Name: Who We Are Page
*/

?>
<?php get_header(); ?>


<?php get_template_part('ltc/pagetitle'); ?>
<?php if ( ot_get_option( 'banner_about' ) !='off'): ?>
<?php get_template_part('ltc/aboutpagebanner'); ?>
<?php endif; ?>
<?php get_template_part('ltc/aboutpage'); ?>
<?php if ( ot_get_option( 'recent_about' ) !='off'): ?>
<?php get_template_part('ltc/recentdesign'); ?>
<?php endif; ?>
<?php if ( ot_get_option( 'designpro_about' ) !='off'): ?>
<?php get_template_part('ltc/designprocess'); ?>
<?php endif; ?>
<?php if ( ot_get_option( 'responsive_about' ) !='off'): ?>
<?php get_template_part('ltc/responsive'); ?>
<?php endif; ?>
<?php if ( ot_get_option( 'start_about' ) !='off'): ?>
<?php get_template_part('ltc/starttime'); ?>
<?php endif; ?>
<?php if ( ot_get_option( 'whyus_about' ) !='off'): ?>
<?php get_template_part('ltc/why'); ?>
<?php endif; ?>
<?php if ( ot_get_option( 'testimonial_about' ) !='off'): ?>
<?php get_template_part('ltc/clienttalk'); ?>
<?php endif; ?>
<?php if ( ot_get_option( 'ready_about' ) !='off'): ?>
<?php get_template_part('ltc/ready'); ?>
<?php endif; ?>




<?php get_footer(); ?>