<?php get_header(); ?>
<?php
    $images = rwmb_meta( 'image_upload', 'type=image_advanced&size=ful' ); // Prior to 4.8.0
	
    if ( !empty( $images ) ) {
        foreach ( $images as $image ) {
            $images_bg =  $image['url'];
        }
    }
	
$title_header =  do_shortcode( rwmb_meta( 'model_s_prefix_wysiwyg' ) );
   
	
?>

<div style="background:url('<?php if (!empty ($images_bg)){echo $images_bg;}else{echo "http://losangelesbodyrubs.com/wp-content/themes/losangelesbodyrubs/images/bg-home-slide.jpg";} ?>') center top no-repeat;" class="gfmw_full_contianer topbanners">
	<div class="gfwm_center blogpost">
		<div class="gw_inner header-parttitle ">
			<div class="hoverimage_text_mod"><?php echo $title_header; ?> </div>
		</div>
</div>
</div>


<div  class="gfmw_full_contianer singlepost">

	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">
<section class="content modelPart">
	
	
	
	<div class="content_post_inner">
		<div class="content_post">
		<?php while ( have_posts() ): the_post(); ?>
			<article <?php post_class(); ?>>	
				<div class="post-inner group">
					
					<div class="model_titlebox" ><h1 class="post-title"><?php the_title(); ?></h1><div class="border_lines"> </div></div>
					
					<?php do_shortcode('[multiple_images]'); ?>
					
					<?php if( get_post_format() ) { get_template_part('inc/post-formats'); } ?>
					
					
					
					<div class="entry">	
						<div class="entry-inner">
						<div class="ownerdetains">
<div class="about_model_text">
<div class="model_titlebox" ><h2> About <?php the_title(); ?></h2><div class="border_lines"> </div></div>
<div class="model_dessetting body_shn"><?php the_content(); ?></div>
</div>

</div>
							
							
							<?php wp_link_pages(array('before'=>'<div class="post-pages">'.__('Pages:','GFMW'),'after'=>'</div>')); ?>
						</div>
						<div class="clear"></div>				
					</div><!--/.entry-->
					
				</div><!--/.post-inner-->	
			</article><!--/.post-->				
		<?php endwhile; ?>
		
		<div class="clear"></div>
		
		<?php the_tags('<p class="post-tags"><span>'.__('Tags:','GFMW').'</span> ','','</p>'); ?>
		
		
		
		<?php // if ( ot_get_option( 'post-nav' ) == 'content') { get_template_part('inc/post-nav'); } ?>
		
		
		
		
		
	</div>
	</div>
	
<!--
<div class="gfmw_related_product">
	<?php // if ( ot_get_option( 'related-posts' ) != '1' ) { get_template_part('inc/related-posts'); } ?>
	</div>
	<div class="gfmw_comment_abox">
	<?php  //comments_template('/comments.php',true); ?>
	</div>-->
</section>

<section class="sidebar_gfmw">

<?php get_sidebar(model); ?> 

</section>




</div>
	</div>
	
</div>


<?php get_footer(); ?>