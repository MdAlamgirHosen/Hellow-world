<?php get_header(); ?>
<?php get_template_part('inc/page-title'); ?>
<div class="gfmw_full_contianer singlepost">

	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">
<section class="content cat_seach_wm">

	
	
	
		<?php if ((category_description() != '') && !is_paged()) : ?>
			<div class="notebox">
				<?php echo category_description(); ?>
			</div>
		<?php endif; ?>
		
		<?php if ( have_posts() ) : ?>
		
			<div class="post-list group">
				<?php $i = 1; echo '<div class="post-row">'; while ( have_posts() ): the_post(); ?>
				<?php get_template_part('content'); ?>
				<?php if($i % 2 == 0) { echo '</div><div class="post-row">'; } $i++; endwhile; echo '</div>'; ?>
			</div><!--/.post-list-->
		
			<?php get_template_part('inc/pagination'); ?>
			
		<?php endif; ?>
		
	
	
</section><!--/.content-->
<section class="page_sidebar">
<?php get_sidebar(); ?> 
</section>
</div>
	</div>
	
</div>



<?php get_footer(); ?>