<?php // footer widgets ?>


<!-------------------Footer start------------------------->
<footer id="footer">

<div class="gfmw_full_contianer page_copyright">
	<div class="gfwm_center blogpost">
		<div class="gw_inner copyright_gw gfmwfix">
<?php if ( ot_get_option( 'copyrighttext' ) ): ?>
<p class="copy_r">
<?php echo ot_get_option( 'copyrighttext' ); ?> © <?php echo date( 'Y' ); ?> <span><?php echo ot_get_option( 'copyright' ); ?></span>. All rights reserved.
</p>
<?php else: ?>
<p class="copy_rn">
Los Angeles Body Rubs  © <?php echo date( 'Y' ); ?> <span>losangelesbodyrubs.com</span>. All rights reserved.
</p>
<?php endif; ?>


</div>
</div>
</div>
</footer>
<!-------------------Footer Section End------------------------->		
<?php if ( ot_get_option( 'scroll_totop' ) !='off'): ?>
<a class="back-to-top" href="#">back to top  </a>
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>