<?php 


?>



<div class="today_bMain headBn_contact">

<div class="container">

<div style="width:100%;  height:auto; position:relative; float:left;">
<?php if ( ot_get_option('conbntitle')): ?>
<p class="workonp">
   <?php echo ot_get_option('conbntitle'); ?>
   </p>
    <?php else: ?>
   <p class="workonp">
    We have handcrafted over 4000 dynamic websites and over 1000 unique logo designs
   </p>
   <?php endif; ?> 
   <?php if ( ot_get_option('conbndesc')): ?>
<p class="workonps">
    <?php echo ot_get_option('conbndesc'); ?>
   </p>
   <?php else: ?>
   <p class="workonps">
    From fashion to finance, non-profit to new startup, education to ecommerce and everything
   </p>
    <?php endif; ?> 
</div>

</div>

</div>
