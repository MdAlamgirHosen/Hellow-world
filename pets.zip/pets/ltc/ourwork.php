<?php 


?>



<div class="today_bMain wMid">

<div class="container">

<div style="width:100%;  height:auto; position:relative; float:left;">
 <?php if ( ot_get_option('titlework')): ?>
<p class="portp"> 
 <?php echo ot_get_option('titlework'); ?>
</P>
<?php else: ?>
<p class="portp"> 
We have handcrafted over 4000 dynamic websites
and over 1000 unique logo designs
</P>
<?php endif; ?> 
 <?php if ( ot_get_option('sortdeswork')): ?>
<p class="portps">
<?php echo ot_get_option('sortdeswork'); ?>
</P>
<?php else: ?>
<p class="portps">
From fashion to finance, non-profit to new startup, education to ecommerce and everything in between. Here are a handful of our clients from a variety of industries to show case our work. Enjoy!
</P>
<?php endif; ?> 
</div>
<div style="width:100%;  height:auto; position:relative; float:left;">
<ul class="grid cs-style-6">
				<li>
					<figure>
					 <?php if ( ot_get_option('worksite-1')): ?>
					 <img src="<?php echo ot_get_option('worksite-1'); ?>" alt="our client 1">
					 <?php else: ?>
							<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/tequilaqv.jpg" alt="our client 1">
							<?php endif; ?> 
						<figcaption>
						<?php if ( ot_get_option('sitestitle-1')): ?>
							<h3><?php echo ot_get_option('sitestitle-1'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('sitedesc-1')): ?>
							<p><?php echo ot_get_option('sitedesc-1'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>							
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('worksite-2')): ?>
						<img src="<?php echo ot_get_option('worksite-2'); ?>" alt="our client 2">
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/any-dish.jpg" alt="our client 2">
						<?php endif; ?> 
						<figcaption>
							<?php if ( ot_get_option('sitestitle-2')): ?>
							<h3><?php echo ot_get_option('sitestitle-2'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('sitedesc-2')): ?>
							<p><?php echo ot_get_option('sitedesc-2'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('worksite-3')): ?>
						<img src="<?php echo ot_get_option('worksite-3'); ?>" alt="our client 3">
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/unowe.jpg" alt="our client 3">
						<?php endif; ?> 
						<figcaption>
						<?php if ( ot_get_option('sitestitle-3')): ?>
							<h3><?php echo ot_get_option('sitestitle-3'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('sitedesc-3')): ?>
							<p><?php echo ot_get_option('sitedesc-3'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('worksite-4')): ?>
						<img src="<?php echo ot_get_option('worksite-4'); ?>" alt="our client 4">
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/mortgage-freedom.jpg" alt="our client 4">
						<?php endif; ?> 
						<figcaption>
							<?php if ( ot_get_option('sitestitle-4')): ?>
							<h3><?php echo ot_get_option('sitestitle-4'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('sitedesc-4')): ?>
							<p><?php echo ot_get_option('sitedesc-4'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('worksite-5')): ?>
						<img src="<?php echo ot_get_option('worksite-5'); ?>" alt="our client 5">
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/nj-auto-exports.jpg" alt="our client 5">
						<?php endif; ?> 
						<figcaption>
							<?php if ( ot_get_option('sitestitle-5')): ?>
							<h3><?php echo ot_get_option('sitestitle-5'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('sitedesc-5')): ?>
							<p><?php echo ot_get_option('sitedesc-5'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('worksite-6')): ?>
						<img src="<?php echo ot_get_option('worksite-6'); ?>" alt="our client 6">
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/crnla.jpg" alt="our client 6">
						<?php endif; ?> 
						<figcaption>
							<?php if ( ot_get_option('sitestitle-6')): ?>
							<h3><?php echo ot_get_option('sitestitle-6'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('sitedesc-6')): ?>
							<p><?php echo ot_get_option('sitedesc-6'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('worksite-7')): ?>
						<img src="<?php echo ot_get_option('worksite-7'); ?>" alt="our client 7>
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/trust-business-funding.jpg" alt="our client 7">
						<?php endif; ?> 
						<figcaption>
							<?php if ( ot_get_option('sitestitle-7')): ?>
							<h3><?php echo ot_get_option('sitestitle-7'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('sitedesc-7')): ?>
							<p><?php echo ot_get_option('sitedesc-7'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('worksite-8')): ?>
						<img src="<?php echo ot_get_option('worksite-8'); ?>" alt="our client 8>
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/sunny-hills.jpg" alt="our client 8">
						<?php endif; ?> 
						<figcaption>
							<?php if ( ot_get_option('sitestitle-8')): ?>
							<h3><?php echo ot_get_option('sitestitle-8'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('sitedesc-8')): ?>
							<p><?php echo ot_get_option('sitedesc-8'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('worksite-9')): ?>
						<img src="<?php echo ot_get_option('worksite-9'); ?>" alt="our client 9>
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/veteran-creative-arts.jpg" alt="our client 9">
						<?php endif; ?> 
						<figcaption>
							<?php if ( ot_get_option('sitestitle-9')): ?>
							<h3><?php echo ot_get_option('sitestitle-9'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('sitedesc-9')): ?>
							<p><?php echo ot_get_option('sitedesc-9'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('worksite-10')): ?>
						<img src="<?php echo ot_get_option('worksite-10'); ?>" alt="our client 10>
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/del-mar-wire.jpg" alt="our client 10">
						<?php endif; ?> 
						<figcaption>
							<?php if ( ot_get_option('sitestitle-10')): ?>
							<h3><?php echo ot_get_option('sitestitle-10'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('sitedesc-10')): ?>
							<p><?php echo ot_get_option('sitedesc-10'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('worksite-11')): ?>
						<img src="<?php echo ot_get_option('worksite-11'); ?>" alt="our client 11>
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/bright-harbor-advisors.jpg" alt="our client 11">
						<?php endif; ?> 
						<figcaption>
							<?php if ( ot_get_option('sitestitle-11')): ?>
							<h3><?php echo ot_get_option('sitestitle-11'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('sitedesc-11')): ?>
							<p><?php echo ot_get_option('sitedesc-11'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('worksite-12')): ?>
						<img src="<?php echo ot_get_option('worksite-12'); ?>" alt="our client 12>
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/today-credit-repair.jpg" alt="our client 12">
						<?php endif; ?> 
						<figcaption>
							<?php if ( ot_get_option('sitestitle-12')): ?>
							<h3><?php echo ot_get_option('sitestitle-12'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('sitedesc-12')): ?>
							<p><?php echo ot_get_option('sitedesc-12'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('worksite-13')): ?>
						<img src="<?php echo ot_get_option('worksite-13'); ?>" alt="our client 13>
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/a-top-transportation.jpg" alt="our client 13">
						<?php endif; ?> 
						<figcaption>
							<?php if ( ot_get_option('sitestitle-13')): ?>
							<h3><?php echo ot_get_option('sitestitle-13'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('sitedesc-13')): ?>
							<p><?php echo ot_get_option('sitedesc-13'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('worksite-14')): ?>
						<img src="<?php echo ot_get_option('worksite-14'); ?>" alt="our client 14>
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/valley-direct.jpg" alt="our client 14">
						<?php endif; ?> 
						<figcaption>
							<?php if ( ot_get_option('sitestitle-14')): ?>
							<h3><?php echo ot_get_option('sitestitle-14'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('sitedesc-14')): ?>
							<p><?php echo ot_get_option('sitedesc-14'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('worksite-15')): ?>
						<img src="<?php echo ot_get_option('worksite-15'); ?>" alt="our client 15>
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/us-start-up-business-loans.jpg" alt="our client 15">
						<?php endif; ?> 
						<figcaption>
							<?php if ( ot_get_option('sitestitle-15')): ?>
							<h3><?php echo ot_get_option('sitestitle-15'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('sitedesc-15')): ?>
							<p><?php echo ot_get_option('sitedesc-15'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
			</ul>
</div>
</div>
</div>