<?php 


?>






<div class="today_bMain bg-computers">
<div class="container">
<div style="width:100%;  height:auto; position:relative; float:left;">
<?php if ( ot_get_option('midbtitle')): ?>
<p class="mRespon_p">
   <?php echo ot_get_option('midbtitle'); ?>
   </p>
    <?php else: ?>
<p class="mRespon_p tech-co">
   Just some of our  <span class="tech-splitbold">online computer services. </span> <span class="tech-split">we don't charge per issue like that others! </span>
   </p>
  <?php endif; ?> 
 
 <div class="tech-global sixbox">
	<div class="six-service-box">
	<img src="http://localhost/techshelpme/wordpress/wp-content/themes/techshelpme/images/our-work/virus-home-re.png" class="sixboximage">
	<p class="text-title"> 
	Virus removal
	</p>
	<p class="text-title norcom"> 
	 Newbird is a lean, senior-level team, based out of Buffalo, NY. What value do we bring to your business? We have the well-refined processes of a large ad agency without a bloated team 
	</p>
	</div>
	
	<div class="six-service-box">
	<img src="http://localhost/techshelpme/wordpress/wp-content/themes/techshelpme/images/our-work/pc-tune-home-re.png" class="sixboximage">
	<p class="text-title"> 
	PC Tune up
	</p>
	<p class="text-title norcom"> 
	 Newbird is a lean, senior-level team, based out of Buffalo, NY. What value do we bring to your business? We have the well-refined processes of a large ad agency without a bloated team 
	</p>
	</div>
	
	<div class="six-service-box">
	<img src="http://localhost/techshelpme/wordpress/wp-content/themes/techshelpme/images/our-work/software-home-re.png" class="sixboximage">
	<p class="text-title"> 
	Software Installation
	</p>
	<p class="text-title norcom"> 
	 Newbird is a lean, senior-level team, based out of Buffalo, NY. What value do we bring to your business? We have the well-refined processes of a large ad agency without a bloated team 
	</p>
	</div>
	
	<div class="six-service-box">
	<img src="http://localhost/techshelpme/wordpress/wp-content/themes/techshelpme/images/our-work/file-transfer-honmere.png" class="sixboximage">
	<p class="text-title"> 
	File Transfer
	</p>
	<p class="text-title norcom"> 
	 Newbird is a lean, senior-level team, based out of Buffalo, NY. What value do we bring to your business? We have the well-refined processes of a large ad agency without a bloated team 
	</p>
	</div>
	
	<div class="six-service-box">
	<img src="http://localhost/techshelpme/wordpress/wp-content/themes/techshelpme/images/our-work/data-backup-home.png" class="sixboximage">
	<p class="text-title"> 
	Data Backup
	</p>
	<p class="text-title norcom"> 
	 Newbird is a lean, senior-level team, based out of Buffalo, NY. What value do we bring to your business? We have the well-refined processes of a large ad agency without a bloated team 
	</p>
	</div>
	
	<div class="six-service-box">
	<img src="http://localhost/techshelpme/wordpress/wp-content/themes/techshelpme/images/our-work/wirless-networkhome.png" class="sixboximage">
	<p class="text-title"> 
	Wireless Networking Setup 
	</p>
	<p class="text-title norcom"> 
	 Newbird is a lean, senior-level team, based out of Buffalo, NY. What value do we bring to your business? We have the well-refined processes of a large ad agency without a bloated team 
	</p>
	</div>

</div>

</div>
</div>
</div>























