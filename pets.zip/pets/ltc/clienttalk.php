<?php 


?>



<div class="today_bMain clienttesti">

<div class="container">

<div class="websites_" style="width:100%;  height:auto; position:relative; float:left;">
 <?php if ( ot_get_option('client_head_title')): ?>
<h1><?php echo ot_get_option('client_head_title'); ?> </h1>
<?php else: ?>
<h1>What our Clients Say </h1>
<?php endif; ?>
 <?php if ( ot_get_option('client_top_des')): ?>
<p>
<?php echo ot_get_option('client_top_des'); ?>
</p>
<?php else: ?>
<p>
See What our Customers have to Say about our Remarkable Design Services
</p>
<?php endif; ?>
</div>
<div class="design_s" style="width:100%;  height:auto; position:relative; float:left;">

<div class="pro_box_c">
      <?php if ( ot_get_option('client_img_1')): ?>
      <img src="<?php echo ot_get_option('client_img_1'); ?>">
	  <?php else: ?>
	  <img src="<?php echo get_template_directory_uri(); ?>/images/process_1.png">
	 <?php endif; ?>
	 <?php if ( ot_get_option('client_title_1')): ?>
	  <p class="pro_scon_c">    <?php echo ot_get_option('client_title_1'); ?></p>
	   <?php else: ?>
	   <p class="pro_scon_c">    Requirement Gathering</p>
	    <?php endif; ?>
		<?php if ( ot_get_option('client_des_1')): ?>
	  <p class="pro_des_c"> 
<?php echo ot_get_option('client_des_1'); ?>
	  </p>
	    <?php else: ?>
	   <p class="pro_des_c"> 
	  The first phase of the project cycle involves laying out the client’s objectives and making an initial survey of the project’s technical requirements. We contact in person, by email or a phone call, whatever you feel most comfortable with.
	  </p>
	   <?php endif; ?>
     
</div>
<div class="pro_box_c">
     
      <?php if ( ot_get_option('client_img_2')): ?>
      <img src="<?php echo ot_get_option('client_img_2'); ?>">
	  <?php else: ?>
	  <img src="<?php echo get_template_directory_uri(); ?>/images/process_1.png">
	 <?php endif; ?>
	 <?php if ( ot_get_option('client_title_2')): ?>
	  <p class="pro_scon_c">    <?php echo ot_get_option('client_title_2'); ?></p>
	   <?php else: ?>
	   <p class="pro_scon_c">    Requirement Gathering</p>
	    <?php endif; ?>
		<?php if ( ot_get_option('client_des_3')): ?>
	  <p class="pro_des_c"> 
<?php echo ot_get_option('client_des_3'); ?>
	  </p>
	    <?php else: ?>
	   <p class="pro_des_c"> 
	  The first phase of the project cycle involves laying out the client’s objectives and making an initial survey of the project’s technical requirements. We contact in person, by email or a phone call, whatever you feel most comfortable with.
	  </p>
	   <?php endif; ?>
</div>
<a class="a_buttons_c" href="">
 More Client Testimonials
</a>

</div>

</div>
</div>