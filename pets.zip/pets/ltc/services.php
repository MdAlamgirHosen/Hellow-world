<?php 


?>


<div class="today_bMain mTcenter">


<div class="today_bMain mTcenterM">
<div class="container">
   
<div class="box_center c_idea">
<div class="imgbox">
<?php if ( ot_get_option('serlink-1')): ?>
 <a href=" <?php echo ot_get_option('serlink-1'); ?> " class=""> 
  <?php else: ?>	
  <a href=" <?php echo site_url(); ?> " class=""> 
 <?php endif; ?>
<?php if ( ot_get_option('serimg-1')): ?>
<img class="icon_img_1" src="<?php echo ot_get_option('serimg-1'); ?>">
 <?php else: ?>	
<img class="icon_img_1" src="<?php echo get_template_directory_uri();?>/images/icons/computer-repair-icon-home.png">
 <?php endif; ?>
</a>
</div>
 <?php if ( ot_get_option('ser-title-1')): ?>
<p class="imgbox_p">
   <?php echo ot_get_option('ser-title-1'); ?>
 </p>
  <?php else: ?>	
 <p class="imgbox_p">
   computer repair
 </p>
 <?php endif; ?>
  <?php if ( ot_get_option('ser-des-1')): ?>
 <p class="imgbox_ps">
  <?php echo ot_get_option('ser-des-1'); ?>
 </p>
   <?php else: ?>	
  <p class="imgbox_ps">
   Newbird is a lean, senior-level team, based out of Buffalo, NY. What value do we bring to your business? We have the well-refined processes of a large ad agency without a bloated team 
 </p>
  <?php endif; ?>
  <p class="more_info_aling">
  <a href="" class="moreinfo"> More Info</a>
  </p>
</div>
<div class="box_center c_idea">
<div class="imgbox">
<?php if ( ot_get_option('serlink-2')): ?>
 <a href=" <?php echo ot_get_option('serlink-2'); ?> " class=""> 
  <?php else: ?>	
  <a href=" <?php echo site_url(); ?> " class=""> 
 <?php endif; ?>
<?php if ( ot_get_option('serimg-2')): ?>
<img class="icon_img_1" src="<?php echo ot_get_option('serimg-2'); ?>">
 <?php else: ?>	
<img class="icon_img_1" src="<?php echo get_template_directory_uri();?>/images/icons/computer-repair-services.png">
 <?php endif; ?>

</a>
</div>
 <?php if ( ot_get_option('ser-title-2')): ?>
<p class="imgbox_p">
   <?php echo ot_get_option('ser-title-2'); ?>
 </p>
  <?php else: ?>	
 <p class="imgbox_p">
   Our Services
 </p>
 <?php endif; ?>
 
  <?php if ( ot_get_option('ser-des-2')): ?>
 <p class="imgbox_ps">
  <?php echo ot_get_option('ser-des-2'); ?>
 </p>
   <?php else: ?>	
  <p class="imgbox_ps">
    Newbird is a lean, senior-level team, based out of Buffalo, NY. What value do we bring to your business? We have the well-refined processes of a large ad agency without a bloated team 
 </p>
 
  <?php endif; ?>
  <p class="more_info_aling">
  <a href="" class="moreinfo"> More Info</a>
  </p>
</div>
<div class="box_center c_idea">
<div class="imgbox">
<?php if ( ot_get_option('serlink-3')): ?>
 <a href=" <?php echo ot_get_option('serlink-3'); ?> " class=""> 
  <?php else: ?>	
  <a href=" <?php echo site_url(); ?> " class=""> 
 <?php endif; ?>
<?php if ( ot_get_option('serimg-3')): ?>
<img class="icon_img_1" src="<?php echo ot_get_option('serimg-3'); ?>">
 <?php else: ?>	
<img class="icon_img_1" src="<?php echo get_template_directory_uri();?>/images/icons/computer-repair-support.png">
 <?php endif; ?>

</a>
</div>
 <?php if ( ot_get_option('ser-title-3')): ?>
<p class="imgbox_p">
   <?php echo ot_get_option('ser-title-3'); ?>
 </p>
  <?php else: ?>	
 <p class="imgbox_p">
   Our Support 
 </p>
 <?php endif; ?>
 
  <?php if ( ot_get_option('ser-des-3')): ?>
 <p class="imgbox_ps">
  <?php echo ot_get_option('ser-des-3'); ?>
 </p>
   <?php else: ?>	
  <p class="imgbox_ps">
   Newbird is a lean, senior-level team, based out of Buffalo, NY. What value do we bring to your business? We have the well-refined processes of a large ad agency without a bloated team 
 </p>
  <?php endif; ?>
  <p class="more_info_aling">
  <a href="" class="moreinfo"> More Info</a>
  </p>
</div>

</div>
</div>


</div>
















