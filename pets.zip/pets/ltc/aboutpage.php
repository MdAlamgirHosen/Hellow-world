<?php 


?>



<div class="today_bMain ser-1">

<div class="container">
<div class="ser_box_sec">

<div style="width:100%;  height:auto; position:relative; float:left;">
<?php if ( ot_get_option('abouttitle-1')): ?>
<p class="ser_p"> <?php echo ot_get_option('abouttitle-1'); ?></p>
 <?php else: ?>
<p class="ser_p"> About Design Angeles</p>
<?php endif; ?>

</div>

<div class="ser-boxs">
<?php if ( ot_get_option('abo_img-1')): ?>
<img class="creative-d" src="<?php echo ot_get_option('abo_img-1'); ?>">
 <?php else: ?>
<img class="creative-d" src="http://www.corvusart.com/images/svc-websites.jpg">
<?php endif; ?>

<?php if ( ot_get_option('abo_des-1')): ?>
<?php echo ot_get_option('abo_des-1'); ?>
 <?php else: ?>
<p class="ser_box_ah"> VISUAL IDENTITY</p>
<p class="ser_box_ps"> everything in between. Here are a handful of our clients from a variety of industries to show case our work. Enjoy! From fashion to finance, non-profit to new startup,</p>

<p class="ser-sml">
From fashion to finance, non-profit to new startup, education to ecommerce and everything in between. Here are a handful of 
our clients from a variety of industries to show case our work. Enjoy! From fashion to finance, non-profit to new startup,<br> <br>education to ecommerce and everything in between. Here are a handful of our clients from a variety of industries to show case our work. Enjoy!
From fashion to finance, 
</p>
<a multilinks-noscroll="true" href="" class="ser-c" data-hover="View More"><span>View More</span></a>
<?php endif; ?>
</div>

<div class="ser-boxs">
<?php if ( ot_get_option('abo_img-2')): ?>
<img class="creative-d" src="<?php echo ot_get_option('abo_img-2'); ?>">
 <?php else: ?>
<img class="creative-d" src="http://www.corvusart.com/images/svc-websites.jpg">
<?php endif; ?>

<?php if ( ot_get_option('abo_des-2')): ?>
<?php echo ot_get_option('abo_des-2'); ?>
 <?php else: ?>
<p class="ser_box_ah"> VISUAL IDENTITY</p>
<p class="ser_box_ps"> everything in between. Here are a handful of our clients from a variety of industries to show case our work. Enjoy! From fashion to finance, non-profit to new startup,</p>

<p class="ser-sml">
From fashion to finance, non-profit to new startup, education to ecommerce and everything in between. Here are a handful of 
our clients from a variety of industries to show case our work. Enjoy! From fashion to finance, non-profit to new startup,<br> <br>education to ecommerce and everything in between. Here are a handful of our clients from a variety of industries to show case our work. Enjoy!
From fashion to finance, 
</p>
<a multilinks-noscroll="true" href="" class="ser-c" data-hover="View More"><span>View More</span></a>
<?php endif; ?>
</div>

<div class="ser-boxs">
<?php if ( ot_get_option('abo_img-3')): ?>
<img class="creative-d" src="<?php echo ot_get_option('abo_img-3'); ?>">
 <?php else: ?>
<img class="creative-d" src="http://www.corvusart.com/images/svc-websites.jpg">
<?php endif; ?>

<?php if ( ot_get_option('abo_des-3')): ?>
<?php echo ot_get_option('abo_des-3'); ?>
 <?php else: ?>
<p class="ser_box_ah"> VISUAL IDENTITY</p>
<p class="ser_box_ps"> everything in between. Here are a handful of our clients from a variety of industries to show case our work. Enjoy! From fashion to finance, non-profit to new startup,</p>

<p class="ser-sml">
From fashion to finance, non-profit to new startup, education to ecommerce and everything in between. Here are a handful of 
our clients from a variety of industries to show case our work. Enjoy! From fashion to finance, non-profit to new startup,<br> <br>education to ecommerce and everything in between. Here are a handful of our clients from a variety of industries to show case our work. Enjoy!
From fashion to finance, 
</p>
<a multilinks-noscroll="true" href="" class="ser-c" data-hover="View More"><span>View More</span></a>
<?php endif; ?>
</div>
</div>
</div>
</div>
