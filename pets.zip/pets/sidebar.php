
<div class="sidebar s1">
	<div class="sideber_recentpost">
<h2>Recent Posts</h2>
<ul>
<?php
	
	$recent_posts = wp_get_recent_posts(  );
	
	foreach( $recent_posts as $recent ){
		echo  '<li><a href="' . get_permalink($recent["ID"]) . '">' . '<div class="img_box_recent">'. get_the_post_thumbnail($recent["ID"]). '</div>'.'<div class="title_box_recent">'.  $recent["post_title"].'</div></a> </li>'. "\n";
	}
	wp_reset_query();
	
?>
</ul>

<div>

		
		<a class="sidebar-toggle" title="<?php _e('Expand Sidebar','GFMW'); ?>"><i class="fa icon-sidebar-toggle"></i></a>
		
		<div class="sidebar-content">
			
			<?php if ( ot_get_option('sidebar-top') != 'off' ): ?>
			<div class="sidebar-top group">
				
			
			</div>
			<?php endif; ?>
			
			
			
			<?php dynamic_sidebar($sidebar); ?>
			
		</div><!--/.sidebar-content-->
		
</div><!--/.sidebar-->
