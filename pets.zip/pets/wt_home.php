<?php 

/*
Template Name: Home Page
*/

get_header(); 
?>

<section class="slider_area"> 
    <div class="wt_container">
	   <div class="wt_header">
	
		  <div class="slider_ovarlay_left">
			<h2>Let's make<br/><span>Your pet healthy</span></h2>
			<p class="text_link"><a href="#">24/7 supervision for your pets</a></p>
	      </div><!--End of slider_ovarlay_left Area-->

		  <div class="slider_ovarlay_right">
			  <form class="form_area">
				<div class="form-group12 text-center">
				   <h3>Contact Us Now</h3>
				   <h5>Please file out the form below</h5>
				  <input type="text" class="form-control" placeholder="Name">
				  <input type="email" class="form-control" placeholder="E-mail">
				  <input type="tel:" class="form-control" placeholder="Phone No">
				  <input type="text" class="form-control" placeholder="Zip Code">
				  <button type="submit" class="form-cont">Submit Form!</button>
				</div>
			   </form>
	      </div><!--End of slider_ovarlay_left Area-->  
      </div>
	</div>
  </section> 
  
  <section class="main_title_area"> 
    <div class="wt_container">
	   <div class="wt_header">
	
		  <div class="main_title_left">
			 <div class="title"> 
			   <h2>Main title Goes here</h2>
			   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
			 </div>
			 
			 <div class="main_item"> 
			    <div class="item_one"> 
				  <i class="fa fa-paw" aria-hidden="true"></i>
				  <h3>Care Advice</h3>
				  <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
				  <a href="#">Read More</a>
				</div>
				
				<div class="item_one"> 
				  <i class="fa fa-paw" aria-hidden="true"></i>
				  <h3>Veterinari Help</h3>
				  <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
				  <a href="#">Read More</a>
				</div>
				
				<div class="item_one"> 
				  <i class="fa fa-paw" aria-hidden="true"></i>
				  <h3>Our Tips</h3>
				  <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
				  <a href="#">Read More</a>
				</div>
				
			 </div>
	      </div><!--End of slider_ovarlay_left Area-->  
		  
      </div>
	</div>
  </section> 

  <section class="join_title_area"> 
    <div class="wt_container">
	   <div class="wt_header">
	
		  <div class="join_title_left">
			<div class="sub_title"> 
			   <div class="title"> 
			     <h2 style="padding:20px;">NEWS & EVENTS</h2>
			   </div>
			   
			   <div class="main_two">
			      <div class="main_right_two"> 
				    <h2>NEWSLETTER SIGN UP</h2>
					 <form class="form_area">
						  <input type="email" class="form-co" placeholder="Enter Your E-mail Address">
						  <button type="submit" class="form-cont1">Join!</button>
					   </form>
				 </div>
			   
			     <div class="main_left_one"> 
				    <h2>FRESH NEWS</h2>
					<div class="articale"> 
					  <p><span>26</span> <a href="#">For information on booking your holiday reservation at Dog Club, please, visit our website. </a></p>  
					  
					  <p><span>20</span> <a href="#">Thank you all for helping to make our first Thanksgiving go so smoothly by making reservation early.</a></p>

					  <p><span>09</span> <a href="#">Please, come out and support our adoption event on December 12th & 19th.</a></p>
					</div>
				 </div>

				
			   </div>
			</div> 
	      </div><!--End of slider_ovarlay_left Area-->  
      </div>
	</div>
  </section> 

  <section class="join_title_area"> 
    <div class="wt_container">
	   <div class="wt_header">
	    
		 <div class="map">
	     <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7303.803080131352!2d90.40349417204219!3d23.7508902585447!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b88fda6db2cd%3A0x26a089bb7f271620!2sMoghbazar+Bus+Stop!5e0!3m2!1sen!2s!4v1499182357351" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe> 
		 </div>
      </div>
	</div>
  </section>  
 


<?php get_footer(); ?>