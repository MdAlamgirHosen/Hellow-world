<?php 
/*

Template Name: Blog

*/


get_header(); 

?>

<?php get_template_part('ltc/pagetitle'); ?>

<div class="today_bMain pagebg">

<div class="container">

<div style="width:100%;  height:auto; position:relative; float:left;">
<?php while ( have_posts() ): the_post(); ?>
		

					<?php the_content(); ?>

			<?php if ( ot_get_option('page-comments') == 'on' ) { comments_template('/comments.php',true); } ?>
			
		<?php endwhile; ?>
</div>

</div>

</div>
<?php get_footer(); ?>