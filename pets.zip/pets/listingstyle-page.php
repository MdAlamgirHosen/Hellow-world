<?php 
/*
Template Name: Listing Style
*/

?>
<?php get_header(); ?>

<div class="gfmw_full_contianer page_title_gfmws">
	<div class="gfwm_center blogpost">
		<div class="gw_inner  gfmwfix">
				 <p><?php the_title(); ?></p>
		</div>
</div>
</div>
<div class="gfmw_full_contianer singlepost">
	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">

	<section id="ajax-posts" class="postlist">

	




<?php 


// the query
$gfmw_query = array(
    'cat'      => array(lt_gifts_catid()),
    'order'    => 'ASC',
    'showposts' => 80
        );
query_posts($gfmw_query);
?>
<?php while (have_posts()) : the_post(); ?>

<article class="list_post_styles">
<div class="listpostimg"> <a class="post_norlink" href="<?php the_permalink(); ?>"><?php if ( has_post_thumbnail() ): ?><?php the_post_thumbnail( 'single-post-thumbnail' ); ?><?php else: ?> <img src="http://giftformenwomen.com/wp-content/uploads/2016/11/gifts-for-men-women-gifs-ideas.png" alt="<?php the_title(); ?>"> <?php endif; ?>	</a></div>
<div class="listposting_content">
<div class="inner_catlist">
<?php
$categories = get_the_category();
$separator = ' / ';
$output = '';
if ( ! empty( $categories ) ) {
    foreach( $categories as $category ) {
        $output .= '<a href="' . esc_url( get_category_link( $category->term_id ) ) . '" alt="' . esc_attr( sprintf( __( 'View all posts in %s', 'giftformenwomen' ), $category->name ) ) . '">' . esc_html( $category->name ) . '</a>' . $separator;
    }
    echo trim( $output, $separator );
}?>
</div>

<a class="listing_posttitle" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
<p><?php echo the_excerpt() ?> </p>
</div>
</article>
<?php endwhile; wp_reset_postdata(); ?>


</section>

	<section class="page_sidebar">
		<?php get_sidebar(); ?> 
		
	</section>
	</div>
</div>
</div>




<div class="gfmw_full_contianer page_simple_content">
	<div class="gfwm_center blogpost">
		<div class="gw_inner pagesimple_content gfmwfix">
				
			
			<?php while ( have_posts() ): the_post(); ?>
		

					<?php the_content(); ?>

			<?php if ( ot_get_option('page-comments') == 'on' ) { comments_template('/comments.php',true); } ?>
			
		<?php endwhile; ?>

		
		
		</div>
</div>
</div>























<?php get_footer(); ?>