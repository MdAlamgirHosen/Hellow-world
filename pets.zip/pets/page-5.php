<?php 
/*
Template Name: Page 5
*/

?>
<?php get_header(); ?>


<div class="gfmw_full_contianer page_title_gfmws">
	<div class="gfwm_center blogpost">
		<div class="gw_inner  gfmwfix">
				 <p><?php the_title(); ?></p>
		</div>
</div>
</div>


<div class="gfmw_full_contianer singlepost">
	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">

	<section class="postlist pagepostnse">
		
		

	

		<?php while ( have_posts() ): the_post(); ?>
		

					<?php the_content(); ?>

			<?php if ( ot_get_option('page-comments') == 'on' ) { comments_template('/comments.php',true); } ?>
			
		<?php endwhile; ?>
		
	</section>

	<section class="page_sidebar sehosne">
		<?php get_sidebar(2); ?> 
		
	</section>
	</div>
</div>
</div>


<?php get_footer(); ?>