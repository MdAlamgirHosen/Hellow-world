=== Woocommerce Minimum and Maximum Quantity ===
Contributors: wpashokg 
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=RTAAFGGL53DMG
Tags: woocommerce, minimum, maximum, quantity, minimum purchase, maximum purchase, purchase
Requires at least: 3.3.1
Tested up to: 4.8
Stable tag: 2.0-Beta
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html


== Description ==
Hello Friends,<br>
This is a wordpress woocommerce support plugin which will Allow the site admin to enable the feature of minimum and maximum purchase of a particular product in each product.

[youtube https://www.youtube.com/watch?v=5uNf6ADOutM]

Features:

    Admin can enable / disable this feature on each product
    Admin can manage the minimum and maximum limit for each product.
    

== Installation ==
	
 * Upload the plugin files to the '/wp-content/plugins/' directory
 * Activate the plugin through the 'Plugins' menu in WordPress
 * Select a prticular prduct from the product list for which you need to enable this feature.
 * Enable this feature and add the minumum and maximum allowed quantity in the respective boxes
 
== Frequently Asked Questions ==

= Does it support category based minimum and maximum purchase limit ? =

Currently it does not support this feature.

= Does it support a central place to maintain the minimum and maximum limit for each product ? =

Currently it doesnot support this feature, to enable this feature we need to configure these values on each product.

== Changelog ==
= 2.0-beta =
Minor Bug fix on Quantity
= 1.1.6 =
Minor Bug fix
= 1.1.5 =
WPML support addition. Suggested by @maxgx
= 1.1.4 =
Bug fixes related to minimum product quantity selection in the product page.

= 1.1.3 =
Removed the view product link.

= 1.1.2 =
Made corrections for plugin activation error.

= 1.1.1 =
Typo  Corrections and standardizations. Bug fix for managed inventory products

= 1.1 =
Fixed the bug for adding same product multiple times which was adding the
product even if the maximum quantity for the product quantity is reached. Now
if the product is added multiple times and if it reached the maximum limit it
shows a popup that you have reached maximum limit for the product and exits
back to the product page
 
= 1.0.0 =
First Release
