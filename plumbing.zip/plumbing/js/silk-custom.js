$(document).on('ready', function() {
      $(".regular").slick({
        dots: true,
        infinite: true,
        slidesToShow: 3,
		 autoplay: true,
        slidesToScroll: 3
		
      });
      $(".center").slick({
        dots: true,
        infinite: true,
        centerMode: true,
        slidesToShow: 3,
        slidesToScroll: 3
      });
      $(".variable").slick({
        dots: true,
        infinite: true,
        variableWidth: true
      });
      $(".lazy").slick({
        lazyLoad: 'ondemand', // ondemand progressive anticipated
        infinite: true,
		 dots: true,
		autoplaySpeed: 3000,
		autoplay: true,
		 fade: true,
		 arrows: false,
    cssEase: 'linear'
      });
    });