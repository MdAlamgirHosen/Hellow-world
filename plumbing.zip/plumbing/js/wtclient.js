// JavaScript Document

	
	

$(document).ready(function() {

   
    $('.mobile-icon').click(function() {
        $('.nav_today').slideToggle();
       
});

    
});


$(window).resize(function() {
  if ($(window).width() > 960) {
      $('.nav_today').css('display','block');
	  
  }
  else {
      $('.nav_today').css('display','none');
  }
});

$(window).scroll(function() {
 if ($(this).scrollTop()>0)
     {
        $('.today_call').fadeOut(100);
		/*$('.logo_').css({display: 'none'});
		$('.logo_s').css({display: 'block',paddingTop: '10px',paddingBottom: '15px', marginLeft: '10px', width: '180px'});*/
		$('.today_micon').css({marginTop: '20px', marginBottom: '5px'});
		 $('.back-to-top').fadeIn(200);
     }
    else
     {
      $('.today_call').fadeIn();
	 /* $('.logo_').css({display: 'block'});
	  $('.logo_s').css({display: 'none'});*/
	  $('.today_micon').css({marginTop: '45px', marginBottom: '0px'});
	  $('.back-to-top').fadeOut(100);
     }
 });
 


