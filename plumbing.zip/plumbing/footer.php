<?php // footer widgets ?>


<!-------------------Footer start------------------------->


<div style="overflow:hidden" class="wta_main footer_bacgrounnd">
	<div class="wta_center">
	<div class="wta_glob padding_footer">
	
		<div class="wta_glob footer_left">
		  <?php if ( ot_get_option( 'copyrighttext' ) ): ?>
			<p class="copy_r">
			<?php echo ot_get_option( 'copyrighttext' ); ?> © <?php echo date( 'Y' ); ?> <span><?php echo ot_get_option( 'copyright' ); ?></span>. All rights reserved.
			</p>
			<?php else: ?>
			<p class="copy_rn">
			Copyright  © <?php echo date( 'Y' ); ?>  All Rights Reserved By webtady.com
			</p>
			<?php endif; ?>
		</div>
		<div class="wta_glob footer_right">
		  <p>Designed by <span style="color:#F6F504;">webtady.com</span></p>
		</div>
		
		</div>
	</div>
</div><!--end of -->

<!-------------------Footer Section End------------------------->		
<?php if ( ot_get_option( 'scroll_totop' ) !='off'): ?>
<a class="back-to-top" href="#">back to top  </a>
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>