<?php get_header(); ?>


<?php
    $images = rwmb_meta( 'image_upload', 'type=image_advanced&size=ful' ); // Prior to 4.8.0
	
    if ( !empty( $images ) ) {
        foreach ( $images as $image ) {
            $images_bg =  $image['url'];
        }
    }
	
$title_header =  do_shortcode( rwmb_meta( 'model_s_prefix_wysiwyg' ) );
   
	
?>

<div style="background:url('<?php if (!empty ($images_bg)){echo $images_bg;}else{echo "http://losangelesbodyrubs.com/wp-content/themes/losangelesbodyrubs/images/bg-home-slide.jpg";} ?>') center top no-repeat;" class="gfmw_full_contianer topbanners">
	<div class="gfwm_center blogpost">
		<div class="gw_inner header-parttitle ">
			<div class="hoverimage_text_mod"><?php echo $title_header; ?> </div>
		</div>
</div>
</div>




<div class="gfmw_full_contianer singlepost">
	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">

	<section class="postlist pagepostnse">
		
		
<div class="gw_inner padding_sets">
	

		<?php while ( have_posts() ): the_post(); ?>
		

					<?php the_content(); ?>

			<?php if ( ot_get_option('page-comments') == 'on' ) { comments_template('/comments.php',true); } ?>
			
		<?php endwhile; ?>
	</div>	
	</section>

	<section class="page_sidebar sehosne">
		<?php get_sidebar(2); ?> 
		
	</section>
	</div>
</div>
</div>


<?php get_footer(); ?>