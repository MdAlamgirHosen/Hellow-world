<?php get_header(); ?>
<div class="gfmw_full_contianer singlepost">

	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">
<section class="content">
	
	
	
	<div class="content_post">
		
		<?php while ( have_posts() ): the_post(); ?>
			<article <?php post_class(); ?>>	
				<div class="post-inner group">
					
					<h1 class="post-title"><?php the_title(); ?></h1>
					<p class="post-byline"><?php _e('by','GFMW'); ?> <?php the_author_posts_link(); ?> &middot; <?php the_time(get_option('date_format')); ?>  <?php get_template_part('inc/page-title'); ?></p>
					
					<?php if( get_post_format() ) { get_template_part('inc/post-formats'); } ?>
					<?php the_post_thumbnail( 'single-post-thumbnail' ); ?>
					<div class="clear"></div>
					<div class="respon_details"><!--details--> </div>
					<div class="clear"></div>
					
					<div class="entry">	
						<div class="entry-inner">
							<?php the_content(); ?>
							<?php wp_link_pages(array('before'=>'<div class="post-pages">'.__('Pages:','GFMW'),'after'=>'</div>')); ?>
						</div>
						<div class="clear"></div>				
					</div><!--/.entry-->
					
				</div><!--/.post-inner-->	
			</article><!--/.post-->				
		<?php endwhile; ?>
		
		<div class="clear"></div>
		
		<?php the_tags('<p class="post-tags"><span>'.__('Tags:','GFMW').'</span> ','','</p>'); ?>
		
		
		
		<?php // if ( ot_get_option( 'post-nav' ) == 'content') { get_template_part('inc/post-nav'); } ?>
		
		
		
		
		
	</div>
	
	

<div class="gfmw_related_product">
	<?php  if ( ot_get_option( 'related-posts' ) != '1' ) { get_template_part('inc/related-posts'); } ?>
	</div>
	<div class="gfmw_comment_abox">
	<?php  comments_template('/comments.php',true); ?>
	</div>
</section>

<section class="sidebar_gfmw">

<?php get_sidebar(); ?> 

</section>




</div>
	</div>
	
</div>


<?php get_footer(); ?>