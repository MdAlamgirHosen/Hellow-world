<!DOCTYPE html> 
<html class="no-js" <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title><?php if(is_front_page()) { echo bloginfo("name");  }elseif ( is_home() ) { echo bloginfo("name");} else { echo lt_page_title();  } ?>
	</title>
    <?php get_template_part('wtfile/metatag'); ?>
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
	
	
	<?php wp_head(); ?>
	
<?php if ( ot_get_option( 'gogle_verify' )): ?>
<?php echo ot_get_option('gogle_verify'); ?>
<?php endif; ?>


</head>

<body <?php body_class(); ?>>

<!--------------------Head Section------------------------>
<div class="wta_main">
	<div class="wta_center">
		<div class="wta_glob">
			<section class="wta_glob wta_logo_area">
			<?php if ( ot_get_option('custom-logo')): ?>
			<a href=" <?php echo site_url(); ?> "><img src="<?php echo ot_get_option('custom-logo'); ?>" class="theme_logo"></a>			
			<?php else: ?>
			<a href="<?php echo site_url(); ?>"><img src="<?php bloginfo('template_url'); ?>/images/logo.png" class="theme_logo"></a>			
			<?php endif; ?>
			</section>
			<section class="wta_glob wta_logo_area_right">
				<p> <span>Contact Us Now</span>
				<a href=""> 888-888-8888</a></p>
			</section>
		</div>
	</div>
</div>


