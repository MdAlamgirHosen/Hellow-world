<?php

/**
 * Fired during plugin deactivation
 *
 * @link       www.example.com
 * @since      1.0.0
 *
 * @package    church_plugin
 * @subpackage church_plugin/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    church_plugin
 * @subpackage church_plugin/includes
 * @author     Md Alamgir <designeralamgirhosen037@gmail.com>
 */
class church_plugin_Deactivator {

	private $tables;
	public function __construct($tables_object){
	   $this->tables = $tables_object;
	}
	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public function deactivate() {
     
	global $wpdb;
	 $wpdb->query("DROP table IF Exists ".$this->tables->churchplugintable());

	 if(!empty(get_option("church_page"))){
	     $page_id = get_option("church_page");
	     wp_delete_post($page_id, true);
	     delete_option("church_page");
		}
	}
	
	public function churchplugintable(){
	  global $wpdb;
	  return $wpdb->prefix."church_plugin_table";
	}
}
