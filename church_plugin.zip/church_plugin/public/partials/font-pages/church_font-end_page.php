<?php 

/*
Template Name: Sermons Page
*/

get_header(); 
?>

<div class="container">
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Sermons Audio: </h4>
        </div>
        <div class="modal-body">
          <div class="mediPlayer text-center">
             <button class="soundBt" name="https://wiki.selfhtml.org/local/Europahymne.mp3">Play</button>
         </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
   <!-- Modal -->
  <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Sermons Video: </h4>
        </div>
        <div class="modal-body">
          <div class="video_control"><iframe width="560" height="315" src="https://www.youtube.com/embed/Et0Vbv-i2Vk" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
var x = document.getElementById("myAudio"); 

function playAudio() { 
  x.play(); 
} 




function pauseAudio() { 
  x.pause(); 
} 

</script>
<section class="sermons_area_top_banner" style="background: url(http://localhost/church-plugin/wp-content/uploads/2018/12/sermonsbanner.jpg); background-size: cover;">
	<div class="container">
		<div class="row">
		    <div class="col-md-12">
	     		<div class="sermons_header_banner">
	     			<h2>Sermons Page</h2>
			    </div>
            </div>		
        </div>
    </div>
 </section> 	

<section class="sermons_area">
	<div class="container">
		<div class="row">
		
		    <div class="col-md-12">
	     		<div class="sermons_header_main">
				   <?php 
				          $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

				          $args = array(
				              'post_type'=>'Sermons', // Your post type name
				              'posts_per_page' => 6,
				              'paged' => $paged,
				          );

				          $loop = new WP_Query( $args );
				          if ( $loop->have_posts() ) {
				              while ( $loop->have_posts() ) : $loop->the_post();
				                 
				             ?>
				            <div class="col-md-4">
				              <div class="Sermons_twopart sermons">
				              	  <div class="sermons_img">
				              	  	<a href="<?php echo get_permalink()?>"><?php echo get_the_post_thumbnail( $post_id, 'full' ); ?></a>
				              	  </div>
				              	  <div class="sermons_text">
				              	  	<h4><?php echo get_the_title(); ?></h4>
				              	  	 <p class="author"><span class="pastor">Pastor:</span> <span class="auth"><?php echo get_the_author(); ?></span></p>
				              	  	 <p class="content"><?php echo get_the_content(); ?></p>
				              	  </div>
				                  <ul class="social_icon"> 
				                      <li><button type="button" data-toggle="modal" data-target="#myModal1"><i class="fa fa-film"></i></button></li>
				                      <li><button type="button" data-toggle="modal" data-target="#myModal"><i class="fa fa-music"></i></button></li>
				                      <li><a href="<?php echo get_post_meta(get_the_ID($post->ID),'readmoreurl', true); ?>"><i class="fa fa-book"></i></a></li>
				                      <li><a href="<?php echo get_post_meta(get_the_ID($post->ID),'readmoreurl', true); ?>"><i class="fa fa-download"></i></a></li>
				                  </ul>
				              </div>
				           </div>
				            <?php 
				              endwhile;
				              ?><div class="col-sm-12 col-md-12">
				              	  <div class="paginatione"><?php 
				              $total_pages = $loop->max_num_pages;

				              if ($total_pages > 1){

				                  $current_page = max(1, get_query_var('paged'));

				                  echo paginate_links(array(
				                      'base' => get_pagenum_link(1) . '%_%',
				                      'format' => '/page/%#%',
				                      'current' => $current_page,
				                      'total' => $total_pages,
				                      'prev_text'    => __('« prev'),
				                      'next_text'    => __('next »'),
				                  ));
				              }
				              ?></div></div><?php  
				          }
				          wp_reset_postdata();
				          ?>
				</div>
         	</div>		
      </div>
    </div>
 </section> <hr/>







<?php echo do_shortcode( '[Slider]' ); ?>
<?php echo do_shortcode( '[testimonilas]' ); ?>
<?php echo do_shortcode( '[Gallery]' ); ?>
<?php echo do_shortcode( '[Events]' ); ?>
<?php echo do_shortcode( '[Sermons]' ); ?>
<?php echo do_shortcode( '[Staff]' ); ?>





<?php get_footer(); ?>
