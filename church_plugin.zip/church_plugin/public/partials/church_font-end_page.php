<?php 

 get_header(); // header php

	echo do_shortcode("[test_shortcode]");

   get_footer();// footer php
?>