<?php 

global $wpdb;
$usersdetails = $wpdb->get_results(
   $wpdb->prepare("SELECT * from ".$wpdb->prefix."users order by id desc","")
);

echo "<pre>";
print_r($usersdetails);
echo "</pre>";

?>