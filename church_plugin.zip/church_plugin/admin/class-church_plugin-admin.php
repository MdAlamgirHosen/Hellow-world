<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       www.example.com
 * @since      1.0.0
 *
 * @package    church_plugin
 * @subpackage church_plugin/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    church_plugin
 * @subpackage church_plugin/admin
 * @author     Md Alamgir <designeralamgirhosen037@gmail.com>
 */
class church_plugin_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	
	private $tables;
	
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		
		require_once churchPLUGIN_URL.'/includes/class-church_plugin-tables.php';
		$this->tables = new church_plugin_tables();
	}
  
	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in church_plugin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The church_plugin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( "bootstrap", plugin_dir_url( __FILE__ ) . 'css/bootstrap.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( "dataTables", plugin_dir_url( __FILE__ ) . 'css/jquery.dataTables.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( "notifyBar", plugin_dir_url( __FILE__ ) . 'css/jquery.notifyBar.css', array(), $this->version, 'all' );
		wp_enqueue_style( "church_plugin", plugin_dir_url( __FILE__ ) . 'css/church_plugin-admin.css', array(), $this->version, 'all' );
		wp_enqueue_style( "font-awesome.min", plugin_dir_url( __FILE__ ) . 'css/font-awesome.min.css', array(), $this->version, 'all' );
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in church_plugin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The church_plugin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( "bootstrap", plugin_dir_url( __FILE__ ) . 'js/bootstrap.min.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "dataTables", plugin_dir_url( __FILE__ ) . 'js/jquery.dataTables.min.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "jquery", plugin_dir_url( __FILE__ ) . 'js/jquery.min.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "notifyBar", plugin_dir_url( __FILE__ ) . 'js/jquery.notifyBar.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "validate", plugin_dir_url( __FILE__ ) . 'js/jquery.validate.min.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "church_plugin", plugin_dir_url( __FILE__ ) . 'js/church_plugin-admin.js', array( 'jquery' ), $this->version, false );
		
		wp_localize_script("church_plugin","adminajaxurl",admin_url("admin-ajax.php"));
	}
	

		// for dashbord menu 

	public function church_plugin_admin_menu() {
	
			add_menu_page( 
				"church Options",//page title
				"church-manages",//menu title
				"manage_options", //admin level
				"church_plugin_admin",//page slug~parent slug
				array($this,"church_plugin_admin_pages"),//call backfunction
				"dashicons-universal-access",//icon
				 //plugins_url( '/asset/img/icon.png', __FILE__ ),
				20
			);
			add_submenu_page( 
				"church_plugin_admin",//parent slug
				"All church user",//page title
				"All church user",//menu title
				"manage_options",//user level
				"church_plugin_admin", //menu slug
				array($this,"church_plugin_admin_pages")//call backfunction
			);
			
			add_submenu_page( 
				"church_plugin_admin",//parent slug
				"Add New church",//page title
				"Add New church",//menu title
				"manage_options",//user level
				"add new admin", //menu slug
				array($this,"church_plugin_admin_pages2")//call backfunction
			);
			add_submenu_page( 
				"church_plugin_admin",//parent slug
				"Administrators",//page title
				"Administrator",//menu title
				"manage_options",//user level
				"Administrator", //menu slug
				array($this,"church_plugin_Administrator_pages")//call backfunction
			);
			add_submenu_page( 
				"church_plugin_admin",//parent slug
				"Add Administrators",//page title
				"Add Admin",//menu title
				"manage_options",//user level
				"addAdministrator", //menu slug
				array($this,"church_plugin_addadministrator_pages")//call backfunction
			);

			add_submenu_page( 
				"church_plugin_admin",//parent slug
				"Donate",//page title
				"Donate",//menu title
				"manage_options",//user level
				"Add New Donate", //menu slug
				array($this,"church_plugin_Donate")//call backfunction
			);
			
			add_submenu_page( 
				"church_plugin_admin",//parent slug
				"Newsletter",//page title
				"Newsletter",//menu title
				"manage_options",//user level
				"Newsletter", //menu slug
				array($this,"church_plugin_Newsletter")//call backfunction
			);
			
			add_submenu_page( 
				"church_plugin_admin",//parent slug
				"Blog",//page title
				"Blog",//menu title
				"manage_options",//user level
				"Blog", //menu slug
				array($this,"church_plugin_blog")//call backfunction
			);
			add_submenu_page( 
				"church_plugin_admin",//parent slug
				"Pages",//page title
				"Pages",//menu title
				"manage_options",//user level
				"Pages", //menu slug
				array($this,"church_plugin_pages")//call backfunction
			);
			
			add_submenu_page( 
				"church_plugin_admin",//parent slug
				"Church Settings",//page title
				"Settings",//menu title
				"manage_options",//user level
				"Settings", //menu slug
				array($this,"church_plugin_setting")//call backfunction
			);
		}
	

		public function church_plugin_admin_pages(){
			include_once churchPLUGIN_URL.'/admin/partials/all_admin_page.php';
		}

		public function church_plugin_admin_pages2(){
			include_once churchPLUGIN_URL.'/admin/partials/add_admin_page.php';
		}
		public function church_plugin_Administrator_pages(){
			include_once churchPLUGIN_URL.'/admin/partials/add_Administrator_page.php';
		}
		public function church_plugin_addadministrator_pages(){
			include_once churchPLUGIN_URL.'/admin/partials/add_administrator_user_page.php';
		}
		public function church_plugin_Donate(){
			include_once churchPLUGIN_URL.'/admin/partials/sliderpage.php';
		}
		public function church_plugin_Staff(){
			include_once churchPLUGIN_URL.'/admin/partials/gallerypage.php';
		}
		public function church_plugin_Newsletter(){
			include_once churchPLUGIN_URL.'/admin/partials/testimonialspage.php';
		}
		public function church_plugin_blog(){
			include_once churchPLUGIN_URL.'/admin/partials/blogpage.php';
		}
		public function church_plugin_pages(){
			include_once churchPLUGIN_URL.'/admin/partials/pages.php';
		}
		public function church_plugin_setting(){
			include_once churchPLUGIN_URL.'/admin/partials/settingpage.php';
		}
		

		// for ajax request code here
		function church_plugin_admin_handle(){
		   $param = isset($_REQUEST['param']) ? $_REQUEST['param']: "";
		   global $wpdb;
		   if(!empty($param) && $param == "save_admin"){
		    $textname = isset($_REQUEST['textname']) ? $_REQUEST['textname'] : "";
		    $textemail = isset($_REQUEST['textemail']) ? $_REQUEST['textemail'] : "";
		    $about = isset($_REQUEST['about']) ? $_REQUEST['about'] : "";
		    $image_url = isset($_REQUEST['image_url']) ? $_REQUEST['image_url'] : "";
			
			$wpdb = $wpdb->insert($this->tables->churchplugintable(), array(
			 "name" => $textname,
			 "email" => $textemail,
			 "about" => $about,
			 "Image" => $image_url
			));
			
			if($wpdb->insert_id > 0){
			 echo json_encode(array(
			 "status" =>1,
			 "message" => "successfully Inserted Data"
			 ));
			}
			else{
			 echo json_encode(array(
			 "status" =>0,
			 "message" => "Data Inserted"
			 ));
			}
		   }elseif(!empty($param) && $param == "delete_data_method"){
		   	 $dataid = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;

		   	 $isdata = $wpdb->get_row(
		   	 	$wpdb->prepare("SELECT * from ".$this->tables->churchplugintable()." WHERE id = %d",$dataid),ARRAY_A
		   	 );

		   	 if(!empty($isdata)){
		   	 	$wpdb->delete($this->tables->churchplugintable(), array(
		   	 		"id"=> $dataid
		   	 	));

		   	 	ob_start();
				include_once churchPLUGIN_URL."/admin/partials/tmfl/all_temp_data.php";
				$template = ob_get_contents();
				ob_end_clean();

		   	 	echo json_encode(array("status"=>1,"message"=>"delete successfully","template"=>$template));
		   	 }else{
		   	 	echo json_encode(array("status"=>0,"message"=>"not delete"));
		   	 }
		   }
		   wp_die();
		}

		//for slider custom post type create
		function custom_post_type_generate() {

			$labels = array(
				'name'                  => _x( 'Church Slider', 'Post Type General Name', 'text_domain' ),
				'singular_name'         => _x( 'Church Slider', 'Post Type Singular Name', 'text_domain' ),
				'menu_name'             => __( 'Church Slider', 'text_domain' ),
				'name_admin_bar'        => __( 'Add Church Slider', 'text_domain' ),
				'archives'              => __( 'Item Archives', 'text_domain' ),
				'parent_item_colon'     => __( 'Parent Item:', 'text_domain' ),
				'all_items'             => __( 'All Church', 'text_domain' ),
				'add_new_item'          => __( 'Add New Church', 'text_domain' ),
				'add_new'               => __( 'Add New Church', 'text_domain' ),
				'new_item'              => __( 'New Item', 'text_domain' ),
				'edit_item'             => __( 'Edit Item', 'text_domain' ),
				'update_item'           => __( 'Update Item', 'text_domain' ),
				'view_item'             => __( 'View Item', 'text_domain' ),
				'search_items'          => __( 'Search Item', 'text_domain' ),
				'not_found'             => __( 'Not found', 'text_domain' ),
				'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
				'featured_image'        => __( 'Featured Image', 'text_domain' ),
				'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
				'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
				'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
				'insert_into_item'      => __( 'Insert into item', 'text_domain' ),
				'uploaded_to_this_item' => __( 'Uploaded to this item', 'text_domain' ),
				'items_list'            => __( 'Items list', 'text_domain' ),
				'items_list_navigation' => __( 'Items list navigation', 'text_domain' ),
				'filter_items_list'     => __( 'Filter items list', 'text_domain' ),
			);
			$rewrite = array(
				'slug'                  => 'custom-post-type-base',
				'with_front'            => false,
				'post'                 => true,
				'feeds'                 => true,
			);
			$args = array(
				'label'                 => __( 'Add Slider', 'text_domain' ),
				'description'           => __( 'Post Type Description', 'text_domain' ),
				'labels'                => $labels,
				'supports'              => array( 'title', 'editor','thumbnail'),
				'taxonomies'            => array( 'category', 'post_tag' ),
				'hierarchical'          => true,
				'public'                => true,
				'show_ui'               => true,
				'show_in_menu'          => true,
				'menu_position'         => 20,
				'menu_icon'             => 'dashicons-slides',
				'show_in_admin_bar'     => true,
				'show_in_nav_menus'     => true,
				'can_export'            => true,
				'has_archive'           => 'custom-post-type',
				'exclude_from_search'   => false,
				'publicly_queryable'    => true,
				'rewrite'               => $rewrite,
				'capability_type'       => 'post',
			);
			register_post_type( 'custom_post_type', $args );

		}

		
			/**
			 * testimonials custompost type
			 */
			function wpt_testimonials_post_type() {
				$labels = array(
					'name'               => __( 'Testimonials' ),
					'singular_name'      => __( 'Testimonials' ),
					'add_new'            => __( 'Add Testimonials' ),
					'add_new_item'       => __( 'Add Testimonials' ),
					'edit_item'          => __( 'Edit Testimonials' ),
					'new_item'           => __( 'Add Testimonials' ),
					'view_item'          => __( 'View Testimonials' ),
					'search_items'       => __( 'Search Testimonials' ),
					'not_found'          => __( 'No events found' ),
					'not_found_in_trash' => __( 'No events found in trash' )
				);
				$supports = array(
					'title',
					'editor',
					'thumbnail',
					'comments',
					'revisions',
				);
				$args = array(
					'labels'               => $labels,
					'supports'             => $supports,
					'public'               => true,
					'capability_type'      => 'post',
					'rewrite'              => array( 'slug' => 'Testimonials' ),
					'has_archive'          => true,
					'menu_position'        => 21,
					'menu_icon'            => 'dashicons-testimonial',
					'register_meta_box_cb' => 'wpt_add_testimonial_metaboxes',
				);
				register_post_type( 'Testimonials', $args );
			}
			
			/**
			 * Gallery custompost type
			 */
			function wpt_Gallery_post_type() {
				$labels = array(
					'name'               => __( 'Church Gallery' ),
					'singular_name'      => __( 'All Gallery' ),
					'add_new'            => __( 'Add New Gallery' ),
					'add_new_item'       => __( 'Add New Gallery' ),
					'edit_item'          => __( 'Edit Gallery' ),
					'new_item'           => __( 'Add New Gallery' ),
					'view_item'          => __( 'View Gallery' ),
					'search_items'       => __( 'Search Gallery' ),
					'not_found'          => __( 'No events found' ),
					'not_found_in_trash' => __( 'No events found in trash' )
				);
				$supports = array(
					'title',
					'editor',
					'thumbnail',
					'comments',
					'revisions',
				);
				$args = array(
					'labels'               => $labels,
					'supports'             => $supports,
					'public'               => true,
					'capability_type'      => 'post',
					'rewrite'              => array( 'slug' => 'Gallery' ),
					'has_archive'          => true,
					'menu_position'        => 22,
					'menu_icon'            => 'dashicons-format-gallery',
					'register_meta_box_cb' => 'wpt_add_testimonial_metaboxes',
				);
				register_post_type( 'Gallery', $args );
			}
			

			/**
			 * Registers the event post type.
			 */
			function wpt_event_post_type() {
				$labels = array(
					'name'               => __( 'Events' ),
					'singular_name'      => __( 'Event' ),
					'add_new'            => __( 'Add New Event' ),
					'add_new_item'       => __( 'Add New Event' ),
					'edit_item'          => __( 'Edit Event' ),
					'new_item'           => __( 'Add New Event' ),
					'view_item'          => __( 'View Event' ),
					'search_items'       => __( 'Search Event' ),
					'not_found'          => __( 'No events found' ),
					'not_found_in_trash' => __( 'No events found in trash' )
				);
				$supports = array(
					'title',
					'editor',
					'thumbnail',
					'comments',
					'revisions',
				);
				$args = array(
					'labels'               => $labels,
					'supports'             => $supports,
					'public'               => true,
					'capability_type'      => 'post',
					'rewrite'              => array( 'slug' => 'events' ),
					'has_archive'          => true,
					'menu_position'        => 23,
					'menu_icon'            => 'dashicons-calendar-alt',
					'register_meta_box_cb' => 'wpt_add_event_metaboxes',
				);
				register_post_type( 'events', $args );
			}


			/**
			 * Registers the Sermons post type.
			 */
			function wpt_Sermons_post_type() {
				$labels = array(
					'name'               => __( 'Sermons' ),
					'singular_name'      => __( 'Sermons' ),
					'add_new'            => __( 'Add New Sermons' ),
					'add_new_item'       => __( 'Add New Sermons' ),
					'edit_item'          => __( 'Edit Sermons' ),
					'new_item'           => __( 'Add New Sermons' ),
					'view_item'          => __( 'View Sermons' ),
					'search_items'       => __( 'Search Sermons' ),
					'not_found'          => __( 'No Sermons found' ),
					'not_found_in_trash' => __( 'No Sermons found in trash' )
				);
				$supports = array(
					'title',
					'editor',
					'thumbnail',
					'comments',
					'revisions',
				);
				$args = array(
					'labels'               => $labels,
					'supports'             => $supports,
					'public'               => true,
					'capability_type'      => 'post',
					'rewrite'              => array( 'slug' => 'Sermons' ),
					'has_archive'          => true,
					'menu_position'        => 18,
					'menu_icon'            => 'dashicons-admin-site',
					'register_meta_box_cb' => 'wpt_add_Sermons_metaboxes',
				);
				register_post_type( 'Sermons', $args );
			}

				/**
			 * Registers the Staff post type.
			 */
			function wpt_Staff_post_type() {
				$labels = array(
					'name'               => __( 'Sermons Staff' ),
					'singular_name'      => __( 'Staff' ),
					'add_new'            => __( 'Add New Staff' ),
					'add_new_item'       => __( 'Add New Staff' ),
					'edit_item'          => __( 'Edit Staff' ),
					'new_item'           => __( 'Add New Staff' ),
					'view_item'          => __( 'View Staff' ),
					'search_items'       => __( 'Search Staff' ),
					'not_found'          => __( 'No Staff found' ),
					'not_found_in_trash' => __( 'No Staff found in trash' )
				);
				$supports = array(
					'title',
					'editor',
					'thumbnail',
					'comments',
					'revisions',
				);
				$args = array(
					'labels'               => $labels,
					'supports'             => $supports,
					'public'               => true,
					'capability_type'      => 'post',
					'rewrite'              => array( 'slug' => 'Staff' ),
					'has_archive'          => true,
					'menu_position'        => 19,
					'menu_icon'            => 'dashicons-groups',
					'register_meta_box_cb' => 'wpt_add_Sermons_metaboxes',
				    'taxonomies'            => array( 'category', 'post_tag' ),
				);
				register_post_type( 'Staff', $args );
			}
       // custom meta box show
		public function custom_juncker_metaboxes() {
				add_meta_box( 'my-meta-box-id', 'Custom meta: ', array( $this, 'my_meta_box_callback' ),
				    null, 'normal','high',
				    array(
				       '__block_editor_compatible_meta_box' => true,
					   '__back_compat_meta_box'             => false,
				    )
				);

			}

		public function my_meta_box_callback($post){
	    wp_nonce_field( 'basename(__FILE__)', 'my_url_metabox_nonce' );
		 ?>

		 <div class="information">
		  <h2 class="custom_heading1">Slider Area Fields : </h2>	
		  <label for="readmore_title">Slider Read More: </label>
		  <input name="readmore" class="widefat somechange" placeholder="Read More Text" type="text" value="<?php echo get_post_meta($post->ID,'readmore',true)?>" /><br/>

		  <label for="readmore_title">Slider Read More Url: </label>
		  <input name="sliderreadmoreurl" class="widefat somechange" placeholder="input Url" type="text" value="<?php echo get_post_meta($post->ID,'sliderreadmoreurl',true)?>" />

		  <h2 class="custom_heading">Sermons Area Fields : </h2>	
		  <label for="readmore_title">Note Book PDF: </label>
		  <input name="readmoreurl" id="getPDF_id" class="widefat somechange" type="hidden" value="<?php echo get_post_meta($post->ID,'readmoreurl',true)?>" />
		  <button type="button" class="widefat somechange" required id="btnpdf">Upload PDF</button>

		  <label for="readmore_title">Sermons Audio Song: </label>
		  <input name="Audiosong" id="getAudio_id" class="widefat somechange" type="hidden" value="<?php echo get_post_meta($post->ID,'Audiosong',true)?>" />
		  <button type="button" class="widefat somechange" required id="btnAudio">Upload Audio</button>

		  <label for="readmore_title">Sermons Video Url or Upload: </label>
		  <input name="videourl" id="getvideo_id" class="widefat somechange" type="text" value="<?php echo get_post_meta($post->ID,'videourl',true)?>" />
		  <button type="button" class="widefat somechange" required id="btnvideo">Upload Video</button>

		  <h2 class="custom_heading">Upcomming Events Fields : </h2>
		  <label for="Event_title">Event Date: </label>
		  <input name="ev_date" class="widefat somechange" type="date" value="<?php echo get_post_meta($post->ID,'ev_date',true)?>" /><br/>
		  <label for="Event_title">Event Address: </label>
		  <input name="ev_address" class="widefat somechange" type="text" value="<?php echo get_post_meta($post->ID,'ev_address',true)?>" />
		  <label for="Event_title">Highlight Event Month: </label>
		  <input name="ev_month" class="widefat somechange" type="month" value="<?php echo get_post_meta($post->ID,'ev_month',true)?>" />

		  <div class="socialmedia">
		  
		  </div>
		  <?php 
		}
		public function wpdocs_save_meta_box( $post_id ) {
		    Update_post_meta($post_id,'readmoreurl',$_POST['readmoreurl']);
		    Update_post_meta($post_id,'Audiosong',$_POST['Audiosong']);
		    Update_post_meta($post_id,'videourl',$_POST['videourl']);
		    Update_post_meta($post_id,'readmore',$_POST['readmore']);
		    Update_post_meta($post_id,'sliderreadmoreurl',$_POST['sliderreadmoreurl']);
		    Update_post_meta($post_id,'ev_date',$_POST['ev_date']);
		    Update_post_meta($post_id,'ev_address',$_POST['ev_address']);
		    Update_post_meta($post_id,'ev_month',$_POST['ev_month']);
		}



}