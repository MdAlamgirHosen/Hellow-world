<?php 

global $wpdb;

if ($_POST) {

    $username = $wpdb->_escape($_POST['user_login']);
    $email = $wpdb->_escape($_POST['email']);
    $fname = $wpdb->_escape($_POST['first_name']);
    $lname = $wpdb->_escape($_POST['last_name']);
    $url = $wpdb->_escape($_POST['url']);
    $role = $wpdb->_escape($_POST['role']);
    $password = $wpdb->_escape($_POST['password']);
    $ConfPassword = $wpdb->_escape($_POST['ConfirmPassword']);

    $error = array();
    if (strpos($username, ' ') !== FALSE) {
        $error['username_space'] = "Username has Space";
    }

    if (empty($username)) {
        $error['username_empty'] = "Needed Username must";
    }

    if (username_exists($username)) {
        $error['username_exists'] = "Username already exists";
    }

    if (!is_email($email)) {
        $error['email_valid'] = "Email has no valid value";
    }

    if (email_exists($email)) {
        $error['email_existence'] = "Email already exists";
    }

    if (strcmp($password, $ConfPassword) !== 0) {
        $error['password'] = "Password didn't match";
    }

    if (count($error) == 0) {

        wp_create_user($username, $password, $email, $fname, $lname, $url, $role);
        echo "User Created Successfully";
        exit();
    }else{
        
        print_r($error);
        
    }
}

?>







<div class="wrap">
<h1 id="add-new-user">Add New User</h1>


<div id="ajax-response"></div>

<p>Create a brand new user and add them to this site.</p>
<form method="post" class="validate" novalidate="novalidate">
<input name="action" type="hidden" value="createuser">
<input type="hidden" id="_wpnonce_create-user" name="_wpnonce_create-user" value="54ff464977"><input type="hidden" name="_wp_http_referer" value="/church-plugin/wp-admin/user-new.php"><table class="form-table">
	<tbody><tr class="form-field form-required">
		<th scope="row"><label for="user_login">Username <span class="description">(required)</span></label></th>
		<td><input name="user_login" type="text" id="user_login" value="" aria-required="true" autocapitalize="none" autocorrect="off" maxlength="60"></td>
	</tr>
	<tr class="form-field form-required">
		<th scope="row"><label for="email">Email <span class="description">(required)</span></label></th>
		<td><input name="email" type="email" id="email" value=""></td>
	</tr>
	<tr class="form-field">
		<th scope="row"><label for="first_name">First Name </label></th>
		<td><input name="first_name" type="text" id="first_name" value=""></td>
	</tr>
	<tr class="form-field">
		<th scope="row"><label for="last_name">Last Name </label></th>
		<td><input name="last_name" type="text" id="last_name" value=""></td>
	</tr>
	<tr class="form-field">
		<th scope="row"><label for="url">Website</label></th>
		<td><input name="url" type="url" id="url" class="code" value=""></td>
	</tr>
	<tr class="form-field form-required user-pass1-wrap">
		<th scope="row">
			<label for="pass1-text">
				Password				<span class="description hide-if-js">(required)</span>
			</label>
		</th>
		<td>
			<input class="hidden" value=" "><!-- #24364 workaround -->
			<button type="button" class="button wp-generate-pw hide-if-no-js">Show password</button>
			<div class="wp-pwd hide-if-js" style="display: none;">
								<span class="password-input-wrapper show-password">
					<input type="password" name="pass1" id="pass1" class="regular-text strong" autocomplete="off" data-reveal="1" data-pw="rhCF6W5Nv!HtP(y8eWZ^Z%OE" aria-describedby="pass-strength-result" disabled=""><input type="text" id="pass1-text" name="pass1-text" autocomplete="off" class="regular-text strong" disabled="">
				</span>
				<button type="button" class="button wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="Hide password">
					<span class="dashicons dashicons-hidden"></span>
					<span class="text">Hide</span>
				</button>
				<button type="button" class="button wp-cancel-pw hide-if-no-js" data-toggle="0" aria-label="Cancel password change">
					<span class="text">Cancel</span>
				</button>
				<div style="" id="pass-strength-result" aria-live="polite" class="strong">Strong</div>
			</div>
		</td>
	</tr>
	<tr class="form-field form-required user-pass2-wrap hide-if-js" style="display: none;">
		<th scope="row"><label for="pass2">Repeat Password <span class="description">(required)</span></label></th>
		<td>
		<input name="ConfirmPassword" type="password" id="pass2" autocomplete="off" disabled="">
		</td>
	</tr>
	<tr class="pw-weak" style="display: none;">
		<th>Confirm Password</th>
		<td>
			<label>
				<input type="checkbox" name="pw_weak" class="pw-checkbox">
				Confirm use of weak password			</label>
		</td>
	</tr>
	<tr>
		<th scope="row">Send User Notification</th>
		<td>
			<input type="checkbox" name="send_user_notification" id="send_user_notification" value="1" checked="checked">
			<label for="send_user_notification">Send the new user an email about their account.</label>
		</td>
	</tr>
	<tr class="form-field">
		<th scope="row"><label for="role">Role</label></th>
		<td><select name="role" id="role">
			
	<option selected="selected" value="subscriber">Subscriber</option>
	<option value="contributor">Contributor</option>
	<option value="author">Author</option>
	<option value="editor">Editor</option>
	<option value="administrator">Administrator</option>			</select>
		</td>
	</tr>
	</tbody></table>


<p class="submit"><input type="submit" name="createuser" id="createusersub" class="button button-primary" value="Add New User"></p>
</form>
</div>
