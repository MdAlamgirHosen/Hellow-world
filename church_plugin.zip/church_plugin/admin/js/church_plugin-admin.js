(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
    
	// add my custom js
	
	
	$(document).ready(function() {
		$('#example').DataTable();
	} ); 
	
	$(function(){
	// delete the record
	
     $("#frmadmin").validate({
	    submitHandler:function(){
		  var postforadmin = $("#frmadmin").serialize()+"&action=church_plugin&param=save_admin";
		  $.post(adminajaxurl,postforadmin, function(response){
		    var data = jQuery.parseJSON(response);
			
			if(data.status==1){
			 alert(data.message);
			}
			else{
			 alert(data.message);
			}
			location.reload();
		  });
		}
	 });
   });
	
	
   //for images wp media use
	$(function(){

	     $(".Delete_data").on("click", function(){
	     	var conf = confirm("Are you sure delete;");
	     	if(conf){
	     		var dataget = $(this).attr("data-id");
		   		var postdata = "action=church_plugin&param=delete_data_method&id="+dataget;
		   		 $.post(adminajaxurl,postdata, function(response){
	   			var data = $.parseJSON(response);
	   			if(data.status == 1){
	   				//alert(data.message);
	   				$("#table_reload_first").html(data.template);

	   			}else{
	     		alert(data.message);
	     	     }  
	   		});
	     	}	
		 });
	    //for user image
	   $("#upload-image").on("click", function(){
	   
		var images = wp.media({
		  title: "Upload Image",
		  multiple: false
		}).open().on("select", function(){
		 var files = images.state().get("selection").first();
		 
		 var jsonfiles = files.toJSON();
		 
		 $("#getImage").attr("src",jsonfiles.url);
		 $("#getImage_id").val(jsonfiles.url);
		 
		});
	   });

       //for user pdf
	   $("#btnpdf").on("click", function(){
	   
		var images = wp.media({
		  title: "Upload pdf",
		  multiple: false
		}).open().on("select", function(){
		 var files = images.state().get("selection").first();
		 
		 var jsonfiles = files.toJSON();
		 
		 $("#getPDF_id").val(jsonfiles.url);
		 
		});
	   });
	   //for user audio song
	    $("#btnAudio").on("click", function(){
	   
		var images = wp.media({
		  title: "Upload pdf",
		  multiple: false
		}).open().on("select", function(){
		 var files = images.state().get("selection").first();
		 
		 var jsonfiles = files.toJSON();
		 
		 $("#getAudio_id").val(jsonfiles.url);
		 
		});
	   });
   
     //for user audio song
       $("#btnvideo").on("click", function(){
	   
		var images = wp.media({
		  title: "Upload pdf",
		  multiple: false
		}).open().on("select", function(){
		 var files = images.state().get("selection").first();
		 
		 var jsonfiles = files.toJSON();
		 
		 $("#getvideo_id").val(jsonfiles.url);
		 
		});
	   });
	  
   });
	 
})( jQuery );
