<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       www.example.com
 * @since      1.0.0
 *
 * @package    church_plugin
 * @subpackage church_plugin/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    church_plugin
 * @subpackage church_plugin/admin
 * @author     Md Alamgir <designeralamgirhosen037@gmail.com>
 */
class church_plugin_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	
	private $tables;
	
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		
		require_once churchPLUGIN_URL.'/includes/class-church_plugin-tables.php';
		$this->tables = new church_plugin_tables();
	}
  
	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in church_plugin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The church_plugin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( "bootstrap", plugin_dir_url( __FILE__ ) . 'css/bootstrap.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( "dataTables", plugin_dir_url( __FILE__ ) . 'css/jquery.dataTables.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( "notifyBar", plugin_dir_url( __FILE__ ) . 'css/jquery.notifyBar.css', array(), $this->version, 'all' );
		wp_enqueue_style( "church_plugin", plugin_dir_url( __FILE__ ) . 'css/church_plugin-admin.css', array(), $this->version, 'all' );
		wp_enqueue_style( "font-awesome.min", plugin_dir_url( __FILE__ ) . 'css/font-awesome.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( "font-awesome.min", plugin_dir_url( __FILE__ ) . 'css/font-awesome.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( "owl.carousel.min", plugin_dir_url( __FILE__ ) . 'css/owl.carousel.min.css', array(), $this->version, 'all' );
		wp_enqueue_style( "owl.theme.default", plugin_dir_url( __FILE__ ) . 'css/owl.theme.default.css', array(), $this->version, 'all' );
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in church_plugin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The church_plugin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( "bootstrap", plugin_dir_url( __FILE__ ) . 'js/bootstrap.min.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "dataTables", plugin_dir_url( __FILE__ ) . 'js/jquery.dataTables.min.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "jquery", plugin_dir_url( __FILE__ ) . 'js/jquery.min.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "notifyBar", plugin_dir_url( __FILE__ ) . 'js/jquery.notifyBar.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "validate", plugin_dir_url( __FILE__ ) . 'js/jquery.validate.min.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "church_plugin", plugin_dir_url( __FILE__ ) . 'js/church_plugin-admin.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "carousel", plugin_dir_url( __FILE__ ) . 'js/owl.carousel.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( "owl.carousel.min", plugin_dir_url( __FILE__ ) . 'js/owl.carousel.min.js', array( 'jquery' ), $this->version, false );
		
        wp_enqueue_script( 'my-script', plugin_dir_url( __FILE__ ) . '/js/dynamic-fields.js', array( 'jquery' ), '20160816', true );

		wp_localize_script("church_plugin","adminajaxurl",admin_url("admin-ajax.php"));
	}
	

	   // for dashbord menu 
	   public function church_plugin_admin_menu() {
	   	 add_menu_page( 
				"Church Wp Plugin",//page title
				"Church Plugin",//menu title
				"manage_options", //admin level
				"church_plugin_admin",//page slug~parent slug
				array($this,"church_plugin_admin_pages"),//call backfunction
				"dashicons-universal-access",//icon
				 //plugins_url( '/asset/img/icon.png', __FILE__ ),
				20
			);
	      add_options_page(
            __( 'Church Settings', 'textdomain' ),
            __( 'Church Settings', 'textdomain' ),
            'manage_options',
            'options_page_slug',
            array(
                $this,
                'church_plugin_setting'
            )
        );
		}
      
      	public function church_plugin_setting(){
			include_once churchPLUGIN_URL.'/admin/partials/settingpage.php';
		}
		public function church_plugin_Donate_pages(){
			include_once churchPLUGIN_URL.'/admin/partials/church_allDonate.php';
		}
		
		// add a new default avatar to the list in WordPress admin

		public function wpb_new_gravatar ($avatar_defaults) {
		$myavatar = "https://freeiconshop.com/wp-content/uploads/edd/person-outline-filled.png";
		$avatar_defaults[$myavatar] = "Default Gravatar";
		return $avatar_defaults;
		}


		
		public function wpl_owt_cpt_custom_columns($columns) {

		    $columns = array(
		        "cb" => "<input type='checkbox'/>",
		        "title" => "Donation Email",
		        "pub_email" => "Publisher Email",
		        "pub_name" => "Publisher Name",
		        "date" => "Date"
		    );

		    return $columns;
		}
	

		// register Options API Settings
		public function register_mysettings() { // whitelist options
			
		    //gallery
		    register_setting( "genarel_options_group", "fname");
		    register_setting( "genarel_options_group", "gtitle_fontsize");
		    register_setting( "genarel_options_group", "gtitle_color");
		    register_setting( "genarel_options_group", "gtext_fontsize");
		    register_setting( "genarel_options_group", "gtext_color");
		    register_setting( "genarel_options_group", "giconchange");
		    register_setting( "genarel_options_group", "gicontext_size");
		    register_setting( "genarel_options_group", "gicontext_color");
		    register_setting( "genarel_options_group", "gicononoff");
		    
		    //Testimonials
		    register_setting( "genarel_options_group", "Ttitle_fontsize");
		    register_setting( "genarel_options_group", "Ttitle_color");
		    register_setting( "genarel_options_group", "Tttext_fontsize");
		    register_setting( "genarel_options_group", "Tttext_color");
		    register_setting( "genarel_options_group", "Ttext_fontsize");
		    register_setting( "genarel_options_group", "Ttext_color");
		    register_setting( "genarel_options_group", "Tbulletonoff");
		    register_setting( "genarel_options_group", "Tatext_fontsize");
		    register_setting( "genarel_options_group", "Tatext_color");
		    
		    //Events 
		    register_setting( "genarel_options_group", "Etitle_fontsize");
		    register_setting( "genarel_options_group", "Etitle_color");
		    register_setting( "genarel_options_group", "Estitle_fontsize");
		    register_setting( "genarel_options_group", "Estitle_color");
		    register_setting( "genarel_options_group", "Etime_fontsize");
		    register_setting( "genarel_options_group", "Etime_color");
		    register_setting( "genarel_options_group", "Eaddress_fontsize");
		    register_setting( "genarel_options_group", "Eaddress_color");
		    register_setting( "genarel_options_group", "Etarikh_fontsize");
		    register_setting( "genarel_options_group", "Etarikh_color");
		    register_setting( "genarel_options_group", "Emonth_fontsize");
		    register_setting( "genarel_options_group", "Emonth_color");
		    register_setting( "genarel_options_group", "Eview_fontsize");
		    register_setting( "genarel_options_group", "Eviewback_color");
		    register_setting( "genarel_options_group", "Eview_color");

		    //Sermons slider
		    register_setting( "sermons_options_group", "title_fontsize");
		    register_setting( "sermons_options_group", "title_color");
		    register_setting( "sermons_options_group", "text_fontsize");
		    register_setting( "sermons_options_group", "text_color");
		    register_setting( "sermons_options_group", "readmore_fontsize");
		    register_setting( "sermons_options_group", "readmore_background");
		    register_setting( "sermons_options_group", "readmore_color");
		    register_setting( "sermons_options_group", "checkbox_bullet");
		    register_setting( "sermons_options_group", "leftright_bullet");

		    //Leatest Sermons
		    register_setting( "sermons_options_group", "Ltitle_fontsize");
		    register_setting( "sermons_options_group", "Ltitle_color");
		    register_setting( "sermons_options_group", "Lstitle_fontsize");
		    register_setting( "sermons_options_group", "Lstitle_color");

		    register_setting( "sermons_options_group", "Lsctitle_fontsize");
		    register_setting( "sermons_options_group", "Lsctitle_color");
		    register_setting( "sermons_options_group", "Lscon_fontsize");
		    register_setting( "sermons_options_group", "Lscon_color");
		    register_setting( "sermons_options_group", "Ltime_fontsize");
		    register_setting( "sermons_options_group", "Ltime_color");
		    register_setting( "sermons_options_group", "Lread_fontsize");
		    register_setting( "sermons_options_group", "Lread_color");
		    register_setting( "sermons_options_group", "Lreadback_color");
		    register_setting( "sermons_options_group", "Lreadborder_color");
		    
		    register_setting( "sermons_options_group", "Lsocial_fontsize");
		    register_setting( "sermons_options_group", "Lsocial_color");
		    register_setting( "sermons_options_group", "Lsocialback_color");
		    register_setting( "sermons_options_group", "Lsocialborder_color");

		    //Sermons Staff
		    register_setting( "sermons_options_group", "Lstaftitle_fontsize");
		    register_setting( "sermons_options_group", "Lstaftitle_color");
		    register_setting( "sermons_options_group", "Lstafstitle_fontsize");
		    register_setting( "sermons_options_group", "Lstafstitle_color");
		    register_setting( "sermons_options_group", "Lsname_fontsize");
		    register_setting( "sermons_options_group", "Lsname_color");
		    register_setting( "sermons_options_group", "Lssocial_backcolor");
		    register_setting( "sermons_options_group", "Lssocial_color");
		    register_setting( "sermons_options_group", "Lssocial_onoff");


		    register_setting( "pages_options_group", "spttitlefont");
		    register_setting( "pages_options_group", "spttitlecolor");
		    register_setting( "pages_options_group", "sbtfont");
		    register_setting( "pages_options_group", "sbtcolor");
		    register_setting( "pages_options_group", "sbrole_font");
		    register_setting( "pages_options_group", "sbrole_color");
		    register_setting( "pages_options_group", "sbauth_font");
		    register_setting( "pages_options_group", "sbauth_color");
		    register_setting( "pages_options_group", "sbreadmore_font");
		    register_setting( "pages_options_group", "sbreadmore_color");
		    register_setting( "pages_options_group", "pagination_active_back");
		    register_setting( "pages_options_group", "pagination_font");
		    register_setting( "pages_options_group", "pagination_color");
		    register_setting( "pages_options_group", "pagination_backcolor");

		    register_setting( "banner_options_group", "banner_img");
		    register_setting( "banner_options_group", "sbanner_img");
		    register_setting( "banner_options_group", "ebanner_img");
		    register_setting( "banner_options_group", "abanner_img");
		    register_setting( "banner_options_group", "lsbanner_img");
		    register_setting( "banner_options_group", "lscolor");
		    register_setting( "banner_options_group", "lscheck");
		    register_setting( "banner_options_group", "tbanner_img");
		    register_setting( "banner_options_group", "tcolor");
		    register_setting( "banner_options_group", "tchek");
        }

		//     add_settings_section( "church_setting_id", "church settings title", "church_settings_callback", "Settings" );

		 //        add_settings_field( "text-field-id", "text field title", "input_field_callbackf", "Settings","church_setting_id" ); 

		 //        add_settings_field( "onoff-id", "onoff title", "onoff_for", "onoff_callbackf", "Settings","church_setting_id" ); 

		 //        add_settings_field( "color-picker-id", "color-picker", "color_picker_callbackf", "Settings","church_setting_id" ); 

			//     add_settings_field( "checkbox-id", "checkbox title", "color_picker_callbackf", "Settings","church_setting_id" ); 

		 //        // media section work
			//     register_setting( 'media_options_group', 'media_field_value');
		 //        add_settings_field( 'media_field_id', 'media field title','media_field_callbackf', 'Settings','media_setting_id' );
		 //        add_settings_section( 'media_setting_id', 'media settings title', 'media_settings_callback', 'Settings' );
			// }
		
		// public function media_field_callbackf(){
		// 	echo '<input type="text" name="" value="" />';
		// }
		// public function media_settings_callback(){
		// 	echo "hello";
		// }




        // All callback functions
		public function mw_enqueue_color_picker( $hook_suffix ) {
		    // first check that $hook_suffix is appropriate for your admin page
		    wp_enqueue_style( 'wp-color-picker' );
		    wp_enqueue_script( 'my-script-handle', plugins_url('/js/color-picker.js', __FILE__ ), array( 'wp-color-picker' ), false, true );
		}
		
		//for slider custom post type create
		public function custom_post_type_generate() {

			$labels = array(
				'name'                  => _x( 'Church Slider', 'Post Type General Name', 'text_domain' ),
				'singular_name'         => _x( 'Church Slider', 'Post Type Singular Name', 'text_domain' ),
				'menu_name'             => __( 'Church Slider', 'text_domain' ),
				'name_admin_bar'        => __( 'Add Church Slider', 'text_domain' ),
				'archives'              => __( 'Item Archives', 'text_domain' ),
				'parent_item_colon'     => __( 'Parent Item:', 'text_domain' ),
				'all_items'             => __( 'All Church Slider', 'text_domain' ),
				'add_new_item'          => __( 'Add New Slider', 'text_domain' ),
				'add_new'               => __( 'Add New Slider', 'text_domain' ),
				'new_item'              => __( 'New Item', 'text_domain' ),
				'edit_item'             => __( 'Edit Item', 'text_domain' ),
				'update_item'           => __( 'Update Item', 'text_domain' ),
				'view_item'             => __( 'View Item', 'text_domain' ),
				'search_items'          => __( 'Search Item', 'text_domain' ),
				'not_found'             => __( 'Not found', 'text_domain' ),
				'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
				'featured_image'        => __( 'Featured Image', 'text_domain' ),
				'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
				'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
				'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
				'insert_into_item'      => __( 'Insert into item', 'text_domain' ),
				'uploaded_to_this_item' => __( 'Uploaded to this item', 'text_domain' ),
				'items_list'            => __( 'Items list', 'text_domain' ),
				'items_list_navigation' => __( 'Items list navigation', 'text_domain' ),
				'filter_items_list'     => __( 'Filter items list', 'text_domain' ),
			);
			$rewrite = array(
				'slug'                  => 'custom-post-type-base',
				'with_front'            => false,
				'post'                 => true,
				'feeds'                 => true,
			);
			$args = array(
				'label'                 => __( 'Add Slider', 'text_domain' ),
				'description'           => __( 'Post Type Description', 'text_domain' ),
				'labels'                => $labels,
				'supports'              => array( 'title', 'editor','thumbnail'),
				'taxonomies'            => array( 'category', 'post_tag' ),
				'hierarchical'          => true,
				'public'                => true,
				'show_ui'               => true,
				'show_in_menu'          => "church_plugin_admin",
				'menu_position'         => 20,
				'menu_icon'             => 'dashicons-slides',
				'show_in_admin_bar'     => true,
				'show_in_nav_menus'     => true,
				'can_export'            => true,
				'has_archive'           => 'custom-post-type',
				'exclude_from_search'   => false,
				'publicly_queryable'    => true,
				'rewrite'               => $rewrite,
				'capability_type'       => 'post',
			);
			register_post_type( 'custom_post_type', $args );

		}
		
		/**
		 * testimonials custompost type
		 */
		public	function wpt_testimonials_post_type() {
				$labels = array(
					'name'               => __( 'Testimonials' ),
					'singular_name'      => __( 'Testimonials' ),
					'all_items'          => __( 'Testimonials'),
					'add_new'            => __( 'Add New Testimonials' ),
					'add_new_item'       => __( 'Add Testimonials' ),
					'edit_item'          => __( 'Edit Testimonials' ),
					'new_item'           => __( 'Add Testimonials' ),
					'view_item'          => __( 'View Testimonials' ),
					'search_items'       => __( 'Search Testimonials' ),
					'not_found'          => __( 'No events found' ),
					'not_found_in_trash' => __( 'No events found in trash' )
				);
				$supports = array(
					'title',
					'editor',
					'thumbnail',
					'comments',
					'revisions',
				);
				$args = array(
					'labels'               => $labels,
					'supports'             => $supports,
					'public'               => true,
					'capability_type'      => 'post',
					'rewrite'              => array( 'slug' => 'Testimonials' ),
					'has_archive'          => true,
					'show_in_menu'          => "church_plugin_admin",
					'menu_position'        => 21,
					'menu_icon'            => 'dashicons-testimonial',
					'register_meta_box_cb' => 'wpt_add_testimonial_metaboxes',
				);
				register_post_type( 'testimonials', $args );
			}
			
		/**
		 * Gallery custompost type
		 */
		public	function wpt_Gallery_post_type() {
				$labels = array(
					'name'               => __( 'Church Gallery' ),
					'singular_name'      => __( 'All Gallery' ),
					'add_new'            => __( 'Add New Image' ),
					'add_new_item'       => __( 'Add New Image' ),
					'edit_item'          => __( 'Edit Gallery' ),
					'new_item'           => __( 'Add New Gallery' ),
					'view_item'          => __( 'View Gallery' ),
					'search_items'       => __( 'Search Gallery' ),
					'not_found'          => __( 'No events found' ),
					'not_found_in_trash' => __( 'No events found in trash' )
				);
				$supports = array(
					'title',
					'editor',
					'thumbnail',
					'comments',
					'revisions',
				);
				$args = array(
					'labels'               => $labels,
					'supports'             => $supports,
					'public'               => true,
					'capability_type'      => 'post',
					'rewrite'              => array( 'slug' => 'Gallery' ),
					'has_archive'          => true,
					'show_in_menu'          => "church_plugin_admin",
					'menu_position'        => 22,
					'menu_icon'            => 'dashicons-format-gallery',
					'register_meta_box_cb' => 'wpt_add_testimonial_metaboxes',
				);
				register_post_type( 'gallery', $args );
			}
			

		/**
		 * Registers the event post type.
		 */
		public	function wpt_event_post_type() {
				$labels = array(
					'name'               => __( 'Events' ),
					'singular_name'      => __( 'Event' ),
					'add_new'            => __( 'Add New Event' ),
					'add_new_item'       => __( 'Add New Event' ),
					'edit_item'          => __( 'Edit Event' ),
					'new_item'           => __( 'Add New Event' ),
					'view_item'          => __( 'View Event' ),
					'search_items'       => __( 'Search Event' ),
					'not_found'          => __( 'No events found' ),
					'not_found_in_trash' => __( 'No events found in trash' )
				);
				$supports = array(
					'title',
					'editor',
					'thumbnail',
					'comments',
					'revisions',
				);
				$args = array(
					'labels'               => $labels,
					'supports'             => $supports,
					'public'               => true,
					'capability_type'      => 'post',
					'rewrite'              => array( 'slug' => 'events' ),
					'has_archive'          => true,
					'show_in_menu'          => "church_plugin_admin",
					'menu_position'        => 23,
					'menu_icon'            => 'dashicons-calendar-alt',
					'register_meta_box_cb' => 'wpt_add_event_metaboxes',
				);
				register_post_type( 'events', $args );
			}


		/**
		 * Registers the Sermons post type.
		 */
		public	function wpt_Sermons_post_type() {
				$labels = array(
					'name'               => __( 'Sermon' ),
					'singular_name'      => __( 'Sermon' ),
					'all_items'          => __( 'Sermon'),
					'add_new'            => __( 'Add New sermon' ),
					'add_new_item'       => __( 'Add New sermon' ),
					'edit_item'          => __( 'Edit sermon' ),
					'new_item'           => __( 'Add New sermon' ),
					'view_item'          => __( 'View sermon' ),
					'search_items'       => __( 'Search sermon' ),
					'not_found'          => __( 'No Sermons found' ),
					'not_found_in_trash' => __( 'No Sermons found in trash' )
				);
				$supports = array(
					'title',
					'editor',
					'thumbnail',
					'comments',
					'revisions',
				);
				$args = array(
					'labels'               => $labels,
					'supports'             => $supports,
					'public'               => true,
					'capability_type'      => 'post',
					'rewrite'              => array( 'slug' => 'sermon' ),
					'has_archive'          => true,
					'show_in_menu'          => "church_plugin_admin",
					'menu_position'        => 18,
					'menu_icon'            => 'dashicons-admin-site',
					'register_meta_box_cb' => 'wpt_add_Sermons_metaboxes',
				);
				register_post_type( 'sermon', $args );
				
			}

		/**
		 * Registers the Staff post type.
		 */
		public	function wpt_Staff_post_type() {
				$labels = array(
					'name'               => __( 'Sermons Staff' ),
					'singular_name'      => __( 'Staff' ),
					'add_new'            => __( 'Add New Staff' ),
					'add_new_item'       => __( 'Add New Staff' ),
					'edit_item'          => __( 'Edit Staff' ),
					'new_item'           => __( 'Add New Staff' ),
					'view_item'          => __( 'View Staff' ),
					'search_items'       => __( 'Search Staff' ),
					'not_found'          => __( 'No Staff found' ),
					'not_found_in_trash' => __( 'No Staff found in trash' )
				);
				$supports = array(
					'title',
					'editor',
					'thumbnail',
					'comments',
					'revisions',
				);
				$args = array(
					'labels'               => $labels,
					'supports'             => $supports,
					'public'               => true,
					'capability_type'      => 'post',
					'rewrite'              => array( 'slug' => 'Staff' ),
					'has_archive'          => true,
					'show_in_menu'          => "church_plugin_admin",
					'menu_position'        => 19,
					'menu_icon'            => 'dashicons-groups',
					'register_meta_box_cb' => 'wpt_add_Sermons_metaboxes',
				    'taxonomies'            => array( 'category', 'post_tag' ),
				);
				register_post_type( 'staff', $args );
			}

		 /**
		 * Registers donation custom post type.
		 */
		public	function wpt_donation_post_type() {
				$labels = array(
					'name'               => __( 'Church Donation' ),
					'singular_name'      => __( 'Donation' ),
					'all_items'          => __( 'Donation'),
					'add_new'            => __( 'Add New Donation' ),
					'add_new_item'       => __( 'Add New Donation' ),
					'edit_item'          => __( 'Edit Donation' ),
					'new_item'           => __( 'Add New Donation' ),
					'view_item'          => __( 'View Donation' ),
					'search_items'       => __( 'Search Donation' ),
					'not_found'          => __( 'No Donation found' ),
					'not_found_in_trash' => __( 'No Donation found in trash' )
				);
				$supports = array(
					'title',
					'editor',
					'thumbnail',
					'comments',
					'revisions',
				);
				$args = array(
					'labels'               => $labels,
					'supports'             => $supports,
					'public'               => true,
					'capability_type'      => 'post',
					'rewrite'              => array( 'slug' => 'Donation' ),
					'has_archive'          => true,
					'show_in_menu'          => "church_plugin_admin",
					'menu_position'        => 18,
					'menu_icon'            => 'dashicons-carrot',
					'register_meta_box_cb' => 'wpt_add_Sermons_metaboxes',
				);
				register_post_type( 'donation', $args );
			}




       // custom meta box show
		public function page_sermons_metaboxes() {
			add_meta_box( 'page-meta-box-id', 'Sermonspage: ', array( $this, 'page_meta_box_callback' ),
			    'page', 'normal','high',
			    array(
			       '__block_editor_compatible_meta_box' => true,
				   '__back_compat_meta_box'             => false,
			    )
			);

		}


		public function custom_juncker_metaboxes() {
			add_meta_box( 'my-meta-box-id', 'Slider Area Fields: ', array( $this, 'my_meta_box_callback' ),
			    'custom_post_type', 'side','high',
			    array(
			       '__block_editor_compatible_meta_box' => true,
				   '__back_compat_meta_box'             => false,
			    )
			);

		}
		public function custom_Sermons_metaboxes() {
			add_meta_box( 'sermon-meta-box-id', 'Sermon Area Fields: ', array( $this, 'sermon_meta_box_callback' ),
			    'sermon', 'normal','high',
			    array(
			       '__block_editor_compatible_meta_box' => true,
				   '__back_compat_meta_box'             => false,
			    )
			);

		}
		public function custom_Sermons_for_banner() {
			add_meta_box( 'banner-meta-box-id', 'Banner Area Fields: ', array( $this, 'banner_meta_box_callback' ),
			    'sermon', 'side','high',
			    array(
			       '__block_editor_compatible_meta_box' => true,
				   '__back_compat_meta_box'             => false,
			    )
			);

		}

		public function custom_events_metaboxes() {
			add_meta_box( 'events-meta-box-id', 'Events Fields Area: ', array( $this, 'events_meta_box_callback' ),
			    'events', 'normal','high',
			    array(
			       '__block_editor_compatible_meta_box' => true,
				   '__back_compat_meta_box'             => false,
			    )
			);

		}
		public function custom_events_for_banner() {
			add_meta_box( 'banner-meta-box-id', 'Events Area Fields: ', array( $this, 'event_meta_box_callback' ),
			    'events', 'side','high',
			    array(
			       '__block_editor_compatible_meta_box' => true,
				   '__back_compat_meta_box'             => false,
			    )
			);

		}
		public function custom_staff_metaboxes() {
			add_meta_box( 'staff-meta-box-id', 'Staff Select Area: ', array( $this, 'staff_meta_box_callback' ),
			    'staff', 'side','high',
			    array(
			       '__block_editor_compatible_meta_box' => true,
				   '__back_compat_meta_box'             => false,
			    )
			);

		}
		public function custom_staff_metaboxesnormal(){
			add_meta_box( 'staff-meta-social-id', 'Staff Select Social Area: ', array( $this, 'staff_meta_social_callback' ),
			    'staff', 'normal','high',
			    array(
			       '__block_editor_compatible_meta_box' => true,
				   '__back_compat_meta_box'             => false,
			    )
			);
		}


		public function custom_donate_metaboxes() {
			add_meta_box( 'donation-meta-box-id', 'donation Area: ', array( $this, 'donation_meta_box_callback' ),
			    'donation', 'normal','high',
			    array(
			       '__block_editor_compatible_meta_box' => true,
				   '__back_compat_meta_box'             => false,
			    )
			);

		}

		public function page_meta_box_callback(){
		 echo "sermons page test";
		}
		public function donation_meta_box_callback(){
		wp_nonce_field( 'basename(__FILE__)', 'donation_metabox_nonce' );
		   include_once churchPLUGIN_URL. "/admin/partials/donationcallfrom.php";
		}
		//Callback custom meta box show	

		public function my_meta_box_callback($post){
	    wp_nonce_field( 'basename(__FILE__)', 'my_url_metabox_nonce' );
		 ?>

		 <div class="information">
		  <label for="readmore_title">Slider Read More Text: </label>
		  <input name="readmore" class="widefat somechange" placeholder="Read More Text" type="text" value="<?php echo get_post_meta($post->ID,'readmore',true)?>" /><br/>

		  <label for="readmore_title">Slider Read More Url: </label>
		  <input name="sliderreadmoreurl" class="widefat somechange" placeholder="input Url" type="text" value="<?php echo get_post_meta($post->ID,'sliderreadmoreurl',true)?>" />

		  </div>
		  <?php 
		}


		public function banner_meta_box_callback($post){
		wp_nonce_field( 'basename(__FILE__)', 'banner_url_metabox_nonce' );
		?>
		  <select id="role" name="author_ss">
		  	<?php
		  	    if( is_user_logged_in() ) {
				    $user = wp_get_current_user();
				    $role = ( array ) $user->roles;
				    $auth_result = $role[0];
				  }
		  	   wp_dropdown_roles( $auth_result );

		  	 ?>
		  </select>
		  <?php
		}
		public function event_meta_box_callback($post){
		wp_nonce_field( 'basename(__FILE__)', 'event_url_metabox_nonce' );
		?>
		  <select id="role" name="author_ss">
		  	<?php
		  	    if( is_user_logged_in() ) {
				    $user = wp_get_current_user();
				    $role = ( array ) $user->roles;
				    $auth_result = $role[0];
				  }
		  	   wp_dropdown_roles( $auth_result );

		  	 ?>
		  </select>
		  <?php
		}


		public function sermon_meta_box_callback($post){
		wp_nonce_field( 'basename(__FILE__)', 'sermon_url_metabox_nonce' );
		?>
		  <label for="readmore_title">Note Book PDF: </label>
		  <input name="readmoreurl" id="getPDF_id" class="widefat somechange" type="text" value="<?php echo get_post_meta($post->ID,'readmoreurl',true)?>" />
		  <button type="button" class="btn btn-primary" class="widefat somechange" required id="btnpdf">Upload PDF</button>

		  <label for="readmore_title">Sermons Audio Song: </label>
		  <input name="Audiosong" id="getAudio_id" class="widefat somechange" type="text" value="<?php echo get_post_meta($post->ID,'Audiosong',true)?>" />
		  <button type="button" class="btn btn-primary"  class="widefat somechange" required id="btnAudio">Upload Audio</button>

		  <label for="readmore_title">Sermons Video Url or Upload: </label>
		  <input name="videourl" id="getvideo_id" class="widefat somechange" type="text" value="<?php echo get_post_meta($post->ID,'videourl',true)?>" />
		  <button type="button" class="btn btn-primary"  class="widefat somechange" required id="btnvideo">Upload Video</button>
		  <?php
		}


		public function events_meta_box_callback($post){
		wp_nonce_field( 'basename(__FILE__)', 'events_url_metabox_nonce' );	
		?>
		  <label for="Event_title">Event Date: </label>
		  <input name="ev_date" class="widefat somechange" type="date" value="<?php echo get_post_meta($post->ID,'ev_date',true)?>" /><br/>
		  <label for="Event_title">Event Address: </label>
		  <input name="ev_address" class="widefat somechange" type="text" value="<?php echo get_post_meta($post->ID,'ev_address',true)?>" />
		  <label for="Event_title">Highlight Event Month: </label>
		  <input name="ev_month" class="widefat somechange" type="month" value="<?php echo get_post_meta($post->ID,'ev_month',true)?>" />
		  <label for="Event_title">Highlight Date: </label>
		  <input name="ev_datenum" class="widefat somechange" type="number" value="<?php echo get_post_meta($post->ID,'ev_datenum',true)?>" />
		<?php
		}

        // for user admin callback functions
		public function staff_meta_box_callback($post){	
		wp_nonce_field( 'basename(__FILE__)', 'staff_url_metabox_nonce' );
		?>
		  <label for="author_s">Autor Select</label>
		  <select id="role" name="author_ss">
		  	<?php
		  	    if( is_user_logged_in() ) {
				    $user = wp_get_current_user();
				    $role = ( array ) $user->roles;
				    $auth_result = $role[0];
				  }
		  	   wp_dropdown_roles( $auth_result );

		  	 ?>
		  </select>
		<?php
		}

		public function staff_meta_social_callback(){
			global $post;
		    $mytext =   get_post_meta($post->ID, 'mytext', true);
		    ?>
		<div class="input_fields_wrap">
		    <a class="add_field_button button-secondary">Add Items</a>
		    <?php
		    if(isset($mytext) && is_array($mytext)) {
		        $i = 1;
		        $output = '';
		        foreach($mytext as $text){
		            //echo $text;
		            $output = '<div class="social chnge"><label for="faicon">Icon Name</label><input placeholder="fa-name" id="faicon" type="text" name="mytext[]" value="' . $text . '"/>';
		            if( $i !== 1 && $i > 1 ) $output .= '<a href="#" class="remove_field">Remove</a>';
		            else $output .= '</div>';
		            
		            echo $output;
		            $i++;
		        }
		    } else {
		        echo '<div class="social"><label for="faicon">Icon Name</label><input placeholder="fa-name" id="faicon" type="text" name="mytext[]"/></div>';
		    }
		    ?>
		</div>
		<?php
	}

		// save all meta box
		public function wpdocs_save_meta_box( $post_id ) {
			if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
 
		    // if our current user can't edit this post, bail
		    if( !current_user_can( 'edit_post' ) ) return;
		 
		    // now we can actually save the data
		    $allowed = array(
		        'a' => array( // on allow a tags
		            'href' => array() // and those anchors can only have href attribute
		        )
		    );
		    // If any value present in input field, then update the post meta
		    if(isset($_POST['mytext'])) {
		        // $post_id, $meta_key, $meta_value
		        update_post_meta( $post_id, 'mytext', $_POST['mytext'] );
		    }



		    Update_post_meta($post_id,'readmoreurl',$_POST['readmoreurl']);
		    Update_post_meta($post_id,'Audiosong',$_POST['Audiosong']);
		    Update_post_meta($post_id,'videourl',$_POST['videourl']);
		    Update_post_meta($post_id,'readmore',$_POST['readmore']);
		    Update_post_meta($post_id,'sliderreadmoreurl',$_POST['sliderreadmoreurl']);
		    Update_post_meta($post_id,'ev_date',$_POST['ev_date']);
		    Update_post_meta($post_id,'ev_address',$_POST['ev_address']);
		    Update_post_meta($post_id,'ev_month',$_POST['ev_month']);
		    Update_post_meta($post_id,'ev_datenum',$_POST['ev_datenum']);


			Update_post_meta($post_id,'fname',$_POST['fname']);
			Update_post_meta($post_id,'lname',$_POST['lname']);
			Update_post_meta($post_id,'email',$_POST['email']);
			Update_post_meta($post_id,'pnumber',$_POST['pnumber']);
			Update_post_meta($post_id,'Organization',$_POST['Organization']);
			Update_post_meta($post_id,'address',$_POST['address']);
			Update_post_meta($post_id,'zip',$_POST['zip']);
			Update_post_meta($post_id,'city',$_POST['city']);
			Update_post_meta($post_id,'state',$_POST['state']);
			Update_post_meta($post_id,'Country',$_POST['Country']);
			Update_post_meta($post_id,'amound',$_POST['amound']);
			Update_post_meta($post_id,'ccard',$_POST['ccard']);
			Update_post_meta($post_id,'Card',$_POST['Card']);
			Update_post_meta($post_id,'Date',$_POST['Date']);
			Update_post_meta($post_id,'month',$_POST['month']);
			Update_post_meta($post_id,'year',$_POST['year']);
			Update_post_meta($post_id,'cvvcode',$_POST['cvvcode']);


		}


         // User save all meta box
         public function staff_save_meta_box($post_id, $post ){
        	
            $author_name ="";
            if(isset($_POST['author_ss'])){
              $author_name = sanitize_text_field($_POST['author_ss']);
            }else{
            	$author_name ="";
            }
        	
        	 Update_post_meta($post_id,"author_aaa", $author_name);
        }

}

?>

