 <div class="row">
      <div class="col-lg-6 col-md-6 col-sm-6 width100">
        <label class="ash">First Name<span class="star">*</span></label>
        <input type="text" required value="<?php echo get_post_meta(get_the_ID(),'fname', true); ?>" class="form-control" id="fname" name="fname">
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 width100">
        <label class="ash">Last Name<span class="star">*</span> </label>
        <input type="text" required value="<?php echo get_post_meta(get_the_ID(),'lname', true); ?>" class="form-control" id="lname" name="lname">
      </div>
  </div>
   <div class="row">
      <div class="col-lg-6 col-md-6 col-sm-6 width100">
        <label class="ash">Email<span class="star">*</span></label>
        <input type="email" required value="<?php echo get_post_meta(get_the_ID(),'email', true); ?>" class="form-control" id="email" name="email">
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 width100">
        <label class="ash">Phone<span class="star">*</span> </label>
        <input type="number" required value="<?php echo get_post_meta(get_the_ID(),'pnumber', true); ?>" class="form-control" id="pnumber" name="pnumber">
      </div>
  </div>
   <div class="row">
      <div class="col-lg-6 col-md-6 col-sm-6 width100">
        <label class="ash">Organization</label>
        <input type="text" required value="<?php echo get_post_meta(get_the_ID(),'Organization', true); ?>" class="form-control" id="Organization" name="Organization">
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 width100">
        <label class="ash">Address<span class="star">*</span> </label>
        <input type="text" required value="<?php echo get_post_meta(get_the_ID(),'address', true); ?>" class="form-control" id="address" name="address">
      </div>
  </div>
   <div class="row">
      <div class="col-lg-6 col-md-6 col-sm-6 width100">
        <label class="ash">Zip<span class="star">*</span></label>
        <input type="text" required value="<?php echo get_post_meta(get_the_ID(),'zip', true); ?>" class="form-control" id="zip" name="zip">
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 width100">
        <label class="ash">City<span class="star">*</span> </label>
        <input type="text" required value="<?php echo get_post_meta(get_the_ID(),'city', true); ?>" class="form-control" id="city" name="city">
      </div>
  </div>
   <div class="row">
      <div class="col-lg-6 col-md-6 col-sm-6 width100">
        <label class="ash">State<span class="star">*</span></label>
        <input type="text" required value="<?php echo get_post_meta(get_the_ID(),'state', true); ?>" class="form-control" id="state" name="state">
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 width100">
        <label class="ash">Country<span class="star">*</span> </label>

        <select class="form-control " id="Country" required name="Country" >
            <?php $deshs = array('Afghanistan', 'Akrotiri', 'Albania', 'Algeria', 'American Samoa', 'Andorra', 'Anguilla', 'Antarctica', 'Antigua and Barbuda', 'Argentina', 'Armenia', 'Aruba', 'Ashmore and Cartier Islands', 'Australia', 'Austria', 'Azerbaijan', 'Bahamas', 'Bahrain', 'Bangladesh', 'Barbados', 'Bassas de India', 'Belarus', 'Belgium', 'Belize', 'Benin', 'Bermuda', 'Bhutan', 'Bolivia', 'Bosnia and Herzegovina', 'Botswanna', 'Bouvet Island', 'Brazil', 'British Indian Ocean Territory', 'British Virgin Islands', 'Brunei', 'Bulgaria', 'Burkina Faso', 'Burma', 'Burundi', 'Cambodia', 'Cameroon', 'Canada', 'Cape Verde', 'Cayman Islands', 'Central African Republic', 'Chad', 'Chile', 'China', 'Christmas Island', 'Clipperton Island', 'Cocoas (Keeling) Islands', 'Colombia', 'Comoros', 'Congo (Democratic Republic)', 'Congo (Republic)', 'Cook Islands', 'Coral Sea Islands', 'Costa Rica', 'Cote dlvoire', 'Croatia', 'Cuba', 'Cyprus', 'Czech Republic', 'Denmark', 'Dhekelia', 'Djibouti', 'Dominica', 'Dominican Republic', 'Ecuador', 'Egypt', 'El Salvador', 'Equatorial Guinea', 'Eritrea', 'Estonia', 'Ethiopia', 'Europa Island', 'Falkland Islands (Islas Malvinas)', 'Faroe Islands', 'Fiji', 'Finland', 'France', 'French Guinea', 'French Polynesia', 'French Southern and Antarctic Lands', 'Gabon', 'Gambia', 'Gaza Strip', 'Georgia', 'Germany', 'Ghana', 'Gibraltar', 'Glorioso Islands', 'Greece', 'Greenland', 'Grenada', 'Guadeloupe', 'Guam', 'Guatemala', 'Guernsey', 'Guinea', 'Guinea-Bissau', 'Guyana', 'Haiti', 'Heard Island and McDonald Islands', 'Holy See (Vatican City)', 'Honduras', 'Hong Kong', 'Hungary', 'Iceland', 'India', 'Indonesia', 'Iran', 'Iraq', 'Ireland', 'Isle of Man', 'Israel', 'Italy', 'Jamaica', 'Jan Mayen', 'Japan', 'Jersey', 'Jordan', 'Juan de Nova Island', 'Kazakhstan', 'Kenya', 'Kiribati', 'Korea (North)', 'Korea (South)', 'Kuwait', 'Kyrgyzstan', 'Laos', 'Latvia', 'Lebanon', 'Lesotho', 'Liberia', 'Libya', 'Liechtenstein', 'Lithuania', 'Luxembourg', 'Macau', 'Macedonia', 'Madagascar', 'Malawi', 'Malaysia', 'Maldives', 'Mali', 'Malta', 'Marshall Islands', 'Martinique', 'Mauritania', 'Mauritius', 'Mayotte', 'Mexico', 'Micronesia (Federated States)', 'Moldova', 'Monaco', 'Mongolia', 'Montserrat', 'Morocco', 'Mozambique', 'Namibia', 'Nauru', 'Navassa Island', 'Nepal', 'Netherlands', 'Netherlands Antilles', 'New Caledonia', 'New Zealand', 'Nicaragua', 'Niger', 'Nigeria', 'Niue', 'Norfolk Island', 'Northern Mariana Islands', 'Norway', 'Oman', 'Pakistan', 'Palau', 'Panama', 'Papua New Guinea', 'Paracel Islands', 'Paraguay', 'Peru', 'Philippines', 'Pitcairn Islands', 'Poland', 'Portugal', 'Puerto Rico', 'Qatar', 'Reunion', 'Romania', 'Russia', 'Rwanda', 'Saint Helena', 'Saint Kitts and Nevis', 'Saint Lucia', 'Saint Pierre and Miquelon', 'Saint Vincent and the Grenadines', 'Samoa', 'San Marino', 'Sao Tome and Principe', 'Saudi Arabia', 'Senegal', 'Serbia and Montenegro', 'Seychelles', 'Sierra Leone', 'Singapore', 'Slovakia', 'Slovenia', 'Solomon Islands', 'Somalia', 'South Africa', 'South Georgia and the South Sandwich Islands', 'Spain', 'Spratly Islands', 'Sri Lanka', 'Sudan', 'Suriname', 'Svalbard', 'Swaziland', 'Sweden', 'Switzerland', 'Syria', 'Taiwan', 'Tajikistan', 'Tanzania', 'Thailand', 'Timor-Leste', 'Togo', 'Tokelau', 'Tonga', 'Trinidad and Tobago', 'Tromelin Island', 'Tunisia', 'Turkey', 'Turkmenistan', 'Turks and Caicos Islands', 'Tuvalu', 'Uganda', 'Ukraine', 'United Arab Emirates', 'United Kingdom', 'United States', 'Uruguay', 'Uzbekistan', 'Vanuatu', 'Venezuela', 'Vietnam', 'Virgin Islands', 'Wake Island', 'Wallis and Futuna', 'West Bank', 'Western Sahara', 'Yemen', 'Zambia', 'Zimbabwe');
				$Country = get_post_meta(get_the_ID(),'Country', true);
				foreach ($deshs as $desh) {
				   ?>
				<option value="<?php echo $desh; ?>" <?php if($Country == $desh)echo "selected";?>><?php echo $desh; ?></option>
			<?php
			}?>
        </select>
      </div>
  </div>
   <div class="row dinfo">
   	 <h4>Donation Information</h4>
      <div class="col-lg-6 col-md-6 col-sm-6 width100">
        <label class="ash">Amound<span class="star">*</span></label>
        <input type="text" value="<?php echo get_post_meta(get_the_ID(),'amound', true); ?>" required class="form-control" id="amound" name="amound">
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 width100">
        <label class="ash">Cradit Card Number<span class="star">*</span> </label>
        <input type="text" required value="<?php echo get_post_meta(get_the_ID(),'ccard', true); ?>" class="form-control" id="ccard" name="ccard">
      </div>
  </div>
   <div class="row">
      <div class="col-lg-6 col-md-6 col-sm-6 width1200">
        <label class="ash">Card Type<span class="star">*</span></label>
        <select class="form-control " id="Card" required name="Card" >
            <?php 
            $Card = get_post_meta(get_the_ID(),'Card', true);
			$vcards = array("VISA", "MASTER CARD", "OTHER");
			foreach ($vcards as $index => $vcard) {
		  		?>
		  	  <option value="<?php echo $vcard; ?>" <?php if($Card == $vcard)echo "selected";?>><?php echo $vcard; ?></option> 
		  	 <?php
		  	 }
			?>
        </select>
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 width1300">
        <label class="ash">Expiration Date<span class="star">*</span> </label>
         <div class="col-lg-4 col-md-4 col-sm-4 width12000">
         	<select class="form-control" required id="Date" name="Date" >
         		<?php 
         		    $Date = get_post_meta(get_the_ID(),'Date', true);
					for ($x = 1; $x <= 30; $x++) {?>
					<option value="<?php echo $x; ?>" <?php if($Date == $x ){echo "selected";}?> ><?php echo $x; ?></option>
					<?php
					} 
				?>
        	</select>
         </div>

         <div class="col-lg-4 col-md-4 col-sm-4 width12000">
         	<select class="form-control" required id="month" name="month" >
         		<?php 
         		    $monthss = get_post_meta(get_the_ID(),'month', true);
					$months = array("Jan", "Feb", "Mar", "April","May","June","July","August","Sep","Dec");
					 foreach ($months as $index => $month) {
				  	 ?>
				  	  <option value="<?php echo $month; ?>" <?php if($monthss == $month)echo "selected";?>><?php echo $month; ?></option> 
				  	 <?php
				  	 }
				?>
        	</select>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-4 width12000">
         	<select class="form-control " required id="year" name="year" >
                <?php 
                	$year = get_post_meta(get_the_ID(),'year', true); 
                	for ($x = 2015; $x <= 2030; $x++) {?>
					<option value="<?php echo $x; ?>" <?php if($year == $x ){echo "selected";}?> ><?php echo $x; ?></option>
					<?php
					} 
				?>
        	</select>
         </div>
      </div>
  </div>
   <div class="row">
      <div class="col-lg-6 col-md-6 col-sm-6 width100">
        <label class="ash">Card(CVV) Code<span class="star">*</span></label>
        <input type="text" required value="<?php echo get_post_meta(get_the_ID(),'cvvcode', true); ?>" class="form-control" id="cvvcode" name="cvvcode">
      </div>
  </div>