<?php 

$Etitle_fontsize = get_option('Etitle_fontsize');
$Etitle_color = get_option('Etitle_color');
$Estitle_fontsize = get_option('Estitle_fontsize');
$Estitle_color = get_option('Estitle_color');

$Etime_fontsize = get_option('Etime_fontsize');
$Etime_color = get_option('Etime_color');
$Eaddress_fontsize = get_option('Eaddress_fontsize');
$Eaddress_color = get_option('Eaddress_color');


$Etarikh_fontsize = get_option('Etarikh_fontsize');
$Etarikh_color = get_option('Etarikh_color');
$Emonth_fontsize = get_option('Emonth_fontsize');
$Emonth_color = get_option('Emonth_color');

$Eview_fontsize = get_option('Eview_fontsize');
$Eviewback_color = get_option('Eviewback_color');
$Eview_color = get_option('Eview_color');

?>

<style type="text/css">
.events_twopart_title h4 {
  font-size: <?php echo $Estitle_fontsize;?>;
  color: <?php echo $Estitle_color; ?>;
  font-weight: 300;
}
 .time{
  font-size: <?php echo $Etime_fontsize;?>;
  color: <?php echo $Etime_color; ?>;
 }
 .address{
  font-size: <?php echo $Eaddress_fontsize;?>;
  color: <?php echo $Eaddress_color; ?>;
 } 
 .tarikh{
  font-size: <?php echo $Etarikh_fontsize;?>;
  color: <?php echo $Etarikh_color; ?>;
 }
 .month{
  font-size: <?php echo $Emonth_fontsize;?>;
  color: <?php echo $Emonth_color; ?>;
 }
.View_button a {
  background: <?php echo $Eviewback_color;?>
  font-size: <?php echo $Eview_fontsize;?>;
  color: <?php echo $Eview_color; ?>;
}
</style> 
<div class="container">
<div class="upcomming_Events_area"> 
   <div class="events_header">
      <h2 style="font-size: <?php echo $Etitle_fontsize;?>; color: <?php echo $Etitle_color;?>">UPCOMING EVENTS</h2>
   </div>
   <?php 
      $ektaveriable = new WP_Query(array(
        'post_type' => 'events',
        'posts_per_page' => -1
      ));
      ?>
      <?php if(have_posts()):while($ektaveriable->have_posts()) : $ektaveriable->the_post(); ?>
        <div class="row add">
            <div class="col-md-3">
              <div class="events_twopart_img">
                  <div class="events_images">
                  <?php echo get_the_post_thumbnail( $post_id, 'full' ); ?>
                  </div>
              </div>
             </div>
            <div class="col-md-5">
            <div class="events_twopart_title">
                <h4 class="evemt_subtitle"><?php echo get_the_title(); ?></h4>
                <p class="time">Present Date: <?php the_time('l, F jS, Y') ?> <br/>Event Date: <?php echo get_post_meta(get_the_ID(),'ev_date', true); ?></p>
                <p class="address"><?php echo get_post_meta(get_the_ID(),'ev_address', true); ?></p>
            </div>
           </div>
            <div class="col-md-4">
              <div class="events_twopart">
                  <div class="col-md-6">
                     <div class="date_add">
                        <p><span class="tarikh"><?php echo get_post_meta(get_the_ID(),'ev_datenum', true); ?></span><br/><span class="month"><?php echo get_post_meta(get_the_ID(),'ev_month', true); ?></span></p>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="View_button">
                       <a href="<?php echo get_the_permalink()?>">View Now</a>
                     </div>
                  </div>
              </div>
           </div>
        </div>
      <?php endwhile; endif; ?>
  </div>
</div>