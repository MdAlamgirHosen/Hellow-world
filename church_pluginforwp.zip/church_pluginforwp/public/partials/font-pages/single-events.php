<?php 

/*
Template Name: events single Page
*/
get_header(); 

 ?>


<?php 
	ob_start();
	include_once churchPLUGIN_URL."/public/partials/font-pages/modal.php";
	$template = ob_get_contents();
	ob_end_clean();
	echo $template;
?>

<section class="sermons_area_top_banner" style="background: url(<?php echo get_option('ebanner_img'); ?>); background-size: cover;">
	<div class="container">
		<div class="row">
		    <div class="col-md-12">
	     		<div class="sermons_blog">
	     			<h4>Events Blog Page</h4>
					<?php if(have_posts()):while(have_posts()):the_post(); ?>
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
							  <div class="menu_left">
								   <h2><?php the_title(); ?></h2>
							  </div>
						</div>
				   <?php endwhile; endif; ?>
			    </div>
            </div>		
        </div>
    </div>
 </section> 	

<section class="sermons_area">
	<div class="container">
		<div class="row">
		
		    <div class="col-md-12">
	     		<div class="sermons_header_main">
	     			<div class="content_post">
						<?php if(have_posts()):while(have_posts()):the_post(); ?>
								<div class="post-inner group">
									 <div class="col-sm-6 col-md-8">
							              <div class="Sermons_twopart sermons">
							              	  <div class="sermons_text img">
							              	  	<p class="image_thum"><?php echo get_the_post_thumbnail( $post_id, 'full' ); ?> 
							              	    </p>
							              	  	<h2 class="title_blog"><?php echo get_the_title(); ?></h2>
							              	  	 <p class="author">
							              	  	 	<span class="pastor blog"><?php echo get_post_meta(get_the_ID(),'author_aaa', true); ?> : </span> 

							              	  	 	<span class="auth blog"><a href="<?php echo get_author_posts_url($current_user->ID); ?>"><?php echo get_the_author(); ?></a> </span>
							              	  	 </p>
							              	  	
							              	  	  <p class="time events">Present Date: <?php the_time('l, F jS, Y') ?> <br/>Event Date: <?php echo get_post_meta(get_the_ID(),'ev_date', true); ?></p>
              									  <p class="address events"><?php echo get_post_meta(get_the_ID(),'ev_address', true); ?></p>
              									   <p class="content blog"><?php echo get_the_content();?></p>
							              	  	 <ul class="social_icon blog"> 
							                       <li><button type="button" class="vidLink" link="<?php echo get_post_meta(get_the_ID(),'videourl', true); ?>" data-toggle="modal" data-target="#myModal1"><i class="fa fa-film"></i></button></li>
								                    <li><button type="button" class="audioLink" link="<?php echo get_post_meta(get_the_ID(),'Audiosong', true); ?>" data-toggle="modal" data-target="#myModal"><i class="fa fa-music"></i></button></li>
							                      <li><a href="<?php echo get_post_meta(get_the_ID(),'readmoreurl', true); ?>"><i class="fa fa-download"></i></a></li>
							                  </ul>
							              	  </div>

							              	   <div class="social_share"> 
							              	  	 <div class="ayoshare"><div class="facebook button"><a onclick="ayo_share_og('#');" title="Facebook"><i class="icon"><i class="fa fa-facebook"></i></i><div class="counter"><p>0</p></div></a></div><div class="linkedin button"><a onclick="ayo_share_og('#', 'linkedin');" title="Linkedin"><i class="icon"><i class="fa fa-linkedin"></i></i><div class="counter"><p>0</p></div></a></div><div class="pinterest button"><a onclick="ayo_share_og('#');" title="Pinterest"><i class="icon"><i class="fa fa-pinterest"></i></i><div class="counter"><p>0</p></div></a></div><div class="google button"><a onclick="ayo_share_og('#');" title="Google+"><i class="mobile"><i class="fa fa-google-plus"></i></i></a></div><div class="twitter button"><a onclick="ayo_share_og('#');" title="Twitter"><i class="mobile"><i class="fa fa-twitter"></i></i></a></div></div>
							              	  </div>
							                  
							              </div>

											<div class="form_control">
										        <?php
												if ( post_password_required() )
												    return;
												?>
												<div id="comments" class="comments-area">
												    <?php if ( have_comments() ) : ?>
												        <h2 class="comments-title">
												            <?php
												            printf( _nx( 'One thought on "%2$s"', '%1$s thoughts on "%2$s"', get_comments_number(), 'comments title', 'twentythirteen' ),
												            number_format_i18n( get_comments_number() ), '<span>' . get_the_title() . '</span>' );
												            ?>
												        </h2>
												        <ol class="comment-list">
												            <?php
												                wp_list_comments( array(
												                    'style'       => 'ol',
												                    'short_ping'  => true,
												                    'avatar_size' => 74,
												                ) );
												            ?>
												        </ol><!-- .comment-list -->
												        <?php
												            // Are there comments to navigate through?
												            if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
												        ?>
												        <nav class="navigation comment-navigation" role="navigation">
												            <h1 class="screen-reader-text section-heading"><?php _e( 'Comment navigation', 'twentythirteen' ); ?></h1>
												            <div class="nav-previous"><?php previous_comments_link( __( '&larr; Older Comments', 'twentythirteen' ) ); ?></div>
												            <div class="nav-next"><?php next_comments_link( __( 'Newer Comments &rarr;', 'twentythirteen' ) ); ?></div>
												        </nav><!-- .comment-navigation -->
												        <?php endif; // Check for comment navigation ?>
												 
												        <?php if ( ! comments_open() && get_comments_number() ) : ?>
												        <p class="no-comments"><?php _e( 'Comments are closed.' , 'twentythirteen' ); ?></p>
												        <?php endif; ?>
												 
												    <?php endif; // have_comments() ?>
												 
												    <?php comment_form(); ?>
												 
												</div><!-- #comments -->
										    </div>
							           </div>

							           <div class="col-sm-6 col-md-4">
							              <div class="Sermons_twopart sermonssidebar">
							              	<h2 class="leatest_sermons">LATEST EVENTS</h2>
							              	  <?php $catquery = new WP_Query(array(
							                    'post_type' => 'events',
							                    'posts_per_page' => 5
							                  )); ?>
							              
							                     <?php while($catquery->have_posts()) : $catquery->the_post(); ?>
							                    <div class="main_area_blog">
							                      <div class="col-md-4 side">
							                      	 <div class="sidebarimg">
							                          <a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_post_thumbnail( $post_id, 'full' ); ?></a>
							                          </div>
							                       </div>
							                       <div class="col-md-8">
							                       <div class="single_slide_item sidebar">
							                          <h4><?php echo get_the_title(); ?></h4>
							                          <p><?php the_time('l, F jS, Y') ?></p>
							                      </div>
							                      </div>
							                  	</div>
							                      <?php endwhile; ?> 
							                    <?php wp_reset_postdata(); ?>
							              </div>


							               <div class="Sermons_twopart sermonssidebar blog">
							               	<h2 class="leatest_sermons">LATEST POST</h2>
							              	  <?php $catquery = new WP_Query(array(
							                    'post_type' => 'post',
							                    'posts_per_page' => 4
							                  )); ?>
							              
							                     <?php while($catquery->have_posts()) : $catquery->the_post(); ?>
							                     <div class="main_area_blog">	
							                      <div class="col-md-4 side">
							                      	 <div class="sidebarimg">
							                         <a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_post_thumbnail( $post_id, 'full' ); ?></a>
							                          </div>
							                       </div>
							                       <div class="col-md-8">
							                       <div class="single_slide_item sidebar">
							                          <h4><?php echo get_the_title(); ?></h4>
							                          <p><?php the_time('l, F jS, Y') ?></p>
							                      </div>
							                      </div>
							                    </div>
							                      <?php endwhile; ?> 
							                    <?php wp_reset_postdata(); ?>
							              </div>
							           </div>
									
								</div><!--/.post-inner-->			
						<?php endwhile; endif; ?>
					</div>

				</div>
         	</div>		
      </div>
    </div>
 </section> 

 
 
<?php
get_footer(); 
?>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
	
	$('.vidLink').on('click', function(){
		var link = $(this).attr('link');
		var ytVideoId = youtubeurlid(link);
		var embededLink = "https://www.youtube.com/embed/"+ytVideoId;
		//alert(embededLink);
		$('.modalVidLink').attr('src', embededLink);

	})
	$('.audioLink').on('click', function(){
		var link = $(this).attr('link');
		$("#Audiosong").attr("name",link);
	})

	function youtubeurlid(url){
     var regExp = /^.*(youtu\.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
     var match = url.match(regExp); 
     if (match && match[2].length == 11) { return match[2]; } 
     else {return 0;}
	}

</script>