
<?php 

$Lstaftitle_fontsize = get_option('Lstaftitle_fontsize');
$Lstaftitle_color = get_option('Lstaftitle_color');
$Lstafstitle_fontsize = get_option('Lstafstitle_fontsize');
$Lstafstitle_color = get_option('Lstafstitle_color');
$Lsname_fontsize = get_option('Lsname_fontsize');
$Lsname_color = get_option('Lsname_color');
$Lssocial_backcolor = get_option('Lssocial_backcolor');
$Lssocial_color = get_option('Lssocial_color');
$Lssocial_onoff = get_option('Lssocial_onoff');
?>

<style type="text/css"> 
.single_slide_item h4 {
  font-size: <?php echo $Lsname_fontsize;?>;
  color: <?php echo $Lsname_color;?>;
}
.Staff_socila li a {
  background: <?php echo $Lssocial_backcolor;?>;
  color: <?php echo $Lssocial_color;?>;
}
.Staff_socila {
  display: <?php if($Lssocial_onoff ==1){echo "block";}else{echo "none";}?>
}

</style>

<div class="Staff_area">
   <div class="container">
       <div class="Staff_header">
          <h2 style="font-size: <?php echo $Lstaftitle_fontsize;?>; color: <?php echo $Lstaftitle_color;?>">OUR STAFF</h2>
          <h4 style="font-size: <?php echo $Lstafstitle_fontsize;?>; color: <?php echo $Lstafstitle_color;?>">The churches must learn humility as well as teach it</h4>
       </div>
       
          <div class="owl-carousel owl-theme">
            <?php $catquery = new WP_Query(array(
                'post_type' => 'Staff',
                'posts_per_page' => 4
              )); ?>
          
                 <?php while($catquery->have_posts()) : $catquery->the_post(); ?>
                   <div class="item">
                       <div class="single_slide_item Staff">
                        <div class="images img_change">
                           <?php echo get_the_post_thumbnail( $post_id, 'full' ); ?>
                        </div>
                        <h4><?php echo get_the_title(); ?></h4>
                        <p><?php echo get_post_meta(get_the_ID($post->display_name),'author_aaa', true); ?>
                        </p>
                        <?php $result = get_post_meta(get_the_ID(),'mytext', true); ?>
                        <ul class="Staff_socila">
                          <?php foreach($result as $rus){
                            ?>
                             <li><a href="#"><i class="fa <?php echo $rus; ?>"></i></a></li>
                            <?php
                          }?>
                        </ul>
                    </div>
                    </div>
                  <?php endwhile; ?> 
                <?php wp_reset_postdata(); ?>
          </div>

   </div>     
</div>
