<?php 

$Ttitle_fontsize = get_option('Ttitle_fontsize');
$Ttitle_color = get_option('Ttitle_color');

$Tttext_fontsize = get_option('Tttext_fontsize');
$Tttext_color = get_option('Tttext_color');

$Ttext_fontsize = get_option('Ttext_fontsize');
$Ttext_color = get_option('Ttext_color');

$Tbulletonoff = get_option('Tbulletonoff');

$Tatext_fontsize = get_option('Tatext_fontsize');
$Tatext_color = get_option('Tatext_color');


$tbanner_img = get_option('tbanner_img');
$tcolor = get_option('tcolor');
$tchek = get_option('tchek');
?>
<style type="text/css">
  .tt_content{
    font-size: <?php echo $Ttext_fontsize;?>;
    color: <?php echo $Ttext_color;?>;
  }
  #testimonials_bullet{
    display: <?php if($Tbulletonoff ==1){echo "block";}else{echo "none";}?>
  }
 .testimonials {
  background: url(<?php if($tchek==1){echo $tbanner_img;}?>)<?php if($tcolor){echo $tcolor;} ?>
}
</style>

<div class="testimonials">
   <div class="testimonials_header">
      <h2 style="font-size: <?php echo $Ttitle_fontsize;?>; color: <?php echo $Ttitle_color;?>">TESTIMONIAL</h2>
      <h4 style="font-size: <?php echo $Tttext_fontsize;?>; color: <?php echo $Tttext_color;?>">Experience God's Presence</h4>
   </div>

<div id="carousel-example-testimonilas" class="carousel slide carousel-fade"   data-ride="carousel">
            <!-- Wrapper for slides -->
          <div class="carousel-inner">
            <!-- Indicators -->
            <ol id="testimonials_bullet" class="carousel-indicators">
              <li data-target="#carousel-example-testimonilas" data-slide-to="0" class="active"></li>
              <li data-target="#carousel-example-testimonilas" data-slide-to="1"></li>
              <li data-target="#carousel-example-testimonilas" data-slide-to="2"></li>
            </ol>
            
             <!-- for carousel all item show -->
             <?php 
              $ektaveriable = new WP_Query(array(
                'post_type' => 'Testimonials',
                'posts_per_page' => 3
              ));
              ?>
              <?php $veriable2 = 0; if(have_posts()):while($ektaveriable->have_posts()) : $ektaveriable->the_post(); $veriable2++ ?>
              
              <?php if($veriable2 == 1) : ?>
               <div class="item active">
              <?php else : ?>
               <div class="item">
              <?php endif; ?>
              <div class="single_slide_item somechange">
                  <p class="tt_content"><q class="qeoteclass"><?php echo get_the_content(); ?></q></p>
                  <div class="images">
                  <?php echo get_the_post_thumbnail( $post_id, 'full' ); ?>
                  </div>
                  <h4 style="font-size: <?php echo $Tatext_fontsize;?>; color: <?php echo $Tatext_color;?>" class="author_nametxt"><?php echo get_the_title(); ?></h4>
              </div>
              </div>
              <?php endwhile; endif; ?>
           
          </div>
      </div>
</div>