<?php 

if ( 'POST' == $_SERVER['REQUEST_METHOD'] && !empty( $_POST['action'] ) && $_POST['action'] == "donation") {

//store our post vars into variables for later use
//now would be a good time to run some basic error checking/validation
//to ensure that data for these values have been set
$title     = $_POST['email'];
$content   = $_POST['msg'];
$tags   = $_POST['tag'];
$custom_field1 = $_POST['fname']; 
$custom_field2 = $_POST['lname'];
$custom_field3 = $_POST['email'];
$custom_field4 = $_POST['pnumber'];
$custom_field5 = $_POST['Organization'];
$custom_field6 = $_POST['address'];
$custom_field7 = $_POST['zip'];
$custom_field8 = $_POST['city'];
$custom_field9 = $_POST['state'];
$custom_field10 = $_POST['Country'];
$custom_field11 = $_POST['amound'];
$custom_field12 = $_POST['ccard'];
$custom_field13 = $_POST['Card'];
$custom_field14 = $_POST['Date'];
$custom_field17 = $_POST['month'];
$custom_field15 = $_POST['year'];
$custom_field16 = $_POST['cvvcode'];
$post_type = 'donation';

$uploaddir = wp_upload_dir();
$file = $_FILES["post_Fimage"]["authorimg"];
$uploadfile = $uploaddir['path'] . '/' . basename( $file );

move_uploaded_file( $_FILES["post_Fimage"]["tmp_name"] , $uploadfile );
$filename = basename( $uploadfile );

$wp_filetype = wp_check_filetype(basename($filename), null );

$attachment = array(
    'post_mime_type' => $wp_filetype['type'],
    'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
    'post_content' => '',
    'post_status' => 'inherit',
    'menu_order' => $_i + 1000
);
$attach_id = wp_insert_attachment( $attachment, $uploadfile );
    //echo "<pre>";print_r($wp_filetype);echo "</pre>";
    //echo "<pre>";print_r($_FILES);echo "</pre>";
set_post_thumbnail( $post_id, $attach_id ); 


//the array of arguements to be inserted with wp_insert_post
$new_post = array(
'post_title'    => $title,
'post_content'  => $content,
'tags_input'  => $tags,
'post_status'   => 'publish',
'post_category' => array('0',$_POST['cat']),          
'post_type'     => $post_type 
);

//insert the the post into database by passing $new_post to wp_insert_post
//store our post ID in a variable $pid
//we now use $pid (post id) to help add out post meta data
$pid=wp_insert_post($new_post);
add_post_meta($pid, 'fname', $custom_field1, true);
add_post_meta($pid, 'lname', $custom_field2, true);
add_post_meta($pid, 'email', $custom_field3, true);
add_post_meta($pid, 'pnumber', $custom_field4, true);
add_post_meta($pid, 'Organization', $custom_field5, true);
add_post_meta($pid, 'address', $custom_field6, true);
add_post_meta($pid, 'zip', $custom_field7, true);
add_post_meta($pid, 'city', $custom_field8, true);
add_post_meta($pid, 'state', $custom_field9, true);
add_post_meta($pid, 'Country', $custom_field10, true);
add_post_meta($pid, 'amound', $custom_field11, true);
add_post_meta($pid, 'ccard', $custom_field12, true);
add_post_meta($pid, 'Card', $custom_field13, true);
add_post_meta($pid, 'Date', $custom_field14, true);
add_post_meta($pid, 'year', $custom_field15, true);
add_post_meta($pid, 'cvvcode', $custom_field16, true);
add_post_meta($pid, 'month', $custom_field17, true);
	
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<?php wp_enqueue_media(); ?>
<section class="sermons_area_top_banner" style="background: url(<?php echo get_option('banner_img'); ?>); background-size: cover;">
   <div class="container">
		<div class="row">
		    <div class="col-md-12">
	     		<div class="sermons_blog">
	     		<h4>Donate page</h4>
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					  <div class="menu_left">
						<h2 style="font-size: <?php echo get_option('spttitlefont'); ?>; color: <?php echo get_option('spttitlecolor'); ?>"><?php the_title(); ?></h2>
					  </div>
				</div>
			    </div>
            </div>		
        </div>
    </div>
 </section> 	
<section class="sermons_area">
	<div class="container">
		<div class="row">
		    <div class="col-md-12">
	     		<div class="sermons_header_main">
	     			<div class="formhead">
		     			<h4>THANK YOU FOR DONATE</h4>
		     			<p>With religious faith, with the hope of helping others. We sincerely thank the hearts of donors. Please transfer the money to the address and information on the left or you can fill in the form on the right. We will contact you</p>
	     			</div>
					     <form method="post" name="front_end" action="">
				          <div class="row">
				          <div class="col-lg-6 col-md-6 col-sm-6 width100">
				            <label class="ash">First Name<span class="star">*</span></label>
				            <input type="text" required value="<?php echo get_post_meta(get_the_ID(),'fname', true); ?>" class="form-control" id="fname" name="fname">
				          </div>
				          <div class="col-lg-6 col-md-6 col-sm-6 width100">
				            <label class="ash">Last Name<span class="star">*</span> </label>
				            <input type="text" required value="" class="form-control" id="lname" name="lname">
				          </div>
			          </div>
			           <div class="row">
				          <div class="col-lg-6 col-md-6 col-sm-6 width100">
				            <label class="ash">Email<span class="star">*</span></label>
				            <input type="email" required value="" class="form-control" id="email" name="email">
				          </div>
				          <div class="col-lg-6 col-md-6 col-sm-6 width100">
				            <label class="ash">Phone<span class="star">*</span> </label>
				            <input type="number" required value="" class="form-control" id="pnumber" name="pnumber">
				          </div>
			          </div>
			           <div class="row">
				          <div class="col-lg-6 col-md-6 col-sm-6 width100">
				            <label class="ash">Organization</label>
				            <input type="text" required value="" class="form-control" id="Organization" name="Organization">
				          </div>
				          <div class="col-lg-6 col-md-6 col-sm-6 width100">
				            <label class="ash">Address<span class="star">*</span> </label>
				            <input type="text" required value="" class="form-control" id="address" name="address">
				          </div>
			          </div>
			           <div class="row">
				          <div class="col-lg-6 col-md-6 col-sm-6 width100">
				            <label class="ash">Zip<span class="star">*</span></label>
				            <input type="text" required value="" class="form-control" id="zip" name="zip">
				          </div>
				          <div class="col-lg-6 col-md-6 col-sm-6 width100">
				            <label class="ash">City<span class="star">*</span> </label>
				            <input type="text" required value="" class="form-control" id="city" name="city">
				          </div>
			          </div>
			           <div class="row">
				          <div class="col-lg-6 col-md-6 col-sm-6 width100">
				            <label class="ash">State<span class="star">*</span></label>
				            <input type="text" required value="" class="form-control" id="state" name="state">
				          </div>
				          <div class="col-lg-6 col-md-6 col-sm-6 width100">
				            <label class="ash">Country<span class="star">*</span> </label>
				            <select class="form-control " id="Country" required name="Country" >
                                  <?php 
									$deshs = array('Afghanistan', 'Akrotiri', 'Albania', 'Algeria', 'American Samoa', 'Andorra', 'Anguilla', 'Antarctica', 'Antigua and Barbuda', 'Argentina', 'Armenia', 'Aruba', 'Ashmore and Cartier Islands', 'Australia', 'Austria', 'Azerbaijan', 'Bahamas', 'Bahrain', 'Bangladesh', 'Barbados', 'Bassas de India', 'Belarus', 'Belgium', 'Belize', 'Benin', 'Bermuda', 'Bhutan', 'Bolivia', 'Bosnia and Herzegovina', 'Botswanna', 'Bouvet Island', 'Brazil', 'British Indian Ocean Territory', 'British Virgin Islands', 'Brunei', 'Bulgaria', 'Burkina Faso', 'Burma', 'Burundi', 'Cambodia', 'Cameroon', 'Canada', 'Cape Verde', 'Cayman Islands', 'Central African Republic', 'Chad', 'Chile', 'China', 'Christmas Island', 'Clipperton Island', 'Cocoas (Keeling) Islands', 'Colombia', 'Comoros', 'Congo (Democratic Republic)', 'Congo (Republic)', 'Cook Islands', 'Coral Sea Islands', 'Costa Rica', 'Cote dlvoire', 'Croatia', 'Cuba', 'Cyprus', 'Czech Republic', 'Denmark', 'Dhekelia', 'Djibouti', 'Dominica', 'Dominican Republic', 'Ecuador', 'Egypt', 'El Salvador', 'Equatorial Guinea', 'Eritrea', 'Estonia', 'Ethiopia', 'Europa Island', 'Falkland Islands (Islas Malvinas)', 'Faroe Islands', 'Fiji', 'Finland', 'France', 'French Guinea', 'French Polynesia', 'French Southern and Antarctic Lands', 'Gabon', 'Gambia', 'Gaza Strip', 'Georgia', 'Germany', 'Ghana', 'Gibraltar', 'Glorioso Islands', 'Greece', 'Greenland', 'Grenada', 'Guadeloupe', 'Guam', 'Guatemala', 'Guernsey', 'Guinea', 'Guinea-Bissau', 'Guyana', 'Haiti', 'Heard Island and McDonald Islands', 'Holy See (Vatican City)', 'Honduras', 'Hong Kong', 'Hungary', 'Iceland', 'India', 'Indonesia', 'Iran', 'Iraq', 'Ireland', 'Isle of Man', 'Israel', 'Italy', 'Jamaica', 'Jan Mayen', 'Japan', 'Jersey', 'Jordan', 'Juan de Nova Island', 'Kazakhstan', 'Kenya', 'Kiribati', 'Korea (North)', 'Korea (South)', 'Kuwait', 'Kyrgyzstan', 'Laos', 'Latvia', 'Lebanon', 'Lesotho', 'Liberia', 'Libya', 'Liechtenstein', 'Lithuania', 'Luxembourg', 'Macau', 'Macedonia', 'Madagascar', 'Malawi', 'Malaysia', 'Maldives', 'Mali', 'Malta', 'Marshall Islands', 'Martinique', 'Mauritania', 'Mauritius', 'Mayotte', 'Mexico', 'Micronesia (Federated States)', 'Moldova', 'Monaco', 'Mongolia', 'Montserrat', 'Morocco', 'Mozambique', 'Namibia', 'Nauru', 'Navassa Island', 'Nepal', 'Netherlands', 'Netherlands Antilles', 'New Caledonia', 'New Zealand', 'Nicaragua', 'Niger', 'Nigeria', 'Niue', 'Norfolk Island', 'Northern Mariana Islands', 'Norway', 'Oman', 'Pakistan', 'Palau', 'Panama', 'Papua New Guinea', 'Paracel Islands', 'Paraguay', 'Peru', 'Philippines', 'Pitcairn Islands', 'Poland', 'Portugal', 'Puerto Rico', 'Qatar', 'Reunion', 'Romania', 'Russia', 'Rwanda', 'Saint Helena', 'Saint Kitts and Nevis', 'Saint Lucia', 'Saint Pierre and Miquelon', 'Saint Vincent and the Grenadines', 'Samoa', 'San Marino', 'Sao Tome and Principe', 'Saudi Arabia', 'Senegal', 'Serbia and Montenegro', 'Seychelles', 'Sierra Leone', 'Singapore', 'Slovakia', 'Slovenia', 'Solomon Islands', 'Somalia', 'South Africa', 'South Georgia and the South Sandwich Islands', 'Spain', 'Spratly Islands', 'Sri Lanka', 'Sudan', 'Suriname', 'Svalbard', 'Swaziland', 'Sweden', 'Switzerland', 'Syria', 'Taiwan', 'Tajikistan', 'Tanzania', 'Thailand', 'Timor-Leste', 'Togo', 'Tokelau', 'Tonga', 'Trinidad and Tobago', 'Tromelin Island', 'Tunisia', 'Turkey', 'Turkmenistan', 'Turks and Caicos Islands', 'Tuvalu', 'Uganda', 'Ukraine', 'United Arab Emirates', 'United Kingdom', 'United States', 'Uruguay', 'Uzbekistan', 'Vanuatu', 'Venezuela', 'Vietnam', 'Virgin Islands', 'Wake Island', 'Wallis and Futuna', 'West Bank', 'Western Sahara', 'Yemen', 'Zambia', 'Zimbabwe');
									foreach ($deshs as $desh) {
									    echo "<option value=\"" . $desh . "\">" . $desh . "</option>";
									}?>
                            </select>
				          </div>
			          </div>
			           <div class="row dinfo">
			           	 <h4>Donation Information</h4>
				          <div class="col-lg-6 col-md-6 col-sm-6 width100">
				            <label class="ash">Amound<span class="star">*</span></label>
				            <input type="text" value="" required class="form-control" id="amound" name="amound">
				          </div>
				          <div class="col-lg-6 col-md-6 col-sm-6 width100">
				            <label class="ash">Cradit Card Number<span class="star">*</span> </label>
				            <input type="text" required value="" class="form-control" id="ccard" name="ccard">
				          </div>
			          </div>
			           <div class="row">
				          <div class="col-lg-6 col-md-6 col-sm-6 width1200">
				            <label class="ash">Card Type<span class="star">*</span></label>
				            <select class="form-control " id="Card" required name="Card" >
                                <?php 
									$vcards = array("VISA", "MASTER CARD", "OTHER");
									foreach ($vcards as $vcard) {
									    echo "<option value=\"" . $vcard . "\">" . $vcard . "</option>";
									}
								?>
                            </select>
				          </div>
				          <div class="col-lg-6 col-md-6 col-sm-6 width1300">
				            <label class="ash">Expiration Date<span class="star">*</span> </label>
				             <div class="col-lg-4 col-md-4 col-sm-4 width12000">
				             	<select class="form-control" required id="Date" name="Date" >
				             		<?php 
										for ($x = 1; $x <= 30; $x++) {?>
										<option value="<?php echo$x; ?>"> <?php echo$x; ?></option>
										<?php
										} 
									?>
                            	</select>
				             </div>
				             <div class="col-lg-4 col-md-4 col-sm-4 width12000">
				             	<select class="form-control " required id="month" name="month" >
	                                <?php 
										$months = array("Jan", "Feb", "Mar", "April","May","June","July","August","Sep","Dec");
										foreach ($months as $month) {
										    echo "<option value=\"" . $month . "\">" . $month . "</option>";
										}
									?>
                            	</select>
				             </div>
				              <div class="col-lg-4 col-md-4 col-sm-4 width12000">
				             	<select class="form-control " required id="year" name="year" >
	                                <?php 
										for ($x = 2015; $x <= 2030; $x++) {?>
										<option value="<?php echo$x; ?>"> <?php echo$x; ?></option>
										<?php
										} 
									?>
                            	</select>
				             </div>
				          </div>
			          </div>
			           <div class="row">
				          <div class="col-lg-6 col-md-6 col-sm-6 width100">
				            <label class="ash">Card(CVV) Code<span class="star">*</span></label>
				            <input type="text" required value="" class="form-control" id="cvvcode" name="cvvcode">
				          </div>
			          </div>
			          <div class="col-lg-12 col-md-12 col-sm-12 width1010">
			            <label class="ash">Message<span class="star">*</span> </label>
			            <textarea value="" class="form-control" id="msg" name="msg"></textarea>
			          </div>
				            <button type="submit" class="btn btn-primary">Submit</button>
				            <input type="hidden" name="action" value="donation" />
				        </form>
				</div>
         	</div>		
       </div>
    </div>
 </section> 