<?php 

$gtitle_fontsize = get_option('gtitle_fontsize');
$gtitle_color = get_option('gtitle_color');
$gtext_fontsize = get_option('gtext_fontsize');
$gtext_color = get_option('gtext_color');
$giconchange = get_option('giconchange');
$gicontext_size = get_option('gicontext_size');
$gicontext_color = get_option('gicontext_color');
$gicononoff = get_option('gicononoff');

?>

<style type="text/css">
.img_control li:before {
  color: <?php echo $gicontext_color; ?>;
  font-size: <?php echo $gicontext_size;?>;
  display: <?php if($gicononoff ==1){echo "block";}else{echo "none";}?>
}

</style> 

<section class="gallery_area">
   <div class="gallery_header">
      <h2 style="font-size: <?php echo $gtitle_fontsize;?>; color: <?php echo $gtitle_color;?>">GALLERY</h2>
      <h4 style="font-size: <?php echo $gtext_fontsize;?>; color: <?php echo $gtext_color;?>">Our Church Photo Galleries</h4>
   </div>

<div class="container gallery-container">
    <div class="tz-gallery">

        <div class="row">
            <?php 
              $ektaveriable = new WP_Query(array(
                'post_type' => 'Gallery',
                'posts_per_page' => 5,
                'orderby' => 'ID',
                'order' => 'desc'
                
              ));
             
              ?>

             <ul class="img_control">
              <?php if(have_posts()) : while($ektaveriable->have_posts()) : $ektaveriable->the_post(); ?>
                <?php  
                    $imgurl = get_the_post_thumbnail_url();
                    
                    $latest_cpt = get_posts("post_type=Gallery&numberposts=1");
                    $last = $latest_cpt[0]->ID;
                 ?>
                 <style type="text/css">
                  
                  #post-<?php echo $last; ?> {
                    width: 48%;
                    float: left;
                    margin: 0.3%;
                    padding: 0;
                  }
                </style>
                        <li class="img_controlstyle" <?php post_class(); ?> id="post-<?php the_ID(); ?>">
                          <a href="<?php echo $imgurl; ?>">
                              <?php echo get_the_post_thumbnail( $post_id,'top-photo-thumb' ); ?>
                          </a>
                      </li>
                 
           <?php endwhile; endif; ?>
           </ul>
        </div>

    </div>

  </div>
</section>


<script>
    baguetteBox.run('.tz-gallery');
</script>
