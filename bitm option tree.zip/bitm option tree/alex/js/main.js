(function($){ 
$(document).ready(function(){
  $("#portfolio_filter_action").mixitup({
		effects: ['scale','rotateZ'],
		easing: 'windup'
	});	
	$("a[rel^='prettyPhoto']").prettyPhoto();
	
	$(window).load(function() {
    $('.flexslider').flexslider({
     animation: "slide"
    });
});
}); 
})(jQuery);