<?php

/*
Template Name: faq page
*/

?>
	
<?php get_header(); ?>

	<section id="free_qoute"> 
		   <div class="container">
		   	<div class="row">
		   		<div class="col-lg-12"> 
				   <div class="title text-center"> 
				   <h2>Attorneys</h2>
				  </div>
				</div>
		   	</div>
		   </div>
		</section>
<section id="leatest_area">
		    <div class="container">
			    <div class="row" id="faQRow">
				    
				    	<!-- <div class="panel panel-default faqPanelDiv">
				    		<a href="" class="faqA" width="100%">
								Demo
				    		</a>
				    	</div> -->
				    	<!-- <a href="javascript:void(0);" class="faqA" style="text-decoration: none;">
				    		<div class="panel panel-default faqPanelDiv">
				    			<p class="quesPara">
				    				
<i class="fa fa-caret-down pull-right" aria-hidden="true" style="font-size: 30px; "></i>
				    			</p>
				    		</div>
				    		 the below div for answer
				    		<div class="well answerDiveFaq" style="padding-top: 0; margin-top: -20px; border-radius: 0; background:  white;">
				    			<p style="padding-top: 20px;" class="faqAnswerP">
				    					
				    			</p>
				    		</div>
				    	</a> --> 


   <!-- Question answer20 -->	
		    		<div class="panel panel-default faqPanelDiv" id="faq20">
		    		<a href="javascript:;" class="faqA">
		    			<p class="quesPara">
		    				Who is AutoBoost 123 and what exactly does your company do?
							<i class="fa fa-caret-down pull-right" aria-hidden="true" style="font-size: 30px; "></i>
		    			</p>
		    			</a>

		    		</div>
		    		<!-- the below div for answer -->
		    		<div class="well answerDiveFaq" id="faqAns20" style="">
		    			<p class="faqAnswerP" style="padding-top: 20px;">
		    				We are a Texas based marketing company who specializes in lead generation for new car automotive dealerships all across the country. 
<br>We create, customize and manage every aspect of a multifaceted campaign that is designed to rapidly expand your flow of high quality leads. 
<br>By utilizing our proprietary software along with cutting edge technology, we help auto dealers BOOST their sales in a very short period of time. 
		    			</p>
		    		</div>
		    		<!-- End Question answer20 -->



				    <!-- Question answer1 -->	
		    		<div class="panel panel-default faqPanelDiv" id="faq1">
		    		<a href="javascript:;" class="faqA">
		    			<p class="quesPara">
		    				How long does it take to launch a campaign ?
							<i class="fa fa-caret-down pull-right" aria-hidden="true" style="font-size: 30px; "></i>
		    			</p>
		    			</a>

		    		</div>
		    		<!-- the below div for answer -->
		    		<div class="well answerDiveFaq" id="faqAns1" style="">
		    			<p class="faqAnswerP" style="padding-top: 20px;">
		    				We can have your dealership up and running within 48 hours of signing up as a client...
		    			</p>
		    		</div>
		    		<!-- End Question answer1 -->



<!-- Question answer6 -->	
		    		<div class="panel panel-default faqPanelDiv" id="faq6">
		    		<a href="javascript:;" class="faqA">
		    			<p class="quesPara">
		    				How long does a campaign last ?
							<i class="fa fa-caret-down pull-right" aria-hidden="true" style="font-size: 30px; "></i>
		    			</p>
		    			</a>

		    		</div>
		    		<!-- the below div for answer -->
		    		<div class="well answerDiveFaq" id="faqAns6" style="">
		    			<p class="faqAnswerP" style="padding-top: 20px;">
		    				Your campaign will run over the course of one (1) week...
		    			</p>
		    		</div>
		    		<!-- End Question answer6 -->


<!-- Question answer8 -->	
		    		<div class="panel panel-default faqPanelDiv" id="faq8">
		    		<a href="javascript:;" class="faqA">
		    			<p class="quesPara">
		    				How many total campaigns can we run ?
							<i class="fa fa-caret-down pull-right" aria-hidden="true" style="font-size: 30px; "></i>
		    			</p>
		    			</a>

		    		</div>
		    		<!-- the below div for answer -->
		    		<div class="well answerDiveFaq" id="faqAns8" style="">
		    			<p class="faqAnswerP" style="padding-top: 20px;">
		    				That all depends on the size of your customer database</p>
<p class="faqAnswerP" style="padding-top: 20px;">We load 1,000 names into our software for a one-week campaign. </p>
<p class="faqAnswerP" style="padding-top: 20px;">So for example, if you had 20,000 names in your database we would be able to run a 20 week campaign for your dealership.</p>
		    			</p>
		    		</div>
		    		<!-- End Question answer8 -->



		    		<!-- Question answer2 -->	
		    		<div class="panel panel-default faqPanelDiv" id="faq2">
		    		<a href="javascript:;" class="faqA">
		    			<p class="quesPara">
		    				Does your program work for used car dealerships ?
							<i class="fa fa-caret-down pull-right" aria-hidden="true" style="font-size: 30px; "></i>
		    			</p>
		    			</a>

		    		</div>
		    		<!-- the below div for answer -->
		    		<div class="well answerDiveFaq" id="faqAns2" style="">
		    			<p class="faqAnswerP" style="padding-top: 20px;">
		    				No, it's only offered for new car dealerships...

		    			</p>
		    		</div>
		    		<!-- End Question answer2 -->

		    		<!-- Question answer3 -->	
		    		<div class="panel panel-default faqPanelDiv" id="faq3">
		    		<a href="javascript:;" class="faqA">
		    			<p class="quesPara">
		    				Does this program work in any state ?
							<i class="fa fa-caret-down pull-right" aria-hidden="true" style="font-size: 30px; "></i>
		    			</p>
		    			</a>

		    		</div>
		    		<!-- the below div for answer -->
		    		<div class="well answerDiveFaq" id="faqAns3" style="">
		    			<p class="faqAnswerP" style="padding-top: 20px;">
		    					Yes it does...
		    			</p>
		    		</div>
		    		<!-- End Question answer3 -->


	    		<div class="panel panel-default faqPanelDiv" id="faq5">
		    		<a href="javascript:;" class="faqA">
		    			<p class="quesPara">
		    				Is there a minimum sized dealership that you will work with ?
							<i class="fa fa-caret-down pull-right" aria-hidden="true" style="font-size: 30px; "></i>
		    			</p>
		    			</a>

		    		</div>
		    		<!-- the below div for answer -->
		    		<div class="well answerDiveFaq" id="faqAns5" style="">
		    			<p class="faqAnswerP" style="padding-top: 20px;">
		    				We prefer to work with dealerships who have at least 100 new cars on their lot....
		    			</p>
		    		</div>
		    		<!-- End Question answer5 -->

<!-- Question answer13 -->		
		    		<div class="panel panel-default faqPanelDiv" id="faq13">
		    		<a href="javascript:;" class="faqA">
		    			<p class="quesPara">
		    				Will our dealership receive any information about the results of our campaign?
							<i class="fa fa-caret-down pull-right" aria-hidden="true" style="font-size: 30px; "></i>
		    			</p>
		    			</a>

		    		</div>
		    		<!-- the below div for answer -->
		    		<div class="well answerDiveFaq" id="faqAns13" style="">
		    			<p class="faqAnswerP" style="padding-top: 20px;">
		    				Yes, once it's completed we provide you with a detailed report containing all of the statistics and data that we collected during your campaign. </p>
		    			</p>
		    		</div>
		    		<!-- End Question answer13 -->


		    		<!-- Question answer4 -->	
		    		<div class="panel panel-default faqPanelDiv" id="faq4">
		    		<a href="javascript:;" class="faqA">
		    			<p class="quesPara">
		    				Do you offer a moneyback guarantee?
							<i class="fa fa-caret-down pull-right" aria-hidden="true" style="font-size: 30px; "></i>
		    			</p>
		    			</a>

		    		</div>
		    		<!-- the below div for answer -->
		    		<div class="well answerDiveFaq" id="faqAns4">
		    			<p class="faqAnswerP" style="padding-top: 20px;">
		    				Absolutely, if you are not 100% satisfied with our service then you will pay us NOTHING. If your campaign does not produce a positive ROI (Return on Investment) for your dealership then you Do Not pay.....its that simple!!
		    			</p>
		    		</div>
		    		<!-- End Question answer4 -->

		    		<!-- Question answer5 -->	
	
<!-- Question answer11 -->	
		    		<div class="panel panel-default faqPanelDiv" id="faq7">
		    		<a href="javascript:;" class="faqA">
		    			<p class="quesPara">
		    				Does your company do lead generation for other types of businesses ?
							<i class="fa fa-caret-down pull-right" aria-hidden="true" style="font-size: 30px; "></i>
		    			</p>
		    			</a>

		    		</div>
		    		<!-- the below div for answer -->
		    		<div class="well answerDiveFaq" id="faqAns7" style="">
		    			<p class="faqAnswerP" style="padding-top: 20px;">
		    				No, we only work with new car dealers as we want to focus 100% of our time, energy and attention on staying up-to-date with all current trends and technology in the automotive market place. </p>
		    			</p>
		    		</div>
		    		<!-- End Question answer11 -->
		    		


		    		<!-- Question answer7 -->		
		    		<div class="panel panel-default faqPanelDiv" id="faq14">
		    		<a href="javascript:;" class="faqA">
		    			<p class="quesPara">
		    				Is your company compliant with all FTC and FCC rules, regulations and guidelines ?
							<i class="fa fa-caret-down pull-right" aria-hidden="true" style="font-size: 30px; "></i>
		    			</p>
		    			</a>

		    		</div>
		    		<!-- the below div for answer -->
		    		<div class="well answerDiveFaq" id="faqAns14" style="">
		    			<p class="faqAnswerP" style="padding-top: 20px;">
		    				Yes, we make sure that we observe all telecommunication laws and we scrub all of our lists against the Do Not Call Registry...</p>
		    			</p>
		    		</div>
		    		<!-- End Question answer7 -->


	<!-- Question answer10 -->	
		    		<div class="panel panel-default faqPanelDiv" id="faq10">
		    		<a href="javascript:;" class="faqA">
		    			<p class="quesPara">
		    				Is your company accredited by the Better Business Bureau (BBB) ?
							<i class="fa fa-caret-down pull-right" aria-hidden="true" style="font-size: 30px; "></i>
		    			</p>
		    			</a>

		    		</div>
		    		<!-- the below div for answer -->
		    		<div class="well answerDiveFaq" id="faqAns10" style="">
		    			<p class="faqAnswerP" style="padding-top: 20px;">
		    				Yes we are...</p>
		    			</p>
		    		</div>
		    		<!-- End Question answer10 -->
	    		



<!-- Question answer9 -->	
		    		<div class="panel panel-default faqPanelDiv" id="faq11">
		    		<a href="javascript:;" class="faqA">
		    			<p class="quesPara">
		    				What does your service cost ?
							<i class="fa fa-caret-down pull-right" aria-hidden="true" style="font-size: 30px; "></i>
		    			</p>
		    			</a>

		    		</div>
		    		<!-- the below div for answer -->
		    		<div class="well answerDiveFaq" id="faqAns11" style="">
		    			<p class="faqAnswerP" style="padding-top: 20px;">
		    				Pricing varies based on each clients individual needs. <br>
<br>No matter the size of your dealership, our sales team will work with you to tailor a package that meets your requirements and price considerations. 
<br>So give us a call at 800.290.3038 and we can go over your situation in more detail and provide you with an accurate price quote. </p>
		    			</p>
		    		</div>
		    		<!-- End Question answer9 -->





				    	



			    </div>
		    </div>
 </section>


<?php get_footer(); ?>