<?php
/**
 * Initialize the custom Theme Options.
 */
add_action( 'init', 'custom_theme_options' );

/**
 * Build the custom settings & update OptionTree.
 *
 * @return    void
 * @since     2.0
 */
function custom_theme_options() {

  /* OptionTree is not loaded yet, or this is not an admin request */
  if ( ! function_exists( 'ot_settings_id' ) || ! is_admin() )
    return false;

  /**
   * Get a copy of the saved settings array. 
   */
  $saved_settings = get_option( ot_settings_id(), array() );
  
  /**
   * Custom settings array that will eventually be 
   * passes to the OptionTree Settings API Class.
   */
  $custom_settings = array( 
    'contextual_help' => array( 
      'content'       => array( 
        array(
          'id'        => 'option_types_help',
          'title'     => __( 'Option Types', 'theme-text-domain' ),
          'content'   => '<p>' . __( 'Help content goes here!', 'theme-text-domain' ) . '</p>'
        )
      ),
      'sidebar'       => '<p>' . __( 'Sidebar content goes here!', 'theme-text-domain' ) . '</p>'
    ),
	/* header_logo */
    'sections'        => array( 
      array(
        'id'          => 'header_logo',
        'title'       => __( 'header_logo', 'theme-text-domain' )
      ),  
	  
	  /* categorys */
	  array(
        'id'          => 'categorys',
        'title'       => __( 'categorys', 'theme-text-domain' )
      ),
	  
	  /* slider */
	  array(
        'id'          => 'slider',
        'title'       => __( 'slider', 'theme-text-domain' )
      ),
	  
	  /* gallery */
	  array(
        'id'          => 'gallery',
        'title'       => __( 'gallery', 'theme-text-domain' )
      ),
	  
	  /* On_Off */
	  array(
        'id'          => 'On_Off',
        'title'       => __( 'On_Off', 'theme-text-domain' )
      ),

	  /* peuple_area */
	  array(
        'id'          => 'peuple_area',
        'title'       => __( 'peuple_area', 'theme-text-domain' )
      ),
	  
	  /* Notre_area */
	  array(
        'id'          => 'Notre_area',
        'title'       => __( 'Notre_area', 'theme-text-domain' )
      ),

	  /* FEATURES_post */
	  array(
        'id'          => 'FEATURE_area',
        'title'       => __( 'FEATURE_area', 'theme-text-domain' )
      ),
    ),
	
	
	/* logo_upload */
	
    'settings'        => array( 
      array(
        'id'          => 'logo_upload',
        'label'       => __( 'logo upload', 'theme-text-domain' ),
        'desc'        => 'Upload your logo',
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'header_logo',
      ),
	  array(
        'id'          => 'subtitle',
        'label'       => __( 'subtitle', 'theme-text-domain' ),
        'desc'        => 'Add your subtitle',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'Basic',
      ),
	  
	  /* category_select */
	 array(
        'id'          => 'category_select',
        'label'       => __( 'Category Select', 'theme-text-domain' ),
        'desc'        => __( 'The Category Select post' ),
        'std'         => '',
        'type'        => 'category-select',
        'section'     => 'categorys',
      ),
	  array(
        'id'          => 'Post_number',
        'label'       => __( 'How many post', 'theme-text-domain' ),
        'desc'        => __( 'Number select post' ),
        'std'         => '1',
        'type'        => 'text',
        'section'     => 'categorys',
      ),

	  /* Post_gallery */
	  array(
        'id'          => 'Post_gallery',
        'label'       => __( 'Add your gallery image', 'theme-text-domain' ),
        'desc'        => __( 'Add your chooice gallery image' ),
        'std'         => '',
        'type'        => 'Gallery',
        'section'     => 'gallery',
      ), 
	  
	  /* on off */
	  array(
        'id'          => 'Post_onoff',
        'label'       => __( 'Post_onoff', 'theme-text-domain' ),
        'desc'        => __( 'Add your chooice Post_onoff' ),
        'std'         => 'Off',
        'type'        => 'On-Off',
        'section'     => 'On_Off',
      ),
	 
	   /* Post_peuple_area */
	  array(
        'id'          => 'Post_peuple_area',
        'label'       => __( 'Post_peuple_area', 'theme-text-domain' ),
        'desc'        => __( 'Add Title Post_peuple_area ' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'peuple_area',
      ), 
	 
	  array(
        'id'          => 'content_Post_peuple_area',
        'label'       => __( 'content_Post_peuple_area', 'theme-text-domain' ),
        'desc'        => __( 'Add Content Post_peuple_area ' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'peuple_area',
      ), 
	  
	 /* slider post */
      array(
        'id'          => 'slider_post',
        'label'       => __( 'slider_post', 'theme-text-domain' ),
        'desc'        => __( 'Add your chooice slider images' ),
        'std'         => '',
        'type'        => 'list-Item',
        'section'     => 'slider',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => 'ot-upload-attachment-id',
        'condition'   => '',
        'operator'    => 'and',
		'settings'    => array(
		     array(
        'id'          => 'slider_images',
        'label'       => __( 'slider_image', 'theme-text-domain' ),
        'desc'        => __( 'Add your chooice slider images' ),
        'std'         => '',
        'type'        => 'upload',
        'rows'        => '10',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ), 
	  
	  array(
        'id'          => 'slider_link',
        'label'       => __( 'slider_link', 'theme-text-domain' ),
        'desc'        => __( 'Add your chooice slider link' ),
        'std'         => '',
        'type'        => 'text',
        'rows'        => '10',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
		)
      ),
	  
	  /* Notre_post_area */
	  array(
        'id'          => 'Notre_post',
        'label'       => __( 'Notre_post', 'theme-text-domain' ),
        'desc'        => __( 'Add your Notre_post' ),
        'std'         => '',
        'type'        => 'list-Item',
        'section'     => 'Notre_area',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
		'settings'    => array(
		    array(
				'id'          => 'Notre_post_area',
				'label'       => __( 'Only Use One Title', 'theme-text-domain' ),
				'desc'        => __( 'Add Top Notre_post title' ),
				'std'         => '',
				'type'        => 'text',
				'section'     => 'Notre_area',
			  ),
			  
			  array(
				'id'          => 'Notre_post_img',
				'label'       => __( 'Notre_post_img', 'theme-text-domain' ),
				'desc'        => __( 'Add Notre_post_img' ),
				'std'         => '',
				'type'        => 'upload',
				'section'     => 'Notre_area',
			  ),
			  array(
				'id'          => 'Notre_post_content',
				'label'       => __( 'Notre_post_content', 'theme-text-domain' ),
				'desc'        => __( 'Add Notre_post_content' ),
				'std'         => '',
				'type'        => 'text',
				'section'     => 'Notre_area',
			  ),
		)
	  ), 
	  
	  /* FEATURE_area */
	  array(
        'id'          => 'FEATURES_post',
        'label'       => __( 'left FEATURES_post', 'theme-text-domain' ),
        'desc'        => __( 'Add your FEATURES_post' ),
        'std'         => '',
        'type'        => 'list-Item',
        'section'     => 'FEATURE_area',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
		'settings'    => array(
		    array(
				'id'          => 'FEATURES_post_area',
				'label'       => __( 'Only Use One FEATURE top Title', 'theme-text-domain' ),
				'desc'        => __( 'Add Top Notre_post title' ),
				'std'         => '',
				'type'        => 'text',
				'section'     => 'FEATURE_area',
			  ),
			  
			  array(
				'id'          => 'Notre_post_content',
				'label'       => __( 'Notre_post_content', 'theme-text-domain' ),
				'desc'        => __( 'Add Notre_post_content' ),
				'std'         => '',
				'type'        => 'text',
				'section'     => 'FEATURE_area',
			  ),
			  
			  array(
				'id'          => 'Notre_post_link',
				'label'       => __( 'Notre_post_link', 'theme-text-domain' ),
				'desc'        => __( 'Add Notre_post_content' ),
				'std'         => '',
				'type'        => 'text',
				'section'     => 'FEATURE_area',
			  ),
			  
			   array(
				'id'          => 'FEATURE_area_img',
				'label'       => __( 'right FEATURE_area_img', 'theme-text-domain' ),
				'desc'        => __( 'Add Notre_post_img' ),
				'std'         => '',
				'type'        => 'upload',
				'section'     => 'FEATURE_area',
			  ),
		)
	  ),/* end left FEATURE_area */


	  /* FEATURE_area */
	  array(
        'id'          => 'right_FEATURES_post',
        'label'       => __( 'right_FEATURES_post', 'theme-text-domain' ),
        'desc'        => __( 'Add your FEATURES_post' ),
        'std'         => '',
        'type'        => 'list-Item',
        'section'     => 'FEATURE_area',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
		'settings'    => array(
		       array(
				'id'          => 'right_FEATURES_post_img',
				'label'       => __( 'right FEATURE_area_img', 'theme-text-domain' ),
				'desc'        => __( 'Add Notre_post_img' ),
				'std'         => '',
				'type'        => 'upload',
				'section'     => 'FEATURE_area',
			  ),
			  array(
				'id'          => 'right_FEATURES_post_content',
				'label'       => __( 'Notre_post_content', 'theme-text-domain' ),
				'desc'        => __( 'Add Notre_post_content' ),
				'std'         => '',
				'type'        => 'text',
				'section'     => 'FEATURE_area',
			  ),
			  
			  array(
				'id'          => 'right_FEATURES_post_link',
				'label'       => __( 'Notre_post_link', 'theme-text-domain' ),
				'desc'        => __( 'Add Notre_post_content' ),
				'std'         => '',
				'type'        => 'text',
				'section'     => 'FEATURE_area',
			  ),
			  
		)
	  ),/* end left FEATURE_area */
	  
    )
  );
  
  /* allow settings to be filtered before saving */
  $custom_settings = apply_filters( ot_settings_id() . '_args', $custom_settings );
  
  /* settings are not the same update the DB */
  if ( $saved_settings !== $custom_settings ) {
    update_option( ot_settings_id(), $custom_settings ); 
  }
  
  /* Lets OptionTree know the UI Builder is being overridden */
  global $ot_has_custom_theme_options;
  $ot_has_custom_theme_options = true;
  
}