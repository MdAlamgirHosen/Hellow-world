<?php
/**
 The template name: home page
 */
 get_header();
?>
     <section class="header_slider_area">
	    <div class="flexslider">
			 <?php 
				$list_item = ot_get_option('slider_post', array() );
				if( !empty( $list_item )){
					
					echo '<ul class="slides">'; 
					
				   foreach( $list_item as $slider ){
					   
					echo '<li>
				 <a href="'.$slider['slider_link'].'"><img src="'.$slider['slider_images'].'" alt="'.$slider['title'].'" />
				</a></li>';
				   }
				   
				   echo '</ul>';
				}
			   
			  ?>
		</div>
		</section><!--End slider_area-->

	 <section id="peuple_area">
			<div class="container">
				<div class="row">
					<div data-uk-scrollspy="{cls:'uk-animation-scale-up', repeat: true}" class="col-md-12">
						<div class="peuple text-center"> 
							<h2 class="title_color"><?php get_option_tree('Post_peuple_area','','true'); ?></h2>
							<p><?php get_option_tree('content_Post_peuple_area','','true'); ?></p>
						</div>
					</div>
				</div>
			</div>
		</section>
		
		<section id="peuple_area">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="peuple text-center"> 
						    <h2 class="title_color">Postérité de l'œuvre</h2>
							<img src="<?php echo get_template_directory_uri();?>/img/bor.jpg" alt="" />
							<div class="row">
							     <?php 
										 $cat = ot_get_option('category_select','',false, true, 0 );
										  $args = array( 'numberpost' =>3, 'category' => $cat);
										 $postslist = get_posts( $args );
										 foreach($postslist as $post) : setup_postdata($post);
										 ?>
 							    <div data-uk-scrollspy="{cls:'uk-animation-slide-left', repeat: true}" class="col-md-4">
								    <div class="1st_posterite text-center">
									 
										<a href="#"><i class="fa fa-phone"></i></a>
										<p><span><?php the_title(); ?></span>
										<?php the_content(); ?>
										</p>
										
									</div>
								</div>
								<?php endforeach; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>	
        <section id="Notre_area">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="peuple text-center"> 
						    <h2 class="title_color"><?php get_option_tree('Notre_post_area','','true'); ?></h2>
							
							    <?php 
									$list_item_Notre_area = ot_get_option('Notre_post', array() );
									if( !empty( $list_item_Notre_area )){
										echo '<div class="row"> '; 
										
									   foreach( $list_item_Notre_area as $Notre_area ){
										   
										echo '<div class="col-md-4">
										
										<div class="notre_first">
										
										<a rel="prettyPhoto" href="img/pic2.jpg"><img src="'.$Notre_area['Notre_post_img'].'" alt="" class="img-responsive" /></a>
										<h3>"'.$Notre_area['title'].'"</h3>
										<p>"'.$Notre_area['Notre_post_content'].'"</p>
										<a class="red" href="#"><i class="fa fa-facebook"></i></a>
										<a  class="blue" href="#"><i class="fa fa-youtube"></i></a>
									</div></div>';
									   }
									   
									   echo '</div>';
									}
								   
								 ?>
						</div>
					</div>
				</div>
			</div>
		</section> 
		<section id="FEATURES_area">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="FEATURES text-center"> 
						    <h2 class="title_color"><?php get_option_tree('FEATURES_post_area','','true'); ?></h2>
							<?php 
									$list_item_FEATURES = ot_get_option('FEATURES_post', array() );
									if( !empty( $list_item_FEATURES )){
										echo '<div class="row"> '; 
										
									   foreach( $list_item_FEATURES as $FEATURES_area ){
										   
										echo '<div class="col-md-6">
											<div class="FEATURES_first text-left">
												<h3>"'.$FEATURES_area['title'].'"</h3>
												<p>"'.$FEATURES_area['Notre_post_content'].'"</p>
												<a href="#">"'.$FEATURES_area['Notre_post_link'].'"</a>
											</div>
										</div>
										<div class="col-md-6">
											<div class="FEATURES_first">
												<a rel="prettyPhoto" href="img/cont_1.jpg"><img src="'.$FEATURES_area['FEATURE_area_img'].'" alt="" class="img-responsive" /></a>
											</div>
										</div>';
										}
									   
									   echo '</div>';
									}
								   
								 ?>
								 
								 
								 <?php 
									$right_FEATURES = ot_get_option('right_FEATURES_post', array() );
									if( !empty( $right_FEATURES )){
										echo '<div class="row"> '; 
										
									   foreach( $right_FEATURES as $right_FEATURES_area ){
										   
										echo '<div class="col-md-6">
											<div class="FEATURES_first">
												<a rel="prettyPhoto" href="img/cont_1.jpg"><img src="'.$right_FEATURES_area['right_FEATURES_post_img'].'" alt="" class="img-responsive" /></a>
											</div>
										</div>
										<div class="col-md-6">
											<div class="FEATURES_first text-left">
												<h3>"'.$right_FEATURES_area['title'].'"</h3>
												<p>"'.$right_FEATURES_area['right_FEATURES_post_content'].'"</p>
												<a href="#">"'.$right_FEATURES_area['right_FEATURES_post_link'].'"</a>
											</div>
										</div>
										';
										}
									   
									   echo '</div>';
									}
								   
								 ?>
						
						</div>
					</div>
				</div>
			</div>
		</section>
		<section id="slide2_area">
			<div class="container">
				<div class="row">
					<div data-uk-scrollspy="{cls:'uk-animation-slide-top', repeat: true}" class="col-md-2">
						<div class="owl_carousel_img">
                            <a rel="prettyPhoto" href="<?php echo get_template_directory_uri();?>/img/slide_pic.jpg"><img src="<?php echo get_template_directory_uri();?>/img/slide_pic.jpg" alt="Owl Image"></a>
                        </div>
					</div>
					<div class="col-md-10">
                        <div class="header_slider_area">
							<div class="header_slider2">
								<div id="carousel-my_style" class="carousel slide"   data-ride="carousel" data-interval="1500">
									  <!-- Wrapper for slides -->
									<div class="carousel-inner">
										<div class="item active">
										  <div class="single_item ">
											  <h2 class="title_color text-center">WHAT'S THE B<i class="fa fa-heart"></i>ZZ?</h2>
											  <q><p>What’s our clients talking about our product or </q>service. This is only an example to show you quote block effect here.</p></q>
											  <a class="pull-right" href="#">georg clooney</a>
										  </div>
										</div>
										<div class="item">
										  <div class="single_item">
											  <h2 class="title_color text-center">WHAT'S THE B<i class="fa fa-heart"></i>ZZ?</h2>
											  <q><p>What’s our clients talking about our product or service. This is only an example to show you quote block effect here.</p></q>
											  <a class="pull-right" href="#">georg clooney</a>
										  </div>
										</div>
										<div class="item">
										   <div class="single_item">
											  <h2 class="title_color text-center">WHAT'S THE B<i class="fa fa-heart"></i>ZZ?</h2>
											  <q><p>What’s our clients talking about our product or service. This is only an example to show you quote block effect here.</p></q>
											  <a class="pull-right" href="#">georg clooney</a>
										  </div>
									</div>
								</div>
								  <!-- Indicators -->
									  <ol class="carousel-indi">
										<li data-target="#carousel-my_style" data-slide-to="0" class="active"></li>
										<li data-target="#carousel-my_style" data-slide-to="1"></li>
										<li data-target="#carousel-my_style" data-slide-to="2"></li>
									  </ol>
							</div><!--End slider_area-->
                        </div>
					</div>
				</div>
			</div>
		</section>
		<section id="portfolio_area">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="portfolio text-center">
						    <h3>PORTFOLIO</h3>
							<div class="portfolio_filter">
								<ul>
									<li class="filter active_bg other_bg" data-filter="all active">SHOW</li>
									<li class="filter" data-filter="Collage">ALL</li>
									<li class="filter" data-filter="Teachers">WEB</li>
									<li class="filter" data-filter="Students">PRINT</li>
									<li class="filter" data-filter="Hostel">BRANDING</li>
								</ul>
							</div>
							<div class="portfolio_contents">
								<ul id="portfolio_filter_action">
									<li class="mix Teachers Collage">
										<div class="single_portfolio">
										  <img src="<?php echo get_template_directory_uri();?>/img/1.jpg" alt="" />
										   <div class="our_team_overlay">
												<a rel="prettyPhoto" href="<?php echo get_template_directory_uri();?>/img/1.jpg"><i class="fa fa-facebook"></i></a>
												<a href="#"><i class="fa fa-twitter"></i></a>
										    </div>
										</div>
									</li>
									<li class="mix Teachers Students">
										<div class="single_portfolio">
											<img src="<?php echo get_template_directory_uri();?>/img/2.jpg" alt="" />
											<div class="our_team_overlay">
												<a href="#"><i class="fa fa-facebook"></i></a>
												<a href="#"><i class="fa fa-twitter"></i></a>
										    </div>
										</div>			
									</li>
									<li class="mix Collage Hostel">
										<div class="single_portfolio ">
											<img src="<?php echo get_template_directory_uri();?>/img/3.jpg" alt="" />
											<div class="our_team_overlay">
												<a href="#"><i class="fa fa-facebook"></i></a>
												<a href="#"><i class="fa fa-twitter"></i></a>
										    </div>
										</div>
									</li>
									<li class="mix Collage Students">
										<div class="single_portfolio">
											<img src="<?php echo get_template_directory_uri();?>/img/4.jpg" alt="" />
											<div class="our_team_overlay">
												<a href="#"><i class="fa fa-facebook"></i></a>
												<a href="#"><i class="fa fa-twitter"></i></a>
										    </div>
										</div>
									</li>
									<li class="mix Collage Hostel">
										<div class="single_portfolio">
											<img src="<?php echo get_template_directory_uri();?>/img/5.jpg" alt="" />
											<div class="our_team_overlay">
												<a href="#"><i class="fa fa-facebook"></i></a>
												<a href="#"><i class="fa fa-twitter"></i></a>
										    </div>
										</div>
									</li>
									<li class="mix Teachers">
										<div class="single_portfolio">
											<img src="<?php echo get_template_directory_uri();?>/img/6.jpg" alt="" />
											<div class="our_team_overlay">
												<a href="#"><i class="fa fa-facebook"></i></a>
												<a href="#"><i class="fa fa-twitter"></i></a>
										    </div>
										</div>
									</li>
									<li class="mix Teachers">
										<div class="single_portfolio">
											<img src="<?php echo get_template_directory_uri();?>/img/7.jpg" alt="" />
											<div class="our_team_overlay">
												<a href="#"><i class="fa fa-facebook"></i></a>
												<a href="#"><i class="fa fa-twitter"></i></a>
										    </div>
										</div>
									</li>
									<li class="mix Students">
										<div class="single_portfolio">
											<img src="<?php echo get_template_directory_uri();?>/img/8.jpg" alt="" />
											<div class="our_team_overlay">
												<a href="#"><i class="fa fa-facebook"></i></a>
												<a href="#"><i class="fa fa-twitter"></i></a>
										    </div>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
<?php get_footer();?>		