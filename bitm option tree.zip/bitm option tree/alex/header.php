<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 */

?>

<!DOCTYPE html>
<html class="no-js" <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo('charset'); ?>"> 
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
		<?php wp_head(); ?>
    </head>
    <body <?php body_class(); ?>>
            <!-- Add your site or application content here -->
		<header class="header_area navbar-fixed-top">
		    <div class="header_top">
			    <div class="header_top_overlay">
                <nav class="navbar navbar-default">
					<div class="container-fluid">
						<!--Brand and toggle get grouped for better mobile display-->
						<div class="navbar-header data-wow-duration="1000ms" data-wow-dealy="2s"">
							<button type="button" class="navbar-toggle collapsed"data-toggle="collapse" data-target="#my_style" aria-expanded="false" >
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							</button>
							 <a  class="navbar-brand" href="<?php bloginfo('home');?>"><img src="<?php if( function_exists('get_option_tree')) : if(get_option_tree('logo_upload')) : ?> <?php get_option_tree('logo_upload','','true'); ?><?php else : ?><?php echo esc_url(get_template_directory_uri()); ?>/img/logo.png <?php endif; endif; ?>" alt="" />
							 </a>
						</div>
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse" id="my_style">
							<?php
								wp_nav_menu(array(
								  'theme_location'=>'header-menu',
								  'menu_class'=>"nav navbar-nav my_style_nav",
								  'container'=>false,
								));
							 ?>
							<ul class="nav navbar-nav navbar-right">
								<li><a href="#"><i class="fa fa-envelope"></i></a></li>
								<li><a href="#"><i class="fa fa-phone"></i></a></li>
								<li><a href="#"><i class="fa fa-search"></i></a></li>
							</ul>
						</div>
					</div>
				</nav></div>
			</div><br><!--End navbar_area-->
		</header><!--End header_area-->