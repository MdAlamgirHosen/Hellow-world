<?php
/**
 * The template for displaying the footer
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *1. Please find attached photos for the web. Please use pic #8548 and 8591. 
2. Header -> Moving images -> 3 portion
3. Contact form -> http://awebsiteforlawyers.com/sample27/index.html
4. Add twitter
5. Important Links: home, about, practices areas,

attorneys and resources., Disclaimer, Attorney Advertising, Privacy Policy
6. Logo -> Attorney & Counselor At Law
7. Service Header -> See What We Can Do for You.
 * @package WordPress
 */

?>
 	<footer id="footer_area">
			<div class="footer_top">
				<div class="container">
					<div class="row">
						<div data-uk-scrollspy="{cls:'uk-animation-slide-left', repeat: true}" class="col-md-3">
							<div class="peuple text-center"> 
								<h2>Snippet</h2>
								<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus</p>
							</div>
						</div>
						<div data-uk-scrollspy="{cls:'uk-animation-slide-bottom', repeat: true}" class="col-md-3">
							<div class="peuple text-center"> 
								<h2>Tags</h2>
								<button type="bnt-default">Responsive</button>
								<button type="bnt-default">Flat</button>
								<button type="bnt-default">Template</button>
								<button type="bnt-default">Design</button>
								<button type="bnt-default">Design</button>
								<button type="bnt-default">Creative</button>
								
							</div>
						</div>
						<div data-uk-scrollspy="{cls:'uk-animation-slide-right', repeat: true}" class="col-md-3">
							<div class="peuple text-center"> 
								<h2>Contact</h2>
								<form action="" method="">
									<div class="first_btn pull-left">
								       <label for="">Nom:</label>
									   <input type="text" /> <br>
									   <label for="">Email:</label>
									   <input type="Email" /><br>
									   <label for="">Massage:</label>
									   <textarea name="" id="" cols="15"></textarea>
									</div>
								</form>
							</div>
						</div>
						<div data-uk-scrollspy="{cls:'uk-animation-slide-top', repeat: true}" class="col-md-3">
							<div class="peuple text-center"> 
								<h2>Tweeter</h2>
								<ul>
									<li><a href="#">Check out this great https://www.behance.net/Bridgetech</a></li>
									<li><a href="#">Freddom- Responsive Multi-Purpose</a></li>
									<li><a href="#">March 06 2014</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="footer_down">
			     <div class="container">
			     	<div class="row">
			     		<div data-uk-scrollspy="{cls:'uk-animation-slide-left', repeat: true}" class="col-md-6">
			     			<div class="footer_content">
							    <p>Copyright © All Rights Reserved. Bridgetech-ma.com.com	-	Goh.h.com@gmail.com</p>
							</div>
			     		</div>
						<div class="col-md-4 col-md-offset-2">
			     			<div data-uk-scrollspy="{cls:'uk-animation-slide-right', repeat: true}" class="footer_content">
							    <ul>
							    	<li><a href="#">HOME</a></li>
							    	<li><a href="#">PORTFOLIOS</a></li>
							    	<li><a href="#">BLOG</a></li>
							    	<li><a href="#">CONTACT</a></li>
							    	<li><a href="#">SHOP</a></li>
							    </ul>
							</div>
			     		</div>
			     	</div>
			     </div>
			</div>
		</footer><!--End of footer area-->

		<?php wp_footer(); ?>
    </body>
</html>

