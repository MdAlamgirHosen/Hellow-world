<?php get_header(); ?>
<div style="background:url('http://losangelesbodyrubs.com/wp-content/uploads/2017/01/allmodelimg.jpg') center top no-repeat; " class="gfmw_full_contianer topbanners">
	<div class="gfwm_center blogpost">
		<div class="gw_inner header-parttitle ">
			<div style="margin-top:95px;" class="hoverimage_text_mod"><p >  Models <span class="sp1t">All of our available models</span><span class="sp2t">  </span></p> </div>
		</div>
</div>
</div>

<div class="gfmw_full_contianer singlepost ">

	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding allmodel">
<section class="content cat_seach_wm allmodel_body">

	
	
	
		<?php if ((category_description() != '') && !is_paged()) : ?>
			<div class="notebox">
				<?php echo category_description(); ?>
			</div>
		<?php endif; ?>
		
		<?php if ( have_posts() ) : ?>
		
			<div class="post-list group">
				<?php $i = 1; echo '<div class="post-row">'; while ( have_posts() ): the_post(); ?>
				<?php get_template_part('content'); ?>
				<?php if($i % 2 == 0) { echo '</div><div class="post-row">'; } $i++; endwhile; echo '</div>'; ?>
			</div><!--/.post-list-->
		
			<?php get_template_part('inc/pagination'); ?>
			
		<?php endif; ?>
		
	
	
</section><!--/.content-->

</div>
	</div>
	
</div>



<?php get_footer(); ?>