


	<?php if ( is_home() ) : ?>
		<h2><?php echo lt_blog_title(); ?></h2>

	<?php elseif ( is_single() ): ?>
		
			<?php the_category(' <span>/</span> '); ?>
			<?php if ( comments_open() && ( ot_get_option( 'comment-count' ) != 'off' ) ): ?>
			<a href="<?php comments_link(); ?>"><i class="fa fa-comments-o"></i>  <?php comments_number( '0', '1', '%' ); ?> comments</a>
			<?php endif; ?>
		
		
	<?php elseif ( is_page() ): ?>
		<h2><?php echo lt_page_title(); ?></h2>

	<?php elseif ( is_search() ): ?>

		<h1>
			<?php if ( have_posts() ): ?><i class="fa fa-search"></i><?php endif; ?>
			<?php if ( !have_posts() ): ?><i class="fa fa-exclamation-circle"></i><?php endif; ?>
			<?php $search_count = 0; $search = new WP_Query("s=$s & showposts=-1"); if($search->have_posts()) : while($search->have_posts()) : $search->the_post(); $search_count++; endwhile; endif; echo $search_count;?> <?php _e('Search results','GFMW'); ?></h1>
	
	<?php elseif ( is_404() ): ?>
	<div class="gfmw_full_contianer arcives">
	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">
		<h1><i class="fa fa-exclamation-circle"></i><?php _e('Error 404.','GFMW'); ?> <span><?php _e('Page not found!','GFMW'); ?></span></h1>
		</div>
</div>
</div>
	<?php elseif ( is_author() ): ?>
	<div class="gfmw_full_contianer arcives">
	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">
		<?php $author = get_userdata( get_query_var('author') );?>
		<h1><i class="fa fa-user"></i><?php _e('Author:','GFMW'); ?> <span><?php echo $author->display_name;?></span></h1>
		</div>
</div>
</div>
	<?php elseif ( is_category() ): ?>
	<div class="gfmw_full_contianer arcives">
	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">
		<h1><i class="fa fa-folder-open"></i><?php _e('Category:','GFMW'); ?> <span><?php echo single_cat_title('', false); ?></span></h1>
</div>
</div>
</div>	
	<?php elseif ( is_tag() ): ?>
		<h1><i class="fa fa-tags"></i><?php _e('Tagged:','GFMW'); ?> <span><?php echo single_tag_title('', false); ?></span></h1>
		
	<?php elseif ( is_day() ): ?>
		<h1><i class="fa fa-calendar"></i><?php _e('Daily Archive:','GFMW'); ?> <span><?php echo get_the_time('F j, Y'); ?></span></h1>
		
	<?php elseif ( is_month() ): ?>
		<h1><i class="fa fa-calendar"></i><?php _e('Monthly Archive:','GFMW'); ?> <span><?php echo get_the_time('F Y'); ?></span></h1>
			
	<?php elseif ( is_year() ): ?>
		<h1><i class="fa fa-calendar"></i><?php _e('Yearly Archive:','GFMW'); ?> <span><?php echo get_the_time('Y'); ?></span></h1>
	
	<?php else: ?>
		<h2><?php the_title(); ?></h2>
	
	<?php endif; ?>


