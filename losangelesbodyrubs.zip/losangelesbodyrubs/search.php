<?php get_header(); ?>

	<?php get_template_part('inc/page-title'); ?>
<div class="gfmw_full_contianer singlepost">
	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">
<section class="content cat_seach_wm">


	
	<div class="pad group ">
		
		<div class="notebox">
			<?php _e('For the term','GFMW'); ?> "<span><?php echo get_search_query(); ?></span>".
			<?php if ( !have_posts() ): ?>
				<?php _e('Please try another search:','GFMW'); ?>
			<?php endif; ?>
			<div class="search-again">
				<?php get_search_form(); ?>
			</div>
		</div>
		
		<?php if ( have_posts() ) : ?>
		
			<div class="post-list group">
				<?php $i = 1; echo '<div class="post-row">'; while ( have_posts() ): the_post(); ?>
				<?php get_template_part('content'); ?>
				<?php if($i % 2 == 0) { echo '</div><div class="post-row">'; } $i++; endwhile; echo '</div>'; ?>
			</div><!--/.post-list-->
		
			<?php get_template_part('inc/pagination'); ?>
			
		<?php endif; ?>
		
	</div><!--/.pad-->
	
</section><!--/.content-->
<section class="page_sidebar">
<?php get_sidebar(); ?> 
</section>
</div>
</div>
	
</div>



<?php get_footer(); ?>