<?php 

/*
Template Name: Home Page
*/

get_header(); 
?>






		
<?php while ( have_posts() ): the_post(); ?>
		

					<?php the_content(); ?>

			<?php if ( ot_get_option('page-comments') == 'on' ) { comments_template('/comments.php',true); } ?>
			
		<?php endwhile; ?>





<div class="gfmw_full_contianer mmaboutP">

	<div class="gfwm_center">
		<div class="gw_inner  treesec_s ntovideo">
		
		
		<h2 > All Models  </h2>
		<div class="borderlinetext"> </div>
		<div class="gw_inner modelboxarea">
	
			<?php
			
			$args = array(
    'post_type' => 'model',
    'meta_query' => array(
        array(
            'key' => 'custom_element_grid_class_meta_box',
            'value' => 'yes'
        )
    )
 );
 
  
    $featured = new WP_Query($args);
 
if ($featured->have_posts()): while($featured->have_posts()): $featured->the_post(); ?>

<div class="mw_postbox">

		<a class="imglink" href="<?php the_permalink(); ?>"> <?php the_post_thumbnail(); ?></a> 
		<div class="wa_postdescription"><?php the_excerpt();?> </div>
		<a href="<?php the_permalink(); ?>" class="gmw_post_title"><?php the_title(); ?> </a>
		
		
		
		</div>

<?php

endwhile; else:
endif;
?>

		
		</div>		
	</div>		
	</div>	
</div>	


















		


<?php get_footer(); ?>