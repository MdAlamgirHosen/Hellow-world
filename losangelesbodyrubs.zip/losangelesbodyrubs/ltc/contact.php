<?php 


?>



<div class="today_bMain contactb">

<div class="container">

<div style="width:100%;  height:auto; position:relative; float:left;">
<div class="contact_left">
 <?php if ( ot_get_option('titlecon')): ?>
 <p class="portp"> 
 <?php echo ot_get_option('titlecon'); ?>
</p>
<?php else: ?>
<p class="portp"> 
We have handcrafted over 4000 dynamic websites
and over 1000 unique logo designs
</p>
 <?php endif; ?>
  <?php if ( ot_get_option('shortdescontact')): ?>
 <p class="portps">
<?php echo ot_get_option('shortdescontact'); ?>
</p>
<?php else: ?>
<p class="portps">
Let’s chat about your ideas and how we can help you create the website of your dreams. You can expect to hear from us within 24 hours, but we will get back to you asap.
</p>
 <?php endif; ?>
   <div class="form_foo" style="width:100%;  height:auto; position:relative; float:left;">
   <?php if ( ot_get_option('contactform')): ?>
<?php echo ot_get_option('contactform'); ?>
<?php else: ?>
<script type="text/javascript" src="http://form.jotformpro.com/jsform/43514016425951"></script>
 <?php endif; ?>
 </div>
 </div>
 <div class="contact_right">
 <p class="address_"> Los Angeles Office </p>
   <?php if ( ot_get_option('contactadd')): ?>
 <p class="address_s">  <?php echo ot_get_option('contactadd'); ?></p>
 <?php else: ?>
  <p class="address_s">  9107 Wilshire Blvd  Beverly Hills , CA 90210 </p>
   <?php endif; ?>
  <p class="phone_"> Give Us a Call </p>
     <?php if ( ot_get_option('conphone')): ?>
 <p class="phone_s">  <?php echo ot_get_option('contactfax'); ?></p>
  <?php else: ?>
  <p class="phone_s">  (866) 430-3852 </p>
     <?php endif; ?>
   <p class="fax_"> Send us a Fax </p>
    <?php if ( ot_get_option('conphone')): ?>
 <p class="fax_s">  <?php echo ot_get_option('contactfax'); ?> </p>
 <?php else: ?>
  <p class="fax_s">  (866) 430-3852 </p>
  <?php endif; ?>
 </div>
</div>

</div>
</div>
     <?php if ( ot_get_option('contactmap')): ?>
<div style="width:100%;  height:auto; position:relative; float:left;">
 <?php echo ot_get_option('contactmap'); ?>
  <?php else: ?>
<iframe frameborder="0" height="300" marginheight="0" marginwidth="0" scrolling="no" src="https://maps.google.com/maps?ie=UTF8&amp;q=sunny+hills+behavioral&amp;fb=1&amp;gl=us&amp;hq=sunny+hills+behavioral&amp;hnear=0x80c2c75ddc27da13:0xe22fdf6f254608f4,Los+Angeles,+CA&amp;cid=0,0,11986891616814557652&amp;t=m&amp;ll=33.900199,-117.928705&amp;spn=0.021016,0.023131&amp;z=15&amp;iwloc=A&amp;output=embed" style="background: #B1AEA5;" width="100%"></iframe>
 <?php endif; ?>
</div>