<?php 


?>


<div class="panel-group bodyrubs_" id="accordion" role="" aria-multiselectable="true">

  <div class="panel panel-default">

    

     

        <a class="fq_collapse" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne">

        What exactly is a ‘fetish friendly’ sensual body rub? 

        </a>

      

  

    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">

      <div class="panel-body">

      <p class="wy_us_content_ w_faq_text">

Good question. Fetish friendly sensual body rub is an intimate personal experience which combines elements of body rub with foot fetishes, wrestling fetishes, spanking fetishes and more. If you dream it, our girls can probably do it! (as long as its legal). Call and ask. Don't be embarrassed!<br>
<br>
If you need to discover exactly what your fetish is, our girls can help with that too.  All sessions are customized just for you. They may be fetish/fantasy/or role-play entirely without body rub...its totally up to you.
  </p>

      </div>

    </div>

  </div>

  <div class="panel panel-default">

   

        <a class="collapsed fq_collapse" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">

         Why are the donations on the website different than what you quoted over the phone? 

        </a>

     

    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">

      <div class="panel-body">

       <p class="wy_us_content_ w_faq_text">All donations are based on requirements for your specific situation. The rates listed on each girls' profile are for a basic body rub, tantric reiki, or foot fetish session. Additional fetish services are available for a higher donation. </p>

      </div>

    </div>

  </div>

  <div class="panel panel-default">

    

        <a class="collapsed fq_collapse" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">

        Why do some of the girls have higher/lower donations? 

        </a>

     

    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">

      <div class="panel-body">

      <p class="wy_us_content_ w_faq_text">The girls set their own donations. Some of our ladies are professional models or hold certifications in Reiki or have more experience than others. The donations are how they are to keep everyone content and to ensure the best experience for both you and the girl. If she is happy...you will be too!  </p>

      </div>

    </div>

  </div>

  <div class="panel panel-default">

    

        <a class="collapsed fq_collapse" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">

         	Can I get the girl’s phone number? 

        </a>

     

    <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">

      <div class="panel-body">

      <p class="wy_us_content_ w_faq_text">We do not give out any personal information for our girls. If you would like to see someone, please call us and we can set up an appointment. </p>

      </div>

    </div>

  </div>

  

  <div class="panel panel-default">

    

        <a class="collapsed fq_collapse" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="false" aria-controls="collapseFive">

         		I saw a girl on Backpage offering the same service for half the donation. Can I get a discount? 

        </a>

     

    <div id="collapseFive" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFive">

      <div class="panel-body">

      <p class="wy_us_content_ w_faq_text">No, you can't. Our donations are not negotiable. End of story. </p>

      </div>

    </div>

  </div>

  

  <div class="panel panel-default">

    

        <a class="collapsed fq_collapse" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse6" aria-expanded="false" aria-controls="collapse6">

         		Is tip included in the donation? 

        </a>

     

    <div id="collapse6" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading6">

      <div class="panel-body">

      <p class="wy_us_content_ w_faq_text">Tips are not included in the donation. Since this is a partnership, the girl does not receive the full donation. Please keep that in mind. That said, tipping is NEVER required and you will receive the same level of attention whether you tip or not. Tips are always (GREATLY) appreciated, but never expected. All tips go directly to the girl.</p>

      </div>

    </div>

  </div>

  

  

  <div class="panel panel-default">

    

        <a class="collapsed fq_collapse" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse7" aria-expanded="false" aria-controls="collapse7">

         		Do any of the girls offer ‘extras’? 

        </a>

     

    <div id="collapse7" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading7">

      <div class="panel-body">

      <p class="wy_us_content_ w_faq_text">Asking question like that is a sure way to get hung up on and banned for life. We don't do lewd acronyms...neither do our girls. DON'T EVEN ASK!</p>

      </div>

    </div>

  </div>

  

  <div class="panel panel-default">

    

        <a class="collapsed fq_collapse" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse8" aria-expanded="false" aria-controls="collapse8">

         		Your FAQ didn’t answer all of my questions. Where can I get more information? 

        </a>

     

    <div id="collapse8" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading8">

      <div class="panel-body">

      <p class="wy_us_content_ w_faq_text">Please feel free to call us at 646-657-7646, during business hours , with any questions you may have and as long as they aren't about sexual/illegal activities, we will do our best to answer them. </p>

      </div>

    </div>

  </div>

  

  <div class="panel panel-default">

    

        <a class="collapsed fq_collapse" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse9" aria-expanded="false" aria-controls="collapse9">

         		Are any of the girls available for extended dates or overnights? 

        </a>

     

    <div id="collapse9" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading9">

      <div class="panel-body">

      <p class="wy_us_content_ w_faq_text">Yes, that can absolutely be arranged. However, please keep in mind we are not an escort service, and our girls will not engage in any of the activities typically associated with escorts. Donations are for time and companionship only...yes, I know, they all say that, but we mean it.</p>

      </div>

    </div>

  </div>

  

  

  <div class="panel panel-default">

    

        <a class="collapsed fq_collapse" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse10" aria-expanded="false" aria-controls="collapse10">

         			Do you require screening? 

        </a>

     

    <div id="collapse10" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading10">

      <div class="panel-body">

      <p class="wy_us_content_ w_faq_text">

The safety and discretion of the models who advertise with us is our number one priority. Therefore, we will need to obtain certain personal information from you before setting up an appointment. Please note that some models may require additional screening, and if so, it is noted on their profiles.</p>
 <p class="wy_us_content_ w_faq_text">
All information you share with us will be destroyed immediately following your session. Yes, we know Ashely Madison said that too...which is why we don't keep online records ;-)</p>
 <p class="wy_us_content_ w_faq_text">
1. Your real full name as recorded on your government issued ID.</p>
 <p class="wy_us_content_ w_faq_text">
2. A link to your Linked IN profile and/or your bio page on your employer's website.</p>
 <p class="wy_us_content_ w_faq_text">
3. Your handle on websites like P411, Date-Check, TER, etc.</p>
 <p class="wy_us_content_ w_faq_text">
4. A real phone number, not a Google voice/VOIP number.</p>
 <p class="wy_us_content_ w_faq_text">
5. References from other well established agencies/providers are always helpful.
 </p>

      </div>

    </div>

  </div>

</div>