<?php 


?>



<div class="today_bMain callAction">
<div class="container">
<div style="width:100%;  height:auto; position:relative; float:left;">
 <?php if ( ot_get_option('readytitle')): ?>
<p class="mRespon_p ">
   <?php echo ot_get_option('readytitle'); ?>
   </p>
     <?php else: ?>
<p class="mRespon_p techocon">
   <span style="font-weight:bold;"> Questions?</span>  Contact us today at <span style="color:#fff; text-shadow:none;">888-555-4584</span>  
   </p>
 <?php endif; ?> 
  <?php if ( ot_get_option('readydes')): ?>
    <p style="" class="mRespon_pm">
 <?php echo ot_get_option('readydes'); ?>
 </p>
   <?php else: ?>
    <p style="" class="mRespon_pm techocon">
  has the expertise necessary to deliver quality, cost-effective internet marketing services that yield high-end results.   Spend thirty minutes with one of our specialists and quickly 
   </p>
   <?php endif; ?> 
  
  </div>
</div>
</div>
</div>






















<div class="today_bMain callAction">
<div class="container">
<div style="width:100%;  height:auto; position:relative; float:left;">


    
<p class="mRespon_p techocon">
   <span style="font-weight:bold;"> Questions?</span>  Contact us today at <span style="color:#fff; text-shadow:none;">888-555-4584</span>  
   </p>
 
 
   
    <p style="" class="mRespon_pm techocon">
  has the expertise necessary to deliver quality, cost-effective internet marketing services that yield high-end results.   Spend thirty minutes with one of our specialists and quickly 
   </p>
  
  
  </div>
</div>
</div>
</div>
