<?php 


?>



<div class="today_bMain recent-bg">

<div class="container">

<div id="recent_" class="websites_" style="width:100%;  height:auto; position:relative; float:left;">
<h1>Recent Web Design Projects </h1>
<p>
Working with Best Designers in the Industry, We Create Immaculate Designs that Speaks for Itself
</p>

</div>
<div class="design_s" style="width:100%;  height:auto; position:relative; float:left;">
<ul class="grid cs-style-6">
				<li>
					<figure>
					 <?php if ( ot_get_option('r_worksite-1')): ?>
					 <img src="<?php echo ot_get_option('r_worksite-1'); ?>" alt="our client 1">
					 <?php else: ?>
							<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/tequilaqv.jpg" alt="our client 1">
							<?php endif; ?> 
						<figcaption>
						<?php if ( ot_get_option('r_sitestitle-1')): ?>
							<h3><?php echo ot_get_option('r_sitestitle-1'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('r_sitedesc-1')): ?>
							<p><?php echo ot_get_option('r_sitedesc-1'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>							
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('r_worksite-2')): ?>
						<img src="<?php echo ot_get_option('r_worksite-2'); ?>" alt="our client 2">
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/any-dish.jpg" alt="our client 2">
						<?php endif; ?> 
						<figcaption>
							<?php if ( ot_get_option('r_sitestitle-2')): ?>
							<h3><?php echo ot_get_option('r_sitestitle-2'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('r_sitedesc-2')): ?>
							<p><?php echo ot_get_option('r_sitedesc-2'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('r_worksite-3')): ?>
						<img src="<?php echo ot_get_option('r_worksite-3'); ?>" alt="our client 3">
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/unowe.jpg" alt="our client 3">
						<?php endif; ?> 
						<figcaption>
						<?php if ( ot_get_option('r_sitestitle-3')): ?>
							<h3><?php echo ot_get_option('r_sitestitle-3'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('r_sitedesc-3')): ?>
							<p><?php echo ot_get_option('r_sitedesc-3'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('r_worksite-4')): ?>
						<img src="<?php echo ot_get_option('r_worksite-4'); ?>" alt="our client 4">
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/mortgage-freedom.jpg" alt="our client 4">
						<?php endif; ?> 
						<figcaption>
							<?php if ( ot_get_option('r_sitestitle-4')): ?>
							<h3><?php echo ot_get_option('r_sitestitle-4'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('r_sitedesc-4')): ?>
							<p><?php echo ot_get_option('r_sitedesc-4'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('r_worksite-5')): ?>
						<img src="<?php echo ot_get_option('r_worksite-5'); ?>" alt="our client 5">
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/nj-auto-exports.jpg" alt="our client 5">
						<?php endif; ?> 
						<figcaption>
							<?php if ( ot_get_option('r_sitestitle-5')): ?>
							<h3><?php echo ot_get_option('r_sitestitle-5'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('r_sitedesc-5')): ?>
							<p><?php echo ot_get_option('r_sitedesc-5'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
					 <?php if ( ot_get_option('r_worksite-6')): ?>
						<img src="<?php echo ot_get_option('r_worksite-6'); ?>" alt="our client 6">
						<?php else: ?>
						<img src="<?php echo get_template_directory_uri(); ?>/images/our-work/crnla.jpg" alt="our client 6">
						<?php endif; ?> 
						<figcaption>
							<?php if ( ot_get_option('r_sitestitle-6')): ?>
							<h3><?php echo ot_get_option('r_sitestitle-6'); ?></h3>
							 <?php else: ?>
							<h3>Website Name</h3>
							<?php endif; ?>
							<?php if ( ot_get_option('r_sitedesc-6')): ?>
							<p><?php echo ot_get_option('r_sitedesc-6'); ?></p>
							 <?php else: ?>
							<p>Website Name</p>
							<?php endif; ?>		
							<a href="">More about this project</a>
						</figcaption>
					</figure>
				</li>
	
			</ul>
<a class="a_buttons" href="">
View Complete Portfolio
</a>
</div>

</div>
</div>
   