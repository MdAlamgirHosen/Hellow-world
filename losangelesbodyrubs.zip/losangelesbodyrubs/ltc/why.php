<?php 


?>



<div class="today_bMain fooTops">
<div class="container">
<div style="width:100%;  height:auto; position:relative; float:left;">
 <?php if ( ot_get_option('whyus')): ?>
<p class="mRespon_p">
    <?php echo ot_get_option('whyus'); ?>
   </p>
    <?php else: ?>
   <p class="mRespon_p">
   <span style="color:#02adee;font-weight:bold;">Why </span>choose  Today Website Design?
   </p>
    <?php endif; ?> 
  <div class="whybox why_1">
   <?php if ( ot_get_option('whyboxtitle-1')): ?>
  <p class="whyboxp">
  <?php echo ot_get_option('whyboxtitle-1'); ?>
  </p>
   <?php else: ?>
    <p class="whyboxp">
  Experienced & credible
  </p>
   <?php endif; ?> 
    <?php if ( ot_get_option('whyboxdes-1')): ?>
   <p class="whyboxpm">
 <?php echo ot_get_option('whyboxdes-1'); ?>
 </p>
  <?php else: ?>
<p class="whyboxpm">
Were a 100% Australian owned website design company. Since 2006 we’ve helped over 4000 small businesses get online.  
</p>
 <?php endif; ?> 
  </div>
   <div class="whybox why_2">
   <?php if ( ot_get_option('whyboxtitle-2')): ?>
  <p class="whyboxp">
  <?php echo ot_get_option('whyboxtitle-2'); ?>
  </p>
   <?php else: ?>
    <p class="whyboxp">
  Remarkable Custom Design 
  </p>
   <?php endif; ?> 
    <?php if ( ot_get_option('whyboxdes-2')): ?>
   <p class="whyboxpm">
 <?php echo ot_get_option('whyboxdes-2'); ?>
 </p>
  <?php else: ?>
<p class="whyboxpm">
With tailored designs and unlimited revisions you’re guaranteed to have a unique website you love. 
</p>
 <?php endif; ?> 
  
  </div>
   <div class="whybox why_3">
   <?php if ( ot_get_option('whyboxtitle-3')): ?>
  <p class="whyboxp">
  <?php echo ot_get_option('whyboxtitle-3'); ?>
  </p>
   <?php else: ?>
    <p class="whyboxp">
  Edit Your Website 24/7 
  </p>
   <?php endif; ?> 
     <?php if ( ot_get_option('whyboxdes-3')): ?>
   <p class="whyboxpm">
 <?php echo ot_get_option('whyboxdes-3'); ?>
 </p>
  <?php else: ?>
<p class="whyboxpm">
All our websites allow you to update your content from any device. Take control of your website.  
</p>
 <?php endif; ?> 
  
  </div>
   <div class="whybox why_4">
    <?php if ( ot_get_option('whyboxtitle-4')): ?>
  <p class="whyboxp">
  <?php echo ot_get_option('whyboxtitle-4'); ?>
  </p>
   <?php else: ?>
    <p class="whyboxp">
   Unlimited Lifetime Support 
  </p>
   <?php endif; ?> 
   <?php if ( ot_get_option('whyboxdes-4')): ?>
   <p class="whyboxpm">
 <?php echo ot_get_option('whyboxdes-4'); ?>
 </p>
  <?php else: ?>
<p class="whyboxpm">
Have a positive web design experience. Our clients rely on us for ongoing professional support and online marketing advice.   
</p>
 <?php endif; ?> 
  
  </div>
   <div class="whybox why_5">
   <?php if ( ot_get_option('whyboxtitle-5')): ?>
  <p class="whyboxp">
  <?php echo ot_get_option('whyboxtitle-5'); ?>
  </p>
   <?php else: ?>
    <p class="whyboxp">
  Impressive Reputation 
  </p>
   <?php endif; ?> 
    <?php if ( ot_get_option('whyboxdes-5')): ?>
   <p class="whyboxpm">
 <?php echo ot_get_option('whyboxdes-5'); ?>
 </p>
  <?php else: ?>
<p class="whyboxpm">
The outstanding service we provide our clients is reflected in the steady stream of referrals we receive from happy clients. 
</p>
 <?php endif; ?> 
  
  </div>
   <div class="whybox why_6">
   <?php if ( ot_get_option('whyboxtitle-6')): ?>
  <p class="whyboxp">
  <?php echo ot_get_option('whyboxtitle-6'); ?>
  </p>
   <?php else: ?>
    <p class="whyboxp">
   Awesome & Affordable 
  </p>
   <?php endif; ?> 
   <?php if ( ot_get_option('whyboxdes-6')): ?>
   <p class="whyboxpm">
 <?php echo ot_get_option('whyboxdes-6'); ?>
 </p>
  <?php else: ?>
<p class="whyboxpm">
 We specialise in keeping within your budget while providing outstanding websites and logo design.  
</p>
 <?php endif; ?> 
  
  </div>
</div>
</div>
</div>
