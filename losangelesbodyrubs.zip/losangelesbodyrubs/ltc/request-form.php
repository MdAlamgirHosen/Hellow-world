<?php 


?>

<?php 


	if (isset($_POST['req_submit'])){
	
	
	$req_name = $_POST['req_name'];
	$req_email = $_POST['req_email'];
	$req_phone = $_POST['req_phone'];
	$req_subject = $_POST['req_subject'];	
	$req_message = $_POST['req_message'];
	
	
	$to = 'contact@animaltreasuresjewelry.com';
	$req_subjects = 'General Contact From Animal Treasures Jewellery: '  . $req_name ;
	$cRe_message = '<div style="width:100%; height:auto; position:relative; display:inline-table; padding:20px 0 20px 0; margin:0px; background:#f1f1f1; ">

<div style="max-width:800px; min-width:280px; height:auto; position:relative;  padding:0px 20px 0px 20px; margin:0px auto; ">

<div style="width:100%; height:auto; position:relative; display:inline-table; padding:0px;margin:10px 0px 0px 0px; background:#fff; border-bottom:8px solid #000;">


<p style="text-align:center; "><a href=""> <img style="padding:10px; max-width:280px; min-width:220px;  " src="http://animaltreasuresjewelry.com/wp-content/themes/animaltreasuresjewelry/images/logo.png"></a></p>


</div>

<div style="width:100%; height:auto; position:relative; display:inline-table; padding:0px; margin:0px; background:#fff; ">



<table  style="width:90%; margin:15px 5% 0px 5%;  ">
	<tbody>
		<tr>
			<td colspan="2" style="width:100%;">
			
<p style="text-align:center; font-family: lucida sans unicode,lucida grande,sans-serif; font-size:18px; font-weight:bold; margin:0px; color:#333; border:1px solid #eee; padding:6px 0px 6px 0px;">'. $req_subject .'</p>
			</td>
		</tr>
		<tr>
			<td style="width:319px;  padding:5px 0px 5px 0px; border:1px solid #eee;">
			<p style="text-align:center; font-family: lucida sans unicode,lucida grande,sans-serif; font-size:14px; margin:0px; font-weight:700; color:#333; padding:0px;">Name:</p>
			</td>
			<td style="width:319px;  border:1px solid #eee; padding:5px 0px 5px 0px;">
			<p style="text-align:center; font-family: lucida sans unicode,lucida grande,sans-serif; font-size:13px; margin:0px; font-weight:400; color:#333; padding:0px;">'. $req_name .'</p>
			</td>
		</tr>
		<tr>
			<td style="width:319px;  border:1px solid #eee; padding:5px 0px 5px 0px;">
			<p style="text-align:center; font-family: lucida sans unicode,lucida grande,sans-serif; margin:0px; font-size:14px; font-weight:700; color:#333; padding:0px;">Email:</p>
			</td>
			<td style="width:319px;  border:1px solid #eee; padding:5px 0px 5px 0px;">
			<p style="text-align:center; font-family: lucida sans unicode,lucida grande,sans-serif; margin:0px; font-size:13px; font-weight:400; color:#333; padding:0px;">'. $req_email .'</p>
			</td>
		</tr>
<tr>
			<td style="width:319px;  border:1px solid #eee; padding:5px 0px 5px 0px;">
			<p style="text-align:center; font-family: lucida sans unicode,lucida grande,sans-serif; margin:0px; font-size:14px; font-weight:700; color:#333; padding:0px;">Phone:</p>
			</td>
			<td style="width:319px;  border:1px solid #eee; padding:5px 0px 5px 0px;">
			<p style="text-align:center; font-family: lucida sans unicode,lucida grande,sans-serif; margin:0px; font-size:13px; font-weight:400; color:#333; padding:0px;">'. $req_phone .'</p>
			</td>
		</tr>
<tr>
			<td style="width:319px;  border:1px solid #eee; padding:5px 0px 5px 0px;">
			<p style="text-align:center; font-family: lucida sans unicode,lucida grande,sans-serif; margin:0px; font-size:14px; font-weight:700; color:#333; padding:0px;">Subject:</p>
			</td>
			<td style="width:319px;  border:1px solid #eee; padding:5px 0px 5px 0px;">
			<p style="text-align:center; font-family: lucida sans unicode,lucida grande,sans-serif; margin:0px; font-size:13px; font-weight:400; color:#333; padding:0px;">'. $req_subject .'</p>
			</td>
		</tr>

		
	</tbody>
</table>

<div style="width:90%; text-align:center; margin:0px 5% 0px 5%;"> 
<p style="text-align:center; font-family: lucida sans unicode,lucida grande,sans-serif; font-size:14px; margin:0px; font-weight:700; color:#333; padding:6px 0px 5px 0px; border:1px solid #eee;">Message</p>
</div>
<div style="width:90%; text-align:center; margin:0px 5% 15px 5%; "> 
<p style="text-align:center; font-family: lucida sans unicode,lucida grande,sans-serif; font-size:13px;  margin:0px; font-weight:400; color:#333; padding:5px 0px 5px 0px; border:1px solid #eee; background:#f1f1f1;">'. $req_message .'</p>
</div>
</div>
<div style="width:100%; height:auto; position:relative; display:inline-table; padding:0px; margin:0px 0px 10px 0px; background:#333; border-bottom:8px solid #000; ">

			<p style="text-align:center; font-family: lucida sans unicode,lucida grande,sans-serif; font-size:13px; font-weight:400; color:#ccc; padding:5px 0px 5px 0px;">© 2016 Animal Treasures Jewelry All Rights Reserved.</p>


</div>




</div>

</div>';
	$headers = 'From: '. $req_email . "\r\n" .
    'Reply-To: ' . $req_email . "\r\n";
	
	
	
	$wt_get_Qrequest = wp_mail ($to, $req_subjects, $cRe_message, $headers);
	
	
	if ($wt_get_Qrequest){
		
		$replay_email = $req_email;
		$replay_subject = 'WebTady: Receive a Quote Request For ' . $req_subservice ;
		$replay_message = '<div style="width:100%; height:auto; position:relative; display:inline-table; padding:20px 0 20px 0; margin:0px; background:#f1f1f1; ">

<div style="max-width:800px; min-width:280px; height:auto; position:relative;  padding:0px 20px 0px 20px; margin:0px auto; ">

<div style="width:100%; height:auto; position:relative; display:inline-table; padding:0px;margin:10px 0px 0px 0px; background:#086ed0; border-bottom:8px solid #000;">


<p style="text-align:center; "><a href=""> <img style="padding:10px; max-width:280px; min-width:220px;  " src="https://www.webtady.com/wp-content/themes/webtady/images/logo.png"></a></p>


</div>

<div style="width:100%; height:auto; position:relative; display:inline-table; padding:0px; margin:0px; background:#fff; ">





<div style="width:90%; text-align:center; margin:15px 5% 15px 5%; "> 
<p style="text-align:left; font-family: lucida sans unicode,lucida grande,sans-serif; font-size:15px;  margin:0px; font-weight:600; color:#333; padding:25px 10px 25px 25px; border:1px solid #eee; background:#f1f1f1;"> Thank you for contacting us.<br>
<br><span style="font-weight:400; line-height:150%;">We have received your enquiry and one of our customer service agent will respond to you within a few hours.</span><br>
<br>
Have a great day ahead!<br><br> Pro Academic Dallas Support Team</p>
</div>
</div>
<div style="width:100%; height:auto; position:relative; display:inline-table; padding:0px; margin:0px 0px 10px 0px; background:#333; border-bottom:8px solid #000; ">

			<p style="text-align:center; font-family: lucida sans unicode,lucida grande,sans-serif; font-size:13px; font-weight:400; color:#ccc; padding:5px 0px 5px 0px;">© 2016 Pro Academic Dallas. All Rights Reserved.</p>


</div>




</div>

</div>'; 
	
	}
	
	}





?>

 

<script type="text/javascript">    /*
  $(document).ready(function(){
  

  
    $("#request_from_home").validate({
      rules: { 
        
       
		
      },
     submitHandler: function(input_data) {

		 var input_data = $('#request_from_home').serialize();		 
		 $('.loading').addClass('sub_ted');
        $.ajax({
          type: "POST",
          url: "<?php echo "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>",
          data: input_data,          
          success: function() {
             $('.loading').removeClass('sub_ted');
            $('.general_contact_thankS').addClass('sub_ted');
           $("#request_from_home")[0].reset();
		    setTimeout(function() {
        $('.general_contact_thankS').removeClass('sub_ted');
    }, 5000)
          },
          error: function() {
           //
          }
        });
        return false;
      }        
    });
  });*/
 </script>