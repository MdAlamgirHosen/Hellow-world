<?php
/*
Template Name Posts: Multi Product
*/
?>
<?php get_header(); ?>
<div class="gfmw_full_contianer singlepost">

	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">
<section class="content">
	
	
	
	<div class="content_post">
		
		<?php while ( have_posts() ): the_post(); ?>
			<article <?php post_class(); ?>>	
				<div class="post-inner group">
					
					<h1 class="post-title"><?php the_title(); ?></h1>
					<p class="post-byline"><?php _e('by','GFMW'); ?> <?php the_author_posts_link(); ?> &middot; <?php the_time(get_option('date_format')); ?>  <?php get_template_part('inc/page-title'); ?></p>
					
					<?php if( get_post_format() ) { get_template_part('inc/post-formats'); } ?>
					<?php the_post_thumbnail( 'single-post-thumbnail' ); ?>
					<div class="clear"></div>
					<div class="respon_details"><!--details--> </div>
					<div class="clear"></div>
					
					<div class="entry">	
						<div class="entry-inner">
							<?php the_content(); ?>
							<?php wp_link_pages(array('before'=>'<div class="post-pages">'.__('Pages:','GFMW'),'after'=>'</div>')); ?>
						</div>
						<div class="clear"></div>				
					</div><!--/.entry-->
					
				</div><!--/.post-inner-->	
			</article><!--/.post-->				
		<?php endwhile; ?>
		
		<div class="clear"></div>
		
		<?php // the_tags('<p class="post-tags"><span>'.__('Tags:','GFMW').'</span> ','','</p>'); ?>
		
	
		
		<?php // if ( ot_get_option( 'post-nav' ) == 'content') { get_template_part('inc/post-nav'); } ?>
		
		
		
		
		
	</div>
		<!--BEGIN .author-bio-->
<div class="author-bio">
			 <?php echo get_avatar( get_the_author_meta('email'), '90' ); ?>
			<div class="author-info">
				<h3 class="author-title_wm">About  <?php the_author_link(); ?></h3>
				<p class="author-description_wm"><?php the_author_meta('description'); ?></p>
			
				<ul class="icons">
					<?php /*
						$rss_url = get_the_author_meta( 'rss_url' );
						if ( $rss_url && $rss_url != '' ) {
							echo '<li class="rss"><a href="' . esc_url($rss_url) . '"></a></li>';
						}
						
						$google_profile = get_the_author_meta( 'google_profile' );
						if ( $google_profile && $google_profile != '' ) {
							echo '<li class="google"><a href="' . esc_url($google_profile) . '" rel="author"></a></li>';
						}
						
						$twitter_profile = get_the_author_meta( 'twitter_profile' );
						if ( $twitter_profile && $twitter_profile != '' ) {
							echo '<li class="twitter"><a href="' . esc_url($twitter_profile) . '"></a></li>';
						}
						
						$facebook_profile = get_the_author_meta( 'facebook_profile' );
						if ( $facebook_profile && $facebook_profile != '' ) {
							echo '<li class="facebook"><a href="' . esc_url($facebook_profile) . '"></a></li>';
						}
						
						$linkedin_profile = get_the_author_meta( 'linkedin_profile' );
						if ( $linkedin_profile && $linkedin_profile != '' ) {
							echo '<li class="linkedin"><a href="' . esc_url($linkedin_profile) . '"></a></li>';
						}*/
					?>
				</ul>
			</div>
<!--END .author-bio-->
</div>
	<div class="gfmw_related_product">
	<?php  if ( ot_get_option( 'related-posts' ) != '1' ) { get_template_part('inc/related-posts'); } ?>
	</div>
	<div class="gfmw_comment_abox">
	<?php  comments_template('/comments.php',true); ?>
	</div>
</section>

<section class="sidebar_gfmw">

<?php get_sidebar('2'); ?> 
</section>




</div>
	</div>
	
</div>


<?php get_footer(); ?>