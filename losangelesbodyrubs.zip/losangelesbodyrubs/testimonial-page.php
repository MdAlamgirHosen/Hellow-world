<?php 
/*
Template Name: Testimonials 
*/

?>
<?php get_header(); ?>


<?php get_template_part('ltc/pagetitle'); ?>



<?php while ( have_posts() ): the_post(); ?>
		

					<?php the_content(); ?>

			<?php if ( ot_get_option('page-comments') == 'on' ) { comments_template('/comments.php',true); } ?>
			
		<?php endwhile; ?>


<?php get_footer(); ?>