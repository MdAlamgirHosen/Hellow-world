<!DOCTYPE html> 
<html class="no-js" <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title><?php if(is_front_page()) { echo bloginfo("name");  }elseif ( is_home() ) { echo bloginfo("name");} else { echo lt_page_title();  } ?>
	</title>
    <?php get_template_part('ltc/metatag'); ?>
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
	
	
	<?php wp_head(); ?>
	
<?php if ( ot_get_option( 'gogle_verify' )): ?>
<?php echo ot_get_option('gogle_verify'); ?>
<?php endif; ?>
<script type="text/javascript">
    var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
	
	

$(document).ready(function() {
$('.serImg_e')
    // tile mouse actions
    .on('mouseover', function(){
      $(this).css({'transform': 'scale(1.1)'});
    })
    .on('mouseout', function(){
      $(this).css({'transform': 'scale(1)', 'z-index': '99'});
    })
    .on('mousemove', function(e){
      $(this).css({'transform-origin': ((e.pageX - $(this).offset().left) / $(this).width()) * 100 + '% ' + ((e.pageY - $(this).offset().top) / $(this).height()) * 100 +'%'});
    })
    
	
});
</script>

</head>

<body <?php body_class(); ?>>

<!--------------------Head Section------------------------>

<div class="gfmw_main">
 <header class="gfmw_header"> 

  	<div class="gfmw_logo_area">
	<?php if ( ot_get_option('custom-logo')): ?>
	 	<a href=" <?php echo site_url(); ?> "><img src="<?php echo ot_get_option('custom-logo'); ?>" class="gfmw_logo"></a>
		
		<?php else: ?>
	   	<a href="<?php echo site_url(); ?>"><img src="<?php bloginfo('template_url'); ?>/images/logo.png" class="gfmw_logo"></a>
		
		<?php endif; ?>
		
   </div>
  
    <div class="gfmw_logo_right">
   
	<div class="topMenuS"> 
	<?php if ( ot_get_option('header_rightarea')): ?>
	<?php echo ot_get_option('header_rightarea'); ?>
	<?php else: ?>
	<p class="text_callrighse _phone">
	<a href="tel:888-600-5606">888-600-5606</a><span>24 Hours A Day/ 7 Day Week </span>
	</p>
	<p class="text_callrighse">
	Body rub, fetish, and escort experiences
	</p>
	<?php endif; ?>
	<?php wp_nav_menu(array('theme_location'=>'topbar','menu_class'=>'topnavMenu','container'=>'','topMenuS' => '','fallback_cb'=> false)); ?>
	</div>
     
    </div>

	
  </header>  
 <div class="gfmw_menuarea">
	<div class="gfmw_center menu_area_gw">
       <div class="gfmw_menu">
			<div class="mob_menus_gfmw">
			<p> Go to</p>
			<div class="menu_icons_mob"></div>
			</div>
			<?php wp_nav_menu(array('theme_location'=>'header','menu_class'=>'gfmw_nav','container'=>'','gfmw_menu' => '','fallback_cb'=> false)); ?>
	   </div>
	</div>
 </div>
  
</div>


