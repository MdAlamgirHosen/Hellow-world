<?php 
/*
Template Name: About Us
*/

?>
<?php get_header(); ?>


<?php get_template_part('ltc/pagetitle'); ?>


<div class="gfmw_full_contianer page_simple_content">
	<div class="gfwm_center blogpost">
		<div class="gw_inner pagesimple_content simplepost">

		

					
						
		</div>
</div>
</div>


<?php while ( have_posts() ): the_post(); ?>
		

					<?php the_content(); ?>

			<?php if ( ot_get_option('page-comments') == 'on' ) { comments_template('/comments.php',true); } ?>
			
		<?php endwhile; ?>

<?php get_footer(); ?>

















<?php get_footer(); ?>