<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
        <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
        <title>home page</title>
    </head>
    <body>
        <div class="container">
            <div class="row clear_fix">
                <div class="col-md-12 ">
                    <blockquote>
                        <h3><strong>Welcome to codeigniter home page</strong></h3>
                        <iframe src="//www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Fwebrocom.learn&amp;width&amp;layout=button_count&amp;action=like&amp;show_faces=false&amp;share=true&amp;height=21&amp;appId=1464599523806855" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:21px;" allowTransparency="true"></iframe>
                    </blockquote>
                    
                    <a href="http://webrocom.net/ajax-login-system-php-codeigniter/" class="btn btn-info btn-lg pull-left">Back to tutorial</a><a href="<?php echo base_url();?>auth/logout" class="btn btn-info btn-lg pull-right">Logout</a>
                </div>
            </div>
        </div>
    </body>
</html>
