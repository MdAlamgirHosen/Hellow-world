<script src="<?php echo base_url() ?>asset/lib/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="<?php echo base_url() ?>asset/lib/alertify/alertify.min.js"/>

<script>
    $(document).ready(function (){
        
    });
</script>
    </body>
</html>
