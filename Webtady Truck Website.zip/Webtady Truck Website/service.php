<?php 
/*
Template Name: Service Page Template
*/

?>
<?php get_header('whatever'); ?>

	<?php while ( have_posts() ): the_post(); ?>
		

					<?php the_content(); ?>

			
			
		<?php endwhile; ?>


<?php get_footer(); ?>