<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?>



<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8"> 
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>This is Trucks page:</title>
            <!--Google Fonts -->
            <link href="https://fonts.googleapis.com/css?family=Yeseva+One" rel="stylesheet">
           <link href="https://fonts.googleapis.com/css?family=Gentium+Basic:400,400i,700" rel="stylesheet">
             <!--Bootstrap Link -->
            <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
            <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
            <!--Css link for localhost-->
            <link href="css/style.css" rel="stylesheet">
            <link href="css/responsive.css" rel="stylesheet">

        
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <?php wp_head(); ?>
    </head>
    <body>
        <!--/.Application Start-->
        <header id="header_hero_area">
		 
          <div class="header_top">		
		   <div class="container">
		   	<div class="row">
		   		<div class="col-sm-12 col-md-12 col-lg-12">
				    <div class="header_top pull-right"> 
					    <p>Hot line number: <a href="tel:(972) 972-5620 "><i class="fa fa-phone"></i>(972) 972-5620</a></p>
					</div>
				</div>
		   	</div>
		   </div>
		  </div><!--./End of header_top--> 
		<div class="header_bottom">
		  <div class="container">
		  	<div class="row">
		  		<div class="col-sm-12 col-md-12 col-lg-12">
				   <nav class="header_menubar navbar-default text-center">
					<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						   <span class="sr-only">Toggle navigation</span>
						   <span class="icon-bar"></span>
						   <span class="icon-bar"></span>
						   <span class="icon-bar"></span>
							</button>
							<a class="img_wi" href="#"><a href="#"><img src="http://localhost/truck/wp-content/uploads/2017/05/TGandL-bnw.jpg" alt="" class="img-responsive img_wi"/></a></a>
						  </div>
						   <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav navbar-right">
							  <?php
								 wp_nav_menu( array(
								'menu'           => 'Primary Menu', // Do not fall back to first non-empty menu.
								'theme_location' => '__no_such_location',
							 'menu_class' => 'nav navbar-nav',
							 'menu_id' => 'menu',
							 'container' => 'ul',
							 'container_class' => 'collapse navbar-collapse'
							   
							) );  ?>
							</ul>
						  </div>  
					</nav> <!--./End of header_navbar--> 
				</div>
		  	</div>
		  </div>
		 </div><!--/.End of navbar area-->


