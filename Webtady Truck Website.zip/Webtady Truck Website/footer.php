<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the "site-content" div and all content after.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?>

	</div><!-- .site-content -->

		 <footer id="footer_area">
		    <div class="footer_top_area">
				<div class="container">
					<div class="row">
						<div class="col-sm-2 col-md-2 col-lg-2"> 
							<div class="footer"> 
							   <h3>Important Links</h3>
								<ul class="footer_menu">
									<li><a href="http://localhost/truck/">Home</a></li>
									<li><a href="http://localhost/truck/about-us/">About Us</a></li>
									<li><a href="http://localhost/truck/service/">Services</a></li>
									<li><a href="http://localhost/truck/contact/">Contact Us</a></li>
									<li><a href="http://localhost/truck/affiliate/">Affiliate</a></li>
								</ul>
							</div>
						</div>
						<div class="col-sm-3 col-md-3 col-lg-3"> 
							<div class="footer2"> 
							   <h3>For Business Customers</h3>
								<ul class="footer_menu">
									<li><a href="#">For Online Stores</a></li>
									<li><a href="#">For Corporate Customers</a></li>
									<li><a href="#">Customers Support Center</a></li>
									<li><a href="#">Open an account</a></li>
								</ul>
							</div>
						</div>
						<div class="col-sm-7 col-md-7 col-lg-7"> 
							<div class="footer3"> 
							   <h3>Main office</h3>
								<ul class="footer_menu">
									<li><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i>1166 Chisholm Ridge Dr. Rockwall, TX 75032</a></li>
									<li><a href="tel:+(972) 972-5620 "><i class="fa fa-phone" aria-hidden="true"></i>(972) 972-5620 </a></li>
								</ul>
								<a href="www.facebook.com">Facebook</a>
								<a href="www.facebook.com">Twitter</a>
							</div>
						</div>
					</div>
				</div>
			</div><!--End of footer top area-->
			<div class="foote_down_area">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 col-md-12 col-lg-12">
							<div class="foote_down"> 
							    <p>DeliveryCo.@2017.<span>Privacy Policy</span></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		 </footer><!--End of footer area-->
        <!--/.End Application-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="js/main.js"></script>
         <?php wp_footer(); ?> 
    </body>
</html>