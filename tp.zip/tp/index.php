<?php
ob_start();
session_start();
if($_SESSION['name']!='localhost')
{
	header('location: login.php');
}
?>


<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>টাংগাইল পৌরসভা</title>
	<link rel="stylesheet" type="text/css" href="style.css" media="all" />
</head>
<body>
<header>
	<img class="logo" src="Pourosova.jpg" alt="logo" />
	<h1>টাংগাইল পৌরসভা সফটওয়্যার  ম্যানেজমেন্ট </h1>
	<h3>কারিগরি সহায়তায় টাংগাইল কলিং লিমিটেড </h3>
</header>
	<nav>
		<ul>
			<li><a href="bazar_shaka/index.php">বাজার শাখা</a></li>
			<li><a href="tread_lisence/login.php">লাইসেন্স শাখা</a></li>
			<li><a href="holding_tex/login.php">হোল্ডিং  ট্যাক্স  শাখা</a></li>
		</ul>

	</nav>


</body>
</html>



