
<?php
ob_start();
session_start();
if($_SESSION['name']!='tangail')
{
	header('location: login.php');
}
?>
<?php
include('../config.php');
if(isset($_REQUEST['id'])) {
	$id = $_REQUEST['id'];
}
else {
	header('location: view_market_data.php');
}
if(isset($_POST['form1'])) {

	try {
	
		if(empty($_POST['dokan_name'])) {
			throw new Exception(' মার্কেটের নাম দিন');
		}
		
		if(empty($_POST['word_no'])) {
			throw new Exception( '  ওয়ার্ড নাম্বার দিন');
		}
		
		if(empty($_POST['tikana'])) {
			throw new Exception( 'অনুগ্রহ করে দোকানের ঠিকানা দিন');
		}
		
		
		$query=$db->prepare("update market_data set marketer_name=?,word_no=?,marketer_address=? where id='$id'" );
		$query->execute(array($_POST['dokan_name'],$_POST['word_no'],$_POST['tikana']));
		$success_message = 'আপনার তথ্য পরিবর্তন হয়েছে ।.';
		
	
	}
	
	catch(Exception $e) {
		$error_message = $e->getMessage();
	}
	
}

?>
<?php include"header.php"?>

<div class="container">
<h2 class="title">মার্কেটের তথ্য পরিবর্তন করুন</h2>
<?php  
if(isset($error_message)) {echo "<div class='error_message'>".$error_message."</div>";}
if(isset($success_message)) {echo "<div class='success_message'>".$success_message."</div>";}
?>

<br>
<?php
		$query=$db->prepare("select * from market_data where id='$id'");
		$query->execute();
		$result=$query->fetchAll(PDO::FETCH_ASSOC);
		foreach($result as $row) 
	{
		$dokan_name=$row['marketer_name'];
		$word_no= $row['word_no'];
		$dokan_address=$row['marketer_address'];
		
	}
	
	?>
	
<form action="" method="post" >
<table celspacing="1" cellpadding="5">
	<tr>
		<td>মারকেটের নাম:</td>
		<td><input type="text" name="dokan_name" id="" value="<?php echo $dokan_name;?>"/></td>
	</tr>
 <tr>
 	<td>ওর্য়াড নং:</td>
	<td>
	<select name="word_no" id="">
					<option value="<?php echo $word_no;?>"><?php echo $word_no;?></option>
					
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
					<option value="11">11</option>
					<option value="13">13</option>
					<option value="14">14</option>
					<option value="15">15</option>
					<option value="16">16</option>
					<option value="17">17</option>
					<option value="18">18</option>
				</select></td>
 </tr>
 <tr>
	<td>ঠিকানা:</td>
	<td><input type="text" name="tikana" value="<?php echo $dokan_address;?>" /></td>
</tr>

<tr>
	<td></td>
	<td><button class="btn btn-success" type="submit" name="form1">পরিবর্তন করুন</button></td>
</tr>
</table>

</form>

</div> 
</div><!---end container--->