<?php
ob_start();
session_start();
if($_SESSION['name']!='tangail')
{
	header('location: login.php');
}
?>
<?php
include('../config.php');
if(isset($_POST['form1'])) {

	try {
	
		if(empty($_POST['dokan_name'])) {
			throw new Exception(' অনুগ্রহ করে দোকানের নাম দিন');
		}
		
		if(empty($_POST['word_no'])) {
			throw new Exception( 'অনুগ্রহ করে  ওয়ার্ড নাম্বার দিন');
		}
		if(empty($_POST['dokan_no'])) {
			throw new Exception( 'অনুগ্রহ করে দোকানের নাম্বার দিন');
		}
		
		if(empty($_POST['shop_name'])) {
			throw new Exception( 'অনুগ্রহ করে  বরাদ্দ প্রাপকের নাম  দিন');
		}
		if(empty($_POST['maliker_name'])) {
			throw new Exception( 'পিতা / স্বামীর নাম দিন দিন');
		}
		if(empty($_POST['tikana'])) {
			throw new Exception( ' ঠিকান‍া দিন ');
		}
		
		
		if(empty($_POST['vara'])) {
			throw new Exception( 'অনুগ্রহ করে দোকানের মাসিক ভাড়া পরিমান দিন');
		}
		
		
		$query=$db->prepare("select * from market_info WHERE m_no=? and m_name=? ");
		$query->execute(array($_POST['dokan_no'],$_POST['dokan_name']));
		$result=$query->rowCount();
	
	if($result>0) {
			throw new Exception( '  এই নাম্বার দোকানের আছে ');
		}
		$query=$db->prepare("insert into  market_info(m_name,word_no,m_no,dokaner_name,m_malik,address,mobile,m_vara) values(?,?,?,?,?,?,?,?)");
		$query->execute(array($_POST['dokan_name'],$_POST['word_no'],$_POST['dokan_no'],$_POST['shop_name'],$_POST['maliker_name'],$_POST['tikana'],$_POST['mobile_no'],$_POST['vara']));
	
		
		$success_message = 'আপনার তথ্য সংরক্ষন হয়েছে ।.';
		
	
	}
	
	catch(Exception $e) {
		$error_message = $e->getMessage();
	}
	
}

?>
<?php include("header.php")?>

<div class="container">
<br />
<h2 class="title">দোকানের তথ্য সংরক্ষনের ফরম:</h2>
<?php  
if(isset($error_message)) {echo "<div class='error_message'>".$error_message."</div>";}
if(isset($success_message)) {echo "<div class='success_message'>".$success_message."</div>";}
?>
<form action="" method="post" >
<table celspacing="1" cellpadding="5">
	<tr>
		<td>মার্কেটের নাম:</td>
		<td>
		<select name="dokan_name" id="">
		<option value="">মার্কেটের নাম নির্বাচন  করুন</option>
	
			<?php 
		$query=$db->prepare("select * from market_data");
		$query->execute();
		$result=$query->fetchAll(PDO::FETCH_ASSOC);
		foreach($result as $row){
		?>
			<option value="<?php echo $row['marketer_name'];?>"><?php echo $row['marketer_name'];?></option>
			<?php
		}
			
			
			?>
			
		</select>
		</td>
	</tr>
 <tr>
 	<td>ওর্য়াড নং:</td>
 	<td>
	<select name="word_no" id="">
					<option value="">ওয়ার্ড  নং  নির্বাচন করুন</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
					<option value="11">11</option>
					<option value="13">13</option>
					<option value="14">14</option>
					<option value="15">15</option>
					<option value="16">16</option>
					<option value="17">17</option>
					<option value="18">18</option>
				</select></td>
 </tr>
 <tr>
 	<td>দোকান নং:</td>
 	<td><input type="text" name="dokan_no"/></td>
 </tr>
 <tr>
 	<td>বরাদ্দ প্রাপকের  নাম:</td>
 	<td><input type="text" name="shop_name"/></td>
 </tr>
<tr>
	<td>পিতা / স্বামীর  নাম:</td>
	<td><input type="text" name="maliker_name" /></td>
</tr>
<tr>
	<td>ঠিকান‍া:</td>
	<td><input type="text" name="tikana" /></td>
</tr>
<tr>
	<td>মোবাইল নাম্বার:</td>
	<td><input type="text" name="mobile_no" /></td>
</tr>

<tr>
	<td>মাসিক ভাড়া:</td>
	<td><input type="text" name="vara"/></td>
</tr>
<tr>
	<td></td>
	<td><button class="btn btn-success" type="submit" name="form1">সংরক্ষন করুন</button></td>
</tr>
</table>

</form>

</div> 
</div><!---end container--->