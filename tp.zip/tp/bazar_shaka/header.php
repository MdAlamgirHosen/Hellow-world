

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>টাংগাইল পৌরসভা </title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
		
		
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">
		<link rel="stylesheet" href="css/responsive.css">
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

		<header>
			<div class="container">
				<img class="logo" src="../Pourosova.jpg" alt="logo" />
				<h1> টাংগাইল পৌরসভা সফটওয়্যার ম্যানেজমেন্ট </h1>
				<h2> বাজার শাখা</h2>
				<h3>কারিগরি সহায়তায় :  টাংগাইল কলিং লি.</h3>
				
				
			</div> 
	
				<div class="container">
					<nav class="mainmenu">
						<ul id="nav">
							
							<li><a href="">দোকান সংক্রান্ত তথ্যাবলি </a>
								
								<ul>
									
									<li><a href="insert.php">নতুন দোকন/প্রতিষ্ঠানের  তথ্য</a></li>
									<li><a href="dokan_data_correction.php"> দোকনের তথ্য সংশোধন </a></li>
									<li><a href="view_dokan_data.php"> দোকনের তথ্য মুছুন </a></li>
									
								</ul>
							
							</li>
							<li><a href="">মার্কেট সংক্রান্ত তথ্যাবলি </a>
							<ul>
								<li><a href="market_data.php">নতুন মার্কেটের তথ্য </a></li>
								<li><a href="market_list.php">সকল মার্কেটের তালিকা </a></li>
								<li><a href="marketer_data_correction.php">মার্কেটের  তথ্য সংশোধন </a></li>
								<li><a href="view_marketer_data.php"> মার্কেটের তথ্য মুছুন </a></li>
							</ul>
							</li>
							<li><a href="">দোকানের তলিকা</a>
							
							<ul>
								<li><a href="view.php">সকল দোকানের তলিকা</a></li>
								<li><a href="view_dokan_list.php">মার্কেট অনুযায়ী তলিকা</a></li>
								<li><a href="view_list_by_word_no.php">ওয়ার্ড নং অনুযায়ী  তলিকা</a></li>
									
							</ul>
							
							</li>
							<li><a href="">ভাড়া সংক্রান্ত তথ্যাবলি</a>
								<ul>
									<li><a href="month_vara.php">মাসিক ভাড়া আদায়</a></li>
									
									<li><a href="joma_report.php">মাসিক ভাড়া প্রদানের তালিকা</a></li>
									<li><a href="bokeia.php">মাসিক ভাড়া বকেয়া তালিকা</a></li>
								</ul>
								
							</li>
							<li><a href="cost.php">ব্যায় বিবরনী</a></li>
							<li><a href="">রশীদ </a>
							<ul>
								<li><a href="vara_roshid.php">ভাড়া আদায়ের রশীদ</a></li>
								<li><a href="view_cost_roshid.php">খরচের ভাউচার</a></li>
									
							</ul>
							
							
							</li>
							
							<li><a href="balance_sheet.php">ব্যালেন্সসীট</a></li>
							
							<li><a href="bokeia.php">রিপোর্ট</a>
							
							<ul>
								<li><a href=""> ভাড়া আদায়ের  রিপোর্ট</a>
									<ul>
									<li><a href="day_report.php">দৈনিক রিপোর্ট</a></li>
									<li><a href="monthly_report.php">মাসিক রিপোর্ট</a></li>
									<li><a href="yearly_report.php">বাৎসারিক রিপোর্ট</a></li>
									
									</ul>
								
								</li>
								
								<li><a href="">ব্যায় বিবরনী  রিপোর্ট</a>
									<ul>
									<li><a href="cost_day_report.php">দৈনিক রিপোর্ট</a></li>
									<li><a href="cost_monthly_report.php">মাসিক রিপোর্ট</a></li>
									<li><a href="cost_yearly_report.php">বাৎসারিক রিপোর্ট</a></li>
					
									</ul>
								
								</li>
								
								
							</ul>
							</li>
							
							
							
							
							<li><a href="change_password.php">পাসওয়ার্ড  পরিবতন করুন</a></li>
							<li><a href="logout.php">লগআউট</a></li>
						</ul>
					</nav>
				</div>
				
		</header>