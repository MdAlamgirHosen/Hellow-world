<?php
ob_start();
session_start();
if($_SESSION['name']!='tangail')
{
	header('location: login.php');
}
?>
<?php include('../config.php'); ?>
<?php include("header.php");?>
		
<?php 



if(isset($_REQUEST['dokan_no']) && isset($_REQUEST['dokan_name'])){
$input_dokan_no=$_REQUEST['dokan_no'];
$input_market_name=$_REQUEST['dokan_name'];

		$query=$db->prepare("select * from market_info WHERE m_no=? and m_name=?");
		$query->execute(array($input_dokan_no,$input_market_name));
		$result=$query->rowCount();
		if($result==0) {
			header("location:dokan_data_correction.php?error=1");
		}
		

	
		}
	
else{
	
	header("location:dokan_data_correction.php?error=0");
}


?>
<?php

	
	$query=$db->prepare("select * from market_info  where m_no='$input_dokan_no' and m_name='$input_market_name'");
	$query->execute();
	$result=$query->fetchAll(PDO::FETCH_ASSOC);
	foreach($result as $row) 
	{
		 $dokan_name=$row['m_name'];
		 $word_no= $row['word_no'];
		$dokan_no= $row['m_no'];
		 $dokaner_name=$row['dokaner_name'];
		$dokaner_malik=$row['m_malik'];
		$dokan_address=$row['address'];
		$dokan_mobile=$row['mobile'];
		$vara=$row['m_vara'];
		
		
	}
	
	?>
<div class="container">
<h2 class="title">দোকানের  তথ্য বিবরণী </h2>
<table cellspacing="2" cellpadding="5" >
	<tr>
		<td>দোকান নং:</td>
		<td><?php echo $dokan_no;?></td>
		
	</tr>
	<tr>
	<td>মারকেটের নাম:</td>
	<td><?php echo $dokan_name;?></td>
	</tr>
	<tr>
		<td>বরাদ্দ প্রাপকের নাম:</td>
		<td><?php echo $dokaner_name;?></td>
	</tr>
	<tr>
		<td>পিতা / স্বামীর  নাম:</td>
		<td><?php echo $dokaner_malik;?></td>
	</tr>
	<tr>
	<td>ঠিকানা:  </td>
	<td><?php echo $dokan_address;?></td>
	</tr>
	<tr>
		<td>মাসিক ভাড়া:</td>
		<td><?php echo $vara;?></td>
	</tr>
	<tr>
		<td></td>
		<td>
	<a href="update.php?id=<?php echo $row['m_id']; ?>" class="btn btn-success">সংশোধন</a>
	</tr>
</table>

	
	
</div><!---end container--->
<?php include('footer.php');?>
