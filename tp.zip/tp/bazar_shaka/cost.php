<?php
ob_start();
session_start();
if($_SESSION['name']!='tangail')
{
	header('location: login.php');
}
?>

<?php include('../config.php');?>
<?php include"header.php"?>
    
			

<?php 
if(isset($_POST['form1'])) {
	

	try {
		if(empty($_POST['c_biboron'])) {
			throw new Exception('খরচের বিবরন লিখুন ');
		}
		if(empty($_POST['c_taka'])) {
			throw new Exception('  খরচের পরিমান দিন ');
		}
		
		$date=date('d-m-Y');
		$day=substr($date,0,2);
		$month=substr($date,3,2);
		$year=substr($date,6,4);
		
		$query=$db->prepare("insert into cost(cost_biboron,cost_taka,day,month,year,cost_date) values(?,?,?,?,?,?)");
		$query->execute(array($_POST['c_biboron'],$_POST['c_taka'],$day,$month,$year,$date));
	
		
		$success_message = 'আপনার  খরচের পরিমান জমা হয়েছে ।.';
		


		}
	
	catch(Exception $e) {
		$error_message = $e->getMessage();
	}
	
}

?>	
	

<div class="container">
<br>
<h2 class="title">দৈনন্দিন খরচের পরিমান সঞ্চয় করুন</h2>
    <?php  
if(isset($success_message)) {echo "<div class='success_message'>".$success_message."</div>";}
if(isset($error_message)) {echo "<div class='error_message'>".$error_message."</div>";}
?>
			<form action="" method="post" id="" >
			<table celspacing="1" cellpadding="5">
				<tr>
				<td>খরচের বিবরন:</td>
				<td><input type="text" name="c_biboron" id="" /></td>
				</tr>
				<tr>
					<td>খরচের পরিমান:</td>
					<td><input type="text" name="c_taka"/></td>
				</tr>
				<tr>
				<td></td>
					<td><button class="btn btn-success" name="form1" >সঞ্চয় করুন</button></td>
				</tr>
				
		</table>
			</form>
    </div>    
		
