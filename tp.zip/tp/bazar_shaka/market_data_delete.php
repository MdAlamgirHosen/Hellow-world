<?php
ob_start();
session_start();
if($_SESSION['name']!='tangail')
{
	header('location: login.php');
}
?>
<?php include('../config.php'); ?>
<?php include("header.php");?>

	<script>
		function confirm_delete() {
			return confirm('আপনি কি নিশ্চিত তথ্য মুছে ফেলবেন');
		}
	</script>
		
<?php 



if(isset($_REQUEST['word_no']) && isset($_REQUEST['dokan_name'])){
$input_dokan_no=$_REQUEST['word_no'];
$input_market_name=$_REQUEST['dokan_name'];

		$query=$db->prepare("select * from market_data WHERE word_no=? and marketer_name=?");
		$query->execute(array($input_dokan_no,$input_market_name));
		$result=$query->rowCount();
		if($result==0) {
			header("location:view_marketer_data.php?error=1");
		}
		

	
		}
	
else{
	
	header("location:view_marketer_data.php?error=0");
}


?>
<?php

	
	$query=$db->prepare("select * from market_data  where word_no='$input_dokan_no' and marketer_name='$input_market_name'");
	$query->execute();
	$result=$query->fetchAll(PDO::FETCH_ASSOC);
	foreach($result as $row) 
	{
		 $dokan_name=$row['marketer_name'];
		 $word_no= $row['word_no'];
		$dokan_address=$row['marketer_address'];
		
	}
	
	?>
<div class="container">
<h2 class="title">মার্কেটের তথ্য বিবরণী </h2>
<table cellspacing="2" cellpadding="5" >
	<tr>
	<td>মার্কেটের নাম:</td>
	<td><?php echo $dokan_name;?></td>
	</tr>
	<tr>
		<td>ওয়ার্ড নং</td>
		<td><?php echo $word_no;?></td>
	</tr>
	<tr>
	<td>ঠিকানা:</td>
	<td><?php echo $dokan_address;?></td>
	</tr>
	
	<tr>
		<td></td>
		<td>
	<a onclick="return confirm_delete();" href="market_delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger">মুছেফেলুন</a></td>
	</tr>
</table>

	
	
</div><!---end container--->
<?php include('footer.php');?>
