<?php
ob_start();
session_start();
if($_SESSION['name']!='tangail')
{
	header('location: login.php');
}
?>
<?php
include('../config.php');
if(isset($_POST['form1'])) {

	try {
	
		if(empty($_POST['market_name'])) {
			throw new Exception(' দোকানের নাম দিন');
		}
		
		if(empty($_POST['word'])) {
			throw new Exception( ' ওয়ার্ড নাম্বার দিন');
		}
		
		if(empty($_POST['market_address'])) {
			throw new Exception( ' মার্কেটের ঠিকানা  দিন');
		}
		
		
		$query=$db->prepare("insert into  market_data(marketer_name,word_no,marketer_address) values(?,?,?)");
		$query->execute(array($_POST['market_name'],$_POST['word'],$_POST['market_address']));
	
		
		$success_message = 'আপনার তথ্য সংরক্ষন হয়েছে ।.';
		
	
	}
	
	catch(Exception $e) {
		$error_message = $e->getMessage();
	}
	
}

?>
<?php include("header.php")?>

<div class="container">
<br>
<h2 class="title">মার্কেটের তথ্য সংরক্ষন করুন</h2>
<?php  
if(isset($error_message)) {echo "<div class='error_message'>".$error_message."</div>";}
if(isset($success_message)) {echo "<div class='success_message'>".$success_message."</div>";}
?>
<br />
<form action="" method="post" >
<table celspacing="1" cellpadding="5">
	<tr>
		<td>মার্কেটের  নাম:</td>
		<td><input type="text" name="market_name"/></td>
	</tr>
 <tr>
 	<td>ওর্য়াড নং:</td>
	<td>
	<select name="word" id="">
					<option value="">ওয়ার্ড  নং  নির্বাচন করুন</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
					<option value="11">11</option>
					<option value="13">13</option>
					<option value="14">14</option>
					<option value="15">15</option>
					<option value="16">16</option>
					<option value="17">17</option>
					<option value="18">18</option>
				</select></td>
</tr>
<tr>
		<td>ঠিকানা:</td>
		<td><input type="text" name="market_address"/></td>
</tr>
<tr>
	<td></td>
	<td><button class="btn btn-success" type="submit" name="form1">সংরক্ষন করুন</button></td>
</tr>


</table>

</form>

</div><!---end container--->