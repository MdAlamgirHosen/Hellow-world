-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2018 at 03:56 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `code_ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `manufacture`
--

CREATE TABLE `manufacture` (
  `manufacture_id` int(11) NOT NULL,
  `manufacture_name` varchar(255) NOT NULL,
  `manufacture_sort_desc` varchar(255) NOT NULL,
  `manufacture_desc` text NOT NULL,
  `manufacture_status` tinyint(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `manufacture`
--

INSERT INTO `manufacture` (`manufacture_id`, `manufacture_name`, `manufacture_sort_desc`, `manufacture_desc`, `manufacture_status`) VALUES
(1, 'manufacture name 1', 'manufacture name 1', 'manufacture name 1manufacture name 1manufacture name 1manufacture name 1manufacture name 1manufacture name 1manufacture name 1manufacture name 1manufacture name 1manufacture name 1', 2),
(2, 'manufacture name 1', 'manufacture name 1', 'manufacture name 1manufacture name 1manufacture name 1manufacture name 1manufacture name 1manufacture name 1manufacture name 1manufacture name 1manufacture name 1manufacture name 1', 2),
(3, 'manufacture name 10', 'manufacture name 10', 'manufacture name 10manufacture name 10manufacture name 10manufacture name 10manufacture name 10manufacture name 10manufacture name 10', 2),
(4, 'manufacture name 2', 'manufacture name 2', 'manufacture name 2manufacture name 2manufacture name 2manufacture name 2manufacture name 2', 3),
(5, 'manufacture name 3', 'manufacture name 3', 'manufacture name 3manufacture name 3manufacture name 3manufacture name 3manufacture name 3manufacture name 3manufacture name 3', 2),
(6, 'ACNE 3', 'ACNE 3', 'ACNE 33333333333333<br>', 2),
(7, 'ACNE', ' ACNE  ACNE  ACNE  ACNE  ACNE  ACNE  ACNE ', '&nbsp;ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE&nbsp; ACNE <br>', 3),
(8, 'Albiro 2', 'Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro v', 'Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro v<br>', 2),
(9, 'ACNE ', 'ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE v', 'ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE <br>', 2),
(10, 'Albiro ', 'Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro ', 'Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro Albiro v<br>', 2),
(11, 'ACNE 2', 'ACNE 2 ACNE 2 ACNE 2', 'ACNE 2 ACNE 2 ACNE 2 ACNE 2 ACNE 2 ACNE 2 ACNE 2 ACNE 2 ACNE 2 ACNE 2 ACNE 2 ACNE 2 ACNE 2 ', 2),
(12, 'Dell', 'Dell is the best product Dell is the best product ', 'Dell is the best product Dell is the best product Dell is the best product Dell is the best product Dell is the best product Dell is the best product Dell is the best product Dell is the best product Dell is the best product Dell is the best product <br>', 2),
(13, 'Iphone', 'Iphone is the best product ', 'Iphone is the best product Iphone is the best product Iphone is the best product Iphone is the best product Iphone is the best product Iphone is the best product Iphone is the best product Iphone is the best product Iphone is the best product <br>', 3),
(14, 'Samnung gelaxy 2', 'Samnung gelaxySamnung gelaxySamnung gelaxy', 'Samnung gelaxySamnung gelaxySamnung gelaxySamnung gelaxy', 2),
(15, 'Samnung gelaxy', 'Samnung gelaxySamnung gelaxySamnung gelaxy', 'Samnung gelaxySamnung gelaxySamnung gelaxySamnung gelaxy', 2),
(16, 'hola', 'hola hola hola hola hola hola hola hola hola hola ', 'hola hola hola hola hola hola hola hola hola hola hola hola hola hola hola hola v<br>', 2),
(17, 'hola', 'hola hola hola hola hola hola hola hola hola hola ', 'hola hola hola hola hola hola hola hola hola hola hola hola hola hola hola hola v<br>', 3),
(18, 'ACNE', 'hola hola hola hola hola hola hola hola hola hola', 'hola hola hola hola hola hola hola hola hola hola', 2),
(19, 'Albiro', 'ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE v', 'ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE v', 2),
(20, 'ACNE', 'ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE v', 'ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE v', 2),
(21, 'ACNE 3', 'ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3', 'ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3', 2),
(22, 'ACNE 3', 'ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3', 'ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3ACNE 3', 3),
(23, 'ACNE', 'ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE v', 'jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj', 2),
(24, 'Samnung gelaxy 21', 'ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE v', 'as asdf adf<br>', 1),
(25, 'ACNE', 'ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE ACNE v', 'aaaaaaaaaaaaaaaaaaaa&nbsp;&nbsp;&nbsp; fadsffffffffffffffffffffff<br>', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `cat_id` int(11) NOT NULL,
  `cat_name` varchar(255) NOT NULL,
  `cat_short_desc` varchar(255) NOT NULL,
  `cat_desc` text NOT NULL,
  `cat_status` tinyint(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`cat_id`, `cat_name`, `cat_short_desc`, `cat_desc`, `cat_status`) VALUES
(1, 'save_product asds sdfsdf', 'save_product asss sdfsdf', 'save_product asss sdfsdf<br>', 1),
(2, 'test', 'test', 'test', 1),
(3, 'Add categorys', 'categorys descriptin', 'categorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptin', 3),
(4, 'Add categorys', 'categorys descriptin', 'categorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptin', 3),
(5, 'Add categorys', 'categorys descriptin', 'categorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptin', 3),
(6, 'Add categorys', 'categorys descriptin', 'categorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptin', 3),
(7, 'Add categorys', 'categorys descriptin', 'categorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptincategorys descriptin', 3),
(8, 'Tv', 'Tv short description is here', 'Tv description is here Tv description is here Tv description is here Tv description is here Tv description is here Tv description is here Tv description is here Tv description is here Tv description is here Tv description is here Tv description is here Tv description is here Tv description is here Tv description is here Tv description is here Tv description is here ', 1),
(9, 'Mobile', 'Mobile short description is here ', 'Mobile description is here Mobile description is here Mobile description is here Mobile description is here Mobile description is here Mobile description is here Mobile description is here Mobile description is here Mobile description is here Mobile description is here Mobile description is here Mobile description is here Mobile description is here ', 1),
(10, 'Laptop', 'Laptop short description is here ', 'Laptop description is here Laptop description is here Laptop description is here Laptop description is here Laptop description is here Laptop description is here Laptop description is here Laptop description is here Laptop description is here Laptop description is here Laptop description is here Laptop description is here Laptop description is here ', 1),
(11, 'Add categorys 3', 'Add categorys 3', 'Add categorys 3Add categorys 3Add categorys 3Add categorys 3Add categorys 3Add categorys 3', 3),
(12, 'phone', 'phonephonephonephonephonephonephonephonephone', 'phonephonephonephonephonephonephonephonephonephonephonephone', 1),
(13, 'phone', 'phonephonephonephonephonephonephonephonephone', 'phonephonephonephonephonephonephonephonephonephonephonephone', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_price` float NOT NULL,
  `product_satus` tinyint(3) NOT NULL,
  `product_short_desc` varchar(255) NOT NULL,
  `product_quantity` int(6) NOT NULL,
  `product_img` text NOT NULL,
  `product_desc` text NOT NULL,
  `top_product` tinyint(1) NOT NULL,
  `product_category` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`product_id`, `product_name`, `product_price`, `product_satus`, `product_short_desc`, `product_quantity`, `product_img`, `product_desc`, `top_product`, `product_category`) VALUES
(19, 'Tv Product here 2', 0, 3, 'Tv Product hereTv Product hereTv Product here', 10, 'uploads/android-icon-144x144.png', '', 1, 8),
(20, 'Mobile product here 3', 0, 3, 'Mobile product hereMobile product hereMobile product here', 10, 'uploads/android-icon-36x36.png', 'dsfadfsafd adfasdf <br>', 0, 9),
(21, 'Laptop product here', 0, 3, 'Laptop product here', 10, 'uploads/favicon-96x96.png', '', 1, 10),
(22, 'Head phone', 250, 3, 'Head phoneHead phoneHead phoneHead phoneHead phoneHead phoneHead phone', 10, 'uploads/1488450209.jpg', '', 0, 9),
(23, 'Head phone', 250, 3, 'Head phoneHead phoneHead phoneHead phoneHead phoneHead phoneHead phone', 10, 'uploads/android-icon-96x96.png', '', 0, 8),
(24, 'Head phone', 250, 1, 'Head phoneHead phoneHead phoneHead phoneHead phoneHead phoneHead phone', 10, 'uploads/photo5.jpg', '', 0, 2),
(25, 'data save cheek 3', 250, 1, 'alamgir hosenalamgir hosen', 10, 'uploads/photo1.jpg', '', 0, 0),
(26, 'alamgir hosen', 250, 1, 'alamgir hosenalamgir hosen', 10, 'uploads/photo3.jpg', '', 0, 10),
(27, 'Head phone 2', 250, 2, 'alamgir hosenalamgir hosen', 10, 'uploads/photo7.jpg', 'asdfsdf asdf adf asdfsdfsdfasfd <br>', 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_tbl`
--

CREATE TABLE `user_tbl` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  `user_role` tinyint(3) NOT NULL,
  `user_status` tinyint(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_tbl`
--

INSERT INTO `user_tbl` (`user_id`, `user_name`, `user_email`, `user_pass`, `user_role`, `user_status`) VALUES
(1, 'Alamgir', 'admin@gmail.com', '$2y$10$gdwGOxZ19PfTq/eLnGnntux7li9jUOzMAim8EFbmakT1AJCrat6M.', 1, 1),
(3, 'admin', 'admin@gmail.com', '$2y$10$Kx2nsn1SHO/XDM5uFqxJHO1eYl03G82j5Hfr6d2qgwmYzj0MTylke', 1, 1),
(4, 'admin', 'admin@gmail.com', '$2y$10$QEBkjKj3AgE.1Yw8pn0esujBVYLi0SXK0U5/ux.huv4ZViyxD49oi', 1, 1),
(11, 'kanon', 'kanon@gmail.com', '$2y$10$4SR.q4q/BZ1Hp2hJ8i76q.spsp9QSSJZ3sIoNwMaMqS2P1Ii89b2.', 1, 1),
(12, 'atik', 'atik@gmail.com', '$2y$10$yJjLlOScCZZupZL2t0ZXAOSeMqt9jteZrx/DsxwH4ayYfx.o291Pu', 1, 1),
(13, 'mujib', 'mujib@gmail.com', '$2y$10$s65tVIvyvLun3QlZa3Q0YOmoovsmaRHXNrGSVLjrA/rtbhnL35i82', 1, 1),
(14, 'amin', 'amin@gmail.com', '$2y$10$exL/oO6iw8LvjNKBMKeOMOS1gpvqEIRIB29rOAMo4AbguxgrtCqVO', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `manufacture`
--
ALTER TABLE `manufacture`
  ADD PRIMARY KEY (`manufacture_id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `user_tbl`
--
ALTER TABLE `user_tbl`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `manufacture`
--
ALTER TABLE `manufacture`
  MODIFY `manufacture_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `user_tbl`
--
ALTER TABLE `user_tbl`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
