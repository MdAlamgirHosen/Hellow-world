
<div class="container">
  <!-- Modal https://wiki.selfhtml.org/local/Europahymne.mp3 and https://www.youtube.com/embed/Et0Vbv-i2Vk -- >
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Sermons Audio: </h4>
        </div>
        <div class="modal-body">
          <div class="mediPlayer text-center">
             <button class="soundBt" name="<?php echo get_post_meta(get_the_ID($post->ID),'Audiosong', true); ?>">Play</button>
         </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
   <!-- Modal -->
  <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Sermons Video: </h4>
        </div>
        <div class="modal-body">
          <div class="video_control"><iframe width="560" height="315" src="<?php echo get_post_meta(get_the_ID($post->ID),'videourl', true); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="upcomming_sermons_area"> 
  <div class="container">
   <div class="sermons_header">
      <h2>LATEST SERMON</h2>
      <h4>Experience God's Presence</h4>
   </div>
   <?php 
          $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

          $args = array(
              'post_type'=>'Sermons', // Your post type name
              'posts_per_page' => 3,
              'paged' => $paged,
          );

          $loop = new WP_Query( $args );
          if ( $loop->have_posts() ) {
              while ( $loop->have_posts() ) : $loop->the_post();
                 
             ?>

             <div class="row add bg">
            <div class="col-md-2">
              <div class="Sermons_twopart_img">
                  <div class="Sermons_images changesss">
                  <a href="<?php echo get_page_link( get_page_by_path( 'sermons_blog' ) ); ?>"><?php echo get_the_post_thumbnail( $post_id, 'full' ); ?></a>
                  </div>
              </div>
             </div>
            <div class="col-md-7 some">
            <div class="Sermons_twopart_title">
                <h4><?php echo get_the_title(); ?></h4>
                <p class="content"><?php echo get_the_content(); ?></p>
                 <p class="time"><?php the_time('l, F jS, Y') ?></p>
            </div>
           </div>
            <div class="col-md-3">
              <div class="Sermons_twopart">
                  <ul class="social_icon"> 
                      <li><button type="button" data-toggle="modal" data-target="#myModal"><i class="fa fa-music"></i></button></li>
                      <li><button type="button" data-toggle="modal" data-target="#myModal1"><i class="fa fa-film"></i></button></li>
                      <li><a href="<?php echo get_post_meta(get_the_ID($post->ID),'readmoreurl', true); ?>"><i class="fa fa-book"></i></a></li>
                  </ul>
                  <div class="View_button sermons">
                       <a href="<?php echo get_page_link( get_page_by_path( 'sermons_blog' ) ); ?>">View Now</a>
                  </div>
              </div>
           </div>
        </div>
            <?php 
              endwhile;
              ?><div class="paginatione"><?php 
              $total_pages = $loop->max_num_pages;
              ?></div><?php  
          }
          wp_reset_postdata();
          ?>
  </div>
</div>


<script>
var x = document.getElementById("myAudio"); 

function playAudio() { 
  x.play(); 
} 




function pauseAudio() { 
  x.pause(); 
} 

</script>

