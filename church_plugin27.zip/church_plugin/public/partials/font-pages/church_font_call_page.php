<div id="carousel-example-generic" class="carousel slide carousel-fade"   data-ride="carousel">
            <!-- Wrapper for slides -->
          <div class="carousel-inner">
            <!-- Indicators -->
            <ol class="carousel-indicators">
              <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
              <li data-target="#carousel-example-generic" data-slide-to="1"></li>
              <li data-target="#carousel-example-generic" data-slide-to="2"></li>
            </ol>
             <!-- for carousel all item show -->
             <?php 
              $ektaveriable = new WP_Query(array(
                'post_type' => 'custom_post_type',
                'category_name' => 'slider',
                'posts_per_page' => 3
              ));
              ?>
              <?php $veriable2 = 0; while($ektaveriable->have_posts()) : $ektaveriable->the_post(); $veriable2++ ?>
                              
              <?php if($veriable2 == 1) : ?>
               <div class="item active">
              <?php else : ?>
               <div class="item">
              <?php endif; ?>
              <div class="single_slide_item ">
                 <div class="slider_text">
                    <h2><?php echo get_the_title(); ?></h2>
                    <p><?php echo get_the_content(); ?></p>
                    <a href="<?php echo get_post_meta(get_the_ID($post->ID),'sliderreadmoreurl', true); ?>"> <?php echo get_post_meta(get_the_ID($post->ID),'readmore', true); ?></a>
                  </div>
                  <?php echo get_the_post_thumbnail( $post_id, 'full' ); ?>
              </div>
              </div>
              <?php endwhile;?>
           
          </div>
         <!-- Controls -->
          <a class="left carousel-control changeicon" href="#carousel-example-generic" role="button" data-slide="prev">
         <i class="fa fa-angle-left"></i>
          </a>
          <a class="right carousel-control changeicon" href="#carousel-example-generic" role="button" data-slide="next">
          <i class="fa fa-angle-right"></i>
          </a>
      </div>
      
