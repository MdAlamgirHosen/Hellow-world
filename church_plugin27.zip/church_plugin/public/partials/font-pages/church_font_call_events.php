<div class="container">
<div class="upcomming_Events_area"> 
   <div class="events_header">
      <h2>UPCOMING EVENTS</h2>
   </div>
   <?php 
      $ektaveriable = new WP_Query(array(
        'post_type' => 'events',
        'posts_per_page' => -1
      ));
      ?>
      <?php if(have_posts()):while($ektaveriable->have_posts()) : $ektaveriable->the_post(); ?>
        <div class="row add">
            <div class="col-md-3">
              <div class="events_twopart_img">
                  <div class="events_images">
                  <?php echo get_the_post_thumbnail( $post_id, 'full' ); ?>
                  </div>
              </div>
             </div>
            <div class="col-md-5">
            <div class="events_twopart_title">
                <h4><?php echo get_the_title(); ?></h4>
                <p class="time">Present Date: <?php the_time('l, F jS, Y') ?> <br/>Event Date: <?php echo get_post_meta(get_the_ID($post->ID),'ev_date', true); ?></p>
                <p class="address"><?php echo get_post_meta(get_the_ID($post->ID),'ev_address', true); ?></p>
            </div>
           </div>
            <div class="col-md-4">
              <div class="events_twopart">
                  <div class="col-md-6">
                     <div class="date_add">
                        <p><span class="tarikh"><?php echo get_post_meta(get_the_ID($post->ID),'ev_datenum', true); ?></span><br/><span class="month"><?php echo get_post_meta(get_the_ID($post->ID),'ev_month', true); ?></span></p>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="View_button">
                       <a href="<?php echo get_permalink()?>">View Now</a>
                     </div>
                  </div>
              </div>
           </div>
        </div>
      <?php endwhile; endif; ?>
  </div>
</div>