<?php 

/*
Template Name: Sermons Page
*/

get_header(); 

echo do_shortcode("[sermonspage]");
echo do_shortcode("[sermonspageblog]");
get_footer();


?>
