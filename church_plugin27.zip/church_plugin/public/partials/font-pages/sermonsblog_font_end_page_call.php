<?php 

/*
Template Name: Sermons blog Page
*/

get_header(); 

echo do_shortcode("[sermonspageblog]");

get_footer(); 


 ?>
