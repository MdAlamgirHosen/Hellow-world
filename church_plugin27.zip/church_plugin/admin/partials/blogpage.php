<?php wp_enqueue_media(); ?>

<div class="container">
	<div class="row"> 
	    <div class="panel panel-primary">
		  <div class="panel-heading">Panel Heading</div>
		  <div class="panel-body">
			<form class="form-horizontal" action="javascritp:void(0)" id="frmadmin">
			  <div class="form-group">
				<label class="control-label col-sm-2" for="name">Name:</label>
				<div class="col-sm-10">
				  <input type="text" class="form-control" name="textname" required id="name" placeholder="Enter Your Name">
				</div>
			  </div>
			  
			  <div class="form-group">
				<label class="control-label col-sm-2" for="textemail">Email:</label>
				<div class="col-sm-10">
				  <input type="email" class="form-control" name="textemail" required id="email" placeholder="Enter email">
				</div>
			  </div>
			  
			  <div class="form-group">
				<label class="control-label col-sm-2" for="about">Abouts:</label>
				<div class="col-sm-10">
				  <textarea class="form-control" name="about" id="about">Enter Your About </textarea>
				</div>
			  </div>
			  
			  
			  <div class="form-group">
				<label class="control-label col-sm-2" for="Image">Upload Image:</label>
				<div class="col-sm-10">
				  <button type="button" class="btn btn-info" required id="upload-image">Upload Image</button><br/>
				  <span><img src="" id="getImage" width="200px" height="200px" /></span>
				  <input type="hidden" id="getImage_id" name="image_url" />
				</div>
			  </div>
			  <div class="form-group"> 
				<div class="col-sm-offset-2 col-sm-10">
				  <button type="submit" class="btn btn-default">Submit</button>
				</div>
			  </div>
			</form>
		  </div>
		</div>
	</div>
</div>