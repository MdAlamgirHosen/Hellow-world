<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       www.example.com
 * @since      1.0.0
 *
 * @package    church_plugin
 * @subpackage church_plugin/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    church_plugin
 * @subpackage church_plugin/includes
 * @author     Md Alamgir <designeralamgirhosen037@gmail.com>
 */
class church_plugin {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      church_plugin_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		if ( defined( 'PLUGIN_NAME_VERSION' ) ) {
			$this->version = PLUGIN_NAME_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'church_plugin';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - church_plugin_Loader. Orchestrates the hooks of the plugin.
	 * - church_plugin_i18n. Defines internationalization functionality.
	 * - church_plugin_Admin. Defines all hooks for the admin area.
	 * - church_plugin_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-church_plugin-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-church_plugin-i18n.php';
		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-church_plugin-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-church_plugin-public.php';
		
		$this->loader = new church_plugin_Loader();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the church_plugin_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new church_plugin_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new church_plugin_Admin( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
		
		//define admin menu and submenu link page setting 
		$this->loader->add_action( 'admin_menu', $plugin_admin, 'church_plugin_admin_menu' );
		
		//define custom post
		$this->loader->add_action( 'init', $plugin_admin, 'custom_post_type_generate' );
		$this->loader->add_action( 'init', $plugin_admin, 'wpt_testimonials_post_type' );
		$this->loader->add_action( 'init', $plugin_admin, 'wpt_Gallery_post_type' );
		$this->loader->add_action( 'init', $plugin_admin, 'wpt_event_post_type' );
		$this->loader->add_action( 'init', $plugin_admin, 'wpt_Sermons_post_type' );
		$this->loader->add_action( 'init', $plugin_admin, 'wpt_Staff_post_type' );
		
		
		//define meta box 
		$this->loader->add_action( 'add_meta_boxes_custom_post_type', $plugin_admin, 'custom_juncker_metaboxes' );
		$this->loader->add_action( 'add_meta_boxes_sermons', $plugin_admin, 'custom_Sermons_metaboxes' );
		$this->loader->add_action( 'add_meta_boxes_events', $plugin_admin, 'custom_events_metaboxes' );
		$this->loader->add_action( 'add_meta_boxes_staff', $plugin_admin, 'custom_staff_metaboxes' );
		$this->loader->add_action( 'add_meta_boxes', $plugin_admin, 'page_sermons_metaboxes' );
		$this->loader->add_action( 'save_post', $plugin_admin, 'wpdocs_save_meta_box' );
		$this->loader->add_action( 'save_post', $plugin_admin, 'staff_save_meta_box',10,2);


		//define admin post method 
		$this->loader->add_action( 'wp_ajax_church_plugin', $plugin_admin, 'church_plugin_admin_handle' );

	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new church_plugin_Public( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );
	
		//custom page resistation code
		$this->loader->add_filter( 'page_template', $plugin_public, 'font_end_page_for_sermonsblog' );
		$this->loader->add_filter( 'page_template', $plugin_public, 'font_end_page_for_methodcreate' );

		//shortcode resistation create
		$this->loader->add_action( 'init', $plugin_public, 'register_shortcodes' );
		add_shortcode("sermonspageblog",array($plugin_public, "sermonsblogpage_font_page_call"));
		add_shortcode("sermonspage",array($plugin_public, "sermons_font_page_call"));

	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    church_plugin_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}
