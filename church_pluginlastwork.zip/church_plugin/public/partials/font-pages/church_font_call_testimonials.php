<div class="testimonials">
   <div class="testimonials_header">
      <h2>TESTIMONIAL</h2>
      <h4>Experience God's Presence</h4>
   </div>

<div id="carousel-example-testimonilas" class="carousel slide carousel-fade"   data-ride="carousel">
            <!-- Wrapper for slides -->
          <div class="carousel-inner">
            <!-- Indicators -->
            <ol class="carousel-indicators">
              <li data-target="#carousel-example-testimonilas" data-slide-to="0" class="active"></li>
              <li data-target="#carousel-example-testimonilas" data-slide-to="1"></li>
              <li data-target="#carousel-example-testimonilas" data-slide-to="2"></li>
            </ol>
             <!-- for carousel all item show -->
             <?php 
              $ektaveriable = new WP_Query(array(
                'post_type' => 'Testimonials',
                'posts_per_page' => 3
              ));
              ?>
              <?php $veriable2 = 0; if(have_posts()):while($ektaveriable->have_posts()) : $ektaveriable->the_post(); $veriable2++ ?>
              
              <?php if($veriable2 == 1) : ?>
               <div class="item active">
              <?php else : ?>
               <div class="item">
              <?php endif; ?>
              <div class="single_slide_item somechange">
                  <p><?php echo get_the_content(); ?></p>
                  <div class="images">
                  <?php echo get_the_post_thumbnail( $post_id, 'full' ); ?>
                  </div>
                    <h4><?php echo get_the_title(); ?></h4>
              </div>
              </div>
              <?php endwhile; endif; ?>
           
          </div>
      </div>
</div>