<div class="Staff_area">
   <div class="container">
       <div class="Staff_header">
          <h2>OUR STAFF</h2>
          <h4>The churches must learn humility as well as teach it</h4>
       </div>

        <div id="carousel-example-Staff" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner somechange text-center" role="listbox">
          <!-- Wrapper for slides -->
          <div class="item active">
             <!--/.single slide-->
             <div class="wta_main_item">
               <div class="row">

                <?php $catquery = new WP_Query(array(
                'post_type' => 'Staff',
                'category_name' => 'volunteer',
                'posts_per_page' => 4
              )); ?>
          
                 <?php while($catquery->have_posts()) : $catquery->the_post(); ?>
                  <div class="col-md-3">
                   
                   <div class="single_slide_item">
                      <div class="images img_change">
                         <?php echo get_the_post_thumbnail( $post_id, 'full' ); ?>
                      </div>
                      <h4><?php echo get_the_title(); ?></h4>
                      <p><?php echo get_post_meta(get_the_ID($post->display_name),'author_aaa', true); ?>
                      </p>
                      <ul class="Staff_socila">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                      </ul>
                  </div>
                  </div>
              
                  <?php endwhile; ?> 
                <?php wp_reset_postdata(); ?>
              </div>
             </div>
            </div><!---/.End single slide-->
          <div class="item">
            <!--/.single slide-->
                <div class="wta_main_item">
                 <div class="row">

                <?php $catquery = new WP_Query(array(
                'post_type' => 'Staff',
                'category_name' => 'pastor',
                'posts_per_page' => 4
              )); ?>
          
                 <?php while($catquery->have_posts()) : $catquery->the_post(); ?>
                  <div class="col-md-3">
                   
                   <div class="single_slide_item">
                      <div class="images img_change">
                      <?php echo get_the_post_thumbnail( $post_id, 'full' ); ?>
                      </div>
                      <h4><?php echo get_the_title(); ?></h4>
                      <p><?php echo get_post_meta(get_the_ID($post->display_name),'author_aaa', true); ?></p>
                      <ul class="Staff_socila">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                      </ul>
                  </div>
                  </div>
              
                  <?php endwhile; ?> 
                <?php wp_reset_postdata(); ?>
              </div>
            </div><!---/.End single slide-->
          </div>
          <div class="item">
            <!--/.single slide-->
               <div class="wta_main_item">
                <div class="row">

                  <?php $catquery = new WP_Query(array(
                  'post_type' => 'Staff',
                  'category_name' => 'volunteer',
                  'posts_per_page' => 4
                   )); ?>
            
                   <?php while($catquery->have_posts()) : $catquery->the_post(); ?>
                    <div class="col-md-3">
                     
                     <div class="single_slide_item">
                        <div class="images img_change">
                        <?php echo get_the_post_thumbnail( $post_id, 'full' ); ?>
                        </div>
                        <h4><?php echo get_the_title(); ?></h4>
                        <p><?php echo get_post_meta(get_the_ID($post->display_name),'author_aaa', true); ?></p>
                        <ul class="Staff_socila">
                          <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                          <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                          <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                          <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                        </ul>
                    </div>
                    </div>
                
                    <?php endwhile; ?> 
                  <?php wp_reset_postdata(); ?>
                </div>
            </div><!---/.End single slide-->
          </div>
          <div class="item">
            <!--/.single slide-->
               <div class="wta_main_item">
                  <div class="row">

                    <?php $catquery = new WP_Query(array(
                    'post_type' => 'Staff',
                    'category_name' => 'pastor',
                    'posts_per_page' => 4
                  )); ?>
              
                     <?php while($catquery->have_posts()) : $catquery->the_post(); ?>
                      <div class="col-md-3">
                       
                       <div class="single_slide_item">
                          <div class="images img_change">
                          <?php echo get_the_post_thumbnail( $post_id, 'full' ); ?>
                          </div>
                          <h4><?php echo get_the_title(); ?></h4>
                          <p><?php echo get_post_meta(get_the_ID($post->display_name),'author_aaa', true); ?></p>
                          <ul class="Staff_socila">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                          </ul>
                      </div>
                      </div>
                  
                      <?php endwhile; ?> 
                    <?php wp_reset_postdata(); ?>
                  </div>
               </div><!---/.End single slide-->
          </div>
            <!-- Controls -->
            <a class="left change carousel-control" href="#carousel-example-Staff" role="button" data-slide="prev">
            <i class="fa fa-chevron-left" aria-hidden="true"></i>
            </a>
            <a class="right change carousel-control" href="#carousel-example-Staff" role="button" data-slide="next">
            <i class="fa fa-chevron-right" aria-hidden="true"></i>
            </a>

          </div>
        </div>

   </div>     
</div>
