<?php 

/*
Template Name: Sermons blog Page
*/

get_header(); 

 ?>

<div class="container">
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Sermons Audio: </h4>
        </div>
        <div class="modal-body">
          <div class="mediPlayer text-center">
             <button class="soundBt" name="https://wiki.selfhtml.org/local/Europahymne.mp3">Play</button>
         </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
   <!-- Modal -->
  <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Sermons Video: </h4>
        </div>
        <div class="modal-body">
          <div class="video_control"><iframe width="560" height="315" src="https://www.youtube.com/embed/Et0Vbv-i2Vk" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
var x = document.getElementById("myAudio"); 

function playAudio() { 
  x.play(); 
} 

function pauseAudio() { 
  x.pause(); 
} 

</script>
<section class="sermons_area_top_banner" style="background: url(http://localhost/church-plugin/wp-content/uploads/2018/12/sermonsbanner.jpg); background-size: cover;">
	<div class="container">
		<div class="row">
		    <div class="col-md-12">
	     		<div class="sermons_blog">
	     			<h4>Sermons Blog Page</h4>
						<?php if(have_posts()):while(have_posts()):the_post(); ?>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								  <div class="menu_left">
									   <h2><?php the_title(); ?></h2>
								  </div>
							</div>
					   <?php endwhile; endif; ?>
			    </div>
            </div>		
        </div>
    </div>
 </section> 	

<section class="sermons_area">
	<div class="container">
		<div class="row">
		
		    <div class="col-md-12">
	     		<div class="sermons_header_main">
	     			<div class="content_post">
						
						<?php if(have_posts()):while(have_posts()):the_post(); ?>
								
								<div class="post-inner group">
									
									 <div class="col-sm-6 col-md-8">
							              <div class="Sermons_twopart sermons">
							              	  <div class="sermons_text img">
							              	  	<p class="image_thum"><?php echo get_the_post_thumbnail( $post_id, 'full' ); ?> 
							              	  	<img src="http://localhost/church-plugin/wp-content/uploads/2018/12/1508461889.jpg">
							              	    </p>
							              	  	<h4><?php echo get_the_title(); ?></h4>
							              	  	 <p class="author"><span class="pastor">Pastor: </span><span class="auth"><?php echo get_the_author(); ?></span> </p>
							              	  	 <p class="content"><?php echo get_the_content();?></p>
							              	  	 <ul class="social_icon blog"> 
							                      <li><button type="button" data-toggle="modal" data-target="#myModal1"><i class="fa fa-film"></i></button></li>
							                      <li><button type="button" data-toggle="modal" data-target="#myModal"><i class="fa fa-music"></i></button></li>
							                      <li><a href="<?php echo get_post_meta(get_the_ID($post->ID),'readmoreurl', true); ?>"><i class="fa fa-book"></i></a></li>
							                      <li><a href="<?php echo get_post_meta(get_the_ID($post->ID),'readmoreurl', true); ?>"><i class="fa fa-download"></i></a></li>
							                  </ul>
							              	  </div>

							              	   <div class="social_share"> 
							              	  	 <div class="ayoshare"><div class="facebook button"><a onclick="ayo_share_og('#');" title="Facebook"><i class="icon"><i class="fa fa-facebook"></i></i><div class="counter"><p>0</p></div></a></div><div class="linkedin button"><a onclick="ayo_share_og('#', 'linkedin');" title="Linkedin"><i class="icon"><i class="fa fa-linkedin"></i></i><div class="counter"><p>0</p></div></a></div><div class="pinterest button"><a onclick="ayo_share_og('#');" title="Pinterest"><i class="icon"><i class="fa fa-pinterest"></i></i><div class="counter"><p>0</p></div></a></div><div class="google button"><a onclick="ayo_share_og('#');" title="Google+"><i class="mobile"><i class="fa fa-google-plus"></i></i></a></div><div class="twitter button"><a onclick="ayo_share_og('#');" title="Twitter"><i class="mobile"><i class="fa fa-twitter"></i></i></a></div></div>
							              	  </div>
							                  
							              </div>
							           </div>

							           <div class="col-sm-12 col-md-4">
							              <div class="Sermons_twopart sermonssidebar">
							              	 <?php echo get_sidebar(); ?>
							              </div>
							           </div>
									
								</div><!--/.post-inner-->			
						<?php endwhile; endif; ?>
					</div>

				</div>
         	</div>		
      </div>
    </div>
 </section> 

 
 
<?php
get_footer(); 


 ?>
