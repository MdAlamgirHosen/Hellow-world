<?php

/**
 * Fired during plugin activation
 *
 * @link       www.example.com
 * @since      1.0.0
 *
 * @package    church_plugin
 * @subpackage church_plugin/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    church_plugin
 * @subpackage church_plugin/includes
 * @author     Md Alamgir <designeralamgirhosen037@gmail.com>
 */
class church_plugin_Activator {

	private $tables;
	public function __construct($tables_object){
	   $this->tables = $tables_object;
	}
	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public function activate() {
	
		 require_once(ABSPATH . 'wp-admin/includes/upgrade.php'); 
		 global $wpdb;
		 if(count($wpdb->get_var("show tables like '".$this->tables->churchplugintable()."'")) == 0){
			$sql = 'CREATE TABLE `'.$this->tables->churchplugintable().'` (
				 `id` int(11) NOT NULL AUTO_INCREMENT,
				 `name` varchar(255) DEFAULT NULL,
				 `about` text,
				 `email` varchar(255) DEFAULT NULL,
				 `Image` text,
				 PRIMARY KEY (`id`)
				) ENGINE=InnoDB DEFAULT CHARSET=utf8';
			
		  dbDelta($sql);	
		 }


		 $this->church_create_page();
		 $this->create_role();
		 $this->create_role_volunteer();
	}

	/*
	 //ei khane thaklew hoy better way te construct declar kore korte hobe.
	
	 public function churchplugintable(){
	  global $wpdb;
	  return $wpdb->prefix."church_plugin_table";
	}
	
	*/

  	public function create_role() {
	    add_role( 'Pastor', 'Pastor', array(
	        'read' => true, // True allows that capability
	        'edit_posts' => true, // Allows user to edit their own posts
	        'publish_posts'=>true, //Allows the user to publish, otherwise posts stays in draft mode
	        'edit_published_posts'=>true,
	        'upload_files'=>true,
	        'delete_published_posts'=>true,
	    ));
	}
	public function create_role_volunteer() {
	    add_role( 'volunteer', 'volunteer', array(
	        'read' => true, // True allows that capability
	        'edit_posts' => true, // Allows user to edit their own posts
	        'publish_posts'=>true, //Allows the user to publish, otherwise posts stays in draft mode
	        'edit_published_posts'=>true,
	        'upload_files'=>true,
	        'delete_published_posts'=>true,
	    ));
	}


    public function church_create_page(){
    global $wpdb;
   	   $wbpost = $wpdb->get_row(
       $wpdb->prepare(
       "SELECT * from".$wpdb->prefix."posts WHERE post_name=%s","sermons-page"
       ),ARRAY_A
    );
    if(empty($wbpost)){
    		$page = array();
		   	$page['post_title'] = "sermons page";
		   	$page['post_content'] = "Lorem Ipsume dolor sit Lorem Ipsume dolor sit Lorem Ipsume dolor sit Lorem Ipsume dolor sit Lorem Ipsume dolor sit Lorem Ipsume dolor sit";
		   	$page['post_status'] = "publish";
		   	$page['post_name'] = "sermons-page";
		   	$page['post_type'] = "page";

		   	$post_id = wp_insert_post($page);
		   	add_option("church_page", $post_id);

    }else{
    	echo "rong page";
    }
   
   }


	
}
