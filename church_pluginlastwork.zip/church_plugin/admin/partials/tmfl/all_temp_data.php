 <?php 
global $wpdb;
$alldata = $wpdb->get_results(
   $wpdb->prepare("SELECT * from ".$this->tables->churchplugintable()." order by id desc",""),ARRAY_A   
);
if(count($alldata) > 0){
 $i = 1;
 foreach($alldata as $index => $data){
	?>
	<tr>
	<td><?php echo $i++; ?></td>
	<td><?php echo $data['name'] ?></td>
	<td><?php echo $data['email'] ?></td>
	<td><?php echo $data['about'] ?></td>
	<td><img src="<?php echo $data['Image'] ?>" height="100px" width="100px" alt="" /></td>
	
	<td><a href="javascript:void(0)" class="btn btn-info">Edit | </a>
		<a href="javascript:void(0)" class="btn btn-danger Delete_data" data-id="<?php echo $data['id']; ?>">Delete</a>
	</td>
	</tr>
<?php
 }

}else{
  echo "play list not found";
}


//global $wpdb;
//$usersdetails = $wpdb->get_results(
  // $wpdb->prepare("SELECT * from ".$wpdb->prefix."users order by id desc",""),ARRAY_A
//);

//$usersdetails = $wpdb->get_row(
 //  $wpdb->prepare("SELECT * from ".$wpdb->prefix."users WHERE id=%d",2)
//);

//$usersdetails = $wpdb->get_var(
//   $wpdb->prepare("SELECT user_email from ".$wpdb->prefix."users WHERE id=%d",2)
//);

//echo "<pre>";
//print_r($usersdetails);


?>

