<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 */

?>

<!DOCTYPE html>
<html class="no-js" <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo('charset'); ?>"> 
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

            <!--Google Fonts -->
			<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">

             <!--Bootstrap Link -->
            <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
            <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
            <!--Css link for localhost-->
            <link href="<?php echo get_template_directory_uri(); ?>/css/owl.carousel.css" rel="stylesheet">
            <link href="<?php echo get_template_directory_uri(); ?>/style.css" rel="stylesheet">
            <link href="<?php echo get_template_directory_uri(); ?>/css/responsive.css" rel="stylesheet">

        
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
		<?php wp_head(); ?>
    </head>
    <body <?php body_class(); ?>>
        <!--/.Application Start-->
        <header id="header_hero_area" >
		  <div class="slider_ovarlay">
		    <div class="container">
		     	<div class="row">
		     		<div class="col-sm-4 col-md-4 col-lg-4">
						<div class="header_logo"> 
						   <img src="<?php header_image(); ?>" alt="" />
						</div> 
                         <div class="header_text_area">
						    <h4>Over <img src="<?php echo esc_url(get_template_directory_uri()); ?>/img/line.png" alt="" /></h4>
							<h1>$100 million<br/> recovered</h1>
							<p>We have successfully concluded over 1,000<br/>
							cases in the past 10 years and success rate <br/>is close to 99% for cases we handle</p>
							<a class="header_a" href="#">Request Free Consultation</a>
						 </div>	
						 <div class="video_area"> 
						   <div class="row">
						   	<div class="col-sm-4 col-md-4 col-lg-4"> 
							   <div class="video_one"> 
							      <!-- <video height="auto" controls="controls" preload="none" onclick="this.play()">
							      	<source type="video/mp4" src="video/a.mp4">
									</video> -->
								  <div class="video_img">
									  <img src="<?php echo get_template_directory_uri(); ?>/img/pic11.jpg" alt="" class="img-circle" />
									  <div class="img_icon"> 
										 <a href="#"><i class="fa fa-play" aria-hidden="true"></i></a>
									  </div>
								  </div>
									<p class="p_down">Firm Overview</p>
							   </div>
							</div>
						   	<div class="col-sm-4 col-md-4 col-lg-4">
							    <div class="video_one"> 
							      <!-- <video height="auto" controls="controls" preload="none" onclick="this.play()">
							      	<source type="video/mp4" src="video/a.mp4">
									</video> -->
								  <div class="video_img">
									  <img src="<?php echo get_template_directory_uri(); ?>/img/pic11.jpg" alt="" class="img-circle" />
									  <div class="img_icon"> 
										 <a href="#"><i class="fa fa-play" aria-hidden="true"></i></a>
									  </div>
								  </div>	
								  <p class="p_down">Personal Injury</p>
							   </div>
							</div>
						   	<div class="col-sm-4 col-md-4 col-lg-4">
							     <div class="video_one"> 
							      <!-- <video height="auto" controls="controls" preload="none" onclick="this.play()">
							      	<source type="video/mp4" src="video/a.mp4">
									</video> -->
								  <div class="video_img">
									  <img src="<?php echo esc_url(get_template_directory_uri()); ?>/img/pic11.jpg" alt="" class="img-circle" />
									  <div class="img_icon"> 
										 <a href="#"><i class="fa fa-play" aria-hidden="true"></i></a>
									  </div>
								  </div>
								 <div class="video_text"> 
									<p class="p_down">Cases We Handle</p>
								 </div>
							   </div>
							</div><!--End of col-4-->
						   </div>
						 </div>
					</div>
					<div class="col-sm-6 col-md-offset-2 col-md-6 col-md-offset-2 col-lg-6 col-lg-offset-2">
					  <div class="img"> 
					    
					  </div>
					</div>
		     	</div>
		     </div>
		  </div>
         <div class="slider">
		  <!-- star slides -->
		 <div id="carousel-example-generic" class="carousel slide carousel-fade"   data-ride="carousel">
			<!-- Wrapper for slides -->
			<div class="carousel-inner">
			    <?php 
					$ektaveriable = new WP_Query(array(
					  'post_type' => 'my_slider',
					  'post_per_page' => 3
					));
				  ?>
				  <?php $veriable2 = 0; while($ektaveriable->have_posts()) : $ektaveriable->the_post(); $veriable2++ ?>
				  
				  <?php if($veriable2 == 1) : ?>
				   <div class="item active">
				  <?php else : ?>
				   <div class="item">
				  <?php endif; ?>
					<div class="single_slide_item ">
					  <?php the_post_thumbnail(); ?>
					</div>
				  </div>
				  <?php endwhile;?>
			
			</div>
		 </div><!-- End slides -->
		</div>		  
	    </header><!--End of Header Area-->  
		
		  <section id="main_menu_area">
		    <div class="container">
		     	<div class="row">
		     		<div class="col-sm-12 col-md-12 col-lg-12">
						<div class="header_navbar_area">
							<nav class="navbar navbar-default">
							  <div class="container-fluid">
								<!-- Brand and toggle get grouped for better mobile display -->
								<div class="navbar-header">
								  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								  </button>
								  </div>

								<!-- Collect the nav links, forms, and other content for toggling -->
								<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
								   <?php
										 wp_nav_menu( array(
										'menu' => 'Primary Menu',
										'theme_location' => '__no_such_location',
									 'menu_class' => 'nav navbar-nav',
									 'menu_id' => 'menu',
									 'container' => 'ul',
									 'container_class' => 'collapse navbar-collapse'

									) );
									?>
								</div><!-- /.navbar-collapse -->
							  </div><!-- /.container-fluid -->
							</nav>
						</div>  
					</div>
		     	</div>
		     </div>
	    </section><!--End of mainmenu Area--> 