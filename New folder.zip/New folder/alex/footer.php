<?php
/**
 * The template for displaying the footer
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *1. Please find attached photos for the web. Please use pic #8548 and 8591. 
2. Header -> Moving images -> 3 portion
3. Contact form -> http://awebsiteforlawyers.com/sample27/index.html
4. Add twitter
5. Important Links: home, about, practices areas,

attorneys and resources., Disclaimer, Attorney Advertising, Privacy Policy
6. Logo -> Attorney & Counselor At Law
7. Service Header -> See What We Can Do for You.
 * @package WordPress
 */

?>
 <footer id="footer_area">
		    <div class="footer_top">
			   <div class="container">
			   	<div class="row"> 
				   <div class="col-sm-4 col-md-4 col-lg-4">
						<div class="foote_menu_left"> 
						 <h2>Ours partnars</h2>
						  <img src="img/logo.png" alt="" />
						  <img src="img/logo.png" alt="" />
						</div>
					</div>

					<div class="col-sm-4 col-md-4 col-lg-4">
						<div class="foote_menu_left"> 
						 <h2>Contact Us</h2>
						   <label for="">Phone</label><br/>
						   <a href="tel:205.970.0800">205.970.0800</a><br/><br/>
						   
						   <label for="">Fax</label><br/>
						   <a href="tel:205.970.8809">205.970.8809</a>
						</div>
						<div class="foote_menu_left"> 
						 <h2>Visist Us</h2>
						  <p>2 Perimeter Park South #510E<br/>Birmingham,AL 35242</p>
						  
						  <a class="btn_footer" href="#">Get Directions</a>
						</div>
					</div> 
					
					<div class="col-sm-4 col-md-4 col-lg-4">
						<div class="foote_menu_left"> 
						 <h2>Follow Us</h2>
						   <ul class="footer_menu pull-left">
							 <li><a href="#">google+</a></li>
							 <li><a href="#">facebook</a></li>
							 <li><a href="#">linkedin</a></li>
							 <li><a href="#">linkedin</a></li>
						   </ul>
						   
						   <ul class="footer_menu pull-right">
							 <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							 <li><a href="#"><i class="fa fa-facebook"></i></a></li>
							 <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
							 <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
						   </ul>
						</div>
					</div>
					
			   </div>
			</div>
			</div>
			<div class="footer_down"> 
			     <div class="container">
			   	<div class="row"> 
				   <div class="col-sm-12 col-md-12 col-lg-12">
						<div class="foote_copyright text-center"> 
						   <p>© 2017 Webtady.com - All Rights Reserved.</p>
						</div>
					</div>
			   </div>
			</div>
			</div>
		 </footer><!--End of footer area-->

        <!--/.End Application-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="<?php echo get_template_directory_uri(); ?>/js/owl.carousel.min.js"></script>
        <script src="<?php echo get_template_directory_uri(); ?>/js/plugins.js"></script>
        <script src="<?php echo get_template_directory_uri(); ?>/js/main.js"></script>
		<script>
		var videoPlayer = document.getElementById('videoPlayer');

		// Auto play, half volume.
		videoPlayer.play()
		videoPlayer.volume = 0.5;

		// Play / pause.
		videoPlayer.addEventListener('click', function () {
			if (videoPlayer.paused == false) {
				videoPlayer.pause();
				videoPlayer.firstChild.nodeValue = 'Play';
			} else {
				videoPlayer.play();
				videoPlayer.firstChild.nodeValue = 'Pause';
			}
		});
		</script>
		
		  <script>
			$(document).ready(function () {
			 $('.nav li').click(function(e) {

			$('.nav li').removeClass('active');

			var $this = $(this);
			if (!$this.hasClass('active')) {
				$this.addClass('active');
			}
			//e.preventDefault();
		});
	});
		</script>
		<?php wp_footer(); ?>
    </body>
</html>

