<?php
/**
 * The template Name: contact page
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

	<section id="free_qoute"> 
		   <div class="container">
		   	<div class="row">
		   		<div class="col-lg-12"> 
				   <div class="title text-center"> 
				     <h2>Contact Us</h2>
				     <p>The Drake Law Firm is ready to help you protect your rights against insurance companies and parties responsible for compensating you for your injuries. Our staff will take care of everything, so you can concentrate on recovering your health and getting your life back together after a serious injury or loss of a loved one.</p>
				  </div>
				</div>
			 </div>
		   </div>
		</section>
		<section id="contact_from_area"> 
		    <div class="container">
		    	<div class="row">
				    <div class="col-sm-12 col-md-12 col-lg-12"> 
					   <div class="contact_img"> 
					     <img src="img/contact.png" alt="" />
					   </div>
					</div>
					<div class="row">
						<div class="style_col col-sm-8 col-md-8 col-lg-8"> 
						   <div class="contact_form">
							  <form action="/action_page.php">
								<label for="fname">Name</label>
								<input type="text" id="fname" name="firstname" >

								<label for="lname">E-mail</label>
								<input type="email" id="lname" name="lastname" >

								<label for="lname">Phone Number</label>
								<input type="text" id="lname" name="lastname" >

								<label for="lname">Company Name</label>
								<input type="text" id="lname" name="lastname" >

								<label for="country">How Can We Help you?</label>
								<select id="country" name="country">
								  <option value="australia">No slection</option>
								  <option value="canada">Sales & Rates</option>
								  <option value="usa">Customar Support</option>
								  <option value="usa">Jobs & Careers</option>
								  <option value="usa">Public Relations</option>
								  <option value="usa">Other</option>
								</select>
								
								<label for="country">Which Best Describes Your Current Role? * </label>
								<select id="country" name="country">
								  <option value="australia">No slection</option>
								  <option value="canada">SEO & Owner</option>
								  <option value="usa">DJ & Radio host</option>
								  <option value="usa">Marketing</option>
								  <option value="usa">Publicist/PR</option>
								  <option value="usa">President</option>
								  <option value="usa">Vice President</option>
								  <option value="usa">Other</option>
								</select>

								<label for="subject">Additional Comments</label>
								<textarea id="subject" name="subject"  style="height:200px"></textarea>

								<input type="submit" value="Submit">
							  </form>
							</div>
						</div>
						<div class="col-sm-4 col-md-4 col-lg-4 askdkfja"> 
				  <div class="img_art"> 
				    <div class="col-sm-6 col-md-6 col-lg-6"> 
					   <img class="img_change" src="<?php echo get_template_directory_uri(); ?>/img/pic1.jpg" alt="" />
					</div>
					
					<div class="col-sm-6 col-md-6 col-lg-6"> 
					   <div class="adress"> 
					  <p>Cheryl Fletcher, <br/><br/>Attorney Phone: 561 507-5772<br/><br/> Fax: 561 721-6468<br/><br/> cf@lawyerfletcher.com </p>
					</div>
					</div>
				  </div>
				  
				  <div class="contact_area"> 
					 <form class="form_area">
						<div class="form-group12">
						   <h3>fast case review</h3>
						  <input type="text" class="form-control" placeholder="First name">
						  <input type="text" class="form-control" placeholder="Last name">
						  <input type="email" class="form-control" placeholder="E-mail Address">
						  <button type="submit" class="form-cont">Sing up!</button>
						</div>
					  </form>
				  </div>
				  
				</div>
				  </div>
		    	</div>
		    </div>
		 </section>
		
		<section id="Free_area_gellary"> 
		   <div class="container">
		   	 <div class="row"> 
				   <div class="col-sm-2 col-md-2 col-lg-2">
						<div class="foote_menu_Img"> 
						   <img src="<?php echo get_template_directory_uri(); ?>/img/brand5.png" alt="" />
						</div>
					</div>
					
					<div class="col-sm-2 col-md-2 col-lg-2">
						<div class="foote_menu_Img"> 
						   <img src="<?php echo get_template_directory_uri(); ?>/img/brand5.png" alt="" />
						</div>
					</div>
					
					<div class="col-sm-2 col-md-2 col-lg-2">
						<div class="foote_menu_Img"> 
						   <img src="<?php echo get_template_directory_uri(); ?>/img/brand5.png" alt="" />
						</div>
					</div>
					
					<div class="col-sm-2 col-md-2 col-lg-2">
						<div class="foote_menu_Img"> 
						   <img src="<?php echo get_template_directory_uri(); ?>/img/brand5.png" alt="" />
						</div>
					</div>
					
					<div class="col-sm-2 col-md-2 col-lg-2">
						<div class="foote_menu_Img"> 
						   <img src="<?php echo get_template_directory_uri(); ?>/img/brand5.png" alt="" />
						</div>
					</div>
<div class="col-sm-2 col-md-2 col-lg-2">
						<div class="foote_menu_Img"> 
						   <img src="<?php echo get_template_directory_uri(); ?>/img/brand5.png" alt="" />
						</div>
					</div>
                </div>
		   </div>
		</section>
		
		<section id="Free_area_two"> 
		   <div class="container">
		   	 <div class="row"> 
				   <div class="col-sm-12 col-md-12 col-lg-12">
						<div class="foote_menu_left1"> 
						   <p>"Most of our clients come to us by referral from satisfied clients and other
legal professionals. We even have clients referred to us by insurance lawyers
who opposed us in court. We think that says a lot about our commitment to
integrity and maintaining an open line of communication with our clients
throughout the case." </p>
						  
						  <h4>— Whit Drake</h4>
						</div>
					</div>
                </div>
		   </div>
		</section>
<?php get_footer(); ?>
