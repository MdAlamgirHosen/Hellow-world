<?php
/**
 * The template Name: paractice page
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

	<section id="free_qoute"> 
		   <div class="container">
		   	<div class="row">
		   		<div class="col-lg-12"> 
				   <div class="title text-center"> 
				   <h2>Practce page</h2>
				  </div>
				</div>
		   	</div>
		   </div>
		</section>
		<section id="Free_area"> 
		   <div class="container">
		   	 <div class="row">
				<div class="style_col col-sm-8 col-md-8 col-lg-8"> 
				  <h2 style="color:#4F6273; margin-bottom:30px;">Cheryl Fletcher, Attorney</h2>
				<p style="color:#fff;"class="asdf">
				  <img style="margin:15px;" src="<?php echo get_template_directory_uri();?>/img/pic1.jpg" alt="" class="img-thumbnail pull-left"/>DEMO</div>
				
				<div class="col-sm-4 col-md-4 col-lg-4 askdkfja"> 
				  <div class="img_art"> 
				    <div class="col-sm-6 col-md-6 col-lg-6"> 
					   <img class="img_change" src="<?php echo get_template_directory_uri(); ?>/img/pic1.jpg" alt="" />
					</div>
					
					<div class="col-sm-6 col-md-6 col-lg-6"> 
					   <div class="adress"> 
					  <p>Cheryl Fletcher, <br/><br/>Attorney Phone: 561 507-5772<br/><br/> Fax: 561 721-6468<br/><br/> cf@lawyerfletcher.com </p>
					</div>
					</div>
				  </div>
				  
				  <div class="contact_area"> 
					 <form class="form_area">
						<div class="form-group12">
						   <h3>fast case review</h3>
						  <input type="text" class="form-control" placeholder="First name">
						  <input type="text" class="form-control" placeholder="Last name">
						  <input type="email" class="form-control" placeholder="E-mail Address">
						  <button type="submit" class="form-cont">Sing up!</button>
						</div>
					  </form>
				  </div>
				  
				</div>
		   	</div>
		   </div>
		</section>
<?php get_footer(); ?>
