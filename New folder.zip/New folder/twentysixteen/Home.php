<?php
/**
 * The template Name: Home page
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

	<section id="Learn_mission_area">
		  <div class="container">
		  	<div class="row">
		  		<div class="col-sm-12 col-md-12 col-lg-12">
		  			<div class="learn_title text-center"> 
					   <h2>Learn What We Can Do For You</h2>
					</div>
		  		</div><!--./End of 1st col area--> 
				<div class="row"> 
				    <div class="col-sm-3 col-md-3 col-lg-3"> 
					   <div class="learn_one"> 
					      <img src="<?php echo get_template_directory_uri(); ?>/img/pic1.jpg" alt="" />
						  <div class="img_text_overlay"> 
						     <h3>Vehicle Accidents</h3>
						   </div>
					   </div>
					</div>
				    <div class="col-sm-3 col-md-3 col-lg-3">
					  <div class="learn_one"> 
					      <img src="<?php echo get_template_directory_uri(); ?>/img/pic1.jpg" alt="" />
						  <div class="img_text_overlay"> 
						     <h3>Vehicle Accidents</h3>
						   </div>
					   </div>
					</div>
				    <div class="col-sm-3 col-md-3 col-lg-3">
					   <div class="learn_one"> 
					      <img src="<?php echo get_template_directory_uri(); ?>/img/pic1.jpg" alt="" />
						  <div class="img_text_overlay"> 
						     <h3>Vehicle Accidents</h3>
						   </div>
					   </div>
					 </div>
				    <div class="col-sm-3 col-md-3 col-lg-3">
					   <div class="learn_one"> 
					      <img src="<?php echo get_template_directory_uri(); ?>/img/pic1.jpg" alt="" />
						  <div class="img_text_overlay"> 
						     <h3>Vehicle Accidents</h3>
						   </div>
					   </div>
					</div>
				</div><!--/.End of 1st row-->
				
				<div class="row"> 
				    <div class="col-sm-3 col-md-3 col-lg-3"> 
					   <div class="learn_one"> 
					      <img src="<?php echo get_template_directory_uri(); ?>/img/pic1.jpg" alt="" />
						  <div class="img_text_overlay"> 
						     <h3>Vehicle Accidents</h3>
						   </div>
					   </div>
					</div>
				    <div class="col-sm-3 col-md-3 col-lg-3">
					  <div class="learn_one"> 
					      <img src="<?php echo get_template_directory_uri(); ?>/img/pic1.jpg" alt="" />
						  <div class="img_text_overlay"> 
						     <h3>Vehicle Accidents</h3>
						   </div>
					   </div>
					</div>
				    <div class="col-sm-3 col-md-3 col-lg-3">
					   <div class="learn_one"> 
					      <img src="<?php echo get_template_directory_uri(); ?>/img/pic1.jpg" alt="" />
						  <div class="img_text_overlay"> 
						     <h3>Vehicle Accidents</h3>
						   </div>
					   </div>
					 </div>
				    <div class="col-sm-3 col-md-3 col-lg-3">
					   <div class="learn_one"> 
					      <img src="<?php echo get_template_directory_uri(); ?>/img/pic1.jpg" alt="" />
						  <div class="img_text_overlay"> 
						     <h3>Vehicle Accidents</h3>
						   </div>
					   </div>
					</div>
				</div><!--/.End of 2nd row-->
		  	</div>
		  </div>
		</section><!--/.End of mission Area--> 

		<section id="lawyer_area"> 
		    <div class="container">
		    	<div class="row">
		    		<div class="col-sm-7 col-md-7 col-lg-7"> 
					   <div class="lawyer_text"> 
					      <h2>Lawyer<br/>Marketing</h2>
						  <h3>Take The Challenge</h3>
						   <p>Phasellus diam sapien, fermentum a eleifend non, luctus non augue.Quisque scelerisque purus quis eros sollicitudin gravida.Aliquam erat volutpat.Donec a sem consequat tortor posuere dignissim sit amet at ipsum,</p>
						   <a href="#">Read More</a>
					   </div>
					</div>
					<div class="col-sm-5 col-md-5 col-lg-5"> 
					   <div class="lawyer_img text-center"> 
					      <img src="<?php echo get_template_directory_uri(); ?>/img/pic1.jpg" alt="" class="img-responsive" />
					   </div>
					</div>
		    	</div>
		    </div>
		 </section><!--/.End of lawyer Area--> 
		 
		 <section id="Verdicts_area"> 
		    <div class="container">
		    	<div class="row">
		    		<div class="col-sm-6 col-md-6 col-lg-6"> 
					   <div class="Verdicts_text"> 
					      <div class="Verdicts_one_text">
							  <h2>Verdicts & settlements</h2>
							   <p class="capital"><span>$15M</span><span class="btn_color">Verdict in wrongful death auto accident in clanton,Alabama</p>
							   <p>Family was strucki head-on by drunk driver.One death and multiple, serious injuries by passengesrs.</p>
						  </div>

						  <div class="Verdicts_one_text">
							   <p class="capital"><span>$3.0M</span><span class="btn_color">Verdict in wrongful death auto accident in clanton,Alabama</p>
							   <p>Family was strucki head-on by drunk driver.One death and multiple, serious injuries by passengesrs.</span></p>
						  </div> 
						  
						  <div class="Verdicts_one_text">
							   <p class="capital"><span>$2.2M</span><span class="btn_color">Verdict in wrongful death auto accident in clanton,Alabama</span></p>
							   <p>Family was strucki head-on by drunk driver.One death and multiple, serious injuries by passengesrs.</p>
						  </div> 
						  
						   <div class="quotes_btn"> 
						      <a href="#">veiw our case results</a>
						   </div>
					   </div>
					</div>
					<div class="col-sm-6 col-md-6 col-lg-6"> 
					   <div class="Verdicts_text1 "> 
					     <div class="one_text_title text-center">
					        <p>see the testimonials</p>
						    <h3>that our clients have submitted so far</h3>
						  </div>
						  
						   <div style="margin-bottom:70px;" class="row"> 
						     <div class="col-sm-4 col-md-4 col-lg-4">
							    <div class="img"> 
								   <img src="<?php echo get_template_directory_uri(); ?>/img/pic1.jpg" class="img-circle" alt="" />
								</div>
							 </div>

							 <div class="col-sm-8 col-md-8 col-lg-8">
							    <div class="text"> 
								   <i class="fa fa-quote-left" aria-hidden="true"></i>
                                    <p>Fletcher law office, PA is firmly committed to prociding exceptional representation for clients with immigration and family law issues.</p>
									<h4>-Devid honse</h4>
								</div>
							 </div>
						   </div>
						   
						   <div class="row"> 
						     <div class="col-sm-4 col-md-4 col-lg-4">
							    <div class="img"> 
								   <img src="<?php echo get_template_directory_uri(); ?>/img/pic1.jpg" class="img-circle"  alt="" />
								</div>
							 </div>

							 <div class="col-sm-8 col-md-8 col-lg-8">
							    <div class="text"> 
								   <i class="fa fa-quote-left" aria-hidden="true"></i>
                                    <p>Fletcher law office, PA is firmly committed to prociding exceptional representation for clients with immigration and family law issues.</p>
									<h4>-Devid honse</h4>
								</div>
							 </div>
						   </div>
						  
						  <div class="quotes_btn1"> 
						      <a href="#">Read More</a>
						   </div>
					   </div>
					</div>
		    	</div>
		    </div>
		 </section>
		<section id="Art_area"> 
		   <div class="container">
		   	 <div class="row">
		   		<div class="col-sm-2 col-md-2 col-lg-2"> 
				  <div class="img_art1"> 
				     <img src="<?php echo get_template_directory_uri(); ?>/img/1234.png" alt="" />
				  </div>
				</div>
				
				<div class="col-sm-10 col-md-10 col-lg-10"> 
				  <div class="art_text11"> 
				     <p>Keep up to date on legal issues affection the Arts, with our monthly newsletter,Art+law</p>
		
				    <form class="form_area">
						<div class="form-group1">
						  <input type="email" class="" placeholder="E-mail Address">
						  <button type="submit" class="">Sing me up!</button>
						</div>
					 </form>
				  </div>
				</div>
		   	</div>
		   </div>
		</section>
<?php get_footer(); ?>
