<?php
/**
 * The template Name: attony page
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

	<section id="free_qoute"> 
		   <div class="container">
		   	<div class="row">
		   		<div class="col-lg-12"> 
				   <div class="title text-center"> 
				   <h2>Attorneys</h2>
				  </div>
				</div>
		   	</div>
		   </div>
		</section>
		<section id="Free_area"> 
		   <div class="container">
		   	 <div class="row">
				<div class="style_col col-sm-8 col-md-8 col-lg-8"> 
				  <h2 style="color:#4F6273; margin-bottom:30px;">Cheryl Fletcher, Attorney</h2>
				<p style="color:#fff;"class="asdf">
				  <img style="margin:15px;" src="<?php echo get_template_directory_uri();?>/img/pic1.jpg" alt="" class="img-thumbnail pull-left"/>I am Cheryl Fletcher, and I started my law firm to serve people and protect their rights. When faced with a legal issue, many people feel overwhelmed because they do not fully understand their rights and how to protect them. I provide a clear head, exceptional research skills, and complete preparedness to help you through these difficult times.<br/><br/>

I believe that people want a better life for themselves and it is my job, as your attorney, to uncover your legal rights and create a strategy to help you pursue these rights.<br/><br/>

I am highly competitive, a true warrior, and I enjoy going to battle. I have a natural fighter instinct within me. I will spend the time, refining the best legal strategy for each of my clients.
<br/><br/>
I started my career as a legal researcher at one of the largest universities in Florida. I understand that prospective clients will not care much about my old job. Understandably, you only care about what I know, what my clients think about me, and the results that I get.
<br/><br/>
But the lawyers on the other side will look me up online. They will want to know whether I am a formidable opponent. I can assure you that I am. The many years that I spent doing legal research gives me an upper hand, in fighting for your legal rights. I know how to look for every possible right that you have, how to argue for those rights, and put you in the best possible position to secure a favorable outcome for your case.
<br/><br/>
I have also worked in different law firms, writing legal briefs, drafting motions, affidavits and legal memorandums, creating case plans, conducting depositions, and representing people before the courts.
<br/><br/>
My passion for promoting, justice, fairness, and civil rights comes from my background. I was born and raised in a family of seven people—my two parents, two brothers and two sisters. Although our parents worked hard, we didn’t have much. However, I didn’t sit back and complain about what little resources we had. Instead, I worked hard in school and kept my grades up. Because of the many years that I spent studying, my hardwork and dedication, I was able to beat the odds, and become an attorney.
<br/><br/>
Being an attorney is a position of privilege that gives me the right to fight for people, especially those who cannot fight for themselves. I have the honor of bringing the people’s voice to the courts, and for that I am truly grateful.
<br/><br/>
But, I am not merely a bleeding heart. This is how I make a living and the bottom line is, I am in the business of suing others, to protect your legal rights. I charge a reasonable fee for my services. I believe each of my clients deserve legal representation of the highest quality.
<br/><br/>
I hope that we can work together.

If you are dealing with any of these legal issues, call 561-507-5772, Email: cf@lawyerfletcher.com, or contact us via or contact form.</p>
				</div>
				
				<div class="col-sm-4 col-md-4 col-lg-4 askdkfja"> 
				  <div class="img_art"> 
				    <div class="col-sm-6 col-md-6 col-lg-6"> 
					   <img class="img_change" src="<?php echo get_template_directory_uri(); ?>/img/pic1.jpg" alt="" />
					</div>
					
					<div class="col-sm-6 col-md-6 col-lg-6"> 
					   <div class="adress"> 
					  <p>Cheryl Fletcher, <br/><br/>Attorney Phone: 561 507-5772<br/><br/> Fax: 561 721-6468<br/><br/> cf@lawyerfletcher.com </p>
					</div>
					</div>
				  </div>
				  
				  <div class="contact_area"> 
					 <form class="form_area">
						<div class="form-group12">
						   <h3>fast case review</h3>
						  <input type="text" class="form-control" placeholder="First name">
						  <input type="text" class="form-control" placeholder="Last name">
						  <input type="email" class="form-control" placeholder="E-mail Address">
						  <button type="submit" class="form-cont">Sing up!</button>
						</div>
					  </form>
				  </div>
				  
				</div>
		   	</div>
		   </div>
		</section>
<?php get_footer(); ?>
