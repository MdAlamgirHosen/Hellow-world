<?php 

/*
Template Name: Home Page
*/

get_header(); 
?>

	
<?php while ( have_posts() ): the_post(); ?>
		

					<?php the_content(); ?>

			<?php if ( ot_get_option('page-comments') == 'on' ) { comments_template('/comments.php',true); } ?>
			
<?php endwhile; ?>
		
		

<div class="wta_main wta_bac_color"  style="">

	<div class="wta_center">
			<div class="wta_glob">
			
				<section class="wta_glob wta_header_top">
				    <div class="wta_glob header_one">
				      <img src="<?php echo get_template_directory_uri();?>/images/c1.PNG" class="">
				    </div>
					
					<div class="wta_glob header_two">
				      <img src="<?php echo get_template_directory_uri();?>/images/c2.PNG" class="">
				    </div>
					
					<div class="wta_glob header_three">
				      <img src="<?php echo get_template_directory_uri();?>/images/c3.PNG" class="">
				    </div>
				</section>
				
		</div>
	</div>
	<div class="wta_center header_main_overlay">
		<div class="wta_glob">
			
			<section class="wta_glob wta_header_down">
				<div class="wta_glob wta_header_right_content">
				    <h2>Make chores fun<br/><span>by engaging and rewarding</span></h2>
				    <h3>your kids!</h3>
				</div>
			</section>
				
		</div>
	</div>
	
</div>

<div class="wta_main wta_bac_color1" style="">
   <div class="wta_main wta_bac_color_overlay">
      <img src="<?php echo get_template_directory_uri();?>/images/bac_top.PNG" class="">
   </div>
	<div class="wta_center">
		<div class="wta_glob">
			
				<section class="wta_glob wta_chores_area">
				    <div class="wta_glob wta_chores_left">
					   <div class="wta_glob wta_chores_video">
					    <h2>Your kids will beg to do their chores.</h2>
						<p>With ChoreMonster, it's possible. No chore charts required. ChoreMonster is a suite of web and mobile apps that make chores fun for kids.</p>
			          </div>
					  
					  <div class="wta_glob wta_chores_video">
						<div class='embed-container'><iframe src='https://player.vimeo.com/video/39190143' frameborder='0' webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe></div>
                        <p><a href="https://vimeo.com/142874198">A Guide To Happy</a> from <a href="https://vimeo.com/panoply">Panoply</a> on <a href="https://vimeo.com">Vimeo</a>.</p>
						<h3>Already a member? <button type="button">Parents Login</button> <button type="button">Kid's Login</button></h3>
						 
			          </div> 
				    </div> 
					
					<div class="wta_glob wta_chores_right">
					   <h2>Sign Up For Free!</h2>
				      <img src="<?php echo get_template_directory_uri();?>/images/f1.PNG" class="">
				    </div>
					
				</section>
				
		</div>
	</div>
</div>


<div class="wta_main wta_bac_color2" style="">
   <div class="wta_main wta_bac_color_overlay1">
      <img src="<?php echo get_template_directory_uri();?>/images/bac2.PNG" class="">
   </div>
	<div class="wta_center">
		<div class="wta_glob">
			
				<section class="wta_glob wta_work_area">
				    <div class="wta_glob wta_work_title">
					    <h1>How does it work?</h1>
			         </div>
					  
					  <div class="wta_glob wta_work_two">
					    <div class="wta_glob wta_work_left">
					      <h2>For Parents</h2>
						  <ul class="wta_menu_item">
						  	<li>    Quickly and easily create scheduled chores with point values. When your child says they're done, you approve and they get the points. </li>
							
							<li>Add rewards that your kids “purchase” from their point collection. A reward can be anything from money to a camping trip.</li>
							<li>Watch your kids willingly and enthusiastically do their chores, without the need of chore charts.</li>
						  </ul>
				        </div>  
						
						<div class="wta_glob wta_work_right">
					      <h2>For Kids</h2>
						  <ul class="wta_menu_item">
						  	<li>    Quickly and easily create scheduled chores with point values. When your child says they're done, you approve and they get the points. </li>
							
							<li>Add rewards that your kids “purchase” from their point collection. A reward can be anything from money to a camping trip.</li>
							<li>Watch your kids willingly and enthusiastically do their chores, without the need of chore charts.</li>
						  </ul>
				        </div>
			          </div> 
				</section>
				
		</div>
	</div>
</div>



<div class="wta_main wta_bac_color3" style="">
   <div class="wta_main wta_bac_color_overlay2">
      <img src="<?php echo get_template_directory_uri();?>/images/bac3.PNG" class="">
   </div>
	<div class="wta_center">
		<div class="wta_glob">
			
				<section class="wta_glob wta_testimonial_area">
				    <div class="wta_glob wta_testimonial_title">
					    <img src="<?php echo get_template_directory_uri();?>/images/b1.PNG" class="">
			         </div>
				</section>
				
				<section class="wta_glob wta_testimonial_area">
				   <div class="wta_glob wta_testimonial_title">
				     <h3>But don't just take our word for it.<br/><span>(here's what our users say about their favorite chore app)</span></h3>
				   </div>
				    <div class="wta_glob wta_testimonial_left">
						<img src="<?php echo get_template_directory_uri();?>/images/logo1.PNG" class="">
					</div>
						<div class="wta_glob wta_testimonial_right">
							<div id="carousel-example-generic1" class="carousel slide"   data-ride="carousel" data-interval="1500">
								  <!-- Wrapper for slides -->
								<div class="carousel-inner">
									<div class="item active">
									  <div class="single_item ">
										 <p>Lorem ipsum dolor sit amet, ut quodsi appareat recteque nec. Pri facer summo delicatissimi no. Te mel integre fierent, sea putent percipitur scriptorem ad, no purto postea sententiae usu. In eam errem dolor quaerendum.</p>
										  <a class="pull-left" href="#">Client Name</a>
									  </div>
									</div>
									<div class="item">
									  <div class="single_item ">
										 <p>Lorem ipsum dolor sit amet, ut quodsi appareat recteque nec. Pri facer summo delicatissimi no. Te mel integre fierent, sea putent percipitur scriptorem ad, no purto postea sententiae usu. In eam errem dolor quaerendum.</p>
										  <a class="pull-left" href="#">Demo</a>
									  </div>
									</div>
									<div class="item">
									   <div class="single_item ">
										 <p>Lorem ipsum dolor sit amet, ut quodsi appareat recteque nec. Pri facer summo delicatissimi no. Te mel integre fierent, sea putent percipitur scriptorem ad, no purto postea sententiae usu. In eam errem dolor quaerendum.</p>
										  <a class="pull-left" href="#">Demo</a>
									  </div>
								</div>
							</div>
							  <!-- Indicators -->
								<ol class="carousel-indicators wta_glob_inte">
									<li data-target="#carousel-example-generic1" data-slide-to="0" class="active"></li>
									<li data-target="#carousel-example-generic1" data-slide-to="1"></li>
									<li data-target="#carousel-example-generic1" data-slide-to="2"></li>
								</ol>
						</div>		
					</div><!--End slider_area-->
				</section>
				
		</div>
	</div>
</div>

<div class="wta_main wta_bac_color4" style="">
   <div class="wta_main wta_bac_color_overlay4">
      <img src="<?php echo get_template_directory_uri();?>/images/bac1.PNG" class="">
   </div>
	<div class="wta_center">
		<div class="wta_glob">
			
				<section class="wta_glob wta_work_area">
				   <div class="wta_glob wta_testimonial_title1">
				     <h3>Don’t believe it?<br/><span>Try us out and see.</span></h3>
					  <a href="#">Sign Up Now</a>
				   </div>
					<div class="wta_glob wta_work_other">
					   <h3>Press coverage:</h3>
					   <a href="#"><img src="<?php echo get_template_directory_uri();?>/images/bg.PNG" class=""></a>
			       </div> 
				</section>
				
		</div>
	</div>
</div>

<div class="wta_main wta_bac_color5" style="">
   <div class="wta_main wta_bac_color_overlay5">
      <img src="<?php echo get_template_directory_uri();?>/images/bac4.PNG" class="">
   </div>
	<div class="wta_center">
		<div class="wta_glob">
			
				<section class="wta_glob wta_Still_area">
					<div class="wta_glob wta_Still_top">
					   <div class="wta_glob wta_Still_title1">
						 <h3>Still have questions?</h3>
						 <p>Visit our <a href="#">Frequently Asked Questions</a> page, read <a href="#">Our Blog</a> or leave us your comments, concerns, or questions on our <a href="#">FreshDesk</a> page. </p>
					   </div>
						<div class="wta_glob wta_Still_other">
						   <ul>
							<li><a href="#"><i class="fa fa-wifi" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						   </ul>
					   </div> 
				  </div> 
				  
				  <div class="wta_glob wta_Still_down">
					    <a href="#"><img src="<?php echo get_template_directory_uri();?>/images/a.PNG" class=""></a>
					     <a href="#"><img src="<?php echo get_template_directory_uri();?>/images/g.PNG" class=""></a>
					     <a href="#"><img src="<?php echo get_template_directory_uri();?>/images/k.PNG" class=""></a>
				  </div> 
				   
				</section>
				
		</div>
	</div>
</div>

<?php get_footer(); ?>