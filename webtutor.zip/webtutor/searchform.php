<form method="get" class="owt" action="<?php echo home_url('/') ?>"> <!-- home_url/?s=data -->

    <label for="searchFor">Search For</label>
    <input type="text" class="form-control" name="s" placeholder="Enter search term here"/>
    <button type="submit">Search Now</button>

</form>