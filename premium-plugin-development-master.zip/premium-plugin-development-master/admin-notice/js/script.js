;(function($) {
    $(document).ready(function() {
       $('body').on('click','#sm-notice .notice-dismiss',function(){
            alert('hello');
       });
    
});
})(jQuery)