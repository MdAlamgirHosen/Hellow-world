const icon = <svg width="24" height="24" viewBox="0 0 148 148" fill="none" xmlns="http://www.w3.org/2000/svg">
	<path d="M37 37H12.3333V104.833H37V37Z" />
	<path d="M43.1667 117.167H104.833V24.6667H43.1667V117.167ZM55.5 37H92.5V104.833H55.5V37Z" />
	<path d="M135.667 37H111V104.833H135.667V37Z" />
</svg>;

export default icon;
