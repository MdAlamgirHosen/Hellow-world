export const GRADIENT_TYPE = [
  { label: "Linear", value: "linear" },
  { label: "Radial", value: "radial" }
];

export const RADIAL_TYPES = [
  { label: "Ellipse", value: "ellipse" },
  { label: "Circle", value: "circle" }
];
