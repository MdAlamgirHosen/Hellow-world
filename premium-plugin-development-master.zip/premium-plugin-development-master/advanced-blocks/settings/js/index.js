import App from './App';

ReactDOM.render( <App />, document.getElementById( 'advanced-blocks-settings' ) );
