const BlocksContext = React.createContext();

export default BlocksContext;
