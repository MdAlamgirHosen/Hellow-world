=== Advanced Blocks - WordPress Page Building Blocks ===

Contributors: B-07, advancedblocks
Plugin URI: https://wordpress.org/plugins/advanced-blocks
Tags: gutenberg, page builder, gutenberg blocks, wordpress blocks, blocks
Author URI: https://advanced-blocks.com/
Author: Advanced Blocks
Donate link: https://advanced-blocks.com/
Requires at least: 5.0
Tested up to: 5.5
Requires PHP: 5.6
Version: 1.0.0
License: GPL v2 or later

This plugin brings Advanced Blocks to the new WordPress Gutenberg editor.

== Description ==

## Make Beautiful Web Pages With Advanced Blocks

Avilable Blocks:

* Countdown
* Team Member
* Progress Bar
* Accourdion
* Pricing Table
* Call To Action
* Google Maps
* Paralax Section
* Number Box
* Post Grid
* Alerts
* Blockquote

== Installation ==

From your WordPress dashboard

1. **Visit** Plugins > Add New
2. **Search** for "Advanced Blocks"
3. **Install** the "Advanced  Blocks" plugin
4. **Activate** "Advanced Blocks" from your Plugins page
5. **Insert Block** on your Gutenberg Editor and select "Advanced Blocks"

== Frequently Asked Questions ==

== Screenshots ==


== Changelog ==


= 1.0.0 (21/05/2019) =
* Initial release

== Donations ==

If you like the plugin, consider a donation to support further development. [Click here](http://paypal.me/bdbappi)
