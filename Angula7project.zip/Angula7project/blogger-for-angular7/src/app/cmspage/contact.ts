export class Contact {
    id: number;
    name: string;
    email: string;
    phone?: string;
    message: string;
}
