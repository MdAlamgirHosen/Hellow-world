import { HTTP_INTERCEPTORS } from '@angular/common/http';

    import { AuthorInterceptor } from './author-interceptor';

    export const httpInterceptorProviders = [
        { provide: HTTP_INTERCEPTORS, useClass: AuthorInterceptor, multi: true }
    ];