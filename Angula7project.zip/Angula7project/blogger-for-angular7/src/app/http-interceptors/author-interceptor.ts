import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { AuthorService } from '../author/author.service';
import { Observable } from 'rxjs';

@Injectable()

export class AuthorInterceptor implements HttpInterceptor {

    constructor(private authorService: AuthorService) {}

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        if (this.authorService.isLoggedIn) {
            const authorToken = this.authorService.getAuthorizationToken();

            req = req.clone({
                setHeaders:
                    { Authorization: authorToken}
                }
            );
        }
        return next.handle(req);
    }
}