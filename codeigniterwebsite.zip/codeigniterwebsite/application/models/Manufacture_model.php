<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Manufacture_model extends CI_Model {
	
	public function select_all_publish_manufacture(){
		
		$result = $this->db->select('*')->from('manufacture')->where('manufacture_status', 1)->get()->result();
		return $result;
	}
}
