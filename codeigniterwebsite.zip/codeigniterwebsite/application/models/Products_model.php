<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products_model extends CI_Model {

	public function save_category_show(){
		
	  $data['cat_name'] = $this->input->post('cat_name', TRUE);
	  $data['cat_short_desc'] = $this->input->post('cat_sort_desc', TRUE);
	  $data['cat_desc'] = $this->input->post('cat_desc', TRUE);
	  $data['cat_status'] = 1;
	  
	 $this->db->insert('tbl_category', $data);
	}
	
	public function get_all_catdata(){
		$data = $this->db->select('*')->from('tbl_category')->get()->result();
		return $data;
	}
	
	
	public function change_category_status($cat_id, $status){
	
	   $data['cat_status'] = $status;
	   $this->db->where('cat_id', $cat_id);
	   $this->db->update('tbl_category', $data);
	   
	}
	
	public function edit_category_detais($category_id){
		$data = $this->db->select('*')->from('tbl_category')->where('cat_id', $category_id)->get()->row();
		return $data;
	}
	
	
	public function update_category(){
		$data = $this->input->post(NULL, TRUE);
		$cat_id = $data['cat_id'];
		unset($data['cat_id']);
		
		$this->db->where('cat_id', $cat_id);
	    $this->db->update('tbl_category', $data);
	}
	
	public function get_all_active_cat(){
		
		$result = $this->db->select('*')->from('tbl_category')->where('cat_status', 1)->get()->result();
		return $result;
	}
	
	//for product
	public function upload_product_img(){
		
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']     = '1000';
		$config['max_width'] = '1024';
		$config['max_height'] = '768';
		
		$this->load->library('upload', $config);
		
		if($this->upload->do_upload('product_img')){
			$data = $this->upload->data();
			$image_path = "uploads/$data[file_name]";
			return $image_path;
		}else{
			$error = $this->upload->display_errors();
	     	print_r($error);
		}
	}
	public function change_product_status($product_id, $status){
	
	   $data['product_satus'] = $status;
	   $this->db->where('product_id', $product_id);
	   $this->db->update('tbl_product', $data);
	   
	}
	
	public function edit_product_detais($product_id){
		$data = $this->db->select('*')->from('tbl_product')->where('product_id', $product_id)->get()->row();
		return $data;
	}
	public function update_product(){
		$data = $this->input->post(NULL, TRUE);
		$product_id = $data['product_id'];
		unset($data['product_id']);
		
		$this->db->where('product_id', $product_id);
	    $this->db->update('tbl_product', $data);
	}
	
	
	
	
	public function save_product(){
		
	 $product = $this->input->post(NULL, TRUE);
	 
	 $product['product_satus'] = 1;
	 
	 $product['product_img'] = $this->upload_product_img();
	 
	 $this->db->insert('tbl_product', $product);
	}
	
	public function select_all_product(){
		
		$data = $this->db->select('*')->from('tbl_product')->get()->result();
		
		return $data;
	}
	
	public function all_active_product(){
		$result = $this->db->select('*')
		                   ->from('tbl_product')
						   ->where('top_product',1)
						   ->where('product_satus',1)
						   ->get()
						   ->result();
		
		return $result;
	}
	
	// for manufacture
	public function save_manufacture_show(){
	  
	 $manufacture = $this->input->post(NULL, TRUE);
	 
	 $manufacture['manufacture_status'] = 1;
	 
	 $this->db->insert('manufacture', $manufacture);
	}
	
	public  function get_all_manufacturedata(){
		
		$result = $this->db->select('*')->from('manufacture')->where('manufacture_status',1)->get()->result();
		
		return $result;
	}
	public function change_manufacture_status($manufacture_id, $status){
	
	   $data['manufacture_status'] = $status;
	   $this->db->where('manufacture_id', $manufacture_id);
	   $this->db->update('manufacture', $data);
	   
	}
	
	public function edit_manufacture_detais($manufacture_id){
		$data = $this->db->select('*')->from('manufacture')->where('manufacture_id', $manufacture_id)->get()->row();
		return $data;
	}
	
	
	public function update_manufacture(){
		$data = $this->input->post(NULL, TRUE);
		$manufacture_id = $data['manufacture_id'];
		unset($data['manufacture_id']);
		
		$this->db->where('manufacture_id', $manufacture_id);
	    $this->db->update('manufacture', $data);
	}
	
	public function get_all_active_manufacture(){
		
		$result = $this->db->select('*')->from('manufacture')->where('manufacture_status', 1)->get()->result();
		return $result;
	}
	
	//for top slider product 
	public function select_all_slider(){
		
		$result = $this->db->select('*')->from('tbl_product')->where('top_product',1)->get()->result();
		
		return $result;
	}
	
}



?>