<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome_model extends CI_Model {

	public function all_active_product(){
		$result = $this->db->select('*')->from('tbl_product')->where('product_satus',1)->get()->result();
		
		return $result;
	}
	
	
}


?>