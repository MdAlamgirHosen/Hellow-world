<?php
defined('BASEPATH') OR exit('No direct script access allowed');


?>
<table class="table table-striped table-bordered bootstrap-datatable datatable">
		  <thead>
			  <tr>
				  <th>Categorys Id</th>
				  <th>Categorys Name</th>
				  <th>Status</th>
				  <th>Actions</th>
			  </tr>
		  </thead>   
		  <tbody>
		  <?php foreach($cat_variable as $cat){?>
		    <tr>
				<td><?php echo $cat->cat_id; ?></td>
				<td class="center"><?php echo $cat->cat_name; ?></td>
				
				<td class="center"> 
				
					  <?php if ($cat->cat_status == 1){
						echo 'active';  
					    }
					    elseif ($cat->cat_status == 2){
						 echo 'inactive'; 
					    }

						elseif ($cat->cat_status == 3){
						 echo 'Delete'; 
					    } 
					  ?> 
				</td>
				<td class="center">
				   
				   <?php if ($cat->cat_status == 1 || $cat->cat_status == 3){?> 
				    
					<a class="btn btn-success" title="status update" href="<?php echo base_url("change-category-status/$cat->cat_id/2"); ?>">
						<i class="halflings-icon white thumbs-up"></i>                                            
					</a>
		            <?php } elseif ($cat->cat_status == 2){?> 
				    
					<a class="btn btn-danger" title="status update" href="<?php echo base_url("change-category-status/$cat->cat_id/1"); ?>">
					<i class="halflings-icon white thumbs-down"></i>                                            
					</a>
				   <?php }?>
				   
					
					<a class="btn btn-info" href="<?php echo base_url("edit-category/$cat->cat_id"); ?>" title="Edit">
						<i class="halflings-icon white edit"></i>                                            
					</a>
					
					<?php if($cat->cat_status !=3){?>
					<a class="btn btn-danger" href="<?php echo base_url("change-category-status/$cat->cat_id/3"); ?>" title="Delete" >
						<i class="halflings-icon white trash"></i> 
						
					</a>
					<?php }?>
					
					
				</td>
			</tr>
			
		  <?php }?>
			</tr>
		  </tbody>
	  </table>    

   