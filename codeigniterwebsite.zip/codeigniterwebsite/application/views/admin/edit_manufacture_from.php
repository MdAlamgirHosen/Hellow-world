<div style="color:red;"> 
  <?php 
     //if(isset($successfully_message)){
	 //echo $successfully_message;
   //}
  ?>
</div>

<?php //echo validation_errors(); ?>

<div class="row-fluid sortable">
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon edit"></i><span class="break"></span>Form Elements</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<!--<form class="form-horizontal" action="" method="post">-->
						<?php echo form_open('products/update_manufacture','class=form-horizontal'); ?>
						  <fieldset>
							<div class="control-group">
							  <label class="control-label" for="typeahead">manufacture name :</label>
							  <div class="controls">
								<input type="text" value="<?php echo $manufacture_data->manufacture_name ?>" name="manufacture_name" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4" data-source='["Alabama","Alaska","Arizona","Arkansas","California","Colorado","Connecticut","Delaware","Florida","Georgia","Hawaii","Idaho","Illinois","Indiana","Iowa","Kansas","Kentucky","Louisiana","Maine","Maryland","Massachusetts","Michigan","Minnesota","Mississippi","Missouri","Montana","Nebraska","Nevada","New Hampshire","New Jersey","New Mexico","New York","North Dakota","North Carolina","Ohio","Oklahoma","Oregon","Pennsylvania","Rhode Island","South Carolina","South Dakota","Tennessee","Texas","Utah","Vermont","Virginia","Washington","West Virginia","Wisconsin","Wyoming"]' required >
								
								<input type="hidden" name="manufacture_id" value="<?php echo $manufacture_data->manufacture_id ?>" />
							  </div>
							</div>
							
							<div class="control-group">
							  <label class="control-label" for="typeahead">manufacture short Description </label>
							  <div class="controls">
							  
								<input type="text" value="<?php echo $manufacture_data->manufacture_sort_desc ?>" name="manufacture_sort_desc" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4" data-source='["Alabama","Alaska","Arizona","Arkansas","California","Colorado","Connecticut","Delaware","Florida","Georgia","Hawaii","Idaho","Illinois","Indiana","Iowa","Kansas","Kentucky","Louisiana","Maine","Maryland","Massachusetts","Michigan","Minnesota","Mississippi","Missouri","Montana","Nebraska","Nevada","New Hampshire","New Jersey","New Mexico","New York","North Dakota","North Carolina","Ohio","Oklahoma","Oregon","Pennsylvania","Rhode Island","South Carolina","South Dakota","Tennessee","Texas","Utah","Vermont","Virginia","Washington","West Virginia","Wisconsin","Wyoming"]' required >
								
							  </div>
							</div>
							
							
							<div class="control-group hidden-phone">
							  <label class="control-label" for="textarea2">manufacture Description</label>
							  <div class="controls">
								<textarea name="manufacture_desc" class="cleditor" id="textarea2" rows="3"><?php echo $manufacture_data->manufacture_desc ?></textarea>
							  </div>
							</div>
							
							
							<div class="form-actions">
							  <button type="submit" class="btn btn-primary">Save changes</button>
							  <button type="reset" class="btn">Cancel</button>
							</div>
						  </fieldset>
						  <?php form_close(); ?>
						<!--/form-->   

					</div>
				</div><!--/span-->

			</div><!--/row-->