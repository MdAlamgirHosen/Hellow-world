<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
    public function __construct(){
		parent::__construct();
		
		if(!isset($this->session->user_id) && ($this->session->user_status !=1)){
			redirect('admin');
		}
		
		$this->load->model('admin_model');
	}
	
	public function show_dashboard()
	{	
	 $data = array();
	 $data['main_content'] = '';
	 $this->load->view('admin/dashboard', $data);
	}
	
	public function resister_new_admin(){
     $data = array();
	 $data['main_content'] = $this->load->view('admin/resister_form','', true);
	 $this->load->view('admin/dashboard', $data);
	}
	
	public function user_resistation(){
		
		$this->form_validation->set_rules('user_name', 'User Name','required|max_length[255]');
		
		$this->form_validation->set_rules('user_email', 'User E-mail','required|max_length[255]|is_unique[user_tbl.user_email]');
		
		$this->form_validation->set_rules('user_password', 'User password','required|min_length[6]');
		
		$this->form_validation->set_rules('confirm_password', 'Confirm Password','required|min_length[6]|matches[user_password]');
		
		        if ($this->form_validation->run())
                {
                   $this->admin_model->resister_new_admin();
				    
					$data['successfully_message'] = 'Resister successfully';
				    $data['main_content'] = $this->load->view('admin/resister_form',$data, true);
	                $this->load->view('admin/dashboard', $data);
                }
                else
                {
                  $this->resister_new_admin();
                }
	}
	
}
