<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_login extends CI_Controller {

	
	  public function __construct(){
		parent::__construct();
		
		$this->load->model('admin_model');
	  }
	 
	public function index()
	{	
	 if(isset($this->session->user_id)){
		redirect('admin-dashboard'); 
	 }
	 else{
	 $this->load->view('admin/admin_login');
	 }
	}
	
	public function admin_login_cheek()
	{	
	 $user_email = $this->input->post('user_email', true);
	 $user_password = $this->input->post('user_password', true);
	// $encript_pass = md5($user_password);
	// $encript_pass = password_hash($user_password, PASSWORD_DEFAULT);
	//echo $encript_pass;
	// exit();
	 
	 $this->load->model('admin_model');
	 
	 $user_details = $this->admin_model->get_user_details($user_email);
	 
	// if($encript_pass == $user_details->user_pass){
		//	$this->load->view('admin/dashboard');
	//}
	// if(password_verify($user_password, $user_details->user_pass)){
	  //	$this->load->view('admin/dashboard');
	//}
	
	 if(password_verify($user_password, $user_details->user_pass)){
		
		if(($user_details->user_status == 1) && ($user_details->user_role == 1)){
		 $session_data['user_email'] = $user_details->user_email;
		 $session_data['user_role'] = $user_details->user_role;
		 $session_data['user_id'] = $user_details->user_id;
		 $session_data['user_status'] = $user_details->user_status;
		 $this->session->set_userdata($session_data);
		 
		 redirect('admin-dashboard');
		 
		}
		else{
			$data['error_message'] = 'Incorrect Email';
			$this->load->view('admin/admin_login', $data);
		}
	 }
	 else{
		//redirect('admin');
		$data['error_message'] = 'Incorrect Email or password';
		$this->load->view('admin/admin_login', $data);
	 }
	}
	
	public function admin_logout_cheek(){
		$this->session->sess_destroy();
		redirect('admin');
	}
	
	
	
	
}
