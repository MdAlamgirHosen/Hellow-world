<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {
	
    public function __construct(){
		parent::__construct();
		
		$this->load->model('products_model');
		
	}
	
	public function show_category(){
	    $data = array();
		$data['main_content'] = $this->load->view('admin/product_form',$data, true);
	    $this->load->view('admin/dashboard', $data);
	}
	
	public function save_category(){
		
		$this->products_model->save_category_show();
		
		$this->show_all_categorys();
	}
	
	public function show_all_categorys(){
		
		$cat['cat_variable'] = $this->products_model->get_all_catdata();
		
		$data['main_content'] = $this->load->view('admin/all_cat',$cat, TRUE);
		
		$this->load->view('admin/dashboard', $data);
	}
	
	
	public function change_category_status($cat_id, $status){
		
		$this->products_model->change_category_status($cat_id, $status);
		
		redirect('all-categorys');
	}
	
	
	public function edit_category($category_id){
		
		$data['category_data'] = $this->products_model->edit_category_detais($category_id);
		$data['main_content'] = $this->load->view('admin/edit_categorys_from', $data, TRUE);
		$this->load->view('admin/dashboard', $data);
	}
	
	public function update_category(){
		
		$this->products_model->update_category();
		redirect('all-categorys');
	}
	// for product
	public function add_products(){
		
		$data['cat_info'] = $this->products_model->get_all_active_cat();
		$data['main_content'] = $this->load->view('admin/add_product_form', $data, TRUE);
		$this->load->view('admin/dashboard', $data);
	}
	
	
	public function save_product(){
		
		$this->products_model->save_product();
		
		$this->session->set_userdata('message', 'product save successfully');
		
		$this->add_products();
		
	}
	
	
	public function manage_product(){
		$data = array();
		$data['all_product'] = $this->products_model->select_all_product();
		$data['main_content'] = $this->load->view('admin/manage_product_form', $data, TRUE);
		$this->load->view('admin/dashboard', $data);
	}
	
	public function change_product_status($product_id, $status){
		
		$this->products_model->change_product_status($product_id, $status);
		
		redirect('manage-product');
	}
	public function edit_product($product_id){
		
		$data['product_data'] = $this->products_model->edit_product_detais($product_id);
		$data['cat_info'] = $this->products_model->get_all_active_cat();
		$data['main_content'] = $this->load->view('admin/edit_product_from', $data, TRUE);
		$this->load->view('admin/dashboard', $data);
	}
	
	public function update_product(){
		
		$this->products_model->update_product();
		redirect('manage-product');
	}
	
	// for manufacture
	public function add_manufacture(){
		$data = array();
		$data['main_content'] = $this->load->view('admin/manufacture_form',$data, true);
	    $this->load->view('admin/dashboard', $data);
	}
	
	public function save_manufacture(){
		
		$this->products_model->save_manufacture_show();
		$this->show_all_manufacture();
		
	}
     
	public function show_all_manufacture(){
		
		$cat['all_manufacture_variable'] = $this->products_model->get_all_manufacturedata();
		
		$data['main_content'] = $this->load->view('admin/all_manufacture',$cat, TRUE);
		
		$this->load->view('admin/dashboard', $data);
	}
	
	public function change_manufacture_status($manufacture_id, $status){
		
		$this->products_model->change_manufacture_status($manufacture_id, $status);
		
		redirect('all-manufacture');
	}

	
	public function edit_manufacture_detais($manufacture_id){
		
		$data['manufacture_data'] = $this->products_model->edit_manufacture_detais($manufacture_id);
		$data['main_content'] = $this->load->view('admin/edit_manufacture_from', $data, TRUE);
		$this->load->view('admin/dashboard', $data);
	}
	public function update_manufacture(){
		
		$this->products_model->update_manufacture();
		redirect('all-manufacture');
	}
	 
}


?>