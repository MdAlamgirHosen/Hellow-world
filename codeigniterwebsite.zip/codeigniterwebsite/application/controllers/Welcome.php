<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		
		$this->load->model('welcome_model');
		
	}
	
	public function index()
	{	
		$data = array();
		$data['title'] = "Home";
		$data['all_active_data'] = $this->welcome_model->all_active_product(); 
		$data['slider'] = $this->load->view('pages/slider','$data', true);
		$data['features_items'] = $this->load->view('pages/feture_product', $data, true);
		$data['category_tab'] = $this->load->view('pages/category_tab','', true);
		$this->load->view('master', $data);
	}
	
	public function accounts()
	{	
		$data = array();
		$data['title'] = "Accounts";
		$data['slider'] = '';
		$data['features_items'] = "<h1> Account test </h1>";
		$data['category_tab'] = $this->load->view('pages/category_tab','', true);
		$this->load->view('master', $data);
	}
}
