<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wd_other');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'uui2NWYP^*.w[De-%L/Jqt&Pvj!m Bg|Ft?r]Bvb][fJ;q>q]ARh9I1?iSYbL39;');
define('SECURE_AUTH_KEY',  'HcY^8,9oHLqQpOp9|H/j*5nVCKgilg*?zw5B3S9yz:P:^s*Wlj+l7;ks-0D5,hje');
define('LOGGED_IN_KEY',    'R2EtnR6?sZ,Ebo5=.1$`Er849yVfg;`r3XU0mW2>:_LR3!%T3~%%[V<?~3-0 b~V');
define('NONCE_KEY',        'E<41QMu/A5A-[OGK%%sV1_G vfo`.TnJvDKOkW`stzX:j&h+(KK<^D:P8*uLi$eT');
define('AUTH_SALT',        'is.l&xvRc}g`yi)`Y}+bj4F{)4#c+}c/ajTgh2-*3goJ88}[4<_3S2T[&@jmR:N(');
define('SECURE_AUTH_SALT', 'R+j*kt7..l}>-Sz9lxv*u$$S&.J_Z2lsmcn3+B9.`Mg}z6RB]ATXSUi&r,W*x`aB');
define('LOGGED_IN_SALT',   'Qes7RRvC~;|L{Ebwa@7iYkgpe4i[A(Rv5%PdVtT1T;fYRWb{B{quVJU<Em-l2NdC');
define('NONCE_SALT',       '#j;]g)D@?%xCX`h16r<<>DoP>^^ksDCnc[0:+yV.k!Xg#Cj)!GM:ju(dKtd?Z@o9');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
