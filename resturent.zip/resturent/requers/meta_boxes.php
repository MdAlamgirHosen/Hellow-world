<?php 
function meta_boxes(){
	
	add_meta_box(  
	  'icon_meta',//ID
	  'My Icon Meta box',//Title
	  'icon_meta_callback',//Callback
	  'servic_type',//Screen
	  'normal',//context
	  'low'//prio
	);
	
}
add_action('add_meta_boxes','meta_boxes');

 function icon_meta_callback($post){
	 wp_nonce_field('icon_meta','icon_meta_nonce');
	 $icon = get_post_meta($post->ID,'ms_icon',true);
	 ?>
	 <label for="">Icon</label>
	 <input type="text" name="ms_icon" value="<?php echo $icon ?>" class="widefat" />
	 
	<?php 
 }

  function save_icon_meta($post_id){
	 //check if our nonce is set. 
	  if( ! isset( $_POST['icon_meta_nonce'])){
		  return;
	  } 
	  //Verify that the nonce is valid. 
	  if( ! wp_verify_nonce($_POST['icon_meta_nonce'],'icon_meta')){
		  return;
	  }
	  
	  //Make sure that it is set. 
	  if( ! isset( $_POST['ms_icon'])){
		  return;
	  }
	  //Sanitize user input sure. 
	  $my_icon = sanitize_text_field( $_POST['ms_icon']);
	  
	  //Update the meta field in the database. 
	  update_post_meta( $post_id, 'ms_icon',$my_icon);
	  
  }
 add_action('save_post','save_icon_meta');
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 