<?php 
 /*
 Template name: fornt page
 */
 get_header();
?>  
	<div class="about_us_area">
	   <div class="container">
	   	<div class="row">
			<?php query_posts(array(
			  'post_type'=>'servic_type',
			  'post_per_page'=>1
			)); ?>
			<?php if(have_posts()):while(have_posts()):the_post(); ?>
			    <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
					  <div class="about_img">
					   <?php the_post_thumbnail(); ?>
					 </div>
				   </div>
				<div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
				  <div class="about_text">
				   <i class="fa fa-4x <?php echo get_post_meta($post->ID,'ms_icon',true); ?>"></i>
					<h2><?php the_title(); ?></h2>
					<p><?php the_content(); ?></p>
				 </div>
			   </div>
		   <?php endwhile; endif; ?>
	   	 </div>
	   </div>
	</div><!-- End of about_img-->
	<div class="our_menu_area">
	   <div class="our_menu_area_overlay"></div>
	   <div class="container">
	    <div class="row">
			<?php query_posts(array(
				  'post_type'=>'special_type',
				  'post_per_page'=>1
				)); ?>
			<?php if(have_posts()):while(have_posts()):the_post(); ?>
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					  <div class="oue_top text-center">
						<h2><?php echo the_title(); ?></h2>
						<?php the_post_thumbnail(); ?>
					  </div>
				   </div>
		   <?php endwhile; endif; ?>
		</div><!--End of 1st row-->
		
		<div class="row">
			<?php query_posts(array(
				  'post_type'=>'submainmenu_type',
				  'post_per_page'=>1
				)); ?>
			<?php if(have_posts()):while(have_posts()):the_post(); ?>
				<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					  <div class="main_menu text-center">
						<?php
							wp_nav_menu(array(
							  'menu_class'=>"nav navbar-nav",
							  'container'=>false,
							  'theme_location'=>'sidemenu',
							));
						 ?>
					  </div>
				</div>
		   <?php endwhile; endif; ?>
		</div><!--End of 2nd row--> 
		
		<div class="row">
			<?php query_posts(array(
				  'post_type'=>'menu_left_type',
				  'post_per_page'=>1
				)); ?>
			<?php if(have_posts()):while(have_posts()):the_post(); ?>
				<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					  <div class="menu_left">
						<div class="menu_left_1">
						   <h5><?php the_title(); ?></h5>
						  <p><?php the_content(); ?></p>
						</div>
					  </div>
				</div>
		   <?php endwhile; endif; ?>
		</div><!--End of 2nd row--> 
	  <div class="row">
	   	            
	   	 			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6"> 
	   	 			  <div class="menu_left">
	   	 			    <div class="menu_left_1">
	   	 			       <h5>Jerry's Sandwiches...................................................................14$</h5>
	   	 				  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </p>
	   	 				</div>
	   	 				<div class="menu_left_1">
	   	 			       <h5>Taco De Pescado.......................................................................14$</h5>
	   	 				  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </p>
	   	 				</div>
	   	 				<div class="menu_left_1">
	   	 			       <h5>Portuguese Chicken...................................................................14$</h5>
	   	 				  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </p>
	   	 				</div>
	   	 				<div class="menu_left_1">
	   	 			       <h5>Jerry's Sandwiches....................................................................14$</h5>
	   	 				  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </p>
	   	 				</div>
	   	 				<div class="menu_left_1">
	   	 			       <h5>Mussels & Frites........................................................................14$</h5>
	   	 				  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </p>
	   	 				</div>
	   	 			  </div>	
	   	 			</div>
	   	 			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6"> 
	   	 			  <div class="menu_left">
	   	 			    <div class="menu_left_1">
	   	 			        <h5>Little Goat.................................................................................14$</h5>
	   	 				  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </p>
	   	 				</div>
	   	 				<div class="menu_left_1">
	   	 			        <h5>Jerry's Sandwiches..................................................................14$</h5>
	   	 				  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </p>
	   	 				</div>
	   	 				<div class="menu_left_1">
	   	 			       <h5>Torta Ahogada..........................................................................14$</h5>
	   	 				  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </p>
	   	 				</div>
	   	 				<div class="menu_left_1">
	   	 			        <h5>Crispy Brussels Sprout Salad................................................14$</h5>
	   	 				  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit</p>
	   	 				</div>
	   	 				<div class="menu_left_1">
	   	 			        <h5>Jerry's Sandwiches.................................................................14$</h5>
	   	 				  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, </p>
	   	 				</div>
	   	 			  </div>	
	   	 			</div>
	   	 	   	</div> -->
	   </div>
	</div><!-- End of our_menu_area-->
	<div class="cheif_area">
	    <div class="container">
	    	<div class="row">
			    <?php query_posts(array(
					  'post_type'=>'ourtop_type',
					  'post_per_page'=>1
					)); ?>
				<?php if(have_posts()):while(have_posts()):the_post(); ?>
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						  <div class="oue_top text-center">
							<h2><?php echo the_title(); ?></h2>
							<?php the_post_thumbnail(); ?>
						  </div>
					   </div>
			   <?php endwhile; endif; ?>
			</div><!--End of 1st row--> 
			
			<div class="row">
			    <?php query_posts(array(
					  'post_type'=>'oue_bottom_type',
					  'post_per_page'=>4
					)); ?>
				<?php if(have_posts()):while(have_posts()):the_post(); ?>
					<div class="col-xs-6 col-sm-3 col-md-3 col-lg-3">
					  <div class="oue_bottom">
						<?php the_post_thumbnail(); ?>
						<div class="img_overlay"></div>
						<div class="text_overlay"><i class="fa fa-4x <?php echo get_post_meta($post->ID,'ms_icon',true); ?>"></i></div>
					  
						  <div class="oue_bottom_text">
							<h2><?php the_title(); ?></h2>
							<p><?php the_content(); ?></p>
						  </div>
					 </div> 
				   </div>
			   <?php endwhile; endif; ?>
		    </div>		
	    	</div>
	    </div>
	</div><!-- End of chif-->
	<div class="special_area">
	   <div class="special_area_overlay"></div>
	    <div class="container">
	    	<div class="row">
				<div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-xs-offset-2 col-sm-offset-2 col-md-offset-2 col-lg-offset-2">
				  <div class="our_top text-center">
					<h2><span class="red">Today</span>Special Dishes</h2>
					<img class="logo_img" src="<?php echo get_template_directory_uri(); ?>/img/witebg.jpg" class="img-responsive" alt="" />
				  </div>
				     <div class="carousel slide" data-ride="carousel" id="my_carousel" data-interval="2200">
						<ol class="carousel-indicators">
							<li data-target="#my_carousel" data-slide-to="0" class="active"></li>
							<li data-target="#my_carousel" data-slide-to="1"></li>
							<li data-target="#my_carousel" data-slide-to="2"></li>
							<li data-target="#my_carousel" data-slide-to="3"></li>
						</ol>
						<div class="carousel-inner">
							<div class="item active">
							    <div class="row_bg">
								   <div class="col-md-6">
								       <div class="first_img">
									     <img src="http://localhost/test/wordpress/wp-content/uploads/2017/05/s2.jpg" class="img-responsive" alt="img not found" />
									     <p>Fried chicken <span class="red">39$</span> </p>
								       </div>
								   </div> 
								   <div class="col-md-6">
								       <div class="second_img">
									      <img src="http://localhost/test/wordpress/wp-content/uploads/2017/05/s1-1.jpg" class="img-responsive" alt="img not found" />
									      <p>Fried chicken <span class="red">39$</span>  </p>
								       </div>
								   </div>
							    </div>
							</div>
							<div class="item">
							    <div class="row_bg">
								   <div class="col-md-6">
								       <div class="first_img">
									     <img src="http://localhost/test/wordpress/wp-content/uploads/2017/05/s2.jpg" class="img-responsive" alt="img not found" />
									     <p>Fried chicken <span class="red">39$</span> </p>
								       </div>
								   </div> 
								   <div class="col-md-6">
								       <div class="second_img text-right">
									      <img src="http://localhost/test/wordpress/wp-content/uploads/2017/05/s1-1.jpg" class="img-responsive" alt="img not found" />
									      <p>Fried chicken <span class="red">39$</span>  </p>
								       </div>
								   </div>
							    </div>
							</div>
							<div class="item">
								 <div class="row_bg">
								   <div class="col-md-6">
								       <div class="first_img">
									     <img src="http://localhost/test/wordpress/wp-content/uploads/2017/05/s2.jpg" class="img-responsive" alt="img not found" />
									     <p>Fried chicken <span class="red">39$</span> </p>
								       </div>
								   </div> 
								   <div class="col-md-6">
								       <div class="second_img text-right">
									      <img src="http://localhost/test/wordpress/wp-content/uploads/2017/05/s1-1.jpg" class="img-responsive" alt="img not found" />
									      <p>Fried chicken <span class="red">39$</span>  </p>
								       </div>
								   </div>
							    </div>
							</div>
						</div>
						 <a href="#my_carousel" class="left carousel-control" role="button" data-slide="prev" >
                            <span class="glyphicon glyphicon-chevron-left"></span>
                        </a>
                        <a href="#my_carousel" class="right carousel-control" role="button" data-slide="next" >
                            <span class="glyphicon glyphicon-chevron-right"></span>
                        </a>
					</div>
				</div>
	    	</div>
	    </div>
	</div><!-- End of special_area-->
	<div class="booktable_area">
	    <div class="container">
	    	<div class="row">
	    		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				    <div class="oue_top text-center">
					<h2><span class="red">Book A </span> Table</h2>
					<img src="img/chif_logo.jpg" width="365px;" alt="" />
				  </div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<form action="" method="">
						<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
							<div class="form_area_1">
								<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Full Name">
								<input type="Date" class="form-control" id="exampleInputEmail1" placeholder="Month">
							</div>
							</div>
							<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
								<div class="form_area_1">
									<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Your email">
									<input type="Date" class="form-control" id="exampleInputEmail1" placeholder="Day">
								</div>
							</div>
							<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
								<div class="form_area_1">
									<input type="tel" class="form-control" id="exampleInputEmail1" placeholder="Phone">
									<div style="margin-left:20px;"class="select_area text-center">
									<select name="" id="" placeholder="Hour">
										   <option value="">Hour</option>
										   <option value="">Min</option>
										   <option value="">Sec</option>
									</select>
									<select name="" id="" placeholder="Hour">
										   <option value="">Min</option>
										   <option value="">AM</option>
										   <option value="">Sec</option>
									</select>
									<select name="" id="" placeholder="Hour">
										   <option value="">AM</option>
										   <option value="">Min</option>
										   <option value="">Sec</option>
									</select>
									</div>
								</div>
							</div>
							<div class="col-sm-3 col-md-3 col-lg-3">
							  <div class="form_area_1">
								<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Numbers guests">
								<input type="Date" class="form-control" id="exampleInputEmail1" placeholder="Comments">
							</div>
						</div>
					</form> 
					<div class="submit text-center">
					    <button type="submit" class="btn btn-default">Subscrib now!</button>
					</div>
				</div>
	    	</div>
	    </div>
	</div><!-- End of book&table_area-->
	<?php get_footer(); ?>