<?php 
require_once '/requers/custom_post.php';
require_once '/requers/ourtop.php';
require_once '/requers/oue_bottom.php';
require_once '/requers/submenu.php';
require_once '/requers/special_menu.php';
require_once '/requers/meta_boxes.php';
 add_theme_support('custom-header');
 add_theme_support('post-thumbnails');

 register_nav_menus(
    array(
      'primary'=>'this is primary menu',
      'footer' =>'this is footer menu',
     )
   );


function enqueue_my_styles() {
    
    // Load the main stylesheet lInks....
    wp_enqueue_style( 'my-theme', get_stylesheet_uri() );
	
    wp_enqueue_style('bootstrap', get_stylesheet_directory_uri() ."/css/bootstrap.min.css", array(),'3.3.7','all');
	
	wp_enqueue_style( 'wpb-fa', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css' );
	
	wp_enqueue_style('font-awesome',get_template_directory_uri()."/css/font-awesome.min.css",array(),'4.7.0','all');
	
	wp_enqueue_style('carousel',get_template_directory_uri()."/css/owl.carousel.css",array(),'1.3.3','all');
	
	
	
	wp_enqueue_script('jquery', 'http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js', false, '1.11.3');
	
    wp_enqueue_script( 'bootstrap_js', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js');
	
    wp_enqueue_script( 'carousel', plugins_url( '/js/owl.carousel.min.js' , __FILE__ ), array(), '1.3.3',true );
}

add_action( 'wp_enqueue_scripts', 'enqueue_my_styles' );
 ?>