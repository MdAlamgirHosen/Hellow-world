<!DOCTYPE HTML>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset');?>">
	<title><?php wp_title();?></title>
	
	<?php wp_head(); ?>
</head>
<body>
	<header class="header_area social_bookmark-fixed-top ">
		<div class="container">
			<div class="row">
				<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
					<div class="logo">
						<img src="<?php header_image(); ?>" width="" height="" alt=""/>
					</div>
				</div>	
				<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
					<div class="social_bookmark">
						<ul>
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
							<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
	    </div><!--end header_top-->
		 <nav class="navbar navbar-default">
		    <div class="navbar_overlay"></div>
            <div class="container">
                <div class="navbar-header">
                    <button type="button" data-toggle="collapse" class="navbar-toggle" data-target="#my_menu">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="my_menu">
                    	<?php
						wp_nav_menu(array(
						  'menu_class'=>"nav navbar-nav",
						  'container'=>false,
						  'theme_location'=>'primary',
						));
					   
					 ?>
                </div>
            </div>
        </nav><!--End of header navber-->
		
		 <div class="header_slider_area">
			<div class="container cont">
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"> 
						<div class="carousel carousel_mystyle slide" data-ride="carousel" id="my_carousel" data-interval="2200">
							<ol class="carousel-indicators">
								<li data-target="#my_carousel" data-slide-to="0" class="active"></li>
								<li data-target="#my_carousel" data-slide-to="1"></li>
								<li data-target="#my_carousel" data-slide-to="2"></li>
								<li data-target="#my_carousel" data-slide-to="3"></li>
							</ol>
							<div class="carousel-inner">
								<div class="item active">
								   <h3>Welcome To</h3>
								   <h2>Panthashala Restaurant</h2>
								   <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh 
euismod tincidunt ut laoreet dolore magna aliquam erat volutpat</p>
								</div>
								<div class="item">
									 <h3>Congratulation To</h3>
								   <h2>Restaurant Panthashala </h2>
								   <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh 
euismod tincidunt ut laoreet dolore magna aliquam erat volutpat</p>
								</div>
								<div class="item">
									 <h3>Welcome To</h3>
								   <h2>Panthashala Restaurant</h2>
								   <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh 
euismod tincidunt ut laoreet dolore magna aliquam erat volutpat</p>
								</div>
								<div class="item">
									 <h3>Very very nice</h3>
								   <h2>Restaurant Panthashala </h2>
								   <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh 
euismod tincidunt ut laoreet dolore magna aliquam erat volutpat</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
	    </div><!--End of header slider-->
	</header><!-- End of header_area-->