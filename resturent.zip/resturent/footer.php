<div class="footer_area">
	    <div class="footer_area_overlay"></div>
	    <div class="container">
	    	<div class="row">
	    		<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
				   <div class="footer_top1">
				      <h2>open Hours</h2>
					  <p>Mondays  ............  <span class="red">Closed</span></p>
                      <p>Tue-Fri ...........  10am - 12am</p>
                      <p>Sat-Sun .............  7am - 1am</p>
                      <p>Public Holidays  ............ 7am - 1am</p>
				   </div>
				</div>
				<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
				   <div class="footer_top1">
				      <h2>recent <span class="red">post</span></h2>
					   <div class="img_text">
					     <img src="<?php the_post_thumbnail(); ?>/img/r1.jpg" class="img-responsive" alt="img not found" />
					    <p>Lorem ipsum dolor sit amet
consectetuer adipiscing.</p>
                       </div>
					   <div class="img_text">
                          <img src="<?php echo get_template_directory_uri()?>/img/r2.jpg" class="img-responsive" alt="" />
					     <p>Lorem ipsum dolor sit amet
consectetuer adipiscing.</p>
                       </div>
				   </div>
				</div>
				<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
				   <div class="footer_top1">
				      <h2>Gallery</h2>
					   <img src="<?php echo get_template_directory_uri()?>/img/g1.jpg" class="img-responsive" alt="" />
					   <img src="<?php bloginfo("template_directory"); ?>/img/g2.jpg" class="img-responsive" alt="" />
					   <img src="<?php bloginfo("template_directory"); ?>/img/g3.jpg" class="img-responsive" alt="" />
					   <img src="<?php bloginfo("template_directory"); ?>/img/g4.jpg" class="img-responsive" alt="" />
					   <img src="<?php bloginfo("template_directory"); ?>/img/g5.jpg" class="img-responsive" alt="" />
					   <img src="<?php bloginfo("template_directory"); ?>/img/g6.jpg" class="img-responsive" alt="" />
				   </div>
				</div>
				<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
				   <div class="footer_top1">
				      <h2>contact <span class="red">us</span></h2>
					  <p>You can contact us via the info@gmail.com</p>
					  <h6><span class="red">Our address</span></h6>
					  <p>250 Biscayne Blvd. (North) 11st Floor 
New World Tower Miami, Florida 33148</p>
                      <h6><span class="red">Our phone</span></h6>
					  <p>000-111-1234-4567 </p>
				   </div>
				</div>
	    	</div>
	    </div>
	</div><!-- End of special_area-->
	<div class="footer_area_bottom text-center">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"> 
				    <div class="copyright"> 
					    <p>Copyright BootstrapCafe 2016. All Rights Reserved</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php wp_footer(); ?>
</body>
</html>