<?php 
/*
Template Name: Faq
*/

?>
<?php get_header(); ?>




<?php get_template_part('ltc/pagetitle'); ?>

<div  class="gfmw_full_contianer singlepost">
	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">

	<section style="min-height:1000px;" class="postlist pagepostnse">
		
		
		<div class="gw_inner padding_sets">



		<?php while ( have_posts() ): the_post(); ?>
		

					<?php the_content(); ?>

			<?php if ( ot_get_option('page-comments') == 'on' ) { comments_template('/comments.php',true); } ?>
			
		<?php endwhile; ?>
		<div class="panel-group bodyrubs_" id="accordion" role="" aria-multiselectable="true">
			<?php echo lt_faqs_(); ?>
		</div>	
		<?php //get_template_part('ltc/faq'); ?>
		</div>
	</section>

	<section class="page_sidebar sehosne">
		<?php
			
			$args = array(
    'post_type' => 'wtsidebar',
    'meta_query' => array(
       
    )
 );
 
  
    $sidebarcotnent = new WP_Query($args);
 
if ($sidebarcotnent->have_posts()): while($sidebarcotnent->have_posts()): $sidebarcotnent->the_post(); 

the_content(); 

endwhile; else:
endif;
?>
		
	</section>
	</div>
</div>
</div>


<?php get_footer(); ?>