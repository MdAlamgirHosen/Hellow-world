<article id="post-<?php the_ID(); ?>" <?php post_class('group'); ?>>	
	
		
		<div class="listpostimg">
			<a class="post_norlink" href="<?php the_permalink(); ?>"><?php if ( has_post_thumbnail() ): ?><?php the_post_thumbnail( 'single-post-thumbnail' ); ?><?php else: ?> <img src="http://giftformenwomen.com/wp-content/uploads/2016/11/gifts-for-men-women-gifs-ideas.png" alt="<?php the_title(); ?>"> <?php endif; ?>	
				
			</a>
			</div>
		<div class="listposting_content">
<div class="inner_catlist">	
			
		
		

			<p class="post-category"><?php the_category(' / '); ?></p>
			
		</div><!--/.post-meta-->
		
		
			<a class="listing_posttitle" href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a>
		
		
		<?php if (ot_get_option('excerpt-length') != '0'): ?>
		<p><?php echo the_excerpt() ?> </p>
		<?php endif; ?>
		
	</div><!--/.post-inner-->	
</article><!--/.post-->	