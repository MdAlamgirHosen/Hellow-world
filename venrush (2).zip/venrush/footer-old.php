<?php // footer widgets ?>


<!-------------------Footer start------------------------->
<footer id="footer">


<div class="gfmw_full_contianer page_footer_gfmw">
	<div class="gfwm_center blogpost">
		<div class="gw_inner footer_main gfmwfix">
		
		<div class="menuarea_foo">
		 <h2> resources </h2>
		 <div class="gfwm_center footermenu_s">
		<?php wp_nav_menu(array('theme_location'=>'footer_1','menu_class'=>'footer_menu_ul_ltc','menu_id'=>'','container'=>'footermenu_s','' => '','fallback_cb'=> false)); ?>
		 </div>
		  <div class="gfwm_center footermenu_s ">
		<?php wp_nav_menu(array('theme_location'=>'footer_2','menu_class'=>'footer_menu_ul_ltc','menu_id'=>'','container'=>'footermenu_s','' => '','fallback_cb'=> false)); ?>
		 </div>

		</div>
		
		<div class="logosare_foo">
		
		 <?php if ( ot_get_option( 'now_hiringfooter' ) ): ?>
		 <?php echo ot_get_option( 'now_hiringfooter' ); ?>
		 <?php else: ?>
		  <h2 class="apy_toWork"> Now Hiring </h2>
			
			<?php endif; ?>
		</div>

</div>
</div>
</div>

<div class="gfmw_full_contianer page_copyright">
	<div class="gfwm_center blogpost">
		<div class="gw_inner copyright_gw gfmwfix">
<?php if ( ot_get_option( 'copyrighttext' ) ): ?>
<p class="copy_r">
<?php echo ot_get_option( 'copyrighttext' ); ?> © <?php echo date( 'Y' ); ?> <span><?php echo ot_get_option( 'copyright' ); ?></span>. All rights reserved.
</p>
<?php else: ?>
<p class="copy_rn">
Los Angeles Body Rubs  © <?php echo date( 'Y' ); ?> <span>losangelesbodyrubs.com</span>. All rights reserved.
</p>
<?php endif; ?>


</div>
</div>
</div>
</footer>
<!-------------------Footer Section End------------------------->		
<?php if ( ot_get_option( 'scroll_totop' ) !='off'): ?>
<a class="back-to-top" href="#">back to top  </a>
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>