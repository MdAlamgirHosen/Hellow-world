<?php 
/*
Template Name: programs page
*/

?>
<?php get_header(); ?>


<?php get_template_part('ltc/pagetitle'); ?>
 
<div class="gfmw_full_contianer singlepost">
	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">

			<section class="postlist pagepostnse wta_main_two_item">
			  
				  <h2 class="about_top_title">TD CAP - Special Programs</h2>
<p class="wta_service_t_p"><strong>TD CAP is Strongly Committed to Finance Wind and Solar Energy Infrastructure Projects in 2013.<br/>
Construction Financing:  Energy Related Facilities Internationally</strong><br/><br/>

Energy Related Projects - The scope energy project funding is international and covers alternative energy (wood, wind, solar,) ... alternative fuels to electricity. Minimum loan considered $50 million, program offers financing of 65% to 85% debt financing. This program has a very stringent structure and based on LIBOR and must be guaranteed by PPA agreements for a minimum of 10 years; has a 2 year construction component plus 8 years operating term. Prepayment is allowed anytime after the two yeartermwithout penalty. Rates are based upon LIBOR with the lowest rate being 375 bps spread over LIBOR, floating and are adjustable every 3 years. <br/><br/>

Notice: We do not offer any 100% Financing. If you have no pre-existing verifiable cash in your own proposed funding request, we will not be able to assist you in financing your project.<br/><br/>

For detailed information email us at:  energy@tdcapitaladvisors.com<br/><br/>


Construction Financing:   Hotels - Medical Centers - Shopping Centers - Office Buildings Internationally <br/><br/>

TD CAP is actively seeking hotels and hotel resorts in need of refinancing or debt equity restructuring of construction or performing properties throughout Mexico, Central America and the Caribbean, South America, Europe, Australia and Asia. This program offers long-term financing based on the 30 day LIBOR. The program offers both debt and equity capital. The first tranche is expected to be $500,000,00. The minimum loan acceptable into this portfolio is $35 Million except for South America,Europe, Australia and Asia where the minimum loan is $50 Million. Terms are 2 years construction followed by 3 year to 10 year terms (normally 5 years to 7 years); interest rates from 450 bps spread over LIBOR and are always subject to underwriting and credit criteria.
Notice: We do not offer any 100% Financing. If you have no pre-existing verifiable cash in your own proposed funding request, we will not be able to assist you in financing your project.<br/><br/>

For detailed information email us at:<a href="#"> info@tdcapitaladvisors.com</a>

</p>


<p class="wta_service_t_p"><strong>Correspondent Brokers:</strong><br/><br/>

TD CAP is seeking proactive, experienced, international commercial real estate brokers who may be interested in becoming a Thompson-Dewitt Correspondent Broker.<br/><br/>

We offer a Guaranteed Correspondent Broker Fee Protection.  Understanding your direct relationship with your prospective borrower is important; we will protect your reasonable success fees.<br/><br/>

Cumulative, additional transaction bonuses after achieving a specific annual volume levels of closed new loan business.
Three (3) year client and source protection on roll-overs and new closed loans from same borrower source.
Use of TD CAP’s corporate identity consisting of physical address, email address, telephone directory listing allowing our receptionists to forward your inbound calls to you. [Made available at your option and request, after your first project submission meeting our funding criteria.]
We look forward to working with you.

  
<br/><br/> 

Additional information email us: <a href="#"> affiliate@tdcapitaladvisors.com</a>

</p>


<p class="wta_service_t_p"><strong>Correspondent Brokers:</strong><br/><br/>

TD CAP is seeking proactive, experienced, international commercial real estate brokers who may be interested in becoming a Thompson-Dewitt Correspondent Broker.<br/><br/>

We offer a Guaranteed Correspondent Broker Fee Protection.  Understanding your direct relationship with your prospective borrower is important; we will protect your reasonable success fees.<br/><br/>
Cumulative, additional transaction bonuses after achieving a specific annual volume levels of closed new loan business.
Three (3) year client and source protection on roll-overs and new closed loans from same borrower source.
Use of TD CAP’s corporate identity consisting of physical address, email address, telephone directory listing allowing our receptionists to forward your inbound calls to you. [Made available at your option and request, after your first project submission meeting our funding criteria.]
We look forward to working with you.<br/><br/>


Additional information email us: <a href="#">affiliate@tdcapitaladvisors.com </a>  

</p>


<p class="wta_service_t_p"><strong>Individual Investor Relations:</strong><br/><br/>

Do you prefer to make your investment decisions yourself? If you are a high-net-worth individual with five-million dollars or more to invest you may come to appreciate TD CAP. We have a variety of short-term joint venture opportunities available, including just the right one to fit your investing strategies and budget.To initiate discussions please email us:   investorrelations@tdcapitaladvisors.com<br/><br/>


Distressed and Performing Assets Acquisition - Internationally<br/><br/>
We are seeking distressed assets backed by real estate and some performing assets backed by real estate. Distressed assets must be 120 days in arrears or greater. Minimum transaction size is $25 Million in the USA, elsewhere $50 Million. Outside of the US, we prefer portfolios of distressed assets to be geographically clustered greater than $100 Million.   COMMUNICATIONS MUST BE PRINCIPAL TO PRINCIPAL.<br/><br/>

 For detailed information email us at: <a href="#"> info@tdcapitaladvisors.com</a>  

</p>


<p class="wta_service_t_p"><strong>Direct Pay Letter of Credit Financing Program:</strong><br/><br/>
 For detailed information email us at: <a href="#"> dplc@tscapitaladvisors.com</a>  

</p>

<p class="wta_service_t_p"><strong>Master Art Financing and Sales:</strong><br/><br/>
 For detailed information email us at: <a href="#">info@tdcapitaladvisors.com</a>  

</p>
			
				
			</section>
			
			
		<div class="wta_sidebar_area">
		   <h2 class="about_top_title_side">Our Services</h2>
		 <section class="wta_content_area"> 
		     <div class="wta_five_area10"> 
			   <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			   <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			  <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			  <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			   <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			   <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			   <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
		  </section>
		</div>
		

	</div>
</div>
</div>

<?php get_footer(); ?>















