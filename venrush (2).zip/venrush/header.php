<!DOCTYPE html> 
<html class="no-js" <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title><?php if(is_front_page()) { echo bloginfo("name");  }elseif ( is_home() ) { echo bloginfo("name");} else { echo lt_page_title();  } ?>
	</title>
    <?php get_template_part('ltc/metatag'); ?>
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
	
	
	<?php wp_head(); ?>
	
<?php if ( ot_get_option( 'gogle_verify' )): ?>
<?php echo ot_get_option('gogle_verify'); ?>
<?php endif; ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

</head>

<body <?php body_class(); ?>>

<!--------------------Head Section------------------------>
 <?php 

if (is_front_page()){

	get_template_part('headerone');
		
}
else{
	
	get_template_part('headertwo');
}
?> 