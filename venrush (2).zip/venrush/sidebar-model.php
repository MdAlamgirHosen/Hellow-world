

<div class="ownerdetains">
<?php 


$age_pro = get_post_meta($post->ID, 'model_age',  true); 
	$model_height_pro = get_post_meta($post->ID, 'model_height', true); 
	$model_weight_pro = get_post_meta($post->ID, 'model_weight', true); 
	$model_eyes_pro = get_post_meta($post->ID, 'model_eyes', true);  
$model_hair_pro = get_post_meta($post->ID, 'model_hair',  true); 
	$model_bustsize_pro = get_post_meta($post->ID, 'model_bustsize', true); 
	$model_ethnicity_pro = get_post_meta($post->ID, 'model_ethnicity', true); 
	$model_languages_pro = get_post_meta($post->ID, 'model_languages', true); 

?>
<div class="about_model_text">
<div class="model_titlebox" ><h2> Profile</h2><div class="border_lines"> </div></div>
<div class="model_bodytype">
<h3>Age  <span> <?php echo $age_pro; ?></span></h3>
<h3 class="_set2"> Height  <span> <?php echo $model_height_pro; ?></span></h3>
<h3>Weight   <span> <?php echo $model_weight_pro; ?></span></h3>
<h3 class="_set2"> Eyes  <span> <?php echo $model_eyes_pro; ?></span></h3>
<h3>Hair   <span> <?php echo $model_hair_pro; ?></span></h3>
<h3 class="_set2"> Ethnicity   <span> <?php echo $model_bustsize_pro; ?></span></h3>
<h3>Nationality    <span> <?php echo $model_ethnicity_pro; ?></span></h3>
<h3 class="_set2"> Languages   <span> <?php echo $model_languages_pro; ?></span></h3>
</div>
</div>

</div>

<?php 


 $model_onehour_pro = get_post_meta($post->ID, 'model_onehour',  true); 
	$model_nintymiun_pro = get_post_meta($post->ID, 'model_nintymiun', true); 
	$model_twohour_pro = get_post_meta($post->ID, 'model_twohour', true); 
	$model_threehour_pro = get_post_meta($post->ID, 'model_threehour', true); 
	$model_oneday_pro = get_post_meta($post->ID, 'model_oneday',  true); 
	$model_special_pro = get_post_meta($post->ID, 'model_special', true); 

?>

<div class="ownerdetains">

<div class="about_model_text">
<div class="model_titlebox" ><h2> OutCall Only</h2><div class="border_lines"> </div></div>
<div class="model_bodytype">
<h3>1 Hour  <span> <?php echo $model_onehour_pro; ?></span></h3>
<h3 class="_set2"> 90 Minutes  <span> <?php echo $model_nintymiun_pro; ?></span></h3>
<h3>2 Hours   <span> <?php echo $model_twohour_pro; ?></span></h3>
<h3 class="_set2"> 3 Hours  <span> <?php echo $model_threehour_pro; ?></span></h3>
<h3>1 Day   <span> <?php echo $model_oneday_pro; ?></span></h3>

<h3 class="_set2">Speical Events    <span> <?php echo $model_special_pro; ?></span></h3>

</div>
</div>

</div>

<?php 



    $model_monday_pro = get_post_meta($post->ID, 'model_monday',  true); 
	$model_thusday_pro = get_post_meta($post->ID, 'model_thusday', true); 
	$model_wednesday_pro = get_post_meta($post->ID, 'model_wednesday', true); 
	$model_thrusdays_pro = get_post_meta($post->ID, 'model_thrusdays', true); 
	$model_friday_pro = get_post_meta($post->ID, 'model_friday',  true); 
	$model_satuerday_pro = get_post_meta($post->ID, 'model_satuerday', true); 
	$model_sunday_pro = get_post_meta($post->ID, 'model_sunday', true); 

?>
<div class="ownerdetains">
<div class="about_model_text">
<div class="model_titlebox" >
<h2 style="width:250px;"> Hours Of Operation </h2>
<div class="border_lines"> </div>
</div>
<div class="model_bodytype">
<h3>Monday <span> <?php echo $model_monday_pro; ?></span></h3>
<h3 class="_set2">Tuesday <span> <?php echo $model_thusday_pro; ?></span></h3>
<h3>Wednesday <span> <?php echo $model_wednesday_pro; ?></span></h3>
<h3 class="_set2">Thursday <span><?php echo $model_thrusdays_pro; ?></span></h3>
<h3>Friday <span> <?php echo $model_friday_pro; ?></span></h3>
<h3 class="_set2">Saturday <span> <?php echo $model_satuerday_pro; ?></span></h3>
<h3>Sunday <span><?php echo $model_sunday_pro; ?> </span></h3>
</div>
</div>
</div>

<script type="text/javascript" src="https://form.jotform.com/jsform/70227672750961"></script>

	
<div class="sidebar s2">
	
	<a class="sidebar-toggle" title="<?php _e('Expand Sidebar','hueman'); ?>"><i class="fa icon-sidebar-toggle"></i></a>
	
	<div class="sidebar-content">
		
		<?php if ( ot_get_option('sidebar-top') != 'off' ): ?>
		<div class="sidebar-top group">
			
		</div>
		<?php endif; ?>
		
		<?php if ( ot_get_option( 'post-nav' ) == 's2') { get_template_part('inc/post-nav'); } ?>
		
		<?php dynamic_sidebar($sidebar); ?>
		
	</div><!--/.sidebar-content-->
	
</div><!--/.sidebar-->