<?php 
/*
Template Name: Full Page
*/

?>
<?php get_header(); ?>


<?php get_template_part('ltc/pagetitle'); ?>

<div class="gfmw_full_contianer singlepost">
	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">

	<section class="postlist pagepostnse rencet_closes">
		
		
<div class="gw_inner padding_sets">
	

		<?php while ( have_posts() ): the_post(); ?>
		

					<?php the_content(); ?>

			<?php if ( ot_get_option('page-comments') == 'on' ) { comments_template('/comments.php',true); } ?>
			
		<?php endwhile; ?>
		
	</div>	
	
	</section>


	</div>
</div>
</div>

<?php get_footer(); ?>