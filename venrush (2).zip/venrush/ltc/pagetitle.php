<?php 


?>



<div class="gfmw_full_contianer page_title_gfmws">
	<div class="gfwm_center blogpost">
		<div class="gw_inner  gfmwfix">
				 <p> <?php the_title(); ?></p>
				 
	</div>
</div>
</div>	

