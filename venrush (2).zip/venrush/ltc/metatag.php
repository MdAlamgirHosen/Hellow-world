<?php 


?>
<!-- google -->
<?php if ( ot_get_option( 'gogle_verify' )): ?>
<?php echo ot_get_option('gogle_verify'); ?>
<?php endif; ?>

<!-- fb -->
<meta property="og:title" content="<?php echo lt_page_title(); ?>"/>
<meta property="og:url" content="<?php echo get_permalink(); ?>"/>
<meta property="og:description" content="<?php echo lt_page_description(); ?>"/>        


<meta name="organization" content="Design Angeles - Web Design, Mobile Applications, Website Hosting, Search Engine Optimization" />    
<meta name="description" content="Website Design Los Angeles, remarkable designs and mobile web solutions to help you reach your customers. - Design Angeles"/>
<meta name="keywords" content="website design, web design, web designing, web development, SEO marketing, fast SEO, web site, website"/>
<meta name="author" content="Salauddin Jhon">
<meta name='copyright' content='LT Bangladesh'>
<meta name="designer" content="LT Bangladesh" /> 
<meta name='language' content='EN'>
<meta property='og:locale' content='en_US'/>
<meta property='og:type' content='article'/>
<meta name="geo.region" content="US-CA" />
<meta name="geo.placename" content="Beverly Hills" />
<meta name="geo.position" content="34.067432;-118.390279" />
<meta name="ICBM" content="34.067432, -118.390279" />


<?php if ( ot_get_option( 'favicon' )): ?>
<link rel="icon" type="image/png" href="<?php echo ot_get_option('favicon'); ?>">
<?php else: ?>
<link rel="icon" type="image/png" href="">
<?php endif; ?>

