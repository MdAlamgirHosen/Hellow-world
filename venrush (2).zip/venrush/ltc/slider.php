<?php 


?>



    <div id="slider1_container" class="slideareas">
      
        <div u="loading" style="position: absolute; top: 0px; left: 0px;">
            <div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block;
                top: 0px; left: 0px; width: 100%; height: 100%;">
            </div>
		            <div style="position: absolute; display: block; background: url(<?php bloginfo('template_url'); ?>/images/loading45.gif) no-repeat center center;
                top: 0px; left: 0px; width: 100%; height: 100%;">
            </div>
        </div>
      
        <div u="slides" class="slidebox">
            <div>
				<?php if ( ot_get_option('slider-image-1')): ?>
	                 <img u="image" src="<?php echo ot_get_option('slider-image-1'); ?>" />
				<?php else: ?>	 
				
                <?php endif; ?>
				
				<?php if ( ot_get_option('slider-one-content')): ?>
				
				<?php echo ot_get_option('slider-one-content'); ?>
				
				<?php else: ?>	 
				
				 
            <div u=caption t="R"  d=-450 class="slidedivsho"> 
                <p class="sldiecotnn"> 
I am Cheryl Fletcher, and I started my law firm to serve people and protect their rights. When faced with a legal issue, many people feel overwhelmed because they do not fully  I provide a clear head,
</p>
                </div>	
                
                		
				  <?php endif; ?>
            </div>
            <div>
			<?php if ( ot_get_option('slider-image-2')): ?>
	                 <img u="image" src="<?php echo ot_get_option('slider-image-2'); ?>" />
				<?php else: ?>	 
				
                <?php endif; ?>
               
			   <?php if ( ot_get_option('slider-two-content')): ?>
				
				<?php echo ot_get_option('slider-two-content'); ?>
				
				<?php else: ?>	 
			  <div u=caption t="R"  d=-450 class="slidedivsho"> 
                <p class="sldiecotnn"> 
I am Cheryl Fletcher, and I started my law firm to serve people and protect their rights. When faced with a legal issue, many people feel overwhelmed because they do not fully  I provide a clear head,
</p>
                </div>	
				 	
				
				<?php endif; ?>
				
            </div>
            <div>
               <?php if ( ot_get_option('slider-image-3')): ?>
	                 <img u="image" src="<?php echo ot_get_option('slider-image-3'); ?>" />
				<?php else: ?>	 
				
                <?php endif; ?>
				
				  <?php if ( ot_get_option('slider-three-content')): ?>
				
				<?php echo ot_get_option('slider-three-content'); ?>
				
				<?php else: ?>	 
				<div u=caption t="R"  d=-450 class="slidedivsho"> 
                <p class="sldiecotnn"> 
I am Cheryl Fletcher, and I started my law firm to serve people and protect their rights. When faced with a legal issue, many people feel overwhelmed because they do not fully  I provide a clear head,
</p>
                </div>	
				 <?php endif; ?>
            </div>
            
            <!--<div>
               <?php // if ( ot_get_option('slider-image-4')): ?>
	                 <img u="image" src="<?php// echo ot_get_option('slider-image-4'); ?>" />
				<?php // else: ?>	 
				<img u="image" src="<?php // echo get_template_directory_uri(); ?>/images/sample-slider.jpg" />
                <?php // endif; ?>
                
            </div>
               <div>
               <?php // if ( ot_get_option('slider-image-5')): ?>
	                 <img u="image" src="<?php // echo ot_get_option('slider-image-5'); ?>" />
				<?php // else: ?>	 
				<img u="image" src="<?php // echo get_template_directory_uri(); ?>/images/sample-slider.jpg" />
                <?php // endif; ?>
                
            </div>-->
            
        </div>
                
      
        <div u="navigator" class="jssorb21" style="position: absolute; bottom: 26px; left: 6px;">
          
            <div u="prototype" style="POSITION: absolute; WIDTH: 19px; HEIGHT: 19px; text-align:center; line-height:19px; color:White; font-size:12px;"></div>
        </div>
     

       
     
     
        <span u="arrowleft" class="jssora21l" style="width: 55px; height: 55px; top: 123px; left: 8px; ">
        </span>
     
        <span u="arrowright" class="jssora21r" style="width: 55px; height: 55px; top: 123px; right: 8px">
        </span>
       
       
    </div>   
    




