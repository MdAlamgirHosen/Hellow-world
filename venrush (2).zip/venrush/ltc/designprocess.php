<?php 


?>



<div class="today_bMain website-bg">

<div class="container">

<div class="websites_" style="width:100%;  height:auto; position:relative; float:left;">
 <?php if ( ot_get_option('designtitle')): ?>
<h1><?php echo ot_get_option('designtitle'); ?> </h1>
 <?php else: ?>
<h1>Design Process </h1>
<?php endif; ?> 
 <?php if ( ot_get_option('design_des')): ?>
<p>
<?php echo ot_get_option('design_des'); ?> 
</p>
 <?php else: ?>
<p>
At LT Inception, the project execution process is client-oriented. We take a systematic approach towards all projects. Design process starts with determining the objectives and priorities of the client. Specific communication protocols, a precisely mapped objective strategy and explicitly planned implementation designs the complete process. LT Inception has an innovative and functional set of methodologies known as Scrum. 
</p>
<?php endif; ?> 
</div>
<div class="design_s" style="width:100%;  height:auto; position:relative; float:left;">

<div class="pro_box">
     <div class="pro_content">
	  <?php if ( ot_get_option('design_img_1')): ?>
      <img src="<?php echo ot_get_option('design_img_1'); ?> ">
	   <?php else: ?>
	     <img src="<?php echo get_template_directory_uri(); ?>/images/process_1.png">
		 <?php endif; ?> 
	  <p class="pro_icon">  Step 1</p>
	  <?php if ( ot_get_option('pro_title_1')): ?>
	  <p class="pro_scon">   <?php echo ot_get_option('pro_title_1'); ?></p>
	   <?php else: ?>
	   <p class="pro_scon">    Requirement Gathering</p>
	    <?php endif; ?> 
		 <?php if ( ot_get_option('pro_des_1')): ?>
	  <p class="pro_des">  
 <?php echo ot_get_option('pro_des_1'); ?>	 
 </p>
  <?php else: ?>
	   <p class="pro_des">  
	   The first phase of the project cycle involves laying out the client’s objectives and making an initial survey of the project’s technical requirements. We contact in person, by email or a phone call, whatever you feel most comfortable with. 
	  </p>
	   <?php endif; ?> 
     </div>
</div>
<div class="pro_box">
    <div class="pro_content">
	 <?php if ( ot_get_option('design_img_2')): ?>
      <img src="<?php echo ot_get_option('design_img_2'); ?>">
	    <?php else: ?>
	   <img src="<?php echo get_template_directory_uri(); ?>/images/process_2.png">
	    <?php endif; ?> 
	  <p class="pro_icon">  Step 2</p>
	   <?php if ( ot_get_option('pro_title_2')): ?>
	  <p class="pro_scon">   <?php echo ot_get_option('pro_title_2'); ?></p>
	    <?php else: ?>
	    <p class="pro_scon">   Feasibility Evaluation</p>
		 <?php endif; ?> 
		 <?php if ( ot_get_option('pro_des_2')): ?>
	  <p class="pro_des">
	  <?php echo ot_get_option('pro_des_2'); ?>	  
	  </p>
	    <?php else: ?>
	   <p class="pro_des">  
	   Once LT Inception has clarified requirements with respect to the client’s objectives as follows:<br>
<br>
   1. Your goals and ideas<br>
   2. Color scheme<br>
   3. Navigational scheme<br>
   4. Flash & Image animation<br>

	  </p>
	   <?php endif; ?> 
     </div>
</div>
<div class="pro_box">
     <div class="pro_content">
	  <?php if ( ot_get_option('design_img_3')): ?>
      <img src=" <?php echo ot_get_option('design_img_3'); ?>">
	   <?php else: ?>
	  <img src="<?php echo get_template_directory_uri(); ?>/images/process_3.png">
	   <?php endif; ?> 
	   <p class="pro_icon">  Step 3</p>
	     <?php if ( ot_get_option('pro_title_3')): ?>
	  <p class="pro_scon">  <?php echo ot_get_option('pro_title_3'); ?></p>
	    <?php else: ?>
	   <p class="pro_scon">   Requirement Refinement</p>
	     <?php endif; ?> 
		  <?php if ( ot_get_option('pro_des_3')): ?>
	  <p class="pro_des"> 
 <?php echo ot_get_option('pro_des_3'); ?>
	  
	  </p>
	    <?php else: ?>
	    <p class="pro_des"> 
 This is the first step of the development process. LT Inception submits a FREE sample website called Mockup Submission. There is no cost or obligation ... It's truly FREE!<br>
<br>
    What is a website mockup? <br>
    Why do we offer FREE mockups? <br>
	  
	  </p>
	   <?php endif; ?> 
     </div>
</div>
<div class="pro_box">
    <div class="pro_content">
	 <?php if ( ot_get_option('design_img_4')): ?>
	      <img src="<?php echo ot_get_option('design_img_4'); ?>">
		   <?php else: ?>
	    <img src="<?php echo get_template_directory_uri(); ?>/images/process_4.png">
		<?php endif; ?> 
	   <p class="pro_icon">  Step 4</p>
	    <?php if ( ot_get_option('pro_title_4')): ?>
	  <p class="pro_scon">   <?php echo ot_get_option('pro_title_4'); ?></p>
	  <?php else: ?>
	    <p class="pro_scon">   Project Progress</p>
		<?php endif; ?> 
		<?php if ( ot_get_option('pro_des_4')): ?>
	  <p class="pro_des"> 
<?php echo ot_get_option('pro_des_4'); ?>
	  </p>
	   <?php else: ?>
	  <p class="pro_des"> 
	  Once the requirements are finalized and Mockup Submission is approved. LT Inception team begin laying out the website development process known as "Scrum" and any brand identity elements. This is a completely interactive process which requires client feedback at each step of execution.
	  </p>
	  <?php endif; ?> 
     </div>
</div>
<div class="pro_box">
    <div class="pro_content">
	<?php if ( ot_get_option('design_img_5')): ?>
      <img src="<?php echo ot_get_option('design_img_5'); ?>">
	    <?php else: ?>
	   <img src="<?php echo get_template_directory_uri(); ?>/images/process_5.png">
	    <?php endif; ?> 
	   <p class="pro_icon">  Step 5</p>
	   <?php if ( ot_get_option('pro_title_5')): ?>
	  <p class="pro_scon">   <?php echo ot_get_option('pro_title_5'); ?></p>
	    <?php else: ?>
	   <p class="pro_scon">   Final Project Delivery</p>
	    <?php endif; ?> 
	   <?php if ( ot_get_option('pro_des_5')): ?>
	  <p class="pro_des"> 
<?php echo ot_get_option('pro_des_5'); ?>
	  </p>
	    <?php else: ?>
	  <p class="pro_des"> 
	  Clients communicate and track project progress using our unique online project communication system. At each step, the client is notified when progress of the current phase is made. Clients can use any of the following methods to communicate with LT Inception to track project status
	  </p>
	   <?php endif; ?> 
     </div>
</div>

</div>

</div>
</div>