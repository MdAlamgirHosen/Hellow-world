<?php 
/*
Template Name: service page
*/

?>
<?php get_header(); ?>

<?php get_template_part('ltc/pagetitle'); ?>
 
<div class="gfmw_full_contianer singlepost">
	<div class="gfwm_center blogpost">
		<div class="gw_inner wpadding gfmwfix">

			<section class="postlist pagepostnse wta_main_two_item">
			    <div class="wta_top_img"> 
				  <img src="<?php echo get_template_directory_uri();?>/images/service.jpg" alt=""/>
				</div> 
			
				  <h2 class="about_top_title">SERVICES</h2>
<p class="wta_service_t_p"><strong>Real Estate Financing </strong><br/><br/>

TD CAPhas funded a diverse portfolio of projects encompassing office, hotel, resorts, healthcare, retail, multifamily, entertainment, casinos, amusement parks, medical office and hospital buildings globally and has a major foothold in all Latin American markets. Our team is well positioned for future opportunities in the global market place with captive investment funds TD CAP is poised to meet all challenges of the new global market. We are prepared to meet the needs of our clients and see a demand for real estate debt offering strong returns with manageable risk. <br/><br/>

In addition to our debt and equity interests, we possess that capability of structuring Preferred Equity, corporate Mezzanine Debt for non-real estate projects, Debt and Equity Restructuring, and other financial vehicles that can facilitate successful financing.<br/><br/> 

For detailed information email us at:  <a href="#"> realestatefinancing@tdcapitaladvisors.com</a>

</p>


<p class="wta_service_t_p"><strong>Partners In Management<br/>
Capital Markets</strong><br/><br/>


For more than 10 years, Thompson-Dewitt has solved complex problems, increased operating performance maximizing the value of the business for shareholders. Our Capital Market Group provides investment services for real estate acquisition, turn-around services, and debt and equity restructuring for sponsors whose mortgages were called or credit lines terminated during the "melt down". Our analytic team of professionals provide sophisticated advice on the values of real estate, today and into the future, the most effective methods to refinance taking into account the current and future needs of the client. <br/><br/>

The Capital Markets Group works closely with our Real Estate Finance team to negotiate capital solutions to facilitate liquidity and restructure debt and equity.<br/><br/> 

For detailed information email us at: <a href="#"> advisoryservices@tdcapitaladvisors.com</a>

</p>


<p class="wta_service_t_p"><strong>Real Estate Financing II</strong><br/><br/>


For the past 10 years, our firm has been a leader in the financing and syndication of capital to fund the development real estate projects, worldwide. Our team has an international presence with very strong relationships in twenty-five countries where it has financed over $100 Billion in properties. <br/><br/>

Our company has been a leader in providing capital to develop Hotels, Office Buildings, Shopping Centers, Medical Facilities, Manufacturing Facilities, Apartment Houses, Coal and Copper Mining, Agricultural projects, Student Housing, Condominiums, Telecommunications, Solar and Wind alternative energy projects in both developed and emerging markets. <br/><br/>

In North America, Mexico, Latin America and Caribbean, Europe, Australia and Asia we have provided more than $33 Billion in capital to finance the development of new projects and refinance existing properties within the past ten years. <br/><br/>

We offer a myriad for programs that range from twenty-five million million dollars to hundreds of millions of dollars. <br/><br/>

Our expert team of consultants, analysts, underwriters, accountants, and lawyers, work together to achieve success with your project. <br/><br/>

For detailed information email us at:  <a href="#"> realestatefinancing@tdcapitaladvisors.com</a>

</p>
			
				
			</section>
			
			
		<div class="wta_sidebar_area">
		   <h2 class="about_top_title_side">Our Services</h2>
		 <section class="wta_content_area"> 
		     <div class="wta_five_area10"> 
			   <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			   <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			  <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			  <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			   <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			   <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
			 
			 <div class="wta_five_area10"> 
			   <a href="http://localhost/financialwebsite/wordpress/">Investment
				<br>
				Management</a>
			 </div>
		  </section>
		</div>
		

	</div>
</div>
</div>

<?php get_footer(); ?>















