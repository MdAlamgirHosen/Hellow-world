<?php 

/*
Template Name: Home Page
*/

get_header(); 
?>
<div class="gfmw_full_contianer pagepadding_content_area">
	<div class="gfwm_center blogpost">
		<div class="wt_inner wta_something_shadaow">
		
      <div class="header_bottom">
	      
		     <?php $catquery = new WP_Query( 'cat=17&posts_per_page=1' ); ?>
				   <div class="wta_slider_top_area">
				<?php while($catquery->have_posts()) : $catquery->the_post(); ?>
				  
					<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
					 <div class="wta_img_overlay_item"> 
						 <a href="<?php the_permalink(); ?>">Design</a>
						 <h3 class="overlay_title"><?php the_title(); ?></h3>
						  <p class="wta_date_author"><?php the_author(); ?> &nbsp; &nbsp;<?php the_time(dmy); ?></p>
					   </div>
				   </div>
				  <?php endwhile; ?> 
				<?php wp_reset_postdata(); ?>

			</div>
			
          <div class="wta_slider_right_area"> 
		  
			<div class="wta_middle_two_img"> 
			  
			      <?php $catquery = new WP_Query( 'cat=19&posts_per_page=2' ); ?>
				<?php while($catquery->have_posts()) : $catquery->the_post(); ?>
				    <div class="wta_left_two_img">
					<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
					 <div class="wta_img_overlay_item"> 
						 <a href="<?php the_permalink(); ?>">Design</a>
						 <h3 class="overlay_title"><?php the_title(); ?></h3>
					   </div>
				     </div>  
				  <?php endwhile; ?> 
				<?php wp_reset_postdata(); ?>
			</div>
			
			<div class="wta_down_one_img"> 
			   <?php $catquery = new WP_Query( 'cat=18&posts_per_page=1' ); ?>
				<?php while($catquery->have_posts()) : $catquery->the_post(); ?>
				  
					<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
					 <div class="wta_img_overlay_item"> 
						 <a href="<?php the_permalink(); ?>">Design</a>
						 <h3 class="overlay_title"><?php the_title(); ?></h3>
					   </div>
				  <?php endwhile; ?> 
				<?php wp_reset_postdata(); ?>
			</div>
		  </div>			
      </div>
	  
    </div>
  </div>


<div class="gfmw_full_contianer pagepadding_content_area">
	<div class="gfwm_center blogpost">
		<div class="wt_inner">
		
		
		          <section class="wta_content_area"> 
					   <div class="wta_back">
						 <h3 class="wta_content_title1">Demo Title</h3>
					  </div>
					  <?php $catquery = new WP_Query( 'cat=20&posts_per_page=3' ); ?>
				<?php while($catquery->have_posts()) : $catquery->the_post(); ?>
				    <div class="wta_imag_content">
					     <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
						 <div class="wta_heading_text"> 
						   <h5><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h5>
						</div> 
					   </div>
				  <?php endwhile; ?> 
				<?php wp_reset_postdata(); ?>
			   </section>  		
		   </div>		  
      </div>		  
 </div>		  
<div class="gfmw_full_contianer pagepadding_content_area">
	<div class="gfwm_center blogpost">
		<div class="wt_inner">
		
		    <section class="wta_content_area_slider"> 
			  <div class="wta_back">
				 <h3 class="wta_content_title1">Demo Title</h3>
			  </div>	
				<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
				  <div class="carousel-inner text-center" role="listbox">
				  <!-- Wrapper for slides -->
					<div class="item active wta_display_none">
					   <!--/.single slide-->
					   <div class="wta_main_item">
					           <?php $catquery = new WP_Query( 'cat=5&posts_per_page=4' ); ?>
				  
								<?php while($catquery->have_posts()) : $catquery->the_post(); ?>
								  <div class="singla_slide_item1">
								    <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
									 <div class="wta_single_slide_overlay"> 
										  <h2><?php the_title(); ?></h2>
										  <h3><a href="<?php the_permalink(); ?>">Mist All Around The Golden Gate Bridge</a></h3>
										</div>
								   </div>
								  <?php endwhile; ?> 
								<?php wp_reset_postdata(); ?>
						</div>
					  </div><!---/.End single slide-->
					<div class="item">
					  <!--/.single slide-->
					      <div class="wta_main_item">
							 <?php $catquery = new WP_Query( 'cat=6&posts_per_page=4' ); ?>
				  
								<?php while($catquery->have_posts()) : $catquery->the_post(); ?>
								  <div class="singla_slide_item1">
								    <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
									 <div class="wta_single_slide_overlay"> 
										  <h2><?php the_title(); ?></h2>
										  <h3><a href="<?php the_permalink(); ?>">Mist All Around The Golden Gate Bridge</a></h3>
										</div>
								   </div>
								  <?php endwhile; ?> 
								<?php wp_reset_postdata(); ?>
						</div><!---/.End single slide-->
					</div>
					<div class="item wta_display_none">
						<!--/.single slide-->
					     <div class="wta_main_item">
							 <?php $catquery = new WP_Query( 'cat=7&posts_per_page=4' ); ?>
				  
								<?php while($catquery->have_posts()) : $catquery->the_post(); ?>
								  <div class="singla_slide_item1">
								    <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
									 <div class="wta_single_slide_overlay"> 
										  <h2><?php the_title(); ?></h2>
										  <h3><a href="<?php the_permalink(); ?>">Mist All Around The Golden Gate Bridge</a></h3>
										</div>
								   </div>
								  <?php endwhile; ?> 
								<?php wp_reset_postdata(); ?>
						</div><!---/.End single slide-->
					</div>
					<div class="item wta_display_none1">
						<!--/.single slide-->
					     <div class="wta_main_item">
							 <?php $catquery = new WP_Query( 'cat=7&posts_per_page=4' ); ?>
				  
								<?php while($catquery->have_posts()) : $catquery->the_post(); ?>
								  <div class="singla_slide_item1">
								    <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
									 <div class="wta_single_slide_overlay"> 
										  <h2><?php the_title(); ?></h2>
										  <h3><a href="<?php the_permalink(); ?>">Mist All Around The Golden Gate Bridge</a></h3>
										</div>
								   </div>
								  <?php endwhile; ?> 
								<?php wp_reset_postdata(); ?>
						</div><!---/.End single slide-->
					</div>
				  </div>

				  <!-- Controls -->
				  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
					<i class="fa fa-chevron-left" aria-hidden="true"></i>
				  </a>
				  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
					<i class="fa fa-chevron-right" aria-hidden="true"></i>
				  </a>
				</div>
		  </section>
		  
        </div>
     </div>
</div>

<div class="gfmw_full_contianer">
	<div class="gfwm_center blogpost">
		<div class="wt_inner">
		
		
		  <section class="wta_top_side_left_area">  
		
		  <div class="wta_content_area_leftside12">
		  
		   <div class="wta_back">
				 <h3 class="wta_content_title1 wta_font_sty">Demo Title</h3>
			  </div>
		   <div class="wta_content_area_leftside_top">  
		    <?php $catquery = new WP_Query( 'cat=21&posts_per_page=1' ); ?>
				<?php while($catquery->have_posts()) : $catquery->the_post(); ?>
				    <div class="featured">
					   <article id="post-16" class="wta_left_list group post-16 post type-post status-publish format-standard has-post-thumbnail hentry category-uncategorized"> 
						
						 <div class="listposting_content">
						  <div class="inner_catlist wta_content_area"> 
						     <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_post_thumbnail(); ?></a>
							  <div class="wta_btn_design">
							     <span><a href="<?php the_permalink(); ?>"> Design </a></span> 
							  </div>
						      <h1><?php the_title(); ?></h1>
						  </div>
                           <div class="wta_continue_btn">
						     <p class="Wta_content_text_area"><?php echo wp_trim_words( get_the_content(), 35, '<a class="read" href="'.get_permalink().'"> Read more </a>' ); ?></p>
						  </div>
						 </div>
					   </article> 
					 </div>
				  <?php endwhile; ?> 
				<?php wp_reset_postdata(); ?>
				
				</div>
				
				<div class="wta_content_area_down"> 
				   <div class="wta_down_top"> 
				       <img src="<?php echo get_template_directory_uri();?>/images/abouts.jpg" alt="">
				       <h4>Netus diam vehicula bibend</h4>
				   </div>

				   <div class="wta_down_top"> 
				       <img src="<?php echo get_template_directory_uri();?>/images/st.jpg" alt="">
				       <h4>Netus diam vehicula bibend</h4>
				   </div>
				</div>
		  </div>  

		  
		  

		  <div class="wta_content_area_leftside12">
		      <div class="wta_back">
				 <h3 class="wta_content_title1 wta_font_sty">Demo Title</h3>
			  </div> 
		   <div class="wta_content_area_leftside_top wta_leftf_divided">  
		     
		    <?php $catquery = new WP_Query( 'cat=21&posts_per_page=1' ); ?>
				<?php while($catquery->have_posts()) : $catquery->the_post(); ?>
				    <div class="featured">
					   <article id="post-16" class="wta_left_list group post-16 post type-post status-publish format-standard has-post-thumbnail hentry category-uncategorized"> 
						
						  <div class="inner_catlist wta_content_area"> 
						     <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_post_thumbnail(); ?></a>
						  </div>
					   </article> 
					 </div>
				
				</div>
				
				<div class="wta_content_area_down wta_right_divided"> 
				   <div class="wta_btn_design">
					 <span><a href="<?php the_permalink(); ?>"> Design </a></span> 
				  </div>
				  <h1><?php the_title(); ?></h1>

				   <div class="wta_continue_btn">
					 <p class="Wta_content_text_area"><?php echo wp_trim_words( get_the_content(), 35, '<a class="read" href="'.get_permalink().'"> Read more </a>' ); ?></p>
				  </div>
				</div>
				
				  <?php endwhile; ?> 
				<?php wp_reset_postdata(); ?>
		  </div> 
		  
		  
		  
		  
		   <div class="wta_content_area_leftside12" style="display-block; overflow:hidden;"> 
		          <div class="wta_back">
				 <h3 class="wta_content_title1 wta_font_sty">Demo Title</h3>
			  </div> 
					 <div class="wta_main_post_area">
					   <?php
                          
						global $post;
						$args = array( 'post_type' => post,'posts_per_page' => 10,'category' => 1 );

						$myposts = get_posts( $args );
						foreach ( $myposts as $post ) : setup_postdata( $post ); ?>
							<div class="wta_left_side_first2"> 
							   <article id="post-16" class="wta_left_list group post-16 post type-post status-publish format-standard has-post-thumbnail hentry category-uncategorized"> 
								
								 <div class="listposting_content wta_left_content">
								  <a class="wta_img_fixed_cls" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_post_thumbnail(); ?></a>
									 <div class="wta_btn_design">
										 <span><a href="<?php the_permalink(); ?>"> Design </a></span> 
									  </div>
									  <h1><?php the_title(); ?></h1>

									   <div class="wta_continue_btn">
										 <p class="Wta_content_text_area"><?php echo wp_trim_words( get_the_content(), 35, '<a class="read" href="'.get_permalink().'"> Read more </a>' ); ?></p>
									  </div>
								  </div>
								   
							   </article> 
							 </div>
						<?php endforeach; 
						wp_reset_postdata();?>
						
					</div>	
		      </div>  
		  </section>
		
		            <!-- side bar area -->
		             <section class="wta_content_sidebar"> 
					 
<div class="wta_top_one">
		    <div class="wta_slider_top_title1"> 
			    <h3>About</h3>
			 </div>
			 <div class="wta_bottom_content_img">
			   <img src="<?php echo get_template_directory_uri();?>/images/abouts.jpg" alt="">
		        <p>I'm Shane, a girly girl and lover of life. Join me on the journey to find latest in fashion.</p>
              <div class="wta_read_more_btn"> 
		       <a href="#">Read More </a>
		      </div>
             </div>
		   </div>

		   <div class="wta_top_one">
		    <div class="wta_slider_top_title2"> 
			    <h3>Top Destinations</h3>
			 </div>
			 <div class="wta_bottom_content_img1">
			   <img src="<?php echo get_template_directory_uri();?>/images/st.jpg" alt="">
                <div class="wta_read_more_btn_overlay"> 
		         <a href="#">Paris</a>
		        </div>
             </div>
			 
			 <div class="wta_bottom_content_img1">
			   <img src="<?php echo get_template_directory_uri();?>/images/shop-girls.jpg" alt="">
                <div class="wta_read_more_btn_overlay"> 
		         <a href="#">London</a>
		        </div>
             </div>
			 
			 <div class="wta_bottom_content_img1">
			   <img src="<?php echo get_template_directory_uri();?>/images/st.jpg" alt="">
                <div class="wta_read_more_btn_overlay"> 
		         <a href="#">Paris</a>
		        </div>
             </div>
		   </div> 
		   
		  
		   
		   <div class="wta_top_one">
		    <div class="wta_slider_top_title2"> 
			    <h3>Connect & Follow</h3>
			 </div>
			 <div class="wta_bottom_content_img1">
			   	<ul class="wta_social_menu">
				<li><a href="#"><i class="fa fa-facebook"></i></a></li>
				<li><a href="#"><i class="fa fa-twitter"></i></a></li>
				<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
				<li><a href="#"><i class="fa fa-instagram"></i></a></li>
				<li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
				<li><a href="#"><i class="fa fa-vimeo"></i></a></li>
				<li><a href="#"><i class="fa fa-search"></i></a></li>
				<li><a href="#"><i class="fa fa-rss"></i></a></li>
			  </ul>
			  
			  
			  <div class="wta_subscribe_area"> 
			      <div class="wta_read_more_btn"> 
				   <a href="#">Newsletter</a>
				  </div>
			      <p>Enter your email address below to subscribe to my newsletter </p>
				  
				  <form action="" method="post">
					  <input class="wta_text_btn" type="text" name="firstname" placeholder="Your E-mail Address..">
					  <br>
					  <input class="wta_submit_btn" type="submit" value="Subscribe">
					</form> 
			  </div>
             </div>
			 
		   </div>

     
		    <div class="wta_top_one2">
		      <?php if (is_category('Blogging')) {
				get_sidebar('blogging');
				} else {
				get_sidebar();
				} ?>
			   </div> 
					   
					   
	          <div class="wta_top_one1">
			  
		        <div class="wta_slider_top_title2"> 
		   			    <h3>Instagram</h3>
		   			 </div>
		   			 <div class="wta_bottom_content_img1">
		   			   <div class="wta_6top_img">
		   			   <div class="wta_3images">
		   			      <img src="<?php echo get_template_directory_uri();?>/images/st.jpg" class="">
		   			   </div>
		   
		   			   <div class="wta_3images">
		   			      <img src="<?php echo get_template_directory_uri();?>/images/st.jpg" class="">
		   			   </div>
		   
		   			   <div class="wta_3images">
		   			      <img src="<?php echo get_template_directory_uri();?>/images/st.jpg" class="">
		   			   </div>
		   			  </div>
		   			  
		   			  <div class="wta_6top_img">
		   			   <div class="wta_3images">
		   			      <img src="<?php echo get_template_directory_uri();?>/images/st.jpg" class="">
		   			   </div>
		   
		   			   <div class="wta_3images">
		   			      <img src="<?php echo get_template_directory_uri();?>/images/st.jpg" class="">
		   			   </div>
		   
		   			   <div class="wta_3images">
		   			      <!-- <img src="<?php echo get_template_directory_uri();?>/images/st.jpg" class="">
		   			      		   			   </div>
		   			      		   			  </div>
		   			      		   			  
		   			      		                </div>
		   			      						
		   			      		              </div>
		   			      					<div class="wta_top_one4">
		   			      						<div class="wta_slider_top_title2"> 
		   			      						 <h3>Categories</h3><br/>
		   			      							<?php wp_get_archives('type=postbypost&limit=10'); ?>
		   			      						</div>
		   			      					 
		   			      				   </div>
		   			      				   
		   			      				  <div class="wta_top_one4">
		   			      				   						<div class="wta_slider_top_title2"> 
		   			      				   						 <h3> Leatest Slider </h3><br/>
		   			      				   							<?php echo do_shortcode('[recent_post_slider]'); ?> 
		   			      				   						</div>
		   			      				   					 
		   			      				   </div>
		   			                      </section> -->
		 </div>
	</div>
</div>
		   
		   

   <div class="gfmw_full_contianer">
		  <section class="wta_content_area12"> 
		  
		        <?php $catquery = new WP_Query( 'cat=23&posts_per_page=6' ); ?>
				  
				<?php while($catquery->have_posts()) : $catquery->the_post(); ?>
				  <div class="singla_slide_item5">
					<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
				   </div>
				  <?php endwhile; ?> 
				<?php wp_reset_postdata(); ?>
		     </section>
			 
   </div>	
<?php get_footer(); ?>
















		<?php while ( have_posts() ): the_post(); ?>
			<article <?php post_class(); ?>>	
				<div class="post-inner group">
					
					<h1 class="post-title"><?php the_title(); ?></h1>
					<p class="post-byline"><?php _e('by','GFMW'); ?> <?php the_author_posts_link(); ?> &middot; <?php the_time(get_option('date_format')); ?>  <?php get_template_part('inc/page-title'); ?></p>
					<?php the_post_thumbnail( 'single-post-thumbnail' ); ?>
					<div class="clear"></div>
					<div class="respon_details"><!--details--> </div>
					<div class="clear"></div>
					
					<div class="entry">	
						<div class="entry-inner">
							<?php the_content(); ?>
							<?php wp_link_pages(array('before'=>'<div class="post-pages">'.__('Pages:','GFMW'),'after'=>'</div>')); ?>
						</div>
						<div class="clear"></div>				
					</div><!--/.entry-->
					
				</div>
				<!--/.post-inner-->	
			</article><!--/.post-->				
		<?php endwhile; ?>








