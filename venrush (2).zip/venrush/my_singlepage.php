<?php 

/*
Template Name: mysingle Page
*/

get_header(); 
?>

<div class="gfmw_full_contianer">
	<div class="gfwm_center blogpost">
		<div class="wt_inner">
		
		  <section class="wta_slider_down_area"> 
		      <div class="wta_tab"> 
			    <div class="tab">
					  <button class="tablinks" onclick="openCity(event, 'London')"><img  src="<?php echo get_template_directory_uri();?>/images/canon/1.png" alt=""></button>
					  <button class="tablinks" onclick="openCity(event, 'Paris')"><img src="<?php echo get_template_directory_uri();?>/images/canon/2.png" alt=""></button>
					  <button class="tablinks" onclick="openCity(event, 'Tokyo')"><img src="<?php echo get_template_directory_uri();?>/images/canon/3.png" alt=""></button>
					</div>

					<div id="London" class="tabcontent">
					  <img src="<?php echo get_template_directory_uri();?>/images/canon/1.png" alt="">
					</div>

					<div id="Paris" class="tabcontent wta_special_active">
					  <img src="<?php echo get_template_directory_uri();?>/images/canon/2.png" alt="">
					</div>

					<div id="Tokyo" class="tabcontent wta_special_active">
					  <img src="<?php echo get_template_directory_uri();?>/images/canon/3.png" alt="">
					</div>
			  </div>
		  
		  </section>
		  <section class="wta_slider_down_sidebar_area"> 
		      <div class="wta_sidebar_top_cont"> 
			       <h5>CARGO SHORTS</h5>
				   <p><del>$35.00</del> $33.00</p>
			  </div>

			  <div class="wta_sidebar_top_cont_2"> 
				   <p>Go sporty this summer with this vintage navy and white striped v-neck t-shirt from the Abercrombie & Fitch. Perfect for pairing with denim and white kicks for a stylish sporty vibe. Will fit a UK 8-10, model shown is a UK 8 and 5'5. !!</p>
			  </div>
			  
			  
			  <div class="wta_sidebar_top_cont_2"> 
			     <h5>ADD TO WISHLIST </h5>
				 <p>SKU: M-05.<br/> Category: Shop Men.<br/> Tags: Clothings, Shirt, Short.</p>
				
			  </div>


			  <div class="woocommerce-tabs panel-group" id="accordion" role="tablist" aria-multiselectable="true"><div class="panel-default"><h4 class="description_tab" role="tab">
<a href="#tab-description" role="button" data-toggle="collapse" data-parent="#accordion" aria-expanded="true" aria-controls="tab-description" class="toggle">Description <span class="plus"><i class="fa fa-plus"></i></span><span class="minus"><i class="fa fa-minus"></i></span></a>

</h4><div class="panel-collapse collapse" role="tabpanel" aria-labelledby="tab-description" id="tab-description"><p>Go sporty this summer with this vintage navy and white striped v-neck t-shirt from the Abercrombie &amp; Fitch.  Perfect for pairing with denim and white kicks for a stylish sporty vibe. Will fit a UK 8-10, model shown is a UK 8 and 5’5. !!</p><ul><li>&ndash; Lightweight, soft-touch jersey</li><li>&ndash; Point collar</li><li>&ndash; Button placket</li><li>&ndash; Chest pocket</li><li>&ndash; Curved hem</li><li>&ndash; Machine wash</li><li>&ndash; 100% Lyocell</li></ul></div></div><div class="panel-default">

<h4 class="additional_information_tab" role="tab">
<a href="#tab-additional_information" role="button" data-toggle="collapse" data-parent="#accordion" aria-expanded="true" aria-controls="tab-additional_information" class="toggle">Additional information <span class="plus"><i class="fa fa-plus"></i></span><span class="minus"><i class="fa fa-minus"></i></span></a>

</h4><div class="panel-collapse collapse" role="tabpanel" aria-labelledby="tab-additional_information" id="tab-additional_information"><table class="shop_attributes"><tbody><tr class=""><th>Colour:&nbsp;</th><td><p>Blue, Brown, Grey, Pink</p></td></tr><tr class="alt"><th>Size:&nbsp;</th><td><p>XS, S, M, L, XL</p></td></tr></tbody></table></div></div><div class="panel-default"><h4 class="reviews_tab" role="tab">

<a href="#tab-reviews" role="button" data-toggle="collapse" data-parent="#accordion" aria-expanded="true" aria-controls="tab-reviews" class="toggle">Reviews (0) <span class="plus"><i class="fa fa-plus"></i></span><span class="minus"><i class="fa fa-minus"></i></span></a></h4><div class="panel-collapse collapse" role="tabpanel" aria-labelledby="tab-reviews" id="tab-reviews"><div id="reviews"><div id="comments"><h2>Reviews</h2><p class="woocommerce-noreviews">There are no reviews yet.</p></div><div id="review_form_wrapper"><div id="review_form"><div id="respond" class="comment-respond"><h3 id="reply-title" class="comment-reply-title">Be the first to review “Sheer Hem T-Shirt” <small><a rel="nofollow" id="cancel-comment-reply-link" href="/look/look-full/product/sheer-hem-t-shirt/#respond" style="display:none;">Cancel reply</a></small></h3><form action="http://magicaltheme.com/look/look-full/wp-comments-post.php" method="post" id="commentform" class="comment-form" novalidate="novalidate"><p class="comment-form-rating"><label for="rating">Your Rating</label><p class="stars"><span><a class="star-1" href="#">1</a><a class="star-2" href="#">2</a><a class="star-3" href="#">3</a><a class="star-4" href="#">4</a><a class="star-5" href="#">5</a></span></p><select name="rating" id="rating" style="display: none;"><option value="">Rate…</option><option value="5">Perfect</option><option value="4">Good</option><option value="3">Average</option><option value="2">Not that bad</option><option value="1">Very Poor</option>
</select></p><p class="comment-form-comment"><label for="comment">Your Review</label><textarea id="comment" name="comment" cols="45" rows="6" aria-required="true"></textarea></p><p class="comment-form-author"><label for="author">Name<span class="required" aria-required="true">*</span></label> <input id="author" name="author" value="" size="30" aria-required="true" type="text"></p><p class="comment-form-email"><label for="email">Email<span class="required" aria-required="true">*</span></label> <input id="email" name="email" value="" size="30" aria-required="true" type="text"></p><p class="form-submit"><input name="submit" id="submit" class="submit" value="Submit" type="submit"> <input name="comment_post_ID" value="456" id="comment_post_ID" type="hidden">
<input name="comment_parent" id="comment_parent" value="0" type="hidden"></p></form></div></div></div><div class="clear"></div></div></div></div></div>

			 

		  </section>
       </div>		
    </div>		
</div>	
<div class="gfmw_full_contianer pagepadding_content_area">
	<div class="gfwm_center blogpost">
		<div class="wt_inner">
		
		  <section class="wta_content_area"> 
			<h3 style="color:#000;text-align:left;" class="wta_content_title1">Demo Products </h3>
				<div class="wta_imag_content13">
				
				 <div class="wta_top_area_one">
				    <div class="wta_new_web_leftside"> 
					   <div class="wta_heading_text"> 
					   <h5><a href="http://localhost/woocommercewebsite/wordpress/home/">Cetagories</a></h5>
					</div>
					</div>
					 <img src="<?php echo get_template_directory_uri();?>/images/canon/1.png" alt="">
					</div> 
					
					<div class="wta_content_crew"> 
					  <p class="wta_crew_content"> Demo Content Demo Content<br/><span><a href="#">Demo Product</a>  <a class="wta_btn_add" href="#">Add to Cart</a> </span></p>
					</div>
			      </div>
				  
				  <div class="wta_imag_content13">
				
				  <div class="wta_top_area_one">
				    <div class="wta_new_web_leftside"> 
					   <div class="wta_heading_text"> 
					   <h5><a href="http://localhost/woocommercewebsite/wordpress/home/">Cetagories</a></h5>
					</div>
					</div>
					   <img src="<?php echo get_template_directory_uri();?>/images/canon/2.png" alt="">
					  
					</div> 
					
					<div class="wta_content_crew"> 
					   <p class="wta_crew_content"> Demo Content Demo Content<br/><span><a href="#">Demo Product</a>  <a class="wta_btn_add" href="#">Add to Cart</a> </span></p>
					</div>
			      </div> 
				  
				  <div class="wta_imag_content13">
				
				  <div class="wta_top_area_one">
				    <div class="wta_new_web_leftside"> 
					   <div class="wta_heading_text"> 
					   <h5><a href="http://localhost/woocommercewebsite/wordpress/home/">Cetagories</a></h5>
					</div>
					</div>
					   <img src="<?php echo get_template_directory_uri();?>/images/canon/3.png" alt="">
					   
					</div> 
					
					<div class="wta_content_crew"> 
					  <p class="wta_crew_content"> Demo Content Demo Content<br/><span><a href="#">Demo Product</a>  <a class="wta_btn_add" href="#">Add to Cart</a> </span></p>
					</div>
			      </div>
				
			
		  </section>  
		  
		  <section class="wta_imag_content11"> 
				<div class="wta_imag_content13">
				
				  <div class="wta_top_area_one">
				    <div class="wta_new_web_leftside"> 
					   <div class="wta_heading_text"> 
					   <h5><a href="http://localhost/woocommercewebsite/wordpress/home/">Cetagories</a></h5>
					</div>
					</div>
					   <img src="<?php echo get_template_directory_uri();?>/images/canon/4.jpg" alt="">
					   
					</div> 
					
					<div class="wta_content_crew"> 
					   <p class="wta_crew_content"> Demo Content Demo Content<br/><span><a href="#">Demo Product</a>  <a class="wta_btn_add" href="#">Add to Cart</a> </span></p>
					</div>
			      </div>
				  
				  <div class="wta_imag_content13">
				
				  <div class="wta_top_area_one">
				    <div class="wta_new_web_leftside"> 
					   <div class="wta_heading_text"> 
					   <h5><a href="http://localhost/woocommercewebsite/wordpress/home/">Cetagories</a></h5>
					</div>
					</div>
					   <img src="<?php echo get_template_directory_uri();?>/images/canon/5.png" alt="">
					  
					</div> 
					
					<div class="wta_content_crew"> 
					  <p class="wta_crew_content"> Demo Content Demo Content<br/><span><a href="#">Demo Product</a>  <a class="wta_btn_add" href="#">Add to Cart</a> </span></p>
					</div>
			      </div> 
				  
				  <div class="wta_imag_content13">
				
				  <div class="wta_top_area_one">
				   <div class="wta_new_web_leftside"> 
					   <div class="wta_heading_text"> 
					   <h5><a href="http://localhost/woocommercewebsite/wordpress/home/">Cetagories</a></h5>
					</div>
					</div>
					   <img src="<?php echo get_template_directory_uri();?>/images/canon/6.jpg" alt="">
					   
					</div> 
					
					<div class="wta_content_crew"> 
					  <p class="wta_crew_content"> Demo Content Demo Content<br/><span><a href="#">Demo Product</a>  <a class="wta_btn_add" href="#">Add to Cart</a> </span></p>
					</div>
			      </div>
				
			
		  </section> 
		
		  
        </div>
     </div>
</div>

<?php get_footer(); ?>