// Avoid `console` errors in browsers that lack a console.
(function() {
    var method;
    var noop = function () {};
    var methods = [
        'assert', 'clear', 'count', 'debug', 'dir', 'dirxml', 'error',
        'exception', 'group', 'groupCollapsed', 'groupEnd', 'info', 'log',
        'markTimeline', 'profile', 'profileEnd', 'table', 'time', 'timeEnd',
        'timeStamp', 'trace', 'warn'
    ];
    var length = methods.length;
    var console = (window.console = window.console || {});

    while (length--) {
        method = methods[length];

        // Only stub undefined methods.
        if (!console[method]) {
            console[method] = noop;
        }
    }
}());

var videoPlayer = document.getElementById('videoPlayer');

		// Auto play, half volume.
		videoPlayer.play()
		videoPlayer.volume = 0.5;

		// Play / pause.
		videoPlayer.addEventListener('click', function () {
			if (videoPlayer.paused == false) {
				videoPlayer.pause();
				videoPlayer.firstChild.nodeValue = 'Play';
			} else {
				videoPlayer.play();
				videoPlayer.firstChild.nodeValue = 'Pause';
			}
		});
		
		JQuery(document).ready(function () {
			 JQuery('.nav li').click(function(e) {

			JQuery('.nav li').removeClass('active');

			var $this = $(this);
			if (!$this.hasClass('active')) {
				$this.addClass('active');
			}
			//e.preventDefault();
		});
	});	
		
		
		
		
		
		