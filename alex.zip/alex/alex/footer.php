<?php
/**
 * The template for displaying the footer
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *1. Please find attached photos for the web. Please use pic #8548 and 8591. 
2. Header -> Moving images -> 3 portion
3. Contact form -> http://awebsiteforlawyers.com/sample27/index.html
4. Add twitter
5. Important Links: home, about, practices areas,

attorneys and resources., Disclaimer, Attorney Advertising, Privacy Policy
6. Logo -> Attorney & Counselor At Law
7. Service Header -> See What We Can Do for You.
 * @package WordPress
 */

?>
 <footer id="footer_area">
		    <div class="footer_top">
			   <div class="container">
			   	<div class="row"> 
				  <?php dynamic_sidebar('footer_widgets'); ?>
			   </div>
			</div>
			</div>
			<div class="footer_down"> 
			     <div class="container">
			   	<div class="row"> 
				   <div class="col-sm-12 col-md-12 col-lg-12">
						<div class="foote_copyright text-center"> 
						   <p>© 2017 Webtady.com - All Rights Reserved.</p>
						</div>
					</div>
			   </div>
			</div>
			</div>
		 </footer><!--End of footer area-->

		<?php wp_footer(); ?>
    </body>
</html>

