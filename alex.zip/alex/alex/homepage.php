<?php
/**
 The template name: home page
 */
 get_header();
?>
      <section id="Learn_mission_area">
		  <div class="container">
		  	<div class="row">
		  
				<div class="col-sm-12 col-md-12 col-lg-12">
					  <div class="learn_title text-center">
						 <h2>Learn What We Can Do For You</h2>
					  </div>
				</div><!--./End of 1st col area--> 
				
				<div class="row"> 
					<?php 
						$ektaveriable = new WP_Query(array(
						  'post_type' => 'mychooiceId_servive',
						  'posts_per_page' => 8
						));
					  ?>
					  <?php while($ektaveriable->have_posts()) : $ektaveriable->the_post(); ?>
						 <div class="col-md-3"> 
						   <div class="learn_one"> 
							  <?php the_post_thumbnail(); ?>
							  <div class="img_text_overlay"> 
								 <h3><a href="<?php the_permalink(); ?>"><?php the_content(); ?></a></h3>
							   </div>
						   </div>
						</div>
					  <?php endwhile;?>
				</div><!--/.End of 1st row-->
		  	</div>
		  </div>
		</section><!--/.End of mission Area--> 

		<section id="lawyer_area"> 
		    <div class="container">
			   <?php 
					$ektaveriable = new WP_Query(array(
					  'post_type' => 'mychooiceId_lawyar',
					  'posts_per_page' => 1
					));
				  ?>
			    <?php while($ektaveriable->have_posts()) : $ektaveriable->the_post(); ?>
    
		    	<div class="row">
		    		<div class="col-sm-7 col-md-7 col-lg-7"> 
					   <div class="lawyer_text"> 
					      <h2><?php the_title(); ?></h2>
						  <h3><?php the_title(); ?></h3>
						   <p><?php the_content(); ?></p>
						   <a href="<?php the_permalink(); ?>">Read More</a>
					   </div>
					</div>
					<div class="col-sm-5 col-md-5 col-lg-5"> 
					   <div class="lawyer_img text-center"> 
					      <?php the_post_thumbnail(); ?>
					   </div>
					</div>
		    	</div>
				  <?php endwhile;?>
		    </div>
		 </section><!--/.End of lawyer Area--> 
		 
		 <section id="Verdicts_area"> 
		    <div class="container">
		    	<div class="row">
		    		<div class="col-sm-6 col-md-6 col-lg-6"> 
					   <div class="Verdicts_text"> 
						  <?php 
							$ektaveriable = new WP_Query(array(
							  'post_type' => 'post',
							  'posts_per_page' => 3
							));
						  ?>
						  
						  <?php while($ektaveriable->have_posts()) : $ektaveriable->the_post(); ?>
							
							<div class="Verdicts_one_text">
							  <h2><?php the_title(); ?></h2>
							   <p class="capital"><span>$15M</span><?php the_content(); ?></p>
							   <p><?php the_content(); ?></p>
						  </div>
						  <?php endwhile;?>
						  
						   <div class="quotes_btn"> 
						      <a href="#">veiw our case results</a>
						   </div>
					   </div>
					</div>
					<div class="col-sm-6 col-md-6 col-lg-6"> 
					   <div class="contact_area"> 
					 <form class="form_area">
						<div class="form-group12 text-center">
						   <h3>fast case review</h3>
						   <h5>Secound title</h5>
						  <input type="text" class="form-control" placeholder="First name">
						  <input type="text" class="form-control" placeholder="Last name">
						  <input type="email" class="form-control" placeholder="E-mail Address">
						  <button type="submit" class="form-cont">Sing up!</button>
						</div>
					  </form>
				  </div>
					</div>
		    	</div>
		    </div>
		 </section>
		<section id="Art_area"> 
		   <div class="container">
		   	 <div class="row">
		   		<div class="col-sm-2 col-md-2 col-lg-2"> 
				  <div class="img_art"> 
				     <img src="<?php echo esc_url(get_template_directory_uri()); ?>/img/1234.png" alt="" />
				  </div>
				</div>
				
				<div class="col-sm-10 col-md-10 col-lg-10"> 
				  <div class="art_text"> 
				     <p>Keep up to date on legal issues affection the Arts, with our monthly newsletter,Art+law</p>
				 <div class="quotes_all"> 
				    <form class="form_area">
						<div class="form-group1">
						  <input type="email" class="" placeholder="E-mail Address">
						  <button type="submit" class="">Sing me up!</button>
						</div>
					  </form>
				 </div>
				  </div>
				</div>
		   	</div>
		   </div>
		</section>
<?php get_footer();?>		