<?php 
 function wp_enqueue_style_register(){ 
  wp_register_style('bootstrap', get_template_directory_uri().'/css/bootstrap.min.css');
  wp_register_style('carousel', get_template_directory_uri().'/css/owl.carousel.css');
  wp_register_style('awesome', get_template_directory_uri().'/css/font-awesome.min.css');
  wp_register_style('cssstyle', get_template_directory_uri().'/style.css');
  wp_register_style('responsive', get_template_directory_uri().'/css/responsive.css');
  
  
  
  
  wp_register_script('bootstrap', get_template_directory_uri().'/js/bootstrap.min.js');
  wp_register_script('carousel', get_template_directory_uri().'/js/owl.carousel.min.js');
  wp_register_script('plugins', get_template_directory_uri().'/js/plugins.js');
  wp_register_script('plugins', get_template_directory_uri().'/js/main.js');
  
  
  wp_enqueue_style('bootstrap');
  wp_enqueue_style('carousel');
  wp_enqueue_style('awesome');
  wp_enqueue_style('cssstyle');
  wp_enqueue_style('responsive');
  
  
  
  
  wp_enqueue_script('jquery');
  wp_enqueue_script('bootstrap');
  wp_enqueue_script('carousel');
  wp_enqueue_script('plugins');
  wp_enqueue_script('main');


 }
 add_action('wp_enqueue_scripts','wp_enqueue_style_register');
 
?>

<?php 

function alexsmithwebsite(){
	
	add_theme_support('title-tag');
	add_theme_support('custom-header',array(
	  'Defult-images' => 'get_template_directory_uri();./img/logo.png'
	));
    add_theme_support('custom-background');
	
	
	add_theme_support('post-thumbnails');
 
   
	 register_nav_menus(
		array(
		  'header-menu' => __( 'Header Menu' ),
		  'extra-menu' => __( 'Extra Menu' )
		 )
	   );
	
	register_post_type('mychooiceId_servive', array(
	   'labels' => array(
		 'name' => 'servic',
		 'add_new_item' => __('Add new servic or other name','sectionservic')
	   ),
	   'public' => true,
	   'supports' => array('thumbnail','editor')
	 ));
		register_post_type('mychooiceId_lawyar', array(
	   'labels' => array(
		 'name' => 'lawyar',
		 'add_new_item' => __('Add new lawyar','sectionservic')
	   ),
	   'public' => true,
	   'supports' => array('title','editor','thumbnail')
	 ));
	 

 
 
 
 
 
 
 
 
 
 
}

add_action('after_setup_theme','alexsmithwebsite');

?>


<?php 

function carousel_defult_fuction(){
	
	add_theme_support('post-thumbnails');
 
   register_post_type('my_slider', array(
   'labels' => array(
	 'name' => 'Carousel Caption',
	 'add_new_item' => 'Add new slider or other name'
   ),
   'public' => true,
   'supports' => array('title', 'thumbnail')
   ));	
	
	
	
	
}

add_action('after_setup_theme','carousel_defult_fuction');

?>





<?php 

function jekononam(){
	register_sidebar(array(
	 'name' => 'left sidebar',
	 'description' => 'This is sidebar posting area',
	 'id' => 'left_side',
	 'before_title' => '<h2>',
	 'after_title' => '</h2>',
	 'before_widget' => '',
	 'after_widget' => ''
	));
	
	register_sidebar(array(
	 'name' => 'right sidebar',
	 'description' => 'This is sidebar posting area',
	 'id' => 'right_side'
	));
	
	
	
	
	 register_sidebar(array(
	 'name' => __('footer widgets', 'language'),
	 'description' => 'This is footer widgets posting area',
	 'id' => 'footer_widgets',
	 'before_widget' => '<div class="col-sm-4 col-md-4 col-lg-4"><div class="foote_menu_left">',
	 'after_widget' => '</div></div></div>',
	 'before_title' => '<h2>',
	 'after_title' => '</h2><div class="img">',
	));
 
	
	
	
	
	
	
	
	
	
	
	
}
 add_action('widgets_init', 'jekononam');

?>

