<?php 
  ob_start();
  session_start();
  if($_SESSION['name'] !='computer'){
    header('location: login.php');
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
	
	<!-- start: Meta -->
	<meta charset="utf-8">
	<title>Product Home Page</title>
	<meta name="description" content="Bootstrap Metro Dashboard">
	<meta name="author" content="Dennis Ji">
	<meta name="keyword" content="Metro, Metro UI, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
	<!-- end: Meta -->
	
	<!-- start: Mobile Specific -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- end: Mobile Specific -->
	
	<!-- start: CSS -->
	<link id="bootstrap-style" href="admin/css/bootstrap.min.css" rel="stylesheet">
	<link href="admin/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link id="base-style" href="admin/css/style.css" rel="stylesheet">
	<link id="base-style-responsive" href="admin/css/style-responsive.css" rel="stylesheet">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&subset=latin,cyrillic-ext,latin-ext' rel='stylesheet' type='text/css'>
	<!-- end: CSS -->
	

	<!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<link id="ie-style" href="css/ie.css" rel="stylesheet">
	<![endif]-->
	
	<!--[if IE 9]>
		<link id="ie9style" href="css/ie9.css" rel="stylesheet">
	<![endif]-->
		
	<!-- start: Favicon -->
	<link rel="shortcut icon" href="../img/favicon.ico">
	<!-- end: Favicon -->
	
		
		
		
</head>

<body>
		<!-- start: Header -->
    <header id="header_area">
    	<div class="container">
    		<div class="row">
    			<div class="col-md-12"> 
                     <h1>hello home page test</h1>
                    					<div class="box-content">
                    <table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>Product Name: </th>
								  <th>Product image</th>
								  <th>Product price</th>
							  </tr>
						  </thead>   
						  <tbody>


						<?php 

						  require('config.php');

						  
						// Attempt select query execution		
						$sql = "SELECT * FROM tbl_product";
						$result = mysqli_query($con, $sql);

						if($result){
						    while($row = mysqli_fetch_array($result)){ ?>
							  <tr>
								<td><?php echo $row['product_name']; ?></td>
								<td><img width="200px" src="uploads/<?php echo $row['product_img']; ?>"></td>
								<td><?php echo $row['product_price']; ?></td>
							</tr>
						<?php	  
						}
					}
						else{
						    echo "ERROR:";
						}

						?>
						  </tbody>
					  </table>            
					</div>
				</div><!--/span-->
    			</div>
    		</div>
    	</div>
    </header>
	
	<footer>

		<p>
			<span style="text-align:left;float:left">&copy; 2018 <a href="http://jiji262.github.io/Bootstrap_Metro_Dashboard/" alt="Bootstrap_Metro_Dashboard">copyright@example.com</a></span>
			
		</p>

	</footer>
	
	<!-- start: JavaScript-->

		<script src="admin/js/jquery-1.9.1.min.js"></script>
	    <script src="admin/js/jquery-migrate-1.0.0.min.js"></script>
		<script src="admin/js/jquery-ui-1.10.0.custom.min.js"></script>
		<script src="admin/js/custom.js"></script>
	<!-- end: JavaScript-->
	
</body>
</html>
