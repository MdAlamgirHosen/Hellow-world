<?php 
  ob_start();
  session_start();
  if($_SESSION['name']!='computer'){
    header('location: ../login.php');
  }
?>
<?php
require('config.php');

try{

$id = $_SESSION['cat_id'];
unset($_SESSION['cat_id']);

if(isset($_POST['sub_submit'])){
 


    //for category update work
   $category_name = $_POST['category_name'];
   $category_desc = $_POST['category_desc'];
   $sub_cat_select = $_POST['sub_cat_select'];

   $cat_update = "UPDATE tbl_categorys SET 
   cat_name = '".$category_name."',
   cat_parent = '".$sub_cat_select."',  
   cat_desc = '".$category_desc."' WHERE cat_id = '$id'";
     
    if($conn->exec($cat_update)){
       header('location: manage_category.php');
    }
    else{
      echo "Error";
    }
    
  }
}
catch(Exception $e)
    {
    echo "Error" . $e->getMessage();
    }

?>	