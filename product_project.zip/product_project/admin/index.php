<?php 
  ob_start();
  session_start();
  if($_SESSION['name'] !='computer'){
    header('location: login.php');
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
	
	<!-- start: Meta -->
	<meta charset="utf-8">
	<title>Product Home Page</title>
	<meta name="description" content="Bootstrap Metro Dashboard">
	<meta name="author" content="Dennis Ji">
	<meta name="keyword" content="Metro, Metro UI, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
	<!-- end: Meta -->
	
	<!-- start: Mobile Specific -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- end: Mobile Specific -->
	
	<!-- start: CSS -->
	<link id="bootstrap-style" href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
	<link id="base-style" href="css/jquery-ui.css" rel="stylesheet">
	<link id="base-style" href="css/style.css" rel="stylesheet">
	<link id="base-style-responsive" href="css/style-responsive.css" rel="stylesheet">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&subset=latin,cyrillic-ext,latin-ext' rel='stylesheet' type='text/css'>
	 <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
	<!-- end: CSS -->
	

	<!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<link id="ie-style" href="css/ie.css" rel="stylesheet">
	<![endif]-->
	
	<!--[if IE 9]>
		<link id="ie9style" href="css/ie9.css" rel="stylesheet">
	<![endif]-->
		
	<!-- start: Favicon -->
	<link rel="shortcut icon" href="../img/favicon.ico">
	<!-- end: Favicon -->
	
</head>

<body>
		<!-- start: Header -->
    <header id="header_area">
    	<div class="container">
    		<div class="row">
    			
    			 <h1>home page content</h1>
    			 <form action="" method="post">
                 <div class="search_main">
                 	<input id="myInput" type="text" placeholder="Search..">
                 </div>
				</form>
				<div class="main_fiter_area">
			            <div class="filter_left_area"> 
			            <div class="filter_title"> 
                           <h2>Filter Categorys</h2>
					   </div>                   
							<div class="list-group">
							    
			                    <div id="price_range"></div>

			                     </div>    
			                     <div class="list-group">
								 
			                    <div style="height: 180px; overflow-y: auto; overflow-x: hidden;">
									<?php
									 require('config.php');
				                    $query = "SELECT DISTINCT(product_name) FROM tbl_product WHERE product_status = '0' ORDER BY product_id DESC";
				                    $statement = $conn->prepare($query);
				                    $statement->execute();
				                    $result = $statement->fetchAll();
				                    foreach($result as $row)
				                    {
				                    ?>
				                    <div class="list-group-item checkbox">
				                        <label><input type="checkbox" class="common_selector brand" value="<?php echo $row['product_name']; ?>"  > <?php echo $row['product_name']; ?></label>
				                    </div>
				                    <?php
				                    }

				                    ?>
				                    </div>
			                </div>

			            </div>

			            <div class="right_area">
			                <div class="filter_data">

			                </div>
			            </div>
				</div>
				<div id="product_area">
    				<div class="sidebar"> 
    					<h2>Product Categorys</h2>
    					   <ul class="category_area">
    						<?php 
						  	    require('config.php');

								$stmt = $conn->prepare("SELECT * FROM tbl_categorys WHERE cat_parent= 0");
						        $stmt->execute();
						        if($stmt->rowCount() > 0)
						        $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);

						 	  if($result){
							    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){ ?>
							    	<li class="main_cat"><span class="maincat"><?php echo $row['cat_name']; ?></span>
							    		   <ul class="sub_category_area">
							    				<?php 
						  	   					 require('config.php');
										  	    $substmt = $conn->prepare("SELECT * FROM tbl_categorys WHERE cat_parent = ".$row['cat_id']."");
										        $substmt->execute();
										        if($substmt->rowCount() > 0)
										        	$result = $substmt->setFetchMode(PDO::FETCH_ASSOC);
										        if($result){
							  					  while($sub = $substmt->fetch(PDO::FETCH_ASSOC)){ ?>
							  					  	<li class="sub_list"><a href="show_cat.php?id=<?php echo $row['cat_id']; ?>"><?php echo $sub['cat_name']; ?></a></li>
										        <?php }
										   		 } 
										    ?>
								    	</ul>
							    	</li>
							    <?php
							      }
							    }
							  ?>

						</ul>	  
    				</div>
    			<div class="mani_area">
					<?php 
                       require('config.php');
                      
						// Attempt select query execution		
					    $stmt = $conn->prepare("SELECT * FROM tbl_product LIMIT 6");
					    $stmt->execute(array());


					    if($stmt->rowCount() > 0)
					    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);

					 	if($result){
						    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){ ?>
						    	<div class="one_box"> 
						    		<table>
						    		 <tbody id="myTable">
    								 <tr>
    								 	<td><img src="<?php echo $row['product_img']; ?>">
    								 	<h4>Price: <?php echo $row['product_price']; ?></h4>
    								 	<h2><?php echo $row['product_name']; ?></h2>
    								 	<p>
    								 	<?php
	    								 	$string = $row['product_desc']; 
	    								 	$abc = substr($string, 0, 60);
	    								 	echo $abc;
    								 	 ?>
    								 	</p>
    								   </td>
    								 </tr>
    								</tbody>
    								</table>
						    	</div>
						   <?php }
						}
						else{
						    echo "ERROR:";
						}

						?>
    		   </div>

    		  </div><!--end of product area--> 
    	   </div>
    	</div>
    </header>

	<footer>

		<p>
			<span style="text-align:left;float:left">&copy; 2018 <a href="http://jiji262.github.io/Bootstrap_Metro_Dashboard/" alt="Bootstrap_Metro_Dashboard">copyright@example.com</a></span>
			
		</p>

	</footer>
	
	<!-- start: JavaScript-->

		<script src="js/jquery-1.9.1.min.js"></script>
	    <script src="js/jquery-migrate-1.0.0.min.js"></script>
		<script src="js/jquery-ui-1.10.0.custom.min.js"></script>
		<script src="js/custom.js"></script>
		<script src="js/jquery-ui.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<style>
#loading
{
	text-align:center; 
	background: url('loader.gif') no-repeat center; 
	height: 150px;
}
</style>

<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<script type="text/javascript">

$(document).ready(function(){
    filter_data();

    function filter_data()
    {
        $('.filter_data').html('<div id="loading" style="" ></div>');
        var action = 'fetch_data';
        var minimum_price = $('#hidden_minimum_price').val();
        var maximum_price = $('#hidden_maximum_price').val();
        var brand = get_filter('brand');
        var ram = get_filter('ram');
        var storage = get_filter('storage');
        $.ajax({
            url:"fetch_data.php",
            method:"POST",
            data:{action:action, minimum_price:minimum_price, maximum_price:maximum_price, brand:brand, ram:ram, storage:storage},
            success:function(data){
                $('.filter_data').html(data);
            }
        });
    }

    function get_filter(class_name)
    {
        var filter = [];
        $('.'+class_name+':checked').each(function(){
            filter.push($(this).val());
        });
        return filter;
    }

    $('.common_selector').click(function(){
        filter_data();
    });

    $('#price_range').slider({
        range:true,
        min:1000,
        max:65000,
        values:[1000, 65000],
        step:500,
        stop:function(event, ui)
        {
            $('#price_show').html(ui.values[0] + ' - ' + ui.values[1]);
            $('#hidden_minimum_price').val(ui.values[0]);
            $('#hidden_maximum_price').val(ui.values[1]);
            filter_data();
        }
    });

});
</script>


<!-- <script>
$( ".main_cat" ).click(function() {
  $( ".sub_category_area" ).toggle();
});
</script> -->

</body>
</html>
