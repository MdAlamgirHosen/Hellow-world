<?php 
  ob_start();
  session_start();
  if($_SESSION['name']!='computer'){
    header('location: ../login.php');
  }
?>
<?php
require('config.php');

try{
$id = $_SESSION['product_id'];

if(isset($_POST['submit'])){

// File upload path
// file upload imageresize
    move_uploaded_file($_FILES['file']['tmp_name'], 'uploads/'.$_FILES['file']['name']);
    $orgfile = 'uploads/'.$_FILES['file']['name'];
    list($width,$height)= getimagesize($orgfile);
    $newfile = imagecreatefromjpeg($orgfile);
    $newwidth = "300";
    $newheight = "200";
    $thum ='uploads/'.$_FILES['file']['name'];
    $truecolor = imagecreatetruecolor($newwidth, $newheight);
    imagecopyresampled($truecolor, $newfile, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
    imagejpeg($truecolor,$thum,100);



    if (isset($_FILES['file']['name']) && !empty($_FILES['file']['name'])) {
     $img_sql = "UPDATE tbl_product SET product_img='$thum' WHERE product_id = '$id'";
     $conn->exec($img_sql);
     }

   //for product update work

   $product_name = $_POST['product_name'];
   $product_price = $_POST['product_price'];
   $product_quantity = $_POST['product_quantity'];
   $product_desc = $_POST['product_desc'];
   $cat_select = $_POST['cat_select'];

   $update = "UPDATE tbl_product SET 
   product_name = '".$product_name."',
   product_price = '".$product_price."',
   product_quantity = '".$product_quantity."', 
   product_cat = '".$cat_select."', 
   product_desc = '".$product_desc."' 
   where product_id = '$id'";

          

    if($conn->exec($update)){
       header('location: manage_product.php');
    }
    else{
      echo "Error";
    }
    
  }
}
catch(Exception $e)
    {
    echo "Error" . $e->getMessage();
    }

?>	