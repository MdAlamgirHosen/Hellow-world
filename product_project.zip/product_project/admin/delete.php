<?php 
require('config.php');
 // delete dat

if(isset($_REQUEST['id'])) {
	$id = $_REQUEST['id'];
	
	$query=$conn->prepare("DELETE FROM tbl_product WHERE product_id= '".$id."'");
	$query->execute();
		

	if($query){
       header('location: manage_product.php');
	}
	else{
      echo'Error';
	}	
	
}
else {
	 echo "Error";
}	


if(isset($_REQUEST['c_id'])) {
	$id = $_REQUEST['c_id'];

		
	$cat_query=$conn->prepare("DELETE FROM tbl_categorys WHERE cat_id= '".$id."'");
	$cat_query->execute();

	if($cat_query){
       header('location: manage_category.php');
	}
	else{
      echo'Error';
	}	
	
}
else {
	 echo "Error";
}


if(isset($_REQUEST['c_id'])) {
	$id = $_REQUEST['c_id'];

		
	$cat_query=$conn->prepare("DELETE FROM tbl_categorys WHERE cat_id= '".$id."'");
	$cat_query->execute();

	if($cat_query){
       header('location: manage_category.php');
	}
	else{
      echo'Error';
	}	
	
}
else {
	 echo "Error";
}

?>		