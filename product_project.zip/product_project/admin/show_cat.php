<?php 
  ob_start();
  session_start();
  if($_SESSION['name']!='computer'){
    header('location: ../login.php');
  }
?>
<?php
//fetch_data.php

require('config.php');

$abc = $_GET['show_cat'];

if(isset($_GET["show_cat"]))
{
$query = "SELECT * FROM tbl_product WHERE product_status = '0' ORDER BY product_id DESC";
$statement = $conn->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
foreach($result as $row)
{
?>
<div class="list-group-item checkbox">
    <img src="<?php echo $row['product_img']; ?>">
    <h4>Price: <?php echo $row['product_price']; ?></h4>
    <h2><?php echo $row['product_name']; ?></h2>
    <p>
    <?php
      $string = $row['product_desc']; 
      $abc = substr($string, 0, 60);
      echo $abc;
     ?>
    </p>
</div>
<?php
}


}
?>