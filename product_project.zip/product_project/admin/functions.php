
<?php 
  ob_start();
  session_start();
  if($_SESSION['name']!='computer'){
    header('location: ../login.php');
  }
?>


<?php
require('config.php');

try {


if(isset($_POST['submit_p'])){

// file upload imageresize
    move_uploaded_file($_FILES['file']['tmp_name'], 'uploads/'.$_FILES['file']['name']);
    $orgfile = 'uploads/'.$_FILES['file']['name'];
    list($width,$height)= getimagesize($orgfile);
    $newfile = imagecreatefromjpeg($orgfile);
    $newwidth = "300";
    $newheight = "200";
    $thum ='uploads/'.$_FILES['file']['name'];
    $truecolor = imagecreatetruecolor($newwidth, $newheight);
    imagecopyresampled($truecolor, $newfile, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
    imagejpeg($truecolor,$thum,100);
     
     //for time set
        $temp = explode(".", $_FILES["file"]["name"]);
        $file_name=$temp[0]. '_'.time();
        $file_ext=$temp[1];
        $img=$file_name . '.' . $file_ext;

      // for product insertion
     $product_name = $_POST['product_name'];
     $product_price = $_POST['product_price'];
     $product_quantity = $_POST['product_quantity'];
     $product_desc = $_POST['product_desc'];
     $product_cat = $_POST['cat_select'];

    $sql = "INSERT INTO tbl_product (product_name, product_img, product_price, product_quantity, product_desc,product_cat)
    VALUES (
             '".$product_name."',
             '".$thum."',
             '".$product_price."',
             '".$product_quantity."',
             '".$product_desc."',
             '".$cat_select."')";

    // use exec() because no results are returned
    if($conn->exec($sql)){
     header('location: manage_product.php');
    }
    else{
       echo "Error";
     } 
    }


if(isset($_POST['sub_cat_submit'])){
  
   // for category insertion
     $category_name = $_POST['category_name'];
     $category_desc = $_POST['category_desc'];
     $sub_cat_select = $_POST['sub_cat_select'];

    

   
    $sub_cat_insert = "INSERT INTO tbl_categorys (cat_name, cat_desc, cat_parent)
    VALUES (
             '".$category_name."',
             '".$category_desc."',
             '".$sub_cat_select."')";
    
    // use exec() because no results are returned
    if($conn->exec($sub_cat_insert)){
     header('location: manage_category.php');
    }
    else{
      echo "Error";
     } 
    }

if(isset($_POST['submit'])){
   // for category insertion
     $category_name = $_POST['category_name'];
     $category_desc = $_POST['category_desc'];

    $cat_insert = "INSERT INTO tbl_categorys (cat_name, cat_desc)
    VALUES (
             '".$category_name."',
             '".$category_desc."')";

    // use exec() because no results are returned
    if($conn->exec($cat_insert)){
     header('location: manage_category.php');
    }
    else{
      echo "Error";
     } 
    }

}
catch(Exception $e)
    {
    echo "<br>" . $e->getMessage();
    }

?>